require("dotenv").config();
const config = require('./src/config/config');
const express = require("express");
const cors = require("cors");
const path = require('path');
const db = require('./src/config/db'); // MySQL pool is initialized

const app = express();

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use(cors());

// Security headers
app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self';");
  next();
});

// Health check route
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// Static file serving
app.use('/static', express.static(path.join(config.workspace)));

// API routes
const api_version_number = config.api_version_number;
app.use(`/${api_version_number}/api/auth`, require("./src/routes/auth_routes"));
app.use(`/${api_version_number}/api/cms`, require("./src/routes/cms_routes"));
app.use(`/${api_version_number}/api/common`, require("./src/routes/common_routes"));
app.use(`/${api_version_number}/api/queries`, require("./src/routes/queries_routes"));

// 404 handler (must be last)
app.use((req, res, next) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
const PORT = config.port || 8080;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
