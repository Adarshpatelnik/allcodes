require("dotenv").config();

module.exports = {
        // DB config start
        host: process.env.DB_HOST,
        db_user: process.env.DB_USER,
        db_pass: process.env.DB_PASS,
        db_name: process.env.DB_NAME,
        // DB config end

        // Common config start
        port : process.env.PORT,
        node_env : process.env.NODE_ENV,
        api_version_number : process.env.API_VERSION_NUMBER,
        asset_folder : process.env.ASSETS_FOLDER,
        asset_folder_blog : process.env.ASSETS_FOLDER_BLOG,
        workspace : process.env.WORKSPACE,
        // Common config end

        //mail start
        admin_mail_id : process.env.ADMIN_MAIL_ID,
        smtp_mail : process.env.SMTP_MAIL,
        smtp_password : process.env.SMPT_PASSWORD,
        //mail end

        // JWT config start
        jwt_secret : process.env.JWT_SECRET,
        jwt_expiration : process.env.JWT_EXPIRATION,
        // JWT config end

        // Forget password start
        baseUrl : process.env.BASE_URL,
        frontendUrl : process.env.FRONTEND_URL       
        // Forget password end
}