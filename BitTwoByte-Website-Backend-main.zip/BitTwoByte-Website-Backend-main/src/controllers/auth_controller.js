const auth_model = require("../models/auth_model");
const logger = require('../config/logger');
const messages = require('../utils/messages');
const { validationResult } = require('express-validator');


// Admin Side Start
exports.admin_register = async (req, res) => {
    try {
        const { mail_id, password, name } = req.body;
        const result = await auth_model.admin_register(name, mail_id, password);
        
        if (result.success) {
            return res.status(200).json({ data: result.data });
        } else {
            return res.status(404).json({ data: result.data });
        }
    } catch (error) {
        logger.error(`Controller - admin register - Error: ${error.message}`);
        return res.status(500).json({ error: messages.internal_server_error });
    }
};

exports.admin_login = async (req, res) => {
    try {
        const result = await auth_model.admin_login(req.body);
        
        if (result.success) {
            return res.status(200).json(result);
        } else {
            return res.status(401).json(result);
        }
    } catch (error) {
        logger.error(`Controller - admin login - Error: ${error.message}`);
        
        if (error.message === 'InvalidCredentials') {
            return res.status(401).json({ error: 'Invalid credentials. Please try again.' });
        }
        return res.status(500).json({ error: messages.internal_server_error });
    }
};


exports.change_password = async (req, res) => {
    const { user_id, old_password, new_password } = req.body;

    if (!user_id || !old_password || !new_password) {
        return res.status(400).json({ success: false, data: messages.need_required_fields });
    }
    if (new_password.length < 6) {
        return res.status(400).json({ success: false, data: messages.password_warning });
    }
    const result = await auth_model.change_password(user_id, old_password, new_password);

    if (result.success) {
        return res.status(200).json(result.data);
    } else {
        return res.status(400).json(result.data);
    }
};

// Admin Side End

// Forgot password start

exports.forgetPasswordSendMail = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const { mailID } = req.body;
    try {
      const result = await auth_model.sendPasswordResetEmail(mailID);
      if (!result.success) {
        return res.status(404).json({ error: result.message });
      }
      return res.status(200).json({ message: result.message,token:result.token });
    } catch (error) {
      logger.error(`Error resetting password: ${error.message}`);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  exports.reset_password = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { token, newPassword, confirmpassword } = req.body;

    if (newPassword !== confirmpassword) {
        return res.status(400).json({ error: 'Passwords do not match' });
    }

    try {
        const result = await auth_model.reset_password(token, newPassword);
        res.status(200).json(result); 
    } catch (error) {
        logger.error(`Error resetting password: ${error.message}`);

        if (error.message === 'Invalid or expired token') {
            return res.status(400).json({ error: 'Invalid or expired token' });
        } else if (error.message === 'Token has expired') {
            return res.status(400).json({ error: 'Token has expired' });
        } else if (error.message === 'User not found') {
            return res.status(404).json({ error: 'User not found' });
        }

        res.status(500).json({ error: 'Internal Server Error' });
    }
};

// Forgot password end
