const cms_model = require("../models/cms_model");
const logger = require('../config/logger');
const path = require('path');
const fs = require('fs');
const messages = require('../utils/messages');
const config = require('../config/config');

exports.insert_single_image_section = async (req, res) => {
    try {
        const { contents, parent_id } = req.body;
        const { section_name, page_name } = req.params; 
        const image = req.file;
        const timestamp = Date.now();

        let assets_folder = path.join(__dirname, config.asset_folder, section_name);
        if (parent_id && page_name === "case_study") {
            assets_folder = path.join(__dirname, config.asset_folder, `${section_name}${parent_id}`);
        }

        if (!fs.existsSync(assets_folder)) {
            fs.mkdirSync(assets_folder, { recursive: true });
        }

        let image_path = 'None';
        if (image) {
            const section_image_name = `${section_name}_${timestamp}${path.extname(image.originalname)}`;
            const section_image_path = path.join(assets_folder, section_image_name);

            fs.writeFileSync(section_image_path, image.buffer);
            if(parent_id && page_name === "case_study"){
                image_path = `static/${section_name}${parent_id}/${section_image_name}`;

            }else{
                image_path = `static/${section_name}/${section_image_name}`;
            }

            const files_in_folder = fs.readdirSync(assets_folder);
            const old_section_image = files_in_folder.find(file => file.startsWith(`${section_name}_`) && file !== section_image_name);
            if (old_section_image) {
                fs.unlinkSync(path.join(assets_folder, old_section_image));
            }
        }

        const result = await cms_model.insert_single_image_section(section_name, contents, image_path, page_name, parent_id);
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Error updating: ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
};

exports.get_single_image_section = async (req, res) => {
    try {
        const section_name = req.params.section_name;
        const page_name = req.params.page_name;
        const result = await cms_model.get_single_image_section(section_name, page_name);
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - insert page - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.insert_page = async (req, res) => {
    try {
        const { page_name, label } = req.body;
        const result = await cms_model.insert_page(page_name, label);
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - insert page - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}


exports.insert_section = async (req, res) => {
    try {
        const { section_name, page_name } = req.body;
        const result = await cms_model.insert_section(section_name, page_name);
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - insert section - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.get_page_section_details = async (req, res) => {
    try {
        const result = await cms_model.get_page_section_details();
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - page section details get - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.insert_multiple = async (req, res) => {
    try {
        const { status, description, technology_id } = req.body;
        const section_name = req.params.section_name;
        const page_name = req.params.page_name;

        const image = req.file;
        let image_path_url = null;

        if (image) {
            const timestamp = Date.now();
            const image_name = `${section_name}_${timestamp}${path.extname(image.originalname)}`;

            const assets_folder = path.join(__dirname, config.asset_folder, section_name);
            image_path_url = `static/${section_name}/${image_name}`;

            if (!fs.existsSync(assets_folder)) {
                fs.mkdirSync(assets_folder, { recursive: true });
            }
            const image_path = path.join(assets_folder, image_name);
            fs.writeFileSync(image_path, image.buffer);
        } else {
            image_path_url = image_path_url;
        }
        const result = await cms_model.insert_multiple(description, status, image_path_url, section_name, page_name, technology_id);
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: messages.insert_success });
    } catch (error) {
        logger.error(`Controller - insert multiple images - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.update_multiple = async (req, res) => {
    try {
        const { id, description, status } = req.body;
        const section_name = req.params.section_name;
        const page_name = req.params.page_name;
        const image = req.file;

        let new_image_url = null;

        const old_image_url = await cms_model.get_image_url(id, section_name);
        if (old_image_url) {
            new_image_url = old_image_url;
        }

        if (image) {
            const section_dir = path.join(__dirname, config.asset_folder, section_name);

            if (!fs.existsSync(section_dir)) {
                fs.mkdirSync(section_dir, { recursive: true });
            }

            const new_file_name = `${section_name}_${Date.now()}${path.extname(image.originalname)}`;
            const new_image_path = path.join(section_dir, new_file_name);

            fs.writeFileSync(new_image_path, image.buffer);
            new_image_url = `static/${section_name}/${new_file_name}`;

            if (old_image_url) {
                const old_image_path = path.join(section_dir, path.basename(old_image_url));
                if (fs.existsSync(old_image_path)) {
                    try {
                        fs.unlinkSync(old_image_path);
                    } catch (err) {
                        logger.error(`Controller - Unable to delete old image - Error: ${err.message}`);
                    }
                }
            }
        }

        const result = await cms_model.update_multiple(id, section_name, new_image_url, description, status, page_name);

        if (result.success) {
            return res.status(200).json({ success: true, data: result.data });
        } else {
            logger.error(`Controller - Update Image DB - Error: ${result.data}`);
            return res.status(500).json({ success: false, data: messages.update_failed });
        }

    } catch (error) {
        logger.error(`Controller - Update multiple images - Error: ${error.message}`);
        return res.status(500).json({ success: false, data: messages.internal_server_error });
    }
};

exports.get_multiple = async (req, res) => {
    try {
        const section_name = req.params.section_name;
        const page_name = req.params.page_name;
        const result = await cms_model.get_multiple(section_name, page_name);
        if (result.success) {
            return res.status(200).json({ data : result.data });

        }else{
            return res.status(404).json({ data : result.data });
        }
    } catch (error) {
        logger.error(`Controller - get multiple images - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.delete_multiple = async (req, res) => {
    try {
        const { id } = req.body;
        const { page_name, section_name } = req.params;

        if(page_name === "case_study"){
            const image_urls = await cms_model.get_all_images_by_parent(id, section_name);

            if (image_urls.length > 0) {
                for (const image_url of image_urls) {
        
                    if (image_url) {
                       const relative_path = image_url.split('static/')[1];
                       if (!relative_path) continue;
                       const section_name = relative_path.split('/')[0]; 
                       const image_path = path.join(__dirname, config.asset_folder, section_name, path.basename(image_url));
                       try {
                           if (fs.existsSync(image_path)) {
                               fs.unlinkSync(image_path); 
                            //    logger.info(`Deleted image: ${image_path}`);
                           }
                            const folder_path = path.join(__dirname, config.asset_folder, section_name);
                            if (fs.existsSync(folder_path) && fs.readdirSync(folder_path).length === 0) {
                                fs.rmSync(folder_path, { recursive: true, force: true });
                                // logger.info(`Deleted folder: ${folder_path}`);
                            }
                       } catch (err) {
                           logger.error(`Controller - Error deleting image: ${image_path} - ${err.message}`);
                       }
                    }
                }
            }
        }
        
        const old_image_url = await cms_model.get_image_url(id, section_name);
        if (old_image_url) {
            const old_image_path = path.join(__dirname, config.asset_folder, section_name, path.basename(old_image_url));

            try {
                if (fs.existsSync(old_image_path)) {
                    fs.unlinkSync(old_image_path);
                }
            } catch (err) {
                logger.error(`Controller - Unable to delete old image - Error: ${err.message}`);
            }
        }

        const result = await cms_model.delete_multiple(id, page_name, section_name);
        if (!result || !result.success) {
            return res.status(404).json({ success: false, data: result.data });
        }
        return res.status(200).json({ success: true, data: result.data });

    } catch (error) {
        logger.error(`Controller - Delete Multiple - Error: ${error.message}`);
        return res.status(500).json({ success: false, message: "Internal Server Error" });
    }
};

exports.get_page_details = async (req, res) => {
    try {
        const page_name = req.params.page_name;
        const access = req.params.access;

        const result = await cms_model.get_page_details(page_name, access);
        if (result.success) {
            return res.status(200).json(result.data);

        }else{
            return res.status(404).json(result.data );
        }
    } catch (error) {
        logger.error(`Controller - get page details - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.insert_multiple_in_single_request = async (req, res) => {
    try {
        const { section_name, page_name } = req.params;
        const images = req.files || []; 
        const contents = req.body.contents;

        // if (!images.length) {
        //     return res.status(400).json({ data: messages.image_not_found });
        // }

        const assets_folder = path.join(__dirname, config.asset_folder, section_name);

        if (!fs.existsSync(assets_folder)) {
            fs.mkdirSync(assets_folder, { recursive: true });
        }

        const image_paths = {};

        for (const file of images) {
            const image_key = file.fieldname; 
            const original_extension = path.extname(file.originalname);
            const timestamp = Date.now();
            const new_image_name = `${image_key}_${timestamp}${original_extension}`;
            const new_image_path = path.join(assets_folder, new_image_name);

            fs.writeFileSync(new_image_path, file.buffer);
            image_paths[image_key] = `static/${section_name}/${new_image_name}`;

            const existing_files = fs.readdirSync(assets_folder);
            const old_image = existing_files.find(
                (filename) =>
                    filename.startsWith(`${image_key}_`) && filename !== new_image_name
            );

            if (old_image) {
                const old_image_path = path.join(assets_folder, old_image);
                fs.unlinkSync(old_image_path);
            }
        }

        const result = await cms_model.insert_multiple_in_single_request(
            section_name,
            contents,
            image_paths,
            page_name
        );

        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }

        return res.status(200).json({ data: result.data });

    } catch (error) {
        logger.error(`Controller - Insert multiple images in a single request - Error: ${error.stack}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
};

exports.get_case_study = async (req, res) => {
    try{
        const parent_id = req.params.parent_id; 
        const result = await cms_model.get_case_study(parent_id);
        if (result.success) {
            return res.status(200).json(result.data);

        }else{
            return res.status(404).json(result.data );
        }
    }catch(error){
        logger.error(`Controller - get case study deatils - Error: ${error.stack}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.get_case_study_user = async (req, res) => {
    try{
        const result = await cms_model.get_case_study_user();
        if (result.success) {
            return res.status(200).json(result.data);

        }else{
            return res.status(404).json(result.data);
        }
    }catch(error){
        logger.error(`Controller - get case study deatils - Error: ${error.stack}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}
