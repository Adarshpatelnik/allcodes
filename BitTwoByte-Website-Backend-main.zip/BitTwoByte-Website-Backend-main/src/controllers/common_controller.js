const common_model = require("../models/common_model");
const logger = require('../config/logger');
const messages = require('../utils/messages');
const path = require('path');
const config = require("../config/config"); 
const fs = require('fs');
const crypto = require('crypto');

const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: "smtp-mail.outlook.com",
    port: 587,
    secure: false, // use TLS
    auth: {
        user: config.smtp_mail,
        pass: config.smtp_password
    }
});



const ALGORITHM = 'aes-256-cbc';
const SECRET_KEY = crypto.createHash('sha256').update('your-password-here').digest(); // 32-byte key

// Encrypt function
function encryptEmail(email) {
    const iv = crypto.randomBytes(16); // 16 bytes for AES
    const cipher = crypto.createCipheriv(ALGORITHM, SECRET_KEY, iv);
    let encrypted = cipher.update(email, 'utf8');
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return `${iv.toString('hex')}:${encrypted.toString('hex')}`;
}

function generateEmailHTML(email) {
    const encrypted = encryptEmail(email);
    const unsubscribeUrl = `${config.frontendUrl}?data=${encodeURIComponent(encrypted)}`;

    return `
        <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 30px;">
            <div style="
                max-width: 600px;
                margin: auto;
                background: #fff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                padding: 30px;
            ">
                <h2 style="color: #2c3e50;">Welcome!</h2>
                <p style="color: #333; font-size: 16px;">
                    Thank you for subscribing. We're glad to have you on board!
                </p>
                <p style="color: #333; font-size: 16px;">
                    You'll now receive updates and news directly in your inbox.
                </p>
                <p style="color: #999; font-size: 13px; margin-top: 40px;">
                    If you no longer wish to receive emails from us, you can
                    <a href="${unsubscribeUrl}" style="color: #2980b9; text-decoration: none;">unsubscribe here</a>.
                </p>
            </div>
        </div>
    `;
}

async function sendSubscriptionMail(toEmail) {
    const htmlContent = generateEmailHTML(toEmail);

    const mailOptions = {
        from: `"BitTwoByte" <${config.smtp_mail}>`,
        to: toEmail,
        subject: "Thanks for Subscribing!",
        html: htmlContent
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Mail sent:', info.messageId);
        return { success: true, message: "Mail sent successfully" };
    } catch (error) {
        console.error('Error sending mail:', error.message);
        return { success: false, message: error.message };
    }
}


function generateJoinCommunityHTML(email) {
    const encrypted = encryptEmail(email);
    const unsubscribeUrl = `${config.frontendUrl}?token=${encodeURIComponent(encrypted)}`;

    return `
        <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 30px;">
            <div style="
                max-width: 600px;
                margin: auto;
                background: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                padding: 30px;
            ">
                <h2 style="color: #2c3e50;">Welcome to Our Community!</h2>
                <p style="color: #333; font-size: 16px;">
                    We're thrilled to have you join us.
                </p>
                <p style="color: #333; font-size: 16px;">
                    You'll now stay updated with our latest news and events.
                </p>
                <p style="color: #999; font-size: 13px; margin-top: 40px;">
                    If you ever wish to leave, you can 
                    <a href="${unsubscribeUrl}" style="color: #2980b9; text-decoration: none;">leave community here</a>.
                </p>
            </div>
        </div>
    `;
}


async function sendJoinCommunityMail(toEmail) {
    const htmlContent = generateJoinCommunityHTML(toEmail);

    const mailOptions = {
        from: `"BitTwoByte" <${config.smtp_mail}>`,
        to: toEmail,
        subject: "Thanks for Joining Our Community!",
        html: htmlContent
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Join community mail sent:', info.messageId);
        return { success: true, message: "Mail sent successfully" };
    } catch (error) {
        console.error('Error sending join community mail:', error.message);
        return { success: false, message: error.message };
    }
}

function decryptEmail(encryptedDataFromUrl) {
    try {
        if (!encryptedDataFromUrl || typeof encryptedDataFromUrl !== 'string') {
            throw new Error('Missing encrypted data');
        }

        const decodedData = decodeURIComponent(encryptedDataFromUrl);
        const [ivHex, encryptedHex] = decodedData.split(':');

        if (!ivHex || !encryptedHex) {
            throw new Error('Encrypted data is not properly formatted');
        }

        const iv = Buffer.from(ivHex, 'hex');
        const encryptedText = Buffer.from(encryptedHex, 'hex');

        if (iv.length !== 16) {
            throw new Error(`Invalid IV length: expected 16 bytes, got ${iv.length}`);
        }

        const decipher = crypto.createDecipheriv(ALGORITHM, SECRET_KEY, iv);
        let decrypted = decipher.update(encryptedText);
        decrypted = Buffer.concat([decrypted, decipher.final()]);

        return decrypted.toString('utf8');
    } catch (err) {
        console.error('Decryption error:', err.message);
        return null;
    }
}

function generateLeaveCommunityHTML(email) {
    const siteLink = config.frontendUrl;

    return `
        <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 30px;">
            <div style="
                max-width: 600px;
                margin: auto;
                background: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                padding: 30px;
            ">
                <h2 style="color: #c0392b;">You've Left the Community</h2>
                <p style="color: #333; font-size: 16px;">
                    We're sorry to see you go, ${email}.
                </p>
                <p style="color: #333; font-size: 16px;">
                    If you change your mind, you're always welcome to join us again.
                </p>
                <div style="margin-top: 30px; text-align: center;">
                    <a href="${siteLink}" style="
                        background-color: #059669;
                        color: white;
                        padding: 12px 24px;
                        border-radius: 8px;
                        text-decoration: none;
                        font-size: 15px;
                        display: inline-block;
                    ">Join the Community Again</a>
                </div>
                <p style="color: #999; font-size: 13px; margin-top: 40px; text-align: center;">
                    Thank you for being a part of our journey.
                </p>
            </div>
        </div>
    `;
}

function generateUnsubscribeHTML(email) {
    return `
        <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 30px;">
            <div style="
                max-width: 600px;
                margin: auto;
                background: #ffffff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
                padding: 30px;
            ">
                <h2 style="color: #e74c3c;">You've Unsubscribed</h2>
                <p style="color: #333; font-size: 16px;">
                    Hello ${email},
                </p>
                <p style="color: #333; font-size: 16px;">
                    You've successfully unsubscribed from our mailing list. You won't receive any more updates from us.
                </p>
                <p style="color: #333; font-size: 14px; margin-top: 30px;">
                    If this was a mistake or you'd like to rejoin, you can always visit us again at
                    <a href="${config.frontendUrl}" style="color: #2980b9; text-decoration: none;">
                        ${config.frontendUrl}
                    </a>
                </p>
                <p style="color: #999; font-size: 13px; margin-top: 40px;">
                    We're sad to see you go, but thank you for being a part of us.
                </p>
            </div>
        </div>
    `;
}

exports.insert_contact_details = async (req, res) => {
    try {
        const result = await common_model.insert_contact_details(req.body);
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - insert contact details - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}
exports.get_contact_details = async (req, res) => {
    try{
        const result = await common_model.get_contact_details();
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - get contact details - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}
exports.insert_join_community = async (req, res) => {
    try {
        const { mail_id, send_mail_status } = req.body;

        if (!mail_id) {
            return res.status(400).json({ data: "Email ID is required" });
        }

        const result = await common_model.insert_join_community({ mail_id, send_mail_status });

        if (result.already_present) {
            return res.status(409).json({ data: result.already_present });
        }

        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }

        if(send_mail_status){
            // Send "Thanks for joining the community" email
            const mailStatus = await sendJoinCommunityMail(mail_id);
            if (!mailStatus.success) {
                logger.warn(`Email send failed for: ${mail_id}, Reason: ${mailStatus.message}`);
            }
        }
        

        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - insert join community details - Error: ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
};


exports.get_join_community = async (req, res) => {
    try{
        const result = await common_model.get_join_community();
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - get join community details - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}
exports.insert_subscribe = async (req, res) => {
    try {
        const { mail_id } = req.body;

        if (!mail_id) {
            return res.status(400).json({ data: "Email ID is required" });
        }

        const result = await common_model.insert_subscribe({ mail_id });

        if (result.already_present) {
            return res.status(409).json({ data: result.already_present });
        }

        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }

        // Send "Thanks for subscribing" email
        const mailStatus = await sendSubscriptionMail(mail_id);
        if (!mailStatus.success) {
            logger.warn(`Email sent failed for: ${mail_id}, Reason: ${mailStatus.message}`);
        }

        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - insert subscribe details - Error: ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.unsubscribe = async (req, res) => {
    try {
        const { token } = req.body;
        const mail = decryptEmail(token);
        const result = await common_model.unsubscribe(mail);

        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }

        // Generate email content
        const htmlContent = generateUnsubscribeHTML(mail);

        const mailOptions = {
            from: `"BitTwoByte" <${config.smtp_mail}>`,
            to: mail,
            subject: "You've Successfully Unsubscribed",
            html: htmlContent
        };

        // Send unsubscribe email
        await transporter.sendMail(mailOptions);

        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - unsubscribe - Error: ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
};

exports.remove_from_community = async (req, res) => {
    try {
        const { token } = req.body;
        const mail = decryptEmail(token);
        const result = await common_model.remove_from_community(mail);

        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }

        // Generate email content
        const htmlContent = generateLeaveCommunityHTML(mail);

        const mailOptions = {
            from: `"BitTwoByte" <${config.smtp_mail}>`,
            to: mail,
            subject: "You've Left Our Community",
            html: htmlContent
        };

        // Send farewell email
        await transporter.sendMail(mailOptions); // assumes `transporter` is your configured nodemailer instance

        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - remove_from_community - Error: ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
};

exports.get_subscribe = async (req, res) => {
    try{
        const result = await common_model.get_subscribe();
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - get subscribe details - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

// Blog section start


exports.add_blog = async (req, res) => {
    try {
      const { title, content, description, status, tags, category_id } = req.body;
  
      const cover_image = req.files?.cover_image?.[0];  // if using upload.fields
      const profile_img = req.files?.profile_img?.[0];
  
      const assetFolderPath = path.join(__dirname, '../assets/blogs');
      const profileImgFolder = path.join(assetFolderPath, 'profile_img');
      const coverImgFolder = path.join(assetFolderPath, 'cover_image');
  
      if (!fs.existsSync(profileImgFolder)) fs.mkdirSync(profileImgFolder, { recursive: true });
      if (!fs.existsSync(coverImgFolder)) fs.mkdirSync(coverImgFolder, { recursive: true });
  
      let coverImagePath = null;
      let profileImagePath = null;
      const timestamp = Date.now();
      if (cover_image) {
          const extension = path.extname(cover_image.originalname);
          const coverImageName = `${timestamp}${extension}`;
          const coverImagePathFull = path.join(coverImgFolder, coverImageName);
    
          fs.writeFileSync(coverImagePathFull, cover_image.buffer);
          coverImagePath = `static/blogs/cover_image/${coverImageName}`;
        }
        if (profile_img) {
          const extension = path.extname(profile_img.originalname);
          const profileImageName = `${timestamp}${extension}`;
          const profileImagePathFull = path.join(profileImgFolder, profileImageName);
    
          fs.writeFileSync(profileImagePathFull, profile_img.buffer);
          profileImagePath = `static/blogs/profile_img/${profileImageName}`;
        }
    
      const result = await common_model.add_blog(
        title,
        content,
        description,
        coverImagePath,
        profileImagePath,
        status,
        tags,
        category_id
      );
  
      if (!result || !result.success) {
        return res.status(400).json({ data: messages.insert_failed });
      }
  
      return res.status(200).json({ data: result.data });
  
    } catch (error) {
      logger.error(`Controller - add_blog - Error: ${error.message}`);
      return res.status(500).json({ data: messages.internal_server_error });
    }
  };
  
  
  exports.update_blog = async (req, res) => {
      try {
        const { id, title, content, description, status,tags } = req.body;
        const old_blog = await common_model.get_blog_by_id(id);
        if (!old_blog.success) {
          return res.status(404).json({ data: messages.no_data_found });
        }
        const assetFolderPath = path.join(__dirname, '../assets/blogs');
        const coverImgFolder = path.join(assetFolderPath, 'cover_image');
        const profileImgFolder = path.join(assetFolderPath, 'profile_img');
        [coverImgFolder, profileImgFolder].forEach(folder => {
          if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
        });
    
        const timestamp = Date.now();
        let coverImagePath = old_blog.data.cover_image_path;
        let profileImagePath = old_blog.data.profileImagePath;
        const saveImage = (file, folderPath) => {
          const extension = path.extname(file.originalname);
          const fileName = `${timestamp}${extension}`;
          const filePathFull = path.join(folderPath, fileName);
          fs.writeFileSync(filePathFull, file.buffer);
          const relativeFolder = path.relative(path.join(__dirname, '..'), folderPath).replace(/\\/g, '/');
          return { path: `${relativeFolder}/${fileName}`, fullPath: filePathFull };
        };
    
        const cover_image = req.files?.cover_image?.[0];
        const profile_img = req.files?.profile_img?.[0];
    
        let newCoverImage, newProfileImage;
        if (cover_image) {
          newCoverImage = saveImage(cover_image, coverImgFolder);
          coverImagePath = newCoverImage.path;
        }
        if (profile_img) {
          newProfileImage = saveImage(profile_img, profileImgFolder);
          profileImagePath = newProfileImage.path;
        }
        if (newCoverImage && old_blog.data.cover_image_path) {
          const oldCoverImagePathFull = path.join(__dirname, '..', old_blog.data.cover_image_path);
          if (fs.existsSync(oldCoverImagePathFull)) fs.unlinkSync(oldCoverImagePathFull);
        }
    
        if (newProfileImage && old_blog.data.profileImagePath) {
          const oldProfileImagePathFull = path.join(__dirname, '..', old_blog.data.profileImagePath);
          if (fs.existsSync(oldProfileImagePathFull)) fs.unlinkSync(oldProfileImagePathFull);
        }
        const updatedCoverImagePath = coverImagePath.replace(/^assets\//, 'static/');
        const updatedProfileImagePath = profileImagePath.replace(/^assets\//, 'static/');
        
        const result = await common_model.update_blog(
          id,
          title,
          content,
          description,
          updatedCoverImagePath,
          updatedProfileImagePath,
          status,
          tags
        );
    
        if (!result || !result.success) {
          return res.status(400).json({ data: messages.update_failed });
        }
    
        return res.status(200).json({ data: messages.update_success });
    
      } catch (error) {
        logger.error(`Controller - update_blog - Error: ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
      }
    };
    
    
  
    exports.delete_blog = async (req, res) => {
      try {
        const { id } = req.body;
    
        const blog = await common_model.get_blog_by_id(id);
        if (!blog.success) {
          return res.status(404).json({ data: messages.no_data_found });
        }
        const { cover_image_path, profileImagePath } = blog.data;
        const deleteFileIfExists = (relativePath) => {
          if (relativePath) {
            const fullPath = path.join(__dirname, '..', relativePath);
            if (fs.existsSync(fullPath)) {
              fs.unlinkSync(fullPath);
            }
          }
        };
        deleteFileIfExists(cover_image_path);
        deleteFileIfExists(profileImagePath);
        const result = await common_model.delete_blog(id);
        if (!result.success) {
          return res.status(400).json({ data: messages.delete_failed });
        }
    
        return res.status(200).json({ data: messages.delete_success });
    
      } catch (error) {
        logger.error(`Controller - delete_blog - Error: ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
      }
    };

exports.get_blogs = async (req, res) => {
    try {
        const result = await common_model.get_blogs();
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - get_blogs - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};

exports.get_blogs_by_catogories = async (req, res) => {
    try {
        const result = await common_model.get_blogs_by_catogories();
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - get_blogs_by_catogories - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};

exports.get_blog_by_id = async (req, res) => {
    try {
        const { id } = req.params;
        const result = await common_model.get_blog_by_id(id);
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - get_blog_by_id - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};

exports.get_blogs_by_status = async (req, res) => {
    try {
        const { status } = req.params;
        const result = await common_model.get_blogs_by_status(status);
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - get_blogs_by_status - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};

exports.get_recent_blogs = async (req, res) => {
    try {
        const result = await common_model.get_recent_blogs();
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - get_recent_blogs - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};
exports.add_blog_category = async (req, res) => {
    try{
        const { category_name } = req.body;
        const result = await common_model.add_blog_category(category_name);
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - add blog category - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
}

exports.update_blog_category = async (req, res) => {
    try{
        const { id, category_name } = req.body;
        const result = await common_model.update_blog_category(id, category_name);
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - update blog category - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
}

exports.get_blog_category = async (req, res) => {
    try{
        const result = await common_model.get_blog_category();
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - get blog category - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
}
exports.get_blog_category_count = async (req, res) => {
    try{
        const result = await common_model.get_blog_category_count();
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - get blog category count - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
}

exports.delete_blog_category = async (req, res) => {
    try{
        const { id } = req.body;
        const result = await common_model.delete_blog_category(id);
        if (!result.success) {
            return res.status(404).json({ data : messages.no_data_found });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - delete blog category - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
}


// Blog section end

// Search keyword section start

exports.create_keyword = async (req, res) => {
    try {
        const { page_name, keywords, page_label, path } = req.body;
        const result = await common_model.create_keyword(page_name, keywords, page_label, path);

        if (!result.success) {
            return res.status(404).json({ data : result.data });
        }
        return res.status(200).json({ data : result.data });
    } catch (error) {
        logger.error(`Controller - Adding Search Keywords - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};

exports.update_keyword = async (req, res) => {
    try {
        const { id, keywords, page_name, page_label, path } = req.body;
        if (!id) {
            return res.status(400).json({ data: messages.need_required_fields });
        }
        if (!Array.isArray(keywords)) {
            return res.status(400).json({ data: messages.invalid_input_format });
        }
        const result = await common_model.update_keyword(id, keywords, page_name, page_label, path);
        if (!result.success) {
            return res.status(404).json({ data : result.data });
        }
        return res.status(200).json({ data : result.data });    } 
    catch (error) {
        logger.error(`Controller - updating keywords - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};

exports.get_keyword = async (req, res) => {
    try {
        const keywords = await common_model.get_keyword();  
        if (!keywords || keywords.length === 0) {
            return res.status(404).json({ message: 'No keywords found' });  
        }
        res.status(200).json({ keywords });  
    } catch (error) {
        logger.error(`Controller - get keywords - Error: ${error.message}`);
        return res.status(500).json({ data : messages.internal_server_error });
    }
};

// search keyword section end

// Technologies section start
exports.technologies = async (req, res) => {
    try {
        const { tech, id } = req.body; 
        const action = req.params.action;
        let result;

        switch (action) {
            case "add":
                if (!tech) return res.status(400).json({ error: "Technology name is required." });
                result = await common_model.add_technologies(tech);
                break;

            case "update":
                if (!id & !tech) return res.status(400).json({ error: "Field required for update." });
                result = await common_model.update_technologies(id, tech);
                break;

            case "delete":
                if (!id) return res.status(400).json({ error: "ID is required for deletion." });
                result = await common_model.delete_technologies(id);
                break;

            case "get":
                result = await common_model.get_technologies();
                break;

            default:
                return res.status(400).json({ error: "Invalid action specified." });
        }

        if (!result || !result.success) {
            return res.status(404).json({ error: "Operation failed", data: result?.data || null });
        }

        return res.status(200).json({ data: result.data });

    } catch (error) {
        logger.error(`Controller - Technologies - Error: ${error.message}`);
        return res.status(500).json({ error: "Internal Server Error" });
    }
};


// Technologies Section end


// Settings Section Start
exports.update_settings = async (req, res) => {
    try{
        const { key, value } = req.body;
        const result = await common_model.update_settings(key, value);
        if (!result.success) {
            return res.status(404).json({ data : result.data });
        }
        return res.status(200).json({ data : result.data });
    }catch(error) {
        logger.error(`Controller - Settings update - Error: ${error.message}`);
        return res.status(500).json({ error: "Internal Server Error" });
    }
}
exports.get_settings = async (req, res) => {
    try{
        const result = await common_model.get_settings();
        if (!result.success) {
            return res.status(404).json({ data : result.data });
        }
        return res.status(200).json({ data : result.data });
    }catch(error){
        logger.error(`Controller - Settings get - Error: ${error.message}`);
        return res.status(500).json({ error: "Internal Server Error" });
    }
}

exports.get_settings_user = async (req, res) => {
    try{
        const settings_key = req.params.settings_key;
        const result = await common_model.get_settings_user(settings_key);
        if (!result.success) {
            return res.status(404).json({ data : result.data });
        }
        return res.status(200).json({ data : result.data });
    }catch(error){
        logger.error(`Controller - Settings get - Error: ${error.message}`);
        return res.status(500).json({ error: "Internal Server Error" });
    }
}
// Settings Section end

//Count section
exports.get_counts = async (req, res) => {
    try{
        const table_name = req.params.table_name;
        const result = await common_model.get_counts(table_name);
        if (!result.success) {
            return res.status(404).json({ data : result.data });
        }
        return res.status(200).json({ data : result.data });
    }catch(error){
        logger.error(`Controller - get counts - Error: ${error.message}`);
        return res.status(500).json({ error: "Internal Server Error" });
    }
}

