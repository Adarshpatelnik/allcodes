const queries_model = require("../models/queries_model");
const logger = require('../config/logger');
const path = require('path');
const fs = require('fs');
const messages = require('../utils/messages');
const config = require('../config/config');
const nodemailer = require("nodemailer");

const trasnporter = nodemailer.createTransport({
    host: "smtp-mail.outlook.com",
    port: 587,
    secure: false, // use TLS
    auth: {
            user : config.smtp_mail,
            pass : config.smtp_password
    }
  });

exports.faq = async (req, res) => {
    try {
        const action = req.params.action;
        let result;
        if(action == "add"){
            result = await queries_model.add_faq(req.body);
        }else if(action == "update"){
            result = await queries_model.update_faq(req.body);
        }else if(action == "delete"){
            result = await queries_model.delete_faq(req.body);
        }else if(action == "get"){
            result = await queries_model.get_faq(req.body);
        }else{
            return res.status(404).json({ data: messages.invalid_action });
        }
        
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    } catch (error) {
        logger.error(`Controller - insert FAQs - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.drop_a_note = async (req, res) => {
    try{
        const result = await queries_model.drop_a_note(req.body);
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        // send the note to admin
        const template_path = path.join(__dirname, "../templates/user_note_template.html");
        let email_template = fs.readFileSync(template_path, 'utf8');
        email_template = email_template
                            .replace("{{mail_id}}", req.body.mail_id)
                            .replace("{{user_name}}", req.body.user_name)
                            .replace("{{phone_number}}", req.body.phone_number)
                            .replace("{{company_name}}", req.body.company_name)
                            .replace("{{topic}}", req.body.topic)
                            .replace("{{country}}", req.body.country)
                            .replace("{{message}}", req.body.message)
        const mail_options = {
            from : config.admin_mail_id,
            to : config.admin_mail_id,
            subject : "Drop a Note - Message From User", 
            html : email_template
        } 
        trasnporter.sendMail(mail_options);

        return res.status(200).json({ data: result.data });
    }catch(error){
        logger.error(`Controller - Drop_a_note insert - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }
}

exports.get_drop_a_note = async (req, res) => {
    try{
        const result = await queries_model.get_drop_a_note();
        if (!result || !result.success) {
            return res.status(404).json({ data: result.data });
        }
        return res.status(200).json({ data: result.data });
    }catch(error){
        logger.error(`Controller - get Drop_a_note - Error: , ${error.message}`);
        return res.status(500).json({ data: messages.internal_server_error });
    }   
}