const logger = require('../config/logger');
const db = require('../config/db');
const config = require('../config/config');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const messages = require('../utils/messages');

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const nodemailer = require("nodemailer");

// const transporter = nodemailer.createTransport(
//     {
//         service : "smtp-mail.outlook.com",
//         auth : {
//             user : config.smtp_mail,
//             pass : config.smtp_password
//         }
        
//     }
// )

const transporter = nodemailer.createTransport({
    host: "smtp-mail.outlook.com",
    port: 587,
    secure: false, // use TLS
    auth: {
            user : config.smtp_mail,
            pass : config.smtp_password
    }
  });


exports.admin_register = async (name, mail_id, password) => {
    let connection;
    try {
        connection = await db.getConnection();
        
        // Check if mail_id already exists
        const [existingUser] = await connection.execute(
            'SELECT mail_id FROM admin_users WHERE mail_id = ?',
            [mail_id]
        );
        
        if (existingUser.length > 0) {
            return { success: false, data: messages.already_exists };
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        const [result] = await connection.execute(
            'INSERT INTO admin_users (name, mail_id, password) VALUES (?, ?, ?)',
            [name, mail_id, hashedPassword]
        );
        
        if (result.affectedRows > 0) {
            return { success: true, data: messages.insert_success };
        } else {
            return { success: false, data: messages.insert_failed };
        }
    } catch (error) {
        logger.error(`Model - Insert admin data. Error: ${error}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

exports.admin_login = async ({ mail_id, password }) => {
    let connection;
    try {
        connection = await db.getConnection();
        const [user_rows] = await connection.query('SELECT * FROM admin_users WHERE mail_id = ?', [mail_id]);
        connection.release();
        
        if (user_rows.length === 0) {
            throw new Error('InvalidCredentials');
        }
        
        const user = user_rows[0];
        const password_match = await bcrypt.compare(password, user.password);
        if (!password_match) {
            throw new Error('InvalidCredentials');
        }
        
        const token = jwt.sign(
            { id: user.id, mail_id: user.mail_id, role: user.role },
            config.jwt_secret,
            { expiresIn: config.jwt_expiration }
        );
        
        return {
            success: true,
            data: messages.login_success,
            token,
            mail_id,
            user_id : user.id

        };
    } catch (error) {
        if (error.message === 'InvalidCredentials') {
            return { success: false, data: messages.invalid_cred };
        }
        logger.error(`Model - Admin login - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};


exports.change_password = async (user_id, old_password, new_password) => {
    let connection;
    try {
        connection = await db.getConnection();

        const [rows] = await connection.execute(
            "SELECT password FROM admin_users WHERE id = ?",
            [user_id]
        );

        if (rows.length === 0) {
            return { success: false, data: messages.no_data_found };
        }

        const storedHashedPassword = rows[0].password;

        const isMatch = await bcrypt.compare(old_password, storedHashedPassword);
        if (!isMatch) {
            return { success: false, data: messages.invalid_cred };
        }

        const hashedNewPassword = await bcrypt.hash(new_password, 10);

        const [result] = await connection.execute(
            "UPDATE admin_users SET password = ? WHERE id = ?",
            [hashedNewPassword, user_id]
        );

        return result.affectedRows > 0 
            ? { success: true, data: messages.update_success }
            : { success: false, data: messages.update_failed };

    } catch (error) {
        logger.error(`Model - Change Password - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

// Forgot password start


exports.sendPasswordResetEmail = async (mailID) => {
    let connection;
    try {
        connection = await db.getConnection();
        const [rows] = await connection.execute(
            'SELECT id FROM admin_users WHERE mail_id = ?', [mailID]
        );

        if (rows.length === 0) {
            return { success: false, message: 'No user found with this email address' };
        }
        const userId = rows[0].id;
        const resetToken = crypto.randomBytes(32).toString('hex');
        const expiration = new Date(Date.now() + 3600000); // 1 hour
        await connection.execute(
            'INSERT INTO reset_passwords (userId, token, expiration) VALUES (?, ?, ?)',
            [userId, resetToken, expiration]
        );
        const resetLink = `${config.baseUrl}/reset-password?token=${encodeURIComponent(resetToken)}`;
        const templatePath = path.join(__dirname, '../templates/reset_temp.html');
        let emailTemplate;

        try {
            emailTemplate = fs.readFileSync(templatePath, 'utf8');
            emailTemplate = emailTemplate
                .replace('{{resetlink}}', resetLink)
                .replace('{{weblink}}', config.frontendUrl);
        } catch (error) {
            logger.error(`Error reading email template: ${error.message}`);
            throw new Error('Failed to load email template');
        }

        const mailOptions = {
            from: config.smtp_mail, 
            to: mailID,
            subject: 'Password Reset Request',
            html: emailTemplate
        };
        const response = await transporter.sendMail(mailOptions);
        if (response.accepted.includes(mailID)) {
            return { success: true, token: resetToken,  message: 'Password reset email sent successfully',};
        } else {
            throw new Error('Failed to send email');
        }
    } catch (error) {
        logger.error(`Error sending password reset email: ${error.message}`);
        throw new Error('Error sending password reset email');
    } finally {
        if (connection) connection.release();
    }
};

  
exports.reset_password = async (token, newPassword) => {
    let connection;
    try {
        connection = await db.getConnection();

        // 1. Check if token exists
        const [rows] = await connection.execute(
            'SELECT userId, expiration FROM reset_passwords WHERE token = ?', [token]
        );

        if (rows.length === 0) {
            throw new Error('Invalid or expired token');
        }

        const resetData = rows[0];

        // 2. Check if token has expired
        if (new Date() > new Date(resetData.expiration)) {
            throw new Error('Token has expired');
        }

        // 3. Check if user exists
        const [userRows] = await connection.execute(
            'SELECT * FROM admin_users WHERE id = ?', [resetData.userId]
        );

        if (userRows.length === 0) {
            throw new Error('User not found');
        }

        // 4. Hash the new password and update
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        await connection.execute(
            'UPDATE admin_users SET password = ? WHERE id = ?', [hashedPassword, resetData.userId]
        );

        // 5. Remove used reset token
        await connection.execute('DELETE FROM reset_passwords WHERE token = ?', [token]);

        return { message: 'Password reset successfully' };
    } catch (error) {
        logger.error(`Error resetting password: ${error.message}`);
        throw error;
    } finally {
        if (connection) connection.release();
    }
};

// Forget password end