const logger = require('../config/logger');
const db = require('../config/db');
const messages = require('../utils/messages');

exports.insert_single_image_section = async (section_name, contents, image_path, page_name, parent_id) => {
    let connection;
    try {
        connection = await db.getConnection();

        if (parent_id) {
            let checkQuery = `SELECT * FROM page_contents WHERE section_name = ? AND parent_id = ?;`;
            let [rows] = await connection.execute(checkQuery, [section_name, parent_id]);

            if (rows.length > 0) {
                let updateQuery = `UPDATE page_contents SET content = ?, updated_timestamp = CURRENT_TIMESTAMP`;
                let queryParams = [contents];
                
                if (image_path && image_path !== 'None') {
                    updateQuery += `, images = ?`;
                    queryParams.push(image_path);
                }

                updateQuery += ` WHERE section_name = ? AND parent_id = ?;`;
                queryParams.push(section_name, parent_id);
                
                await connection.execute(updateQuery, queryParams);
                return { success: true, data: messages.update_success };
            } else {
                let insertQuery = `INSERT INTO page_contents (section_name, content, images, page_name, parent_id, created_timestamp) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP);`;
                await connection.execute(insertQuery, [section_name, contents, image_path !== 'None' ? image_path : null, page_name, parent_id]);
                return { success: true, data: messages.insert_success };
            }
        } else {
            let updateQuery = `UPDATE page_contents SET content = ?, updated_timestamp = CURRENT_TIMESTAMP`;
            let queryParams = [contents];

            if (image_path && image_path !== 'None') {
                updateQuery += `, images = ?`;
                queryParams.push(image_path);
            }

            updateQuery += ` WHERE section_name = ? AND page_name = ?;`;
            queryParams.push(section_name, page_name);

            const [result] = await connection.execute(updateQuery, queryParams);

            if (result.affectedRows === 0) {
                let insertQuery = `INSERT INTO page_contents (section_name, content, images, page_name, created_timestamp) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP);`;
                await connection.execute(insertQuery, [section_name, contents, image_path !== 'None' ? image_path : null, page_name]);
                return { success: true, data: messages.insert_success };
            }
            return { success: true, data: messages.update_success };
        }
    } catch (error) {
        logger.error(`Model - updating single image section - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            await connection.release();
        }
    }
};

exports.get_single_image_section = async (section_name, page_name) => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `SELECT * FROM page_contents WHERE section_name = ? AND page_name = ?`;
        
        const query_params = [section_name, page_name];

        const [result] = await connection.execute(query, query_params);

        if (result.length > 0) {
            return { success: true, data: result }; 
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get_single_image_section - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            await connection.release();
        }
    }
};

exports.insert_page = async (page_name, label) => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `INSERT INTO pages (page_name, label, role, expire_time) VALUES (?, ?, ?, ?)`;
        
        // All expire date will be one year from creation time
        const expire_time = new Date();
        expire_time.setFullYear(expire_time.getFullYear() + 1);
        
        const query_params = [page_name, label, JSON.stringify(["super_admin"]), expire_time];

        const [result] = await connection.execute(query, query_params);

        if (result.affectedRows === 0) {
            return { success: false, data: messages.insert_failed };
        } else {
            return { success: true, data: messages.insert_success };
        }
    } catch (error) {
        logger.error(`Model - insert page - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            await connection.release();
        }
    }
};


exports.insert_section = async (section_name, page_name) => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `INSERT INTO page_contents (page_name, section_name) VALUES (?, ?)`;
        
        const query_params = [page_name, section_name];

        const [result] = await connection.execute(query, query_params);

        if (result.affectedRows === 0) {
            return { success: false, data: messages.insert_failed };
        } else {
            return { success: true, data: messages.insert_success };
        }
    } catch (error) {
        logger.error(`Model - insert section - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            await connection.release();
        }
    }
};

exports.get_page_section_details = async () => {
    let connection;
    try {
        connection = await db.getConnection();        
        const query = `
            SELECT 
                p.page_name, p.label, p.role, p.expire_time, 
                pc.section_name, pc.content, pc.images 
            FROM pages p 
            JOIN page_contents pc ON p.page_name = pc.page_name
        `;

        const [result] = await connection.execute(query);

        if (result.length === 0) {
            return { success: false, data: messages.no_data_found };
        }

        const formattedResult = result.reduce((acc, row) => {
            if (!acc[row.page_name]) {
                acc[row.page_name] = {
                    label: row.label,
                    role: row.role,
                    expire_time: row.expire_time,
                    sections: []
                };
            }
            acc[row.page_name].sections.push({
                section_name: row.section_name,
                content: row.content,
                images: row.images
            });

            return acc;
        }, {});

        return { success: true, data: formattedResult };
    } catch (error) {
        logger.error(`Model - get_page_section_details - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            await connection.release();
        }
    }
};

exports.insert_multiple = async (description, status, image_path_url, section_name, page_name, technology_id) => {
    let connection;
    try {
        connection = await db.getConnection();
        let query, query_params;


        if (section_name === "banner_images_order_number") {

            const get_last_order_query = `
                SELECT COALESCE(MAX(order_number), 0) AS last_order 
                FROM page_images 
                WHERE page_name = ?;
            `;
            const [result] = await connection.execute(get_last_order_query, [page_name]);
            const new_order_number = result[0].last_order + 1;

            query = `
                INSERT INTO page_images 
                (image_url, section_name, status, description, page_name, order_number) 
                VALUES (?, ?, ?, ?, ?, ?);
            `;
            query_params = [image_path_url, section_name, status, description, page_name, new_order_number];

        } else {
            query = `
                INSERT INTO page_images 
                (image_url, section_name, status, description, page_name, technology) 
                VALUES (?, ?, ?, ?, ?, ?);
            `;
            query_params = [
                image_path_url,
                section_name,
                status,
                description || null,  
                page_name,
                technology_id || null
            ];
        }
        const [insertResult] = await connection.execute(query, query_params);

        if (insertResult.affectedRows === 0) {
            return { success: false, data: messages.insert_failed };
        }
        return { success: true, data: messages.insert_success };

    } catch (error) {
        logger.error(`Model - insert multiple images - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };

    } finally {
        if (connection) {
            await connection.release();
        }
    }
};

exports.get_image_url = async (id, section_name) => {
    let connection;
    try {
        connection = await db.getConnection();
        const [rows] = await connection.execute(
            'SELECT image_url FROM page_images WHERE id = ? AND section_name = ?',
            [id, section_name]
        );
        return rows[0]?.image_url || null;
    } catch (error) {
        logger.error(`Model - Get Image URL - Error: ${error.message}`);
        return null; 
    } finally {
        if (connection) {
            connection.release();
        }
    }
};

  exports.update_multiple = async (id, section_name, image_url, description, status, page_name) => {
    let connection;
    try {
        connection = await db.getConnection();

        const sql = `
            UPDATE page_images
            SET 
                image_url = ?, 
                description = COALESCE(?, description), 
                status = ?, 
                updated_timestamp = NOW()
            WHERE id = ? AND section_name = ? AND page_name = ?;
        `;
        const params = [image_url, description, status, id, section_name, page_name];

        const [result] = await connection.execute(sql, params);

        if (result.affectedRows === 0) {
            return { success: false, data: messages.no_matching_record };
        }
        return { success: true, data: messages.update_success };

    } catch (error) {
        logger.error(`Model - Update multiple Images - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };

    } finally {
        if (connection) {
            connection.release();
        }
    }
};

exports.get_multiple = async (section_name, page_name) => {
    if (!section_name || !page_name) {
        return { success: false, data: messages.invalid_parameters };
    }

    let connection;
    try {
        connection = await db.getConnection();
        
        const query = `
            SELECT 
                hp.section_name,
                hp.content,
                hp.images,
                hi.id,
                hi.image_url,
                hi.status,
                hi.order_number,
                hi.description,
                t.technology AS technology_name
            FROM 
                page_contents hp
            LEFT JOIN 
                page_images hi 
                ON hp.section_name = hi.section_name 
                AND hp.page_name = hi.page_name
            LEFT JOIN
                technologies t
                ON hi.technology = t.id  
            WHERE 
                hp.section_name = ? 
                AND hp.page_name = ?
            ORDER BY 
                hi.order_number DESC, hi.id DESC;  
        `;

        const [rows] = await connection.query(query, [section_name, page_name]);

        if (!rows.length) {
            return { success: false, data: messages.no_data_found };
        }

        let imagesData;

        if (section_name === "technology_services") {
            // Group images by technology_name
            imagesData = {};
            rows.forEach(row => {
                if (row.technology_name) {
                    if (!imagesData[row.technology_name]) {
                        imagesData[row.technology_name] = [];
                    }
                    imagesData[row.technology_name].push({
                        id: row.id,
                        image_url: row.image_url || null,
                        status: row.status || 'inactive',
                        description: row.description || '',
                        orderNumber: row.order_number || 0
                    });
                }
            });
        } else {
            // Keep the regular format
            imagesData = rows
                .filter(row => row.id)
                .map(row => ({
                    id: row.id,
                    image_url: row.image_url || null,
                    status: row.status || 'inactive',
                    description: row.description || '',
                    orderNumber: row.order_number || 0,
                    technology_name: row.technology_name || ''
                }));
        }

        const contentResult = {
            section_name: rows[0].section_name,
            contents: {
                content: rows[0].content || '',
                images: rows[0].images || null
            },
            images: imagesData
        };

        return { success: true, data: contentResult };

    } catch (error) {
        logger.error(`Model - Get Multiple Image - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.delete_multiple = async (id, page_name, section_name) => {
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();

        const sql = `
            DELETE FROM page_images
            WHERE id = ? AND section_name = ? AND page_name = ?;
        `;
        const params = [id, section_name, page_name];

        const [result] = await connection.query(sql, params);

        if (result.affectedRows === 0) {
            await connection.rollback();
            return { success: false, data: messages.no_matching_record };
        }

        await connection.commit();
        return { success: true, data: messages.delete_success };

    } catch (error) {
        if (connection) await connection.rollback();
        logger.error(`Model - Delete Multiple Images - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };

    } finally {
        if (connection) connection.release();
    }
};


exports.get_page_details = async (page_name, access) => {
    let connection;
    try {
        connection = await db.getConnection();
        const [details] = await connection.query(
            'SELECT section_name, images, content FROM page_contents WHERE page_name = ?',
            [page_name]
        );

        if (!details || details.length === 0) {
            return { success: false, message: 'Page not found' };
        }

        const filteredDetails = await Promise.all(details.map(async (detail) => {
            const section_name = detail.section_name;

            // For case_study, only allow case_study_overview section
            if (page_name === 'case_study' && section_name !== 'case_study_overview') {
                return null;
            }

            if (detail.content) {
                try {
                    detail.content = JSON.parse(detail.content);
                } catch (e) {
                    logger.warn(`Invalid JSON in content for section_name: ${section_name}`);
                }
            }

            let page_images;
            if(access == "admin"){
                 [page_images] = await connection.query(
                    'SELECT image_url, description FROM page_images WHERE section_name = ? AND status = "active" ORDER BY created_timestamp DESC',
                    [section_name]
                );
            }else{

                if (page_name === 'technology') {
                    [page_images] = await connection.query(
                        'SELECT image_url, description, technology FROM page_images WHERE section_name = ? AND status = "active" ORDER BY created_timestamp',
                        [section_name]
                    );
                }
                else{
                    [page_images] = await connection.query(
                        'SELECT image_url, description FROM page_images WHERE section_name = ? AND status = "active" ORDER BY created_timestamp',
                        [section_name]
                    );
                }
              
            }

            if (page_name === 'technology') {
                const technologyIds = page_images
                    .filter(img => img.technology !== null)
                    .map(img => img.technology);

                if (technologyIds.length > 0) {
                    const [technologies] = await connection.query(
                        `SELECT id, technology FROM technologies WHERE id IN (${technologyIds.join(',')})`
                    );
                    const techMap = {};
                    technologies.forEach(t => {
                        techMap[t.id] = t.technology;
                    });

                    const technologyGroups = {};

                    page_images.forEach(img => {
                        if (img.technology === null) return;

                        if (!technologyGroups[img.technology]) {
                            technologyGroups[img.technology] = {
                                id: img.technology,
                                technology_name: techMap[img.technology] || null,
                                image_contents: []
                            };
                        }

                        technologyGroups[img.technology].image_contents.push({
                            image_url: img.image_url,
                            description: img.description
                        });
                    });


                    detail.technology_contents = Object.values(technologyGroups);
                } else {
                    detail.technology_contents = [];
                }

            }
            
            else {
            detail.image_contents = page_images.length > 0
                ? page_images.map(img => ({ image_url: img.image_url, description: img.description }))
                : [];
            }
            return detail;
        }));

        const resultData = filteredDetails.filter(Boolean); // remove nulls

        return { success: true, data: resultData };

    } catch (error) {
        logger.error('Error fetching page content:', error);
        return { success: false, message: 'Internal Server Error' };
    } finally {
        if (connection) connection.release();
    }
    
};

exports.insert_multiple_in_single_request = async ( section_name, contents, image_paths, page_name ) => {
    let connection;
    try {
        connection = await db.getConnection();

        let query, query_params;

        if (image_paths === 'None') {
            query = `
                UPDATE page_contents
                SET content = ?, updated_timeStamp = CURRENT_TIMESTAMP
                WHERE section_name = ? AND page_name = ?;
            `;
            query_params = [contents, section_name, page_name];

        } else {
            const [existing_rows] = await connection.query(
                `SELECT images FROM page_contents WHERE section_name = ? AND page_name = ?;`,
                [section_name, page_name]
            );

            if (existing_rows.length === 0) {
                return { success: false, data: messages.no_data_found };
            }

            let existing_images = {};

            if (existing_rows[0].images) {
                try {
                    existing_images = JSON.parse(existing_rows[0].images);
                } catch (e) {
                    logger.warn(`Invalid JSON in images for section: ${section_name}, page: ${page_name}`);
                }
            }

            const updated_images = Object.assign({}, existing_images, image_paths);
            const updated_images_json = JSON.stringify(updated_images);

            query = `
                UPDATE page_contents
                SET images = ?, content = ?, updated_timeStamp = CURRENT_TIMESTAMP
                WHERE section_name = ? AND page_name = ?;
            `;
            query_params = [updated_images_json, contents, section_name, page_name];
        }

        const [result] = await connection.query(query, query_params);

        if (result.affectedRows === 0) {
            return { success: false, data: messages.update_failed };
        }
        return { success: true, data: messages.update_success };

    } catch (error) {
        logger.error(`Model - Update Page Content - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };

    } finally {
        if (connection) {
            connection.release();
        }
    }
}


exports.get_case_study = async (parent_id) => {
    let connection;
    try {
        connection = await db.getConnection();
        const [details] = await connection.query(
            'SELECT id, section_name, images, content, page_name FROM page_contents WHERE parent_id = ?',
            [parent_id]
        );

        if (!details || details.length === 0) {
            return { success: false, message: 'Page not found' };
        }

        return { success: true, data: details };

    } catch (error) {
        logger.error(`Model - get case study - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };

    } finally {
        if (connection) {
            connection.release(); 
        }
    }
};

exports.get_case_study_user = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const [rows] = await connection.query(`
            SELECT 
                pi.id AS image_id,
                pi.page_name AS image_page_name,
                pi.section_name AS image_section_name,
                pi.image_url,
                pi.status,
                pi.description,
                pi.order_number,
                pi.created_timestamp AS image_created,
                pi.updated_timestamp AS image_updated,
                pi.technology,
                pc.id AS content_id,
                pc.section_name AS content_section_name,
                pc.content,
                pc.images AS content_images,
                pc.created_timestamp AS content_created,
                pc.updated_timestamp AS content_updated,
                pc.page_name AS content_page_name,
                pc.parent_id
            FROM 
                page_images pi
            LEFT JOIN 
                page_contents pc ON pc.parent_id = pi.id
            WHERE 
                pi.page_name = 'case_study'
                AND pi.status = 'active'
        `);

        // Group results by image_id
        const resultMap = {};
        for (const row of rows) {
            if (!resultMap[row.image_id]) {
                resultMap[row.image_id] = {
                    id: row.image_id,
                    page_name: row.image_page_name,
                    section_name: row.image_section_name,
                    image_url: row.image_url,
                    status: row.status,
                    description: row.description,
                    order_number: row.order_number,
                    created_timestamp: row.image_created,
                    updated_timestamp: row.image_updated,
                    technology: row.technology,
                    contents: []
                };
            }

            if (row.content_id) {
                resultMap[row.image_id].contents.push({
                    id: row.content_id,
                    section_name: row.content_section_name,
                    content: row.content,
                    images: row.content_images,
                    created_timestamp: row.content_created,
                    updated_timestamp: row.content_updated,
                    page_name: row.content_page_name,
                    parent_id: row.parent_id
                });
            }
        }

        return { success: true, data: Object.values(resultMap) };

    } catch (error) {
        logger.error(`Model - getCaseStudyWithContents - Error: ${error.message}`);
        return { success: false, message: 'Internal Server Error' };
    } finally {
        if (connection) connection.release();
    }
};


exports.get_all_images_by_parent = async (parent_id, section_name) => {
    try {
        const query = `SELECT images FROM page_contents WHERE parent_id = ?;`;
        const [rows] = await db.execute(query, [parent_id]);

        if (!rows.length) return [];

        // Extract image URLs (assuming images are stored as comma-separated strings)
        const imageUrls = rows.flatMap(row => row.images ? row.images.split(',') : []);

        return imageUrls;
    } catch (error) {
        logger.error(`Model - get_all_images_by_parent - Error: ${error.message}`);
        return [];
    }
};

// Get the page and section details without format

// exports.get_page_section_details = async () => {
//     let connection;
//     try {
//         connection = await db.getConnection();        
//         const query = `SELECT 
//                             p.page_name, p.label, p.role, p.expire_time, 
//                             pc.section_name, pc.content, pc.images 
//                         FROM pages p 
//                         JOIN page_contents pc ON p.page_name = pc.page_name`;

//         const [result] = await connection.execute(query);

//         if (result.length > 0) {
//             return { success: true, data: result };
//         } else {
//             return { success: false, data: messages.no_data_found };
//         }
//     } catch (error) {
//         logger.error(`Model - insert section - Error: ${error.message}`);
//         return { success: false, data: messages.internal_server_error };
//     } finally {
//         if (connection) {
//             await connection.release();
//         }
//     }
// }

