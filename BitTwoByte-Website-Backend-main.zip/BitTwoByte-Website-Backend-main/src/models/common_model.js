const logger = require('../config/logger');
const db = require('../config/db');
const messages = require('../utils/messages');


exports.insert_contact_details = async ({ first_name, last_name, mail_id, phone_number, message }) => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `
            INSERT INTO contact_details (first_name, last_name, mail_id, phone_number, message) 
            VALUES (?, ?, ?, ?, ?)
        `;
        const query_params = [first_name, last_name, mail_id, phone_number, message];
        const [result] = await connection.execute(query, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.insert_success };
        } else {
            return { success: false, data: messages.insert_failed };
        }
    } catch (error) {
        logger.error(`Model - insert contact details - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};

exports.get_contact_details = async () => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `
            SELECT id, first_name, last_name, mail_id, phone_number, message, created_timestamp FROM contact_details ORDER BY id DESC
        `;
        const [result] = await connection.execute(query);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_records_found };
        }
    } catch (error) {
        logger.error(`Model - get_contact_details - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.insert_join_community = async ({ mail_id, send_mail_status }) => {
    let connection;
    try {
        connection = await db.getConnection();

        const check_query = `SELECT id, send_mail_status FROM join_community WHERE mail_id = ?`;
        const [existingRows] = await connection.execute(check_query, [mail_id]);

        if (existingRows.length > 0) {
            const currentStatus = existingRows[0].send_mail_status;

            if (currentStatus === 1) {
                return { success: true, already_present: messages.already_present };
            } else {
                const update_query = `UPDATE join_community SET send_mail_status = 1 WHERE mail_id = ?`;
                await connection.execute(update_query, [mail_id]);
                return { success: true, data: messages.insert_success };
            }
        }

        const insert_query = `
            INSERT INTO join_community (mail_id, send_mail_status) 
            VALUES (?, ?)
        `;
        const query_params = [mail_id, send_mail_status];
        const [result] = await connection.execute(insert_query, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.insert_success };
        } else {
            return { success: false, data: messages.insert_failed };
        }

    } catch (error) {
        logger.error(`Model - insert join community - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};



exports.get_join_community = async () => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `
            SELECT id, mail_id, send_mail_status, created_timestamp FROM join_community ORDER BY id DESC
        `;
        const [result] = await connection.execute(query);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_records_found };
        }
    } catch (error) {
        logger.error(`Model - get join community - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.insert_subscribe = async ({ mail_id }) => {
    let connection;
    try {
        connection = await db.getConnection();

        const check_query = `SELECT id, status FROM subscribe WHERE mail_id = ?`;
        const [existingRows] = await connection.execute(check_query, [mail_id]);

        if (existingRows.length > 0) {
            const { id, status } = existingRows[0];

            if (status === 1) {
                return { success: true, already_present: messages.already_subscribed };
            } else {
                const updateQuery = `UPDATE subscribe SET status = 1 WHERE id = ?`;
                await connection.execute(updateQuery, [id]);
                return { success: true, data: messages.insert_success }; 
            }
        }

        const insertQuery = `
            INSERT INTO subscribe (mail_id, status) 
            VALUES (?, ?)
        `;
        const query_params = [mail_id, 1];
        const [result] = await connection.execute(insertQuery, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.insert_success };
        } else {
            return { success: false, data: messages.insert_failed };
        }
    } catch (error) {
        logger.error(`Model - insert subscribe - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.unsubscribe = async (mail_id) => {
    let connection;
    try {
        connection = await db.getConnection();

        const check_query = `SELECT id FROM subscribe WHERE mail_id = ?`;
        const [existingRows] = await connection.execute(check_query, [mail_id]);

        if (existingRows.length > 0) {
            const update_query = `UPDATE subscribe SET status = 0 WHERE mail_id = ?`;
            await connection.execute(update_query, [mail_id]);

            return { success: true, data: "Unsubscribed successfully" };
        } else {
            return { success: false, data: "Invalid mail ID to unsubscribe" };
        }
    } catch (error) {
        logger.error(`Model - unsubscribe - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};

exports.remove_from_community = async (mail_id) => {
    let connection;
    try {
        connection = await db.getConnection();

        const check_query = `SELECT id FROM join_community WHERE mail_id = ?`;
        const [existingRows] = await connection.execute(check_query, [mail_id]);

        if (existingRows.length > 0) {
            const update_query = `UPDATE join_community SET send_mail_status = 0 WHERE mail_id = ?`;
            await connection.execute(update_query, [mail_id]);

            return { success: true, data: "Removed from community successfully" };
        } else {
            return { success: false, data: "Invalid mail ID" };
        }
    } catch (error) {
        logger.error(`Model - remove_from_community - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};



exports.get_subscribe = async () => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `
            SELECT id, mail_id, status,created_timestamp FROM subscribe ORDER BY id DESC
        `;
        const [result] = await connection.execute(query);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_records_found };
        }
    } catch (error) {
        logger.error(`Model - get subscribe - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.add_blog = async (title, content, description, cover_image_path,profileImagePath, status, tags, category_id) => {
     let connection;
     try {
 
         connection = await db.getConnection();
        //  if (status == "false") {
        //      status = 0;
        //  } else {
        //      status = 1;
        //  }
         const insertQuery = `
             INSERT INTO blog (title, content, description, cover_image_path,profileImagePath, status, tags, category_id) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         `;
         const query_params = [title, content, description, cover_image_path,profileImagePath, status, tags, category_id];
         const [result] = await connection.execute(insertQuery, query_params);
 
         if (result.affectedRows > 0) {
             return { success: true, data: messages.insert_success };
         } else {
             return { success: false, data: messages.insert_failed };
         }
     } catch (error) {
         logger.error(`Model - insert blog - Error: ${error.message}`);
         return { success: false, data: messages.internal_server_error };
     } finally {
         if (connection) {
             connection.release();
         }
     }
 }
 exports.update_blog = async (id, title, content, description, cover_image_path, profileImagePath, status, tags) => {
     let connection;
     try {
         connection = await db.getConnection();
        //  if (status == "false") {
        //      status = 0;
        //  } else {
        //      status = 1;
        //  }
         const updateQuery = `
             UPDATE blog 
             SET title = ?, content = ?, description = ?, cover_image_path = ?, profileImagePath =?, status = ? , tags = ?
             WHERE id = ?
         `;
         const query_params = [title, content, description, cover_image_path,profileImagePath, status, tags, id];
         const [result] = await connection.execute(updateQuery, query_params);
 
         if (result.affectedRows > 0) {
             return { success: true, data: messages.update_success };
         } else {
             return { success: false, data: messages.update_failed };
         }
     } catch (error) {
         logger.error(`Model - update blog - Error: ${error.message}`);
         return { success: false, data: messages.internal_server_error };
     } finally {
         if (connection) {
             connection.release();
         }
     }
 };
 
 exports.delete_blog = async (id) => {
     let connection;
     try {
         connection = await db.getConnection();
         const delete_query = `DELETE FROM blog WHERE id = ?`;
         const [result] = await connection.execute(delete_query, [id]);
 
         if (result.affectedRows > 0) {
             return { success: true, data: messages.delete_success };
         } else {
             return { success: false, data: messages.delete_failed };
         }
     } catch (error) {
         logger.error(`Model - delete_blog - Error: ${error.message}`);
         return { success: false, data: messages.internal_server_error };
     } finally {
         if (connection) {
             connection.release();
         }
     }
 };

// exports.add_blog = async (title, content, description, cover_image_path, status, tags, category_id) => {
//     let connection;
//     try {
//         connection = await db.getConnection();
//         if (status == "false") {
//             status = 0;
//         } else {
//             status = 1;
//         }
//         const insertQuery = `
//             INSERT INTO blog (title, content, description, cover_image_path, status, tags, category_id) 
//             VALUES (?, ?, ?, ?, ?, ?, ?)
//         `;
//         const query_params = [title, content, description, cover_image_path, status, tags, category_id];
//         const [result] = await connection.execute(insertQuery, query_params);

//         if (result.affectedRows > 0) {
//             return { success: true, data: messages.insert_success };
//         } else {
//             return { success: false, data: messages.insert_failed };
//         }
//     } catch (error) {
//         logger.error(`Model - insert blog - Error: ${error.message}`);
//         return { success: false, data: messages.internal_server_error };
//     } finally {
//         if (connection) {
//             connection.release();
//         }
//     }
// }

exports.get_blog_by_id = async (id) => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `SELECT * FROM blog WHERE id = ?`;
        const [rows] = await connection.execute(query, [id]);

        if (rows.length > 0) {
            return { success: true, data: rows[0] };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get blog by id - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};

// exports.update_blog = async (id, title, content, description, cover_image_path, status) => {
//     let connection;
//     try {
//         connection = await db.getConnection();
//         if (status == "false") {
//             status = 0;
//         } else {
//             status = 1;
//         }
//         const updateQuery = `
//             UPDATE blog 
//             SET title = ?, content = ?, description = ?, cover_image_path = ?, status = ? 
//             WHERE id = ?
//         `;
//         const query_params = [title, content, description, cover_image_path, status, id];
//         const [result] = await connection.execute(updateQuery, query_params);

//         if (result.affectedRows > 0) {
//             return { success: true, data: messages.update_success };
//         } else {
//             return { success: false, data: messages.update_failed };
//         }
//     } catch (error) {
//         logger.error(`Model - update blog - Error: ${error.message}`);
//         return { success: false, data: messages.internal_server_error };
//     } finally {
//         if (connection) {
//             connection.release();
//         }
//     }
// };

// exports.delete_blog = async (id) => {
//     let connection;
//     try {
//         connection = await db.getConnection();
//         const delete_query = `DELETE FROM blog WHERE id = ?`;
//         const [result] = await connection.execute(delete_query, [id]);

//         if (result.affectedRows > 0) {
//             return { success: true, data: messages.delete_success };
//         } else {
//             return { success: false, data: messages.delete_failed };
//         }
//     } catch (error) {
//         logger.error(`Model - delete_blog - Error: ${error.message}`);
//         return { success: false, data: messages.internal_server_error };
//     } finally {
//         if (connection) {
//             connection.release();
//         }
//     }
// };

exports.get_blogs = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT 
                blog.*, 
                blog_categories.category_name 
            FROM 
                blog
            LEFT JOIN 
                blog_categories 
            ON 
                blog.category_id = blog_categories.id 
            ORDER BY 
                blog.created_timestamp DESC
        `;

        const [result] = await connection.execute(query);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get_blogs - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.get_blogs_by_catogories = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT 
                blog.*, 
                blog_categories.category_name 
            FROM 
                blog
            LEFT JOIN 
                blog_categories 
            ON 
                blog.category_id = blog_categories.id 
            ORDER BY 
                blog.created_timestamp DESC
        `;

        const [result] = await connection.execute(query);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get_blogs_by_catogories - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.get_blog_by_id = async (id) => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT 
                blog.*, 
                blog_categories.category_name 
            FROM 
                blog
            LEFT JOIN 
                blog_categories 
            ON 
                blog.category_id = blog_categories.id
            WHERE 
                blog.id = ?
        `;

        const [result] = await connection.execute(query, [id]);

        if (result.length > 0) {
            return { success: true, data: result[0] };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get_blog_by_id - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};


exports.get_blogs_by_status = async (status) => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT 
                blog.*, 
                blog_categories.category_name 
            FROM 
                blog
            LEFT JOIN 
                blog_categories 
            ON 
                blog.category_id = blog_categories.id
            WHERE 
                blog.status = ?
            ORDER BY 
                blog.created_timestamp DESC
        `;

        const [result] = await connection.execute(query, [status]);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get_blogs_by_status - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};


exports.get_recent_blogs = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT 
                blog.*, 
                blog_categories.category_name 
            FROM 
                blog
            LEFT JOIN 
                blog_categories 
            ON 
                blog.category_id = blog_categories.id
            WHERE 
                blog.status = ?
            ORDER BY 
                blog.created_timestamp DESC
            LIMIT 3
        `;

        const [result] = await connection.execute(query, ['active']);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get_blogs_by_status - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};



exports.add_blog_category = async (category_name) => {
    let connection;
    try {
        connection = await db.getConnection();
        const insertQuery = `
        INSERT INTO blog_categories (category_name) 
        VALUES (?)
    `;
        const query_params = [category_name];
        const [result] = await connection.execute(insertQuery, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.insert_success };
        } else {
            return { success: false, data: messages.insert_failed };
        }
    } catch (error) {
        logger.error(`Model - add_blog_category - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
}

exports.update_blog_category = async (id, category_name) => {
    let connection;
    try {
        connection = await db.getConnection();
        const updateQuery = `
            UPDATE blog_categories 
            SET category_name = ? 
            WHERE id = ?
        `;
        const query_params = [category_name, id];
        const [result] = await connection.execute(updateQuery, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.update_success };
        } else {
            return { success: false, data: messages.update_failed };
        }
    } catch (error) {
        logger.error(`Model - update_blog_category - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};

exports.get_blog_category = async () => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `SELECT id, category_name FROM blog_categories ORDER BY id DESC`;
        const [rows] = await connection.execute(query);
        return { success: true, data: rows };
    } catch (error) {
        logger.error(`Model - Get all blog categories - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

exports.get_blog_category_count = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT 
                bc.id AS category_id,
                bc.category_name,
                b.id AS blog_id,
                b.title,
                b.content,
                b.description,
                b.cover_image_path,
                b.status,
                b.created_timestamp,
                b.updated_timestamp,
                b.tags,
                b.profileImagePath
            FROM 
                blog_categories bc
            LEFT JOIN 
                blog b
            ON 
                b.category_id = bc.id
            ORDER BY 
                bc.id DESC
        `;

        const [rows] = await connection.execute(query);

        // Group blogs by category
        const resultMap = new Map();

        rows.forEach(row => {
            const {
                category_id, category_name, blog_id, title, content,
                description, cover_image_path, status,
                created_timestamp, updated_timestamp,
                tags, profileImagePath
            } = row;

            if (!resultMap.has(category_id)) {
                resultMap.set(category_id, {
                    id: category_id,
                    category_name,
                    blog_count: 0,
                    blogs: []
                });
            }

            const category = resultMap.get(category_id);

            if (blog_id) {
                // Safely parse tags
                let parsedTags = [];
                try {
                    parsedTags = tags ? JSON.parse(tags) : [];
                } catch (err) {
                    logger.warn(`Invalid tags JSON for blog ID ${blog_id}: ${tags}`);
                    parsedTags = [];
                }

                category.blogs.push({
                    id: blog_id,
                    title,
                    content,
                    description,
                    cover_image_path,
                    status,
                    created_timestamp,
                    updated_timestamp,
                    tags: parsedTags,
                    profileImagePath
                });

                category.blog_count++;
            }
        });

        return { success: true, data: Array.from(resultMap.values()) };
    } catch (error) {
        logger.error(`Model - get_blog_category_count - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};




exports.delete_blog_category = async (id) => {
    let connection;
    try {
        connection = await db.getConnection();
        const deleteQuery = `DELETE FROM blog_categories WHERE id = ?`;
        const [result] = await connection.execute(deleteQuery, [id]);
        if (result.affectedRows > 0) {
            return { success: true, data: messages.delete_success };
        } else {
            return { success: false, data: messages.not_found };
        }
    } catch (error) {
        logger.error(`Model - delete_blog_category - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};



exports.create_keyword = async (page_name, keywords, page_label, path) => {
    let connection;
    try {
        connection = await db.getConnection();

        const check_query = `SELECT COUNT(*) AS count FROM search_keywords WHERE page_name = ?`;
        const [rows] = await connection.execute(check_query, [page_name]);

        if (rows[0].count > 0) {
            return { success: false, data: messages.duplicate_page_data };
        }

        const insertQuery = `
            INSERT INTO search_keywords (page_name, keywords, page_label, path) 
            VALUES (?, ?, ?, ?)
        `;
        const [result] = await connection.execute(insertQuery, [page_name, JSON.stringify(keywords), page_label, path]);

        return result.affectedRows > 0
            ? { success: true, data: messages.insert_success }
            : { success: false, data: messages.insert_failed };

    } catch (error) {
        logger.error(`Model - Adding Search Keywords - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};


exports.update_keyword = async (id, keywords, page_name, page_label, path) => {
    let connection;
    try {
        connection = await db.getConnection();

        // Dynamically build the SET clause and values
        const fields = [];
        const values = [];

        if (keywords !== null && keywords !== undefined) {
            fields.push('keywords = ?');
            values.push(JSON.stringify(keywords));
        }

        if (page_name !== null && page_name !== undefined) {
            fields.push('page_name = ?');
            values.push(page_name);
        }

        if (page_label !== null && page_label !== undefined) {
            fields.push('page_label = ?');
            values.push(page_label);
        }

        if (path !== null && path !== undefined) {
            fields.push('path = ?');
            values.push(path);
        }

        if (fields.length === 0) {
            return { success: false, data: 'No fields provided to update.' };
        }

        const query = `
            UPDATE search_keywords 
            SET ${fields.join(', ')}
            WHERE id = ?
        `;

        values.push(id); // Add ID as the last value

        const [result] = await connection.execute(query, values);

        return result.affectedRows > 0
            ? { success: true, data: messages.update_success }
            : { success: false, data: messages.no_records_found };

    } catch (error) {
        logger.error(`Model - Updating Search Keywords - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

exports.get_keyword = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const [rows] = await connection.execute(
            'SELECT id, page_name, keywords, page_label, path FROM search_keywords'
        );

        rows.forEach(row => {
            if (typeof row.keywords === "string") {
                row.keywords = JSON.parse(row.keywords);
            }
        });

        return { success: true, data: rows };

    } catch (error) {
        logger.error(`Model - Updating Get Keywords - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

exports.add_technologies = async (tech) => {
    let connection;
    try {
        connection = await db.getConnection();
        const insertQuery = `
            INSERT INTO technologies (technology) 
            VALUES (?)
        `;
        const [result] = await connection.execute(insertQuery, [tech]);

        return result.affectedRows > 0
            ? { success: true, data: messages.insert_success }
            : { success: false, data: messages.insert_failed };
    } catch (error) {
        logger.error(`Model - Add Categories - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    }
}
exports.update_technologies = async (id, tech) => {
    let connection;
    try {
        connection = await db.getConnection();

        const updateQuery = `
            UPDATE technologies 
            SET technology = ? 
            WHERE id = ?
        `;

        const [result] = await connection.execute(updateQuery, [tech, id]);

        return result.affectedRows > 0
            ? { success: true, data: messages.update_success }
            : { success: false, data: messages.update_failed };

    } catch (error) {
        logger.error(`Model - Update Technologies - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

exports.delete_technologies = async (id) => {
    let connection;
    try {
        connection = await db.getConnection();

        const deleteQuery = `
            DELETE FROM technologies 
            WHERE id = ?
        `;

        const [result] = await connection.execute(deleteQuery, [id]);

        return result.affectedRows > 0
            ? { success: true, data: messages.delete_success }
            : { success: false, data: messages.delete_failed };

    } catch (error) {
        logger.error(`Model - Delete Technologies - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

exports.get_technologies = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const selectQuery = `
            SELECT id, technology, created_timestamp, updated_timestamp 
            FROM technologies
        `;

        const [rows] = await connection.execute(selectQuery);

        return rows.length > 0
            ? { success: true, data: rows }
            : { success: false, data: messages.no_records_found };

    } catch (error) {
        logger.error(`Model - Get Technologies - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};

exports.update_settings = async (key,value) =>{
    let connection;
    try {
        connection = await db.getConnection();

        const update_query = `
           UPDATE settings SET settings_value = ? WHERE settings_key = ? 
        `;
        const query_params = [value, key];

        const [rows] = await connection.execute(update_query, query_params);

        return rows.affectedRows > 0
            ? { success: true, data: messages.update_success}
            : { success: false, data: messages.update_failed };

    } catch (error) {
        logger.error(`Model - Update settings - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
}
exports.get_settings = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const selectQuery = `
            SELECT settings_key, settings_value FROM settings
        `;

        const [rows] = await connection.execute(selectQuery);

        return rows.length > 0
            ? { success: true, data: rows }
            : { success: false, data: messages.no_records_found };

    } catch (error) {
        logger.error(`Model - Get settings - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
}
exports.get_settings_user = async (settings_key) => {
    let connection;
    try {
        connection = await db.getConnection();

        const selectQuery = `
            SELECT settings_value FROM settings where settings_key = ?
        `;

        const [rows] = await connection.execute(selectQuery,[settings_key]);

        return rows.length > 0
            ? { success: true, data: rows[0]["settings_value"] }
            : { success: false, data: messages.no_records_found };

    } catch (error) {
        logger.error(`Model - Get settings based on key - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
}

exports.get_counts = async (table_name) => {
    let connection;
    try {
        const allowedTables = ['blog', 'pages', 'admin_user', 'user_notes']; // Update as needed
        if (!allowedTables.includes(table_name)) {
            return { success: false, data: 'Invalid table name' };
        }

        connection = await db.getConnection();

        const selectQuery = `SELECT COUNT(*) AS count FROM \`${table_name}\``;

        const [rows] = await connection.query(selectQuery);

        return rows.length > 0
            ? { success: true, data: rows[0].count }
            : { success: false, data: messages.no_records_found };

    } catch (error) {
        logger.error(`Model - Get Count - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) connection.release();
    }
};





