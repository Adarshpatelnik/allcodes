const logger = require('../config/logger');
const db = require('../config/db');
const messages = require('../utils/messages');

exports.drop_a_note = async ({ user_name, mail_id, phone_number, company_name, topic, country, message }) => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `
            INSERT INTO user_notes (user_name, mail_id, phone_number, company_name, topic, country, messages) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;
        const query_params = [ user_name, mail_id, phone_number, company_name, topic, country, message ];
        const [result] = await connection.execute(query, query_params);

        if (result.affectedRows > 0) {

            return { success: true, data: messages.insert_success };
        } else {
            return { success: false, data: messages.insert_failed };
        }
    } catch (error) {
        logger.error(`Model - add Drop a note - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};

exports.get_drop_a_note = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT id, user_name, mail_id, phone_number, company_name, topic, country, messages, created_timestamp FROM user_notes ORDER BY id DESC
        `;

        const [result] = await connection.execute(query);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get drop a note - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
}


exports.add_faq = async ({ question, answer, status }) => {
    let connection;
    try {
        connection = await db.getConnection();
        const query = `
            INSERT INTO faq (question, answer, status) 
            VALUES (?, ?, ?)
        `;
        const query_params = [question, answer, status];
        const [result] = await connection.execute(query, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.insert_success };
        } else {
            return { success: false, data: messages.insert_failed };
        }
    } catch (error) {
        logger.error(`Model - add FAQs - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};
exports.update_faq = async ({ id, question, answer, status }) => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            UPDATE faq 
            SET question = ?, answer = ?, status = ? 
            WHERE id = ?
        `;
        const query_params = [question, answer, status, id];
        const [result] = await connection.execute(query, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.update_success };
        } else {
            return { success: false, data: messages.update_failed };
        }
    } catch (error) {
        logger.error(`Model - update_faq - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


exports.delete_faq = async ({ id }) => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            DELETE FROM faq WHERE id = ?
        `;

        const query_params = [id];
        const [result] = await connection.execute(query, query_params);

        if (result.affectedRows > 0) {
            return { success: true, data: messages.delete_success };
        } else {
            return { success: false, data: messages.delete_failed };
        }
    } catch (error) {
        logger.error(`Model - delete faq - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};

exports.get_faq = async () => {
    let connection;
    try {
        connection = await db.getConnection();

        const query = `
            SELECT id, question, answer, status FROM faq
        `;

        const [result] = await connection.execute(query);

        if (result.length > 0) {
            return { success: true, data: result };
        } else {
            return { success: false, data: messages.no_data_found };
        }
    } catch (error) {
        logger.error(`Model - get faq - Error: ${error.message}`);
        return { success: false, data: messages.internal_server_error };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};


