const express = require('express');
const router = express.Router();
const authenticate_token = require("../middlewares/authenticateToken");
const auth_controller = require('../controllers/auth_controller');

router.post('/admin_login', auth_controller.admin_login);
router.post('/admin_register', auth_controller.admin_register);
router.post('/change_password', authenticate_token, auth_controller.change_password);

// Forgot password start
router.post('/forget_password',auth_controller.forgetPasswordSendMail);
router.post('/reset_password',auth_controller.reset_password);
// Forgot password end

module.exports = router;