const express = require('express');
const router = express.Router();
const authenticate_token = require("../middlewares/authenticateToken");
const cms_controller = require('../controllers/cms_controller');
const multer = require('multer');

// Multer configuration for get multiple images
const storage = multer.memoryStorage(); 
const upload = multer({
    storage,
    limits: { fileSize: 10 * 1024 * 1024 } 
});

const uploads = multer({
    storage,
    limits: { fileSize: 10 * 1024 * 1024 } 
}).any(); 

// Page and Section Routes
router.post('/insert_single/:page_name/:section_name', authenticate_token, upload.single('image'), cms_controller.insert_single_image_section);
router.get('/get_single/:page_name/:section_name', authenticate_token, cms_controller.get_single_image_section);

// Single Image Routes
router.post('/insert_page', authenticate_token, cms_controller.insert_page);
router.post('/insert_section', authenticate_token, cms_controller.insert_section);
router.get('/get_page_section_details',authenticate_token, cms_controller.get_page_section_details);

// Multiple image in a single API
router.post('/insert_multiple_in_single_request/:page_name/:section_name', authenticate_token, uploads, cms_controller.insert_multiple_in_single_request);

// Multiple Images Routes
router.post('/insert_multiple/:page_name/:section_name', authenticate_token, upload.single('image'), cms_controller.insert_multiple);
router.post('/update_multiple/:page_name/:section_name', authenticate_token, upload.single('image'), cms_controller.update_multiple);
router.get('/get_multiple/:page_name/:section_name', authenticate_token, cms_controller.get_multiple);
router.post('/delete_multiple/:page_name/:section_name',authenticate_token, cms_controller.delete_multiple);

// Whole Page get
// router.get('/get_page_details/:access/:page_name', authenticate_token, cms_controller.get_page_details);
router.get('/get_page_details/:access/:page_name', cms_controller.get_page_details);

// Case Study Get
router.get('/get_case_study_admin/:parent_id', authenticate_token, cms_controller.get_case_study);
router.get('/get_case_study_user', cms_controller.get_case_study_user);

module.exports = router;