const express = require('express');
const router = express.Router();
const authenticate_token = require("../middlewares/authenticateToken");
const common_controller = require("../controllers/common_controller");
const config = require("../config/config");
const multer = require('multer');
const fs = require('fs');

router.post('/insert_contact_details', common_controller.insert_contact_details);
router.get('/get_contact_details', authenticate_token, common_controller.get_contact_details);

router.post('/insert_join_community', common_controller.insert_join_community);
router.get('/get_join_community', authenticate_token, common_controller.get_join_community);

router.post('/insert_subscribe', common_controller.insert_subscribe);
router.post('/unsubscribe', common_controller.unsubscribe);
router.post('/remove_from_community', common_controller.remove_from_community);
router.get('/get_subscribe', authenticate_token, common_controller.get_subscribe);
// Blog routes start


// Ensure blog image directory exists
const BLOG_IMAGE_FOLDER = "src/"+config.asset_folder_blog;
if (!fs.existsSync(BLOG_IMAGE_FOLDER)) {
    fs.mkdirSync(BLOG_IMAGE_FOLDER, { recursive: true });
}

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

router.post(
    '/add_blog',
    authenticate_token,
    upload.fields([
      { name: 'cover_image', maxCount: 1 },
      { name: 'profile_img', maxCount: 1 }
    ]),
    common_controller.add_blog
  );

router.post('/update_blog', authenticate_token,  upload.fields([
  { name: 'cover_image', maxCount: 1 },
  { name: 'profile_img', maxCount: 1 }
]), common_controller.update_blog);


// router.post('/add_blog', authenticate_token, upload.single('cover_image'), common_controller.add_blog);
// router.post('/update_blog', authenticate_token, upload.single('cover_image'), common_controller.update_blog);
router.post('/delete_blog', authenticate_token, common_controller.delete_blog);
router.get('/get_blogs', authenticate_token, common_controller.get_blogs); //admin
router.get('/get_blogs_by_catogories', common_controller.get_blog_category); //user
router.get('/get_blog/:id', common_controller.get_blog_by_id);  //user
router.get('/get_blogs_by_status/:status' , common_controller.get_blogs_by_status); //user
router.get('/get_recent_blogs', common_controller.get_recent_blogs);

router.post('/add_blog_category', authenticate_token, common_controller.add_blog_category);
router.post('/update_blog_category', authenticate_token, common_controller.update_blog_category);
router.get('/get_blog_category', authenticate_token, common_controller.get_blog_category);
router.get('/get_blog_category_count', common_controller.get_blog_category_count);
router.post('/delete_blog_category', authenticate_token, common_controller.delete_blog_category);

// Blog routes end


// keyword routes start
router.post('/create_keyword', authenticate_token, common_controller.create_keyword);
router.post('/update_keyword', authenticate_token, common_controller.update_keyword);
router.get('/get_keyword', authenticate_token, common_controller.get_keyword);
router.get('/get_keyword_user', common_controller.get_keyword);
// keyword routes end

// Technologies routes start
router.post('/technologies/:action', authenticate_token, common_controller.technologies);
router.get('/technologies/:action', authenticate_token, common_controller.technologies);
// Technologies routes end

// Settings API start 
router.post('/update_settings', authenticate_token, common_controller.update_settings);
router.get('/get_settings', authenticate_token, common_controller.get_settings);
router.get('/get_settings_user/:settings_key', common_controller.get_settings_user);

// Settings API end

// Count routes start
router.get('/get_counts/:table_name', authenticate_token, common_controller.get_counts);
// Count routes end

module.exports = router;