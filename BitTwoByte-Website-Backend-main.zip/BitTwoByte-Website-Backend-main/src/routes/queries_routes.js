const express = require('express');
const router = express.Router();
const authenticate_token = require("../middlewares/authenticateToken");
const queries_controller = require("../controllers/queries_controller");

router.post('/faq/:action', authenticate_token, queries_controller.faq);
router.get('/faq/:action', authenticate_token, queries_controller.faq);
router.post('/drop_a_note', queries_controller.drop_a_note);
router.get('/drop_a_note',authenticate_token, queries_controller.get_drop_a_note);


module.exports = router;