import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { pageRoutes } from './routes/pageRoutes';
import NotFound from './components/notfound';
import Login from './components/login';
import "./App.css";
import Unauthorized from './components/unauthorized';
import Dashboard from './pages/Dashboard/dashboard';
import HomePage from './pages/Home/homepage';
import DataAnalytics from './pages/DataAnalytics/Dataanalytics';
import ProtectedRoute from './routes/ProtectedRoute';
import CloudServices from './pages/CloudServices/CloudServices';
import DataGovernance from './pages/DataGovernance/DataGovernance';
import DataEngineering from './pages/DataEngineering/DataEngineering';
import SupplyChain from './pages/SupplyChain/SupplyChain';
import DataScience from './pages/DataScience/DataScience';
import AboutUs from './pages/Aboutus/AboutUs';
import FAQs from './pages/faqs/FAQs';
import ContactUs from './pages/ContactUs/ContactUs';
import Careers from './pages/Careers/Careers';
import CaseStudy from './pages/CaseStudy/CaseStudy';
import ManagementConsulting from './pages/ManagementConsulting/ManagementConsulting';
import Implementation from './pages/Implementation Services/Implementation';
import Migration from './pages/Migration/Migration';
import Managed from './pages/ManagedServices/Managed';
import Staffing from './pages/Staffing/Staffing';
import HealthCare from './pages/HealthCare/HealthCare';
import Banking from "./pages/Banking/Banking";
import Retail from "./pages/Retail/Retail";
import Manufacturing from "./pages/Manufacturing/Manufacturing";
import Entertainment from "./pages/Entertainment/Entertainment";
import Technologies from './pages/Technologies/Technologies';
import Blogs from "./pages/Blogs/Blogs";
import SettingsHome from './pages/Settings/SettingsHome';
import UserQueries from "./pages/UserQueries/UserQueries";
import WorkTogether from "./pages/WorkTogether/WorkTogether";
import Ourcommunity from './pages/Ourcommunity/Ourcommunity';
import Subscribedusers from './pages/Subscribedusers/Subscribedusers';
import ForgotPassword from "./components/forgotpassword";
import ResetPassword from "./components/ResetPassword";
import ChangePassword from './components/ChangePassword';
import TokenMonitor from './routes/TokenMonitor';
import TermsandConditions from "./pages/TermsandConditions/TermsandConditions";
import PrivayPolicy from './pages/PrivacyPolicy/PrivacyPolicy';

function App() {
  return (
    <Router>
      <TokenMonitor />
      <Routes>
        {/* Login Route */}
        <Route path={pageRoutes.login} element={<Login />} />
        <Route path={pageRoutes.unauthorized} element={<Unauthorized />} />
        <Route path={pageRoutes.forgotpassword} element={<ForgotPassword />} />
        <Route path={pageRoutes.resetpassword} element={<ResetPassword />} />
        <Route element={<ProtectedRoute />}>
          {/* Change Password */}
          <Route path={pageRoutes.changepassword} element={<ChangePassword />} />
          {/* Dashboard */}
          <Route path={pageRoutes.dashboard} element={<Dashboard />} />
          <Route path={pageRoutes.blogs} element={<Blogs />} />
          <Route path={pageRoutes.casestudy} element={<CaseStudy />} />
          <Route path={pageRoutes.userqueries} element={<UserQueries />} />
          <Route path={pageRoutes.worktogether} element={<WorkTogether />} />
          <Route path={pageRoutes.ourcommunity} element={<Ourcommunity />} />
          <Route path={pageRoutes.subscribedusers} element={<Subscribedusers />} />

          {/* CMS */}
          <Route path={pageRoutes.home} element={<HomePage />} />
          <Route path={pageRoutes.aboutus} element={<AboutUs />} />
          <Route path={pageRoutes.faqs} element={<FAQs />} />
          <Route path={pageRoutes.dataanalytics} element={<DataAnalytics />} />
          <Route path={pageRoutes.cloudservices} element={<CloudServices />} />
          <Route path={pageRoutes.datagovernance} element={<DataGovernance />} />
          <Route path={pageRoutes.dataengineering} element={<DataEngineering />} />
          <Route path={pageRoutes.datascience} element={<DataScience />} />

          {/* SCM Services */}
          <Route path={pageRoutes.supplychain} element={<SupplyChain />} />
          <Route path={pageRoutes.managementconsulting} element={<ManagementConsulting />} />
          <Route path={pageRoutes.implementation} element={<Implementation />} />
          <Route path={pageRoutes.migration} element={<Migration />} />
          <Route path={pageRoutes.managed} element={<Managed />} />
          <Route path={pageRoutes.staffing} element={<Staffing />} />

          {/* Industries */}
          <Route path={pageRoutes.mediaandentertainment} element={<Entertainment />} />
          <Route path={pageRoutes.healthcare} element={<HealthCare />} />
          <Route path={pageRoutes.banking} element={<Banking />} />
          <Route path={pageRoutes.retail} element={<Retail />} />
          <Route path={pageRoutes.manufacturing} element={<Manufacturing />} />

          <Route path={pageRoutes.technologies} element={<Technologies />} />
          <Route path={pageRoutes.getintouch} element={<ContactUs />} />
          <Route path={pageRoutes.careers} element={<Careers />} />

          <Route path={pageRoutes.termsandconditions} element={<TermsandConditions />} />
          <Route path={pageRoutes.privacypolicy} element={<PrivayPolicy />} />
          <Route path={pageRoutes.settings} element={<SettingsHome />} />

        </Route>
        {/* Catch-All NotFound Route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
