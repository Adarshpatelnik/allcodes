.btn,
.grey-btn {
    text-transform: none !important;
    border-radius: 18px !important;
    color: #fff !important;
    font-family: mediumtxt !important
}

.btn,
.grey-btn,
body {
    font-family: mediumtxt !important
}

@font-face {
    font-family: mediumtxt;
    src: url("./assets/fonts/PlusJakartaSans-Medium.ttf") format('truetype')
}

@font-face {
    font-family: boldtxt;
    src: url("./assets/fonts/PlusJakartaSans-SemiBold.ttf") format('truetype')
}

@font-face {
    font-family: boldertxt;
    src: url("./assets/fonts/PlusJakartaSans-Bold.ttf") format('truetype')
}

.btn {
    background-color: #298939 !important
}

.grey-btn {
    background-color: #918c8b !important
}

.dotloader {
    width: 15px;
    aspect-ratio: 1;
    border-radius: 50%;
    animation: 1s linear infinite alternate l5
}

@keyframes l5 {
    0% {
        box-shadow: 20px 0 #298939, -20px 0 rgba(255, 96, 0, .2);
        background: #298939
    }

    33% {
        box-shadow: 20px 0 #298939, -20px 0 rgba(255, 96, 0, .2);
        background: rgba(255, 96, 0, .2)
    }

    66% {
        box-shadow: 20px 0 rgba(255, 96, 0, .2), -20px 0 #298939;
        background: rgba(255, 96, 0, .2)
    }

    100% {
        box-shadow: 20px 0 rgba(255, 96, 0, .2), -20px 0 #298939;
        background: #298939
    }
}

.w-100 {
    width: 100% !important
}

.mob-btn {
    display: none !important
}

.offcanvas-header {
    justify-content: end !important;
    border: none !important;
    background-color: #ff6b0175;
    color: #000;
    height: 3vh
}

.justify {
    justify-content: space-between;
    align-items: center !important
}

.align-center {
    display: flex;
    align-items: center !important;
    justify-content: center !important
}

.link {
    text-decoration: none !important
}

.sidebar_layout {
    width: 21%
}

.main_layout {
    width: 79%
}

.side-card {
    /* background: #2989392e !important; */
    background-image: url("../images/background.jpg") !important;
    color: #298939;
    overflow-y: scroll !important;
    bottom: 0;
    top: 0;
    width: 21%;
    position: fixed;
    box-shadow: rgba(50, 50, 93, .25) 0 50px 100px -20px, rgba(0, 0, 0, .3) 0 30px 60px -30px, rgba(10, 37, 64, .35) 0 -2px 6px 0 inset !important
}

.admin_text {
    color: #000;
    font-size: 15px;
    text-align: left;
    font-weight: 700
}

.bann-img {
    height: 210px;
    width: 100%
}

.form-control:disabled {
    background-color: #ced8e1;
    cursor: not-allowed;
    width: 100%
}

.cms-ban-img {
    height: 180px;
    width: 100%
}

@media only screen and (max-width:768px) {

    .mob-nav,
    .web-btn {
        display: none !important
    }

    .mob-btn {
        display: block !important
    }

    .main_layout,
    .side-card {
        width: 100% !important
    }

    .side-card {
        box-shadow: unset !important;
        /* margin-top: -11% */
        margin-top: -5%
    }

    .offcanvas-header {
        background-color: #ff6b010e;
        /* height: 3vh; */
        height: 6vh;
        z-index: 999
    }

    svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeMedium.css-i4bv87-MuiSvgIcon-root {
        width: 19px !important;
        height: 19px !important;
        color: #000 !important;
        margin-top: 1%
    }
}

/* .nav-link {
    color: #000;
    cursor: pointer
} */

.nav-link,
.nav-link * {
    color: #fff;
    cursor: pointer;
    transition: color 0.3s ease, text-shadow 0.3s ease;
}


/* .active-link-text,
.nav-link:hover {
    color: #298939;
    text-shadow:  0 0 35px rgba(41, 137, 57, 0.8);
} */

.nav-link:hover,
.nav-link:hover * {
    color: #298939 !important;
    /* text-shadow:  0 0 35px rgba(41, 137, 57, 0.8); */
    text-shadow: 0 0 35px rgba(255, 255, 255, 0.4);
}


.active-link-text,
.active-link-text * {
    color: #298939 !important;
    /* text-shadow:  0 0 35px rgba(41, 137, 57, 0.8); */
    text-shadow: 0 0 35px rgba(255, 255, 255, 0.4);
}

.active-link-text svg,
.nav-link:hover svg {
    text-shadow: 0 0 6px rgba(41, 137, 57, 0.4);
}

p {
    margin-bottom: 0
}

.dashboard_card {
    background-color: #ffff
}

.dash_text {
    color: #fff;
    /* font-size: 17px; */
    font-size: 16px;
    /* font-weight: 500; */
    margin-left: 10px !important;
    margin-bottom: 0 !important
}

.dash_count,
.swal2-confirm {
    background-color: #298939 !important
}

.dash_count_text,
.icon-wrapper svg {
    color: #fff
}

.custom-card {
    cursor: pointer;
    border-radius: 15px !important;
    /* background-color: #eaf5ec !important; */
    background-image: url("../images/background.jpg") !important;
    padding: 12px;
    height: 120px;
    display: flex;
    align-items: center;
    border: 1.5px solid #298939;
    /* box-shadow: 0 4px 12px rgba(41, 137, 57, .2) !important */
    box-shadow: 0 4px 12px rgba(41, 137, 57, .5) !important
}


.icon-wrapper {
    background-color: #05371e;
    padding: 10px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px rgba(41, 137, 57, .3) !important
}

.custom-card h4 {
    /* color: #012354; */
    color: #FFF;
    /* text-shadow: 0 0 35px rgba(255, 255, 255, 0.4); */
    text-shadow:  0 0 35px rgba(41, 137, 57, 0.4);
}

.custom-card p {
    /* color: #5f636e; */
    color: #FFF;
    /* text-shadow: 0 0 35px rgba(255, 255, 255, 0.4); */
    text-shadow:  0 0 35px rgba(41, 137, 57, 0.4);
}

.logout_dropdown {
    display: flex;
    flex-direction: row;
    justify-content: flex-end;
    align-items: center;
    width: 25%;
    margin-top: 8px
}

.dropbtn {
    border: none
}

.dropdown_component {
    position: relative;
    display: inline-block;
    cursor: pointer !important
}

.dropdown_component img {
    object-fit: contain;
    width: 35px;
    height: 35px;
    border-radius: 50%
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0 8px 16px 0 rgba(0, 0, 0, .2);
    z-index: 1
}

.dropdown-content p {
    font-size: 13px;
    color: #fd5000;
    padding: 6px 8px;
    text-decoration: none;
    display: block
}

.dropdown-content a:hover {
    background-color: #ddd
}

.dropdown_component:hover .dropdown-content {
    display: block
}

.status_form {
    display: flex;
    flex-direction: column
}

.foot-input {
    width: 240px !important
}

input {
    font-size: small !important
}

#custom-scroll::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(41, 137, 57, .3) !important;
    box-shadow: inset 0 0 6px rgba(41, 137, 57, .3) !important;
    border-radius: 10px !important;
    background-color: #f5f5f5 !important
}

#custom-scroll::-webkit-scrollbar {
    width: 3px !important;
    background-color: #f5f5f5 !important
}

@media only screen and (max-width:600px) {
    .logout_dropdown {
        width: auto !important
    }

    .main {
        margin-top: 10% !important
    }

    .multi-img {
        display: block !important
    }

    .card_img {
        margin-top: 25px;
    }
}

.loader-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 999
}

.spinner {
    border: 4px solid rgba(0, 0, 0, .1);
    border-top: 4px solid #4169e1;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: 1s linear infinite spin
}

@keyframes spin {
    0% {
        transform: rotate(0)
    }

    100% {
        transform: rotate(360deg)
    }
}

.ql-editor img {
    border: .5px solid #707070;
    border-radius: 10px;
    padding: 4px;
    max-width: 100%;
    margin-top: 13px;
    margin-right: 5px
}

.input-img,
.input-img-big,
.input-img-potrait {
    margin-bottom: 10px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(41, 137, 57, .5)
}

.input-img {
    height: 156px !important;
    width: 302px !important
}

.input-img-potrait {
    height: 380px !important;
    width: 280px !important
}

.input-img-big {
    height: auto !important;
    width: 100% !important
}

.foot-input-wrapper {
    display: flex;
    align-items: center;
    gap: 8px
}

.foot-input {
    font-family: mediumtxt;
    font-size: 14px;
    color: #05371e !important;
    border: 1px solid rgba(0, 0, 0, .23);
    border-radius: 6px;
    cursor: pointer;
    transition: border-color .3s ease-in-out, box-shadow .3s ease-in-out
}

.foot-input:focus {
    border-color: #298939 !important;
    box-shadow: 0 0 5px rgba(41, 137, 57, .5);
    outline: 0
}

.foot-input::-webkit-file-upload-button,
.foot-input::file-selector-button {
    background-color: #298939;
    color: #fff;
    font-family: mediumtxt;
    font-size: 14px;
    border: none;
    border-radius: 6px;
    cursor: pointer
}

.foot-input::-webkit-file-upload-button:hover,
.foot-input::file-selector-button:hover {
    color: #298939 !important;
    background-color: #fff;
    border: 1px solid #122215
}

.card_img {
    height: 325px;
    width: 100%;
    border-radius: 16px
}

.collab_card_img {
    height: auto;
    max-height: 150px;
    width: 100%;
    object-fit: contain;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(41, 137, 57, .5)
}

.tag-item {
    display: inline-block;
    background-color: #fff;
    padding: 8px 16px;
    border-radius: 999px;
    font-size: 14px;
    font-weight: 500;
    color: #000;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    font-family: 'Inter', sans-serif;
    white-space: nowrap;
    transition: all 0.2s ease;
}

.tag-item:hover {
    background-color: #f0f0f0;
}


.forgot-password {
    cursor: pointer;
    text-decoration: none;
    color: #012354;
}

.forgot-password:hover {
    color: #012354;
}

.custom_menu_item {
    color: #012354 !important;
    font-family: "mediumtxt" !important;
}

.custom_menu_item:hover {
    color: #298939 !important;
    background-color: transparent;
}

/* .Bg{
    background-image: url("../images/background.jpg");
} */

.Bg {
    background-image: url("../images/background.jpg");
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
}