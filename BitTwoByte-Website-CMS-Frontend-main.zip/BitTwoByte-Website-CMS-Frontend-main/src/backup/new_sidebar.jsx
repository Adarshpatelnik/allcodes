import React, { useState, useEffect, useRef } from "react";
import Card from "@mui/material/Card";
import { CardContent } from "@mui/material";
import { useLocation, Link } from "react-router-dom";
import "../../assets/styles/custom.css";
import Logo from "../../assets/images/logo.svg";
import { pageRoutes } from "../../routes/pageRoutes";
import { Collapse } from "@mui/material";
import {
  Info,
  ExpandMore,
  ExpandLess,
  SpaceDashboard,
  BallotOutlined,
  Home,
  BusinessOutlined,
  QueryStatsOutlined,
  FilterDramaOutlined,
  PolicyOutlined,
  SettingsApplicationsOutlined,
  Psychology,
  MonitorHeartOutlined,
  AccountBalanceOutlined,
  LocalMallOutlined,
  PrecisionManufacturingOutlined,
  DeveloperModeOutlined,
  ContactsOutlined,
  HelpOutline,
  Book,
  Analytics,
  BusinessCenter,
  Hub,
  AccountTree,
  PersonSearch,
  IntegrationInstructions,
  SystemUpdateAlt,
  SupportAgent,
  Movie,
  SupervisorAccount,
  Settings,
  Language,
  ContactSupport,
  Diversity3,
  Forum,
  ThumbUp,
} from "@mui/icons-material";

const SideBar = () => {
  const location = useLocation();
  const [openCms, setOpenCms] = useState(false);
  const [openservices, setOpenServices] = useState(false);
  const [openscm, setOpenSCM] = useState(false);
  const [openIndustries, setOpenInudstries] = useState(false);

  useEffect(() => {
    if (location.pathname.includes("cms")) {
      setOpenCms(true);
      if (location.pathname.includes("services")) {
        setOpenServices(true);
      }
      if (location.pathname.includes("scm")) {
        setOpenSCM(true);
      }
      if (location.pathname.includes("industries")) {
        setOpenInudstries(true);
      }
    } else {
      setOpenCms(false);
    }
  }, [location.pathname]);

  const handleCmsClick = () => {
    setOpenCms(!openCms);
  };

  const handleServicesClick = () => {
    setOpenServices(!openservices);
    setOpenSCM(false);
    setOpenInudstries(false);
  };

  const handleSCMClick = () => {
    setOpenSCM(!openscm);
    setOpenServices(false);
    setOpenInudstries(false);
  };

  const handleIndustriesClick = () => {
    setOpenSCM(false);
    setOpenServices(false);
    setOpenInudstries(!openIndustries);
  };

  return (
    <>
      <Card elevation={0} className="side-card scrollbar p-1" id="custom-scroll">
        {/* <CardContent> */}
        <div className="mb-3">
          <div className="text-center mt-lg-3 mt-5 ">
            <img alt="Logo" className="logo" src={Logo} />
          </div>
        </div>
        <div className="mt-4">
          <Link to={pageRoutes.dashboard} className="link">
            <div
              className={
                location.pathname.includes("dashboard")
                  ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                  : "d-flex mt-2 mx-4 align-items-center nav-link"
              }
            >
              <SpaceDashboard sx={{color: "#fff"}} />
              <h5 className="ms-2 dash_text">Dashboard</h5>
            </div>
          </Link>
          <Link to={pageRoutes.blogs} className="link">
            <div
              className={
                location.pathname.includes("blogs")
                  ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                  : "d-flex mt-2 mx-4 align-items-center nav-link"
              }
            >
              <Book sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">Blogs</h5>
            </div>
          </Link>
          <Link to={pageRoutes.casestudy} className="link">
            <div
              className={
                location.pathname.includes("case-study")
                  ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                  : "d-flex mt-2 mx-4 align-items-center nav-link"
              }
            >
              <Analytics sx={{color: "#fff"}} />
              <h5 className="ms-2 dash_text">Case Study</h5>
            </div>
          </Link>
          <Link to={pageRoutes.userqueries} className="link">
            <div
              className={
                location.pathname.includes("user-queries")
                  ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                  : "d-flex mt-2 mx-4 align-items-center nav-link"
              }
            >
              <ContactSupport sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">User Queries</h5>
            </div>
          </Link>
          <Link to={pageRoutes.worktogether} className="link">
            <div
              className={
                location.pathname.includes("work-together")
                  ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                  : "d-flex mt-2 mx-4 align-items-center nav-link"
              }
            >
              <Diversity3 sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">Work Together</h5>
            </div>
          </Link>
          <Link to={pageRoutes.ourcommunity} className="link">
            <div
              className={
                location.pathname.includes("our-community")
                  ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                  : "d-flex mt-2 mx-4 align-items-center nav-link"
              }
            >
              <Forum sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">Our Community</h5>
            </div>
          </Link>
          <Link to={pageRoutes.subscribedusers} className="link">
            <div
              className={
                location.pathname.includes("subscribed-users")
                  ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                  : "d-flex mt-2 mx-4 align-items-center nav-link"
              }
            >
              <ThumbUp sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">Subscribed Users</h5>
            </div>
          </Link>
        </div>

        <div
          className={
            location.pathname.includes("cms")
              ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
              : "mt-2 d-flex mx-4 align-items-center nav-link"
          }
          onClick={handleCmsClick}
        >
          <BallotOutlined sx={{color: "#fff"}}/>
          <h5 className="ms-2 dash_text">CMS</h5>
          {openCms ? (
            <ExpandLess className="ms-3" sx={{color: "#fff"}}/>
          ) : (
            <ExpandMore className="ms-3" sx={{color: "#fff"}}/>
          )}
        </div>
        <Collapse in={openCms} className="cms-section">
          <div className="mt-2 mx-4 ps-3">
            <Link to={pageRoutes.home} className="link">
              <div
                className={
                  location.pathname.includes("home")
                    ? "d-flex nav-link align-items-center active-link-text"
                    : "d-flex nav-link align-items-center"
                }
              >
                <Home sx={{color: "#fff"}}/>
                <h5 className="ms-2 dash_text">Home</h5>
              </div>
            </Link>
          </div>
          <div className="mt-2 mx-4 ps-3">
            <Link to={pageRoutes.aboutus} className="link">
              <div
                className={
                  location.pathname.includes("about-us")
                    ? "d-flex nav-link align-items-center active-link-text"
                    : "d-flex nav-link align-items-center"
                }
              >
                <Info sx={{color: "#fff"}}/>
                <h5 className="ms-2 dash_text">About Us</h5>
              </div>
            </Link>
          </div>
          <div className="mt-2 mx-4 ps-3">
            <Link to={pageRoutes.faqs} className="link">
              <div
                className={
                  location.pathname.includes("faqs")
                    ? "d-flex nav-link align-items-center active-link-text"
                    : "d-flex nav-link align-items-center"
                }
              >
                <HelpOutline sx={{color: "#fff"}}/>
                <h5 className="ms-2 dash_text">FAQ</h5>
              </div>
            </Link>
          </div>

          {/*Services */}
          <div className="mt-2 mx-4 ps-3">
            <div
              className={
                location.pathname.includes("services")
                  ? "d-flex nav-link align-items-center active-link-text"
                  : "d-flex nav-link align-items-center"
              }
              onClick={handleServicesClick}
            >
              <Language sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">Services</h5>
              {openservices ? (
                <ExpandLess className="ms-3" sx={{color: "#fff"}}/>
              ) : (
                <ExpandMore className="ms-3" sx={{color: "#fff"}}/>
              )}
            </div>
          </div>
          <Collapse in={openservices} className="cms-section">
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.dataanalytics} className="link">
                <div
                  className={
                    location.pathname.includes("data-analytics")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <QueryStatsOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Data Analytics</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.cloudservices} className="link">
                <div
                  className={
                    location.pathname.includes("cloud-services")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <FilterDramaOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Cloud Service</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.datagovernance} className="link">
                <div
                  className={
                    location.pathname.includes("data-governance")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <PolicyOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Data Governance</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.dataengineering} className="link">
                <div
                  className={
                    location.pathname.includes("data-engineering")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <SettingsApplicationsOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Data Engineering</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.datascience} className="link">
                <div
                  className={
                    location.pathname.includes("data-science")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <Psychology sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Data Science</h5>
                </div>
              </Link>
            </div>
          </Collapse>

          {/*SCM Services */}
          <div className="mt-2 mx-4 ps-3">
            <div
              className={
                location.pathname.includes("scm")
                  ? "d-flex nav-link align-items-center active-link-text"
                  : "d-flex nav-link align-items-center"
              }
              onClick={handleSCMClick}
            >
              <Hub sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">SCM Services</h5>
              {openscm ? (
                <ExpandLess className="ms-3" sx={{color: "#fff"}}/>
              ) : (
                <ExpandMore className="ms-3" sx={{color: "#fff"}}/>
              )}
            </div>
          </div>
          <Collapse in={openscm} className="cms-section">
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.supplychain} className="link">
                <div
                  className={
                    location.pathname.includes("supply-chain")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <AccountTree sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Supply Chain</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.managementconsulting} className="link">
                <div
                  className={
                    location.pathname.includes("management-consulting")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <SupervisorAccount sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Management <br />Consulting</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.implementation} className="link">
                <div
                  className={
                    location.pathname.includes("implementation-services")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <IntegrationInstructions sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Implementation <br />Services</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.migration} className="link">
                <div
                  className={
                    location.pathname.includes("upgrade-and-migration-services")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <SystemUpdateAlt sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Upgrade and<br />Migration Services</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.managed} className="link">
                <div
                  className={
                    location.pathname.includes("managed-services")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <SupportAgent sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Managed<br />Services</h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.staffing} className="link">
                <div
                  className={
                    location.pathname.includes("staffing-IS-IT")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <PersonSearch sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">Staffing / IS / IT</h5>
                </div>
              </Link>
            </div>
          </Collapse>
          {/*Industry Services */}
          <div className="mt-2 mx-4 ps-3">
            <div
              className={
                location.pathname.includes("industries")
                  ? "d-flex nav-link align-items-center active-link-text"
                  : "d-flex nav-link align-items-center"
              }
              onClick={handleIndustriesClick}
            >
              <BusinessOutlined sx={{color: "#fff"}}/>
              <h5 className="ms-2 dash_text">Industries</h5>
              {openIndustries ? (
                <ExpandLess className="ms-3" sx={{color: "#fff"}}/>
              ) : (
                <ExpandMore className="ms-3" sx={{color: "#fff"}}/>
              )}
            </div>
          </div>
          <Collapse in={openIndustries} className="cms-section">
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.mediaandentertainment} className="link">
                <div
                  className={
                    location.pathname.includes("media-and-entertainment")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <Movie sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">
                    Media & Entertainment
                  </h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.healthcare} className="link">
                <div
                  className={
                    location.pathname.includes("healthcare")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <MonitorHeartOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">
                    Healthcare
                  </h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.banking} className="link">
                <div
                  className={
                    location.pathname.includes("banking")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <AccountBalanceOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">
                    Banking
                  </h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.retail} className="link">
                <div
                  className={
                    location.pathname.includes("retail")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <LocalMallOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">
                    Retail
                  </h5>
                </div>
              </Link>
            </div>
            <div className="mt-2 mx-4 ps-4">
              <Link to={pageRoutes.manufacturing} className="link">
                <div
                  className={
                    location.pathname.includes("manufacturing")
                      ? "d-flex nav-link align-items-center active-link-text"
                      : "d-flex nav-link align-items-center"
                  }
                >
                  <PrecisionManufacturingOutlined sx={{color: "#fff"}}/>
                  <h5 className="ms-2 dash_text">
                    Manufacturing
                  </h5>
                </div>
              </Link>
            </div>
          </Collapse>

          <div className="mt-2 mx-4 ps-3">
            <Link to={pageRoutes.technologies} className="link">
              <div
                className={
                  location.pathname.includes("technologies")
                    ? "d-flex nav-link align-items-center active-link-text"
                    : "d-flex nav-link align-items-center"
                }
              >
                <DeveloperModeOutlined sx={{color: "#fff"}}/>
                <h5 className="ms-2 dash_text">Technologies</h5>
              </div>
            </Link>
          </div>
          <div className="mt-2 mx-4 ps-3">
            <Link to={pageRoutes.getintouch} className="link">
              <div
                className={
                  location.pathname.includes("get-in-touch")
                    ? "d-flex nav-link align-items-center active-link-text"
                    : "d-flex nav-link align-items-center"
                }
              >
                <ContactsOutlined sx={{color: "#fff"}}/>
                <h5 className="ms-2 dash_text">Get In Touch</h5>
              </div>
            </Link>
          </div>
          <div className="mt-2 mx-4 ps-3">
            <Link to={pageRoutes.careers} className="link">
              <div
                className={
                  location.pathname.includes("careers")
                    ? "d-flex nav-link align-items-center active-link-text"
                    : "d-flex nav-link align-items-center"
                }
              >
                <BusinessCenter sx={{color: "#fff"}}/>
                <h5 className="ms-2 dash_text">Careers</h5>
              </div>
            </Link>
          </div>
        </Collapse>
        <Link to={pageRoutes.settings} className="link">
          <div
            className={
              location.pathname.includes("settings")
                ? "mt-2 mx-4 d-flex align-items-center nav-link active-link-text"
                : "d-flex mt-2 mx-4 align-items-center nav-link"
            }
          >
            <Settings sx={{color: "#fff"}}/>
            <h5 className="ms-2 dash_text">Settings</h5>
          </div>
        </Link>
        {/* </CardContent> */}
      </Card>
    </>
  );
};
export default SideBar;
