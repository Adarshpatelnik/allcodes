import React, { useState, useRef, useEffect } from "react";
import SideBar from "../pages/Sidebar/Sidebar";
import { Card, CardContent, IconButton, Button, Box } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import "../assets/styles/custom.css"
import "react-quill/dist/quill.snow.css";
import Swal from "sweetalert2";
import Dropdown from "./Dropdown";
import Loader from "./loader";
import apiFunctions from "../api/apiFunctions";
import messages from "../constants/messages";
import PasswordField from "./PasswordField";
import { jwtDecode } from "jwt-decode";

const ChangePassword = () => {
    const [isOpen, setIsopen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoader, setIsLoader] = useState(false);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    //Banner Section
    const [error, setError] = useState({});
    const [changePass, setChangePass] = useState({
        old_password: "",
        new_password: "",
        confirm_password: ""
    });

    const handleChangePassChange = (field, subfield, value) => {
        setChangePass((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
        setError((prev) => ({ ...prev, [field]: "" }));
    };

    const validatePassword = () => {
        const { old_password, new_password, confirm_password } = changePass;
        const errors = {};

        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

        if (!old_password) {
            errors.old_password = "Current password is required.";
        }

        if (!new_password) {
            errors.new_password = "New password is required.";
        } else if (!passwordRegex.test(new_password)) {
            errors.new_password = "Password must be at least 8 characters long, with uppercase, lowercase, number, and special character.";
        }

        if (!confirm_password) {
            errors.confirm_password = "Confirm password is required.";
        } else if (new_password !== confirm_password) {
            errors.confirm_password = "New password and confirm password do not match.";
        }

        setError(errors);
        return Object.keys(errors).length === 0;
    };


    const handleChangePasswordSave = async (e) => {
        e.preventDefault();
        if (!validatePassword()) return;
        setIsLoader(true);


        try {
            const token = localStorage.getItem('access-token');
            if (!token) {
                throw new Error("User is not authenticated.");
            }

            const decoded = jwtDecode(token);

            const user_id = decoded?.id;

            if (!user_id) {
                throw new Error("Invalid token. User ID not found.");
            }

            const json = {
                "user_id": user_id,
                "old_password": changePass?.old_password,
                "new_password": changePass?.new_password
            }


            const res = await apiFunctions.changePassword(json);

            if (res?.status === 200) {
                setChangePass({
                    old_password: "",
                    new_password: "",
                    confirm_password: ""
                });
                Swal.fire({
                    text: messages?.changePassword?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

            } else if (res?.status === 400) {
                throw new Error(messages?.changePassword?.incorrectCurrent);
            } else {
                throw new Error(messages?.changePassword?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const isFetched = useRef(false);
    useEffect(() => {
        let timeout = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        if (!isFetched.current) {
            isFetched.current = true;
        }

        return () => clearTimeout(timeout);
    }, []);


    return (
        <>
            <div className="container-fluid p-0 " style={{ overflow: 'hidden' }}>
                <div className="row">
                    <div className={`${isOpen ? "col-lg-2  mob-nav p-0" : "d-none"} sidebar_layout`}>
                        <SideBar />
                    </div>
                    <div className={`${isOpen ? "col-lg-10 col-12  " : "col-12 w-100"} dashboard_card main_layout`} >

                        <div className="d-flex w-100 justify mob-sticky mb-2">
                            <IconButton className="web-btn" onClick={handleOpen} >
                                <MenuIcon />
                            </IconButton>
                            <IconButton className="mob-btn" data-bs-toggle="offcanvas" data-bs-target="#mob-canvas" aria-controls="mob-canvas">
                                <MenuIcon />
                            </IconButton>
                            <div className="logout_dropdown">
                                <Dropdown />
                            </div>
                        </div>
                        {isLoading ?
                            <Loader /> :
                            <>
                                <Card className="p-lg-2 p-1">
                                    <CardContent>
                                        {/* Change Password */}
                                        <div className="row">
                                            <div className="col-lg-6 col-12">
                                                <h4 className="fw-medium" style={{ color: "#298939" }}>Account Security</h4>
                                                <h5 style={{ color: "#012354" }}>Change Password</h5>
                                            </div>
                                        </div>
                                        <form onSubmit={handleChangePasswordSave}>
                                            <div className="row mt-2">
                                                {/* Left Column */}
                                                <div className="col-lg-6 col-12">
                                                    <Box className="mb-2">
                                                        <PasswordField
                                                            size="small"
                                                            label="Current Password"
                                                            value={changePass?.old_password || ""}
                                                            onChange={(e) => handleChangePassChange("old_password", null, e.target.value)}
                                                            required
                                                            fullWidth
                                                            error={!!error.old_password}
                                                            helperText={error.old_password}
                                                        />
                                                    </Box>
                                                    <Box className="mb-2">
                                                        <PasswordField
                                                            size="small"
                                                            label="New Password"
                                                            value={changePass?.new_password || ""}
                                                            onChange={(e) => handleChangePassChange("new_password", null, e.target.value)}
                                                            required
                                                            fullWidth
                                                            error={!!error.new_password}
                                                            helperText={error.new_password}
                                                        />
                                                    </Box>
                                                    <Box className="mb-2">
                                                        <PasswordField
                                                            size="small"
                                                            label="Confirm Password"
                                                            value={changePass?.confirm_password || ""}
                                                            onChange={(e) => handleChangePassChange("confirm_password", null, e.target.value)}
                                                            required
                                                            fullWidth
                                                            error={!!error.confirm_password}
                                                            helperText={error.confirm_password}
                                                        />
                                                    </Box>
                                                    <div className="text-end">
                                                        {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                                        <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                                            {isLoader ? "Saving..." : "Save"}
                                                        </Button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </CardContent>
                                </Card>
                            </>
                        }
                    </div>
                </div>
            </div>
            <div className="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabIndex="-1" id="mob-canvas" aria-labelledby="mob-canvaslabel">
                <div className="offcanvas-header" style={{ background: "transparent" }}>
                    <IconButton data-bs-dismiss="offcanvas" aria-label="Close">
                        <CloseIcon style={{ height: '20px', width: '20px', color: 'black', marginTop: "20px" }} />
                    </IconButton>
                </div>
                <div className="offcanvas-body p-0">
                    <SideBar />
                </div>
            </div>
        </>
    )
}
export default ChangePassword;