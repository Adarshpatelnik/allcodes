import React, { useState, useEffect } from 'react';
import { Chip, Box, FormHelperText } from '@mui/material';
import CustomField from './CustomField';
import "../assets/styles/custom.css";

const ChipInput = ({
    label = 'New Tag',
    fieldLabel = 'Enter Tags',
    value = [],
    onChange,
    unique = true,
    helperText = 'Press Enter to add. Only unique entries allowed.',
    disabled = false,
}) => {
    const [input, setInput] = useState('');
    const [chips, setChips] = useState(value);
    const [error, setError] = useState(false);

    // Sync external value (from parent) with local state
    useEffect(() => {
        setChips(value);
    }, [value]);

    const handleKeyDown = (e) => {
        if (disabled) return;

        if ((e.key === 'Enter' || e.key === 'NumpadEnter') && input.trim()) {
            e.preventDefault();
            const newChip = input.trim();

            const isDuplicate = unique
                ? chips.some((chip) => chip.toLowerCase() === newChip.toLowerCase())
                : false;

            if (isDuplicate) {
                setError(true);
            } else {
                const updatedChips = [...chips, newChip];
                setChips(updatedChips);
                setError(false);
                onChange?.(updatedChips); // Notify parent component of change
            }

            setInput('');
        }
    };

    const handleDelete = (chipToDelete) => {
        if (disabled) return;

        const updatedChips = chips.filter((chip) => chip !== chipToDelete);
        setChips(updatedChips);
        onChange?.(updatedChips); // Notify parent component of change
    };

    return (
        <Box sx={{ border: '1px solid #ccc', padding: 2, borderRadius: 2 }}>
            <p style={{ marginBottom: '4px', color: "#012354" }}>{fieldLabel}</p>

            <FormHelperText sx={{ mb: 0.5, mt: 0, color: error ? 'error.main' : 'text.secondary' }}>
                {error ? 'This tag already exists.' : helperText}
            </FormHelperText>

            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                {chips.map((chip, index) => (
                    <Chip
                        key={index}
                        label={chip}
                        // onDelete={() => handleDelete(chip)}
                        onDelete={disabled ? undefined : () => handleDelete(chip)}
                        sx={{
                            backgroundColor: '#e0e0e0',
                            color: '#333',
                        }}
                    />
                ))}
            </Box>

            <CustomField
                variant="outlined"
                size="small"
                value={input}
                onChange={(e) => {
                    setInput(e.target.value);
                    setError(false);
                }}
                onKeyDown={handleKeyDown}
                label={label}
                fullWidth
                error={error}
                disabled={disabled}
            />
        </Box>
    );
};

export default ChipInput;
