import React from "react";
import { styled } from "@mui/material/styles";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import TextField from "@mui/material/TextField";
import "../assets/styles/custom.css";

// Custom styled TextField
const CustomTextField = styled(TextField)({
    "& label": {
        fontFamily: "mediumtxt",
        fontSize: "14px",
    },
    "& label.Mui-focused": {
        color: "#298939",
    },
    "& .MuiOutlinedInput-root": {
        "& fieldset": {
            borderColor: "rgba(0, 0, 0, 0.23)",
        },
        "&:hover fieldset": {
            borderColor: "rgba(0, 0, 0, 0.87)",
        },
        "&.Mui-focused fieldset": {
            borderColor: "#298939",
        },
    },
    "& .MuiInputBase-input": {
        color: "#05371E !important",
        fontFamily: "mediumtxt",
    },
    "& .MuiOutlinedInput-root.Mui-focused .MuiInputBase-input": {
        color: "#05371E !important",
        fontFamily: "mediumtxt",
    },
});

// Custom DatePicker component
// const CustomDatePicker = ({ size = "medium", fullWidth = false, ...props }) => {
//     return (
//         <DatePicker
//             {...props}
//             slots={{
//                 textField: (params) => <CustomTextField {...params} />,
//             }}
//             slotProps={{
//                 textField: {
//                     size,
//                     fullWidth,
//                 },
//                 popper: {
//                     disablePortal: true, // ← THIS fixes the flash/glitch
//                     modifiers: [
//                         {
//                             name: "preventOverflow",
//                             options: {
//                                 boundary: "viewport", // Ensures it stays within screen
//                             },
//                         },
//                     ],
//                 },
//             }}
//         />
//     );
// };

const CustomDatePicker = ({ size = "medium", fullWidth = false, required = false, ...props }) => {
    return (
        <DatePicker
            {...props}
            slots={{
                textField: (params) => <CustomTextField {...params} required={required} />,
            }}
            slotProps={{
                textField: {
                    size,
                    fullWidth,
                },
                popper: {
                    disablePortal: true,
                    modifiers: [
                        {
                            name: "preventOverflow",
                            options: {
                                boundary: "viewport",
                            },
                        },
                    ],
                },
            }}
        />
    );
};


export default CustomDatePicker;
