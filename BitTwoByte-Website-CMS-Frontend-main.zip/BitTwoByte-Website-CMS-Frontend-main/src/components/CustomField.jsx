import React from "react";
import TextField from "@mui/material/TextField";
import { styled } from "@mui/material/styles";
import "../assets/styles/custom.css"

const CustomTextField = styled(TextField)({
  "& label": {
    fontFamily: "mediumtxt", // Custom font for label
    fontSize: "14px", // Default label font size
  },
  "& label.Mui-focused": {
    color: "#298939",
  },
  "& .MuiOutlinedInput-root": {
    "& fieldset": {
      borderColor: "rgba(0, 0, 0, 0.23)", // Default Material-UI color
    },
    "&:hover fieldset": {
      borderColor: "rgba(0, 0, 0, 0.87)", // Darker on hover
    },
    "&.Mui-focused fieldset": {
      borderColor: "#298939", // Custom color when focused
    },
  },
  "& .MuiInputBase-input": {
    color: "#05371E !important", // Default text color
    fontFamily: "mediumtxt", 
  },
  "& .MuiOutlinedInput-root.Mui-focused .MuiInputBase-input": {
    color: "#05371E !important", // Custom text color when focused
    fontFamily: "mediumtxt", 
  },
});

const CustomField = (props) => {
  return <CustomTextField {...props} />;
};

export default CustomField;