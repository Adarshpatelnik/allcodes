import React from 'react';
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material';

const CustomSelect = ({
  value,
  onChange,
  label,
  options,
  id,
  size = 'medium',
  disabled = false,
  showNoneOption = false,
  required = false,
  optionLabelKey = 'technology',
  optionValueKey = 'id',
}) => {
  return (
    <FormControl fullWidth className="mt-2" size={size}
      sx={{
        '&:hover': disabled
          ? {
            cursor: 'not-allowed',
            '& .MuiSelect-select, & .MuiOutlinedInput-notchedOutline, & .MuiSvgIcon-root': {
              cursor: 'not-allowed',
            },
          }
          : {},
      }}
    >
      <InputLabel
        id={`${id}-label`}
        sx={{
          color: 'gray',
          fontFamily: "mediumtxt",
          fontSize: "14px",
          '&.Mui-focused': { color: '#298939' },
        }}
      >
        {label}
      </InputLabel>
      <Select
        labelId={`${id}-label`}
        id={id}
        value={value}
        label={label}
        onChange={onChange}
        disabled={disabled}
        required={required}
        size={size}
        sx={{
          fontFamily: "mediumtxt",
          fontSize: "14px",
          color: '#05371E', // default text color
          '.MuiOutlinedInput-notchedOutline': {
            borderColor: "rgba(0, 0, 0, 0.23)"
          },
          '&:hover .MuiOutlinedInput-notchedOutline': {
            borderColor: "rgba(0, 0, 0, 0.87)",// hover = black outline
          },
          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: '#298939', // focus = green
          },
          '&.Mui-focused': {
            color: '#05371E',
          },
          '&:hover': {
            color: '#05371E',
          },
          '.MuiSvgIcon-root': {
            color: 'gray', // default
          },
          '&:hover .MuiSvgIcon-root': {
            color: 'black', // hover
          },
          '&.Mui-focused .MuiSvgIcon-root': {
            color: '#298939', // focused
          },

        }}
      >
        {showNoneOption && (
          <MenuItem value="" sx={{ fontFamily: "mediumtxt", fontSize: "14px" }}>
            None
          </MenuItem>
        )}
        {options.map((opt) => (
          <MenuItem
            key={opt[optionValueKey]}
            value={opt[optionValueKey]}
            sx={{ fontFamily: "mediumtxt", fontSize: "14px" }}
          >
            {opt[optionLabelKey]}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default CustomSelect;
