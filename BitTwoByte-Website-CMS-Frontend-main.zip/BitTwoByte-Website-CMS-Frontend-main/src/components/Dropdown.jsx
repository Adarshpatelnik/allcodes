import React, { useState } from "react";
import "../assets/styles/custom.css";
import { Link } from "react-router-dom";
import { pageRoutes } from "../routes/pageRoutes";
import Logout from "./Logout";
import { jwtDecode } from "jwt-decode";
import { Avatar, Menu, MenuItem } from "@mui/material";

export default function Dropdown() {
    // const token = localStorage.getItem("access-token");
    // const decodedToken = jwtDecode();

    const formatRole = (role) => {
        return role
            .split("_")
            .map(word => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ");
    };

    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <div className="dropdown_component" style={{ display: "flex", alignItems: "center", marginRight: "10px" }}>
            {/* <p style={{ cursor: "pointer", marginRight: "10px" }}>{formatRole(decodedToken?.role)}</p> */}
            <Avatar
                sx={{ bgcolor: "#298939", cursor: "pointer" }}
                // alt={formatRole(decodedToken?.role)}
                src="/broken-image.jpg"
                onClick={handleClick}
            />
            <Menu
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                transformOrigin={{ vertical: "top", horizontal: "right" }}
            >
                <MenuItem onClick={handleClose} component={Link} to={pageRoutes?.changepassword} className="custom_menu_item">Change Password</MenuItem>
                {/* <MenuItem onClick={handleClose} component={Link} to={pageRoutes.settings}>Settings</MenuItem> */}
                {/* <MenuItem onClick={handleClose} component={Link} to={pageRoutes.help}>Help</MenuItem> */}
                <MenuItem onClick={handleClose}>
                    <Logout />
                </MenuItem>
            </Menu>
        </div>
    );
}
