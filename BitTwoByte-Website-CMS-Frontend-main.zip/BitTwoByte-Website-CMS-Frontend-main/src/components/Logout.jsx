import { Button } from "@mui/material";
import React from "react";
import LogoutIcon from '@mui/icons-material/Logout';
import Swal from "sweetalert2";
import Logo from "../assets/images/logo.svg";
import "../assets/styles/custom.css";

const Logout = () => {
    const handleLogout = () => {
        Swal.fire({
            text: "Are you sure you want to log out?",
            showConfirmButton: true,
            showCancelButton: true,
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
            imageUrl: Logo,
            // icon: 'warning',
            customClass: {
                confirmButton: 'swal2-confirm',
                cancelButton: 'swal2-cancel',
                image: "logo"
            }

        }
        ).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                localStorage.clear();
                Swal.fire({
                    title: '',
                    text: 'Logged out successfully.',
                    icon: 'success',
                    showConfirmButton: false,
                });
                setTimeout(() => {
                    window.location.replace("/");
                }, 1000);

                // .then((res) => {
                //     localStorage.clear();
                //     window.location.replace("/");
                // });
            }
        }
        )
    }
    return (
        <>
            {/* <Button onClick={handleLogout} style={{ textTransform: 'none', fontFamily: "mediumtxt" }} startIcon={<LogoutIcon />} >Logout</Button> */}
            <Button
                onClick={handleLogout}
                style={{
                    textTransform: 'none',
                    fontFamily: "mediumtxt",
                    color: "#298939"
                }}
                startIcon={<LogoutIcon style={{ color: "#298939" }} />}
            >
                Logout
            </Button>

        </>
    )
}
export default Logout;