import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import {
  FormControl,
  InputLabel,
  OutlinedInput,
  InputAdornment,
  IconButton,
  Typography,
} from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";

const CustomOutlinedInput = styled(OutlinedInput)({
  "& fieldset": {
    borderColor: "rgba(0, 0, 0, 0.23)", // Default border color
  },
  "&:hover fieldset": {
    borderColor: "rgba(0, 0, 0, 0.87)", // Darker on hover
  },
  "&.Mui-focused fieldset": {
    borderColor: "#298939 !important", // Your custom focus color
  },
  "& .MuiInputBase-input": {
    color: "#05371E !important", // Your custom text color
    fontFamily: "mediumtxt",
  },
  "&.Mui-focused .MuiInputBase-input": {
    color: "#05371E !important", // Text color remains the same when focused
  },
});

const CustomInputLabel = styled(InputLabel)({
  fontFamily: "mediumtxt",
  fontSize: "14px",
  color: "rgba(0, 0, 0, 0.6)", // Default label color
  "&.Mui-focused": {
    color: "#298939 !important", // Custom focus color for label
  },
});

// const CustomOutlinedInput = styled(OutlinedInput, {
//   shouldForwardProp: (prop) => prop !== "size",
// })(({ size }) => ({
//   "& fieldset": {
//     borderColor: "rgba(0, 0, 0, 0.23)",
//   },
//   "&:hover fieldset": {
//     borderColor: "rgba(0, 0, 0, 0.87)",
//   },
//   "&.Mui-focused fieldset": {
//     borderColor: "#298939 !important",
//   },
//   "& .MuiInputBase-input": {
//     color: "#05371E !important",
//     fontFamily: "mediumtxt",
//     padding: size === "small" ? "10.5px 14px" : undefined, // fix padding for small
//   },
// }));

// const CustomInputLabel = styled(InputLabel)(({ theme }) => ({
//   fontFamily: "mediumtxt",
//   fontSize: "14px",
//   color: "rgba(0, 0, 0, 0.6)",
//   "&.Mui-focused": {
//     color: "#298939 !important",
//   },
// }));

const PasswordField = ({ value, onChange, error, label = "Password", helperText, size = "medium" }) => {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <FormControl variant="outlined" fullWidth error={!!error} size={size}>
      <CustomInputLabel>{label}</CustomInputLabel>
      <CustomOutlinedInput
        type={showPassword ? "text" : "password"}
        value={value}
        onChange={onChange}
        endAdornment={
          <InputAdornment position="end">
            <IconButton
              onClick={() => setShowPassword(!showPassword)}
              edge="end"
            >
              {showPassword ? <Visibility /> : <VisibilityOff />}
            </IconButton>
          </InputAdornment>
        }
        label={label}
        size={size}
      />
      {helperText && (
        <Typography variant="caption" color="error">
          {helperText}
        </Typography>
      )}
    </FormControl>
  );
};

export default PasswordField;
