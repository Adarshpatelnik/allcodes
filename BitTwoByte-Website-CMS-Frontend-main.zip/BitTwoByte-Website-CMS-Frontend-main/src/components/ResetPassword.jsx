import React, { useEffect, useState } from "react";
import { Container, Button, Card, Form } from "react-bootstrap";
import { Typography, TextField, Box } from "@mui/material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import apiFunctions from "../api/apiFunctions";
import CustomField from "./CustomField";
import CheckIcon from '@mui/icons-material/Check';
import Swal from "sweetalert2";
import PasswordField from "./PasswordField";
import messages from "../constants/messages";

const ResetPassword = () => {
    const [password, setPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [confirmPasswordError, setConfirmPasswordError] = useState("");
    const [success, setSuccess] = useState(false);
    const [token, setToken] = useState("");

    useEffect(() => {
        const searchParams = new URLSearchParams(window.location.search);
        const tokenFromURL = searchParams.get("token");
        if (tokenFromURL) {
            setToken(tokenFromURL);
        }
    }, []);

    const validatePassword = (password) => {
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return passwordRegex.test(password);
    };

    const handleResetPassword = async (e) => {
        e.preventDefault();
        setPasswordError("");

        let isValid = true;

        if (!password) {
            setPasswordError("New Password is required.");
            isValid = false;
        } else if (!validatePassword(password)) {
            setPasswordError("Password must be at least 8 characters long, include uppercase, lowercase, a number, and a special character.");
            isValid = false;
        }

        if (!confirmPassword) {
            setConfirmPasswordError("Confirm password is required.");
            isValid = false;
        } else if (password !== confirmPassword) {
            setConfirmPasswordError("New Passwords do not match.");
            isValid = false;
        }

        if (!isValid) return;

        try {
            const res = await apiFunctions.resetPassword({ token, newPassword: password, confirmpassword: confirmPassword });
            if (res?.status === 200) {
                setSuccess(true);
            } else if (res?.status === 400) {
                throw new Error(messages?.resetPassword?.mismatch);
            } else {
                throw new Error(messages?.resetPassword?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        }
    };

    return (
        <Container
            fluid
            className="d-flex justify-content-center align-items-center vh-100 Bg"
        // style={{ background: "#E0F6E4 0% 0% no-repeat padding-box" }}
        >
            <Card className="shadow-lg border-0 p-4 text-center" style={{ maxWidth: "400px", width: "100%", borderRadius: "12px", backgroundColor: "#fff" }}>
                <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    sx={{
                        backgroundColor: success ? "#D4EDDA" : "#d3e7d9",
                        borderRadius: "50%",
                        width: "70px",
                        height: "70px",
                        margin: "0 auto",
                        mb: 2
                    }}
                >
                    {success ? (
                        <CheckIcon
                            fontSize="large"
                            sx={{ color: "green" }}
                        />
                    ) : (
                        <LockOutlinedIcon
                            fontSize="large"
                            sx={{ color: "#012354" }}
                        />
                    )}
                </Box>

                {success ? (
                    <>
                        <h2 className="fw-bold mb-3" style={{ color: "#012354" }}>
                            Password Reset Successfully!
                        </h2>
                        <p style={{ fontSize: "1rem", color: "#6c757d", marginBottom: "1.5rem" }}>
                            Your password has been updated. You can now log in with your new password.
                        </p>

                        <Button
                            variant="primary"
                            className="btn w-100"
                            onClick={() => window.location.href = "/"}
                        >
                            Back to Login
                        </Button>
                    </>
                ) : (
                    <>
                        <h2 className="fw-bold mb-3" style={{ color: "#012354" }}>
                            Reset Password
                        </h2>
                        <p style={{ fontSize: "1rem", color: "#6c757d", marginBottom: "1.5rem" }}>
                            Enter your new password below.
                        </p>

                        <Form onSubmit={handleResetPassword}>
                            <Box mb={2}>
                                <PasswordField
                                    className="mb-2"
                                    label="New Password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    fullWidth
                                    error={!!passwordError}
                                    helperText={passwordError}
                                />
                            </Box>
                            <Box mb={2}>
                                <PasswordField
                                    className="mb-2"
                                    label="Confirm Password"
                                    fullWidth
                                    required
                                    sx={{ mb: 3 }}
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                    error={!!confirmPasswordError}
                                    helperText={confirmPasswordError}
                                />
                            </Box>
                            <Button
                                type="submit"
                                variant="primary"
                                className="btn w-100"
                            >
                                Reset Password
                            </Button>
                        </Form>
                    </>
                )}
            </Card>
        </Container>
    );
};

export default ResetPassword;
