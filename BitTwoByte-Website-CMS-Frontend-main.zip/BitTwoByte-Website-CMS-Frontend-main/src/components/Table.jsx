import React from "react";
import { DataGrid } from '@mui/x-data-grid';
import { Card, CardContent } from "@mui/material";
import "../assets/styles/table.css";

const Table = ({ rows, columns }) => {
    const fixedColumns = columns.map(column => ({
        ...column,
        resizable: false,
        headerAlign: 'center',
        align: 'center',
        flex: 1,
        minWidth: 100,
        hide: window.innerWidth < 768 && column.hideOnMobile ? true : false,
    }));

    return (
        <Card elevation={4} className="p-0">
            <CardContent className="p-0">
                <div className="table-container">
                    <DataGrid
                        rows={rows}
                        columns={fixedColumns}
                        getRowId={(row) => row.id}
                        initialState={{
                            pagination: {
                                paginationModel: { page: 0, pageSize: 5 },
                            },
                        }}
                        localeText={{
                            noRowsLabel: 'No data found',
                        }}
                        sx={{
                            '& .MuiDataGrid-columnHeader': {
                                backgroundColor: '#298939',
                                color: 'white',
                                fontFamily: 'boldtxt',
                            },
                            '& .MuiDataGrid-root': {
                                fontFamily: 'mediumtxt',
                            },
                        }}
                        pageSizeOptions={[5, 10]}
                        autoHeight
                        rowHeight={70}
                        disableColumnMenu
                    />
                </div>
            </CardContent>
        </Card>
    );
}

export default Table;
