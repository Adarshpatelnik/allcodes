import React, { useState } from "react";
import { Container, Button, Card, Form } from "react-bootstrap";
import { Typography, TextField, Box, IconButton } from "@mui/material";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import { useNavigate } from "react-router-dom";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import apiFunctions from "../api/apiFunctions";
import CustomField from "./CustomField";
import "../assets/styles/custom.css";
import Swal from "sweetalert2";
import messages from "../constants/messages";

const ForgotPassword = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState(false);
    const [isLoader, setIsLoader] = useState(false);

    const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    const handleForgetPassword = async (e) => {
        e.preventDefault();
        setError("");

        if (!email) {
            setError("Email is required");
            return;
        }

        if (!validateEmail(email)) {
            setError("Invalid email format");
            return;
        }

        setIsLoader(true);

        try {
            const res = await apiFunctions?.forgetPassword({ mailID: email });

            if (res?.status === 200) {
                setSubmitted(true);
                Swal.fire({
                    text: messages?.forgotPassword?.emailSent,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

            } else if (res?.status === 404) {
                throw new Error(messages?.forgotPassword?.userNotFound);
            } else {
                throw new Error(messages?.forgotPassword?.emailError);
            }
        } catch (error) {
            console.log("Error", error.message);
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    return (
        <Container
            fluid
            className="d-flex justify-content-center align-items-center vh-100 Bg"
        // style={{ background: "#E0F6E4 0% 0% no-repeat padding-box" }}
        >

            <Card
                className="shadow-lg border-0 p-4 text-center"
                style={{
                    maxWidth: "400px",
                    borderRadius: "12px",
                    backgroundColor: "#fff"
                }}
            >
                {/* Back Arrow Icon */}
                <IconButton
                    onClick={() => navigate(-1)}
                    sx={{
                        position: "absolute",
                        top: 10,
                        left: 10,
                        color: "#fff",
                        backgroundColor: "rgba(0, 0, 0, 0.4)",
                        borderRadius: "50%",
                        padding: "5px",
                        "&:hover": {
                            backgroundColor: "rgba(0, 0, 0, 0.6)",
                        },
                    }}
                >
                    <ArrowBackIcon fontSize="small" />
                </IconButton>

                <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    sx={{
                        backgroundColor: "#d3e7d9",
                        borderRadius: "50%",
                        width: "70px",
                        height: "70px",
                        margin: "0 auto",
                        mb: 2
                    }}
                >
                    <EmailOutlinedIcon fontSize="large" sx={{ color: "#298939" }} />
                </Box>

                {!submitted ? (
                    <>
                        {isLoader && (
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </>
                        )}
                        <h2 className="fw-bold mb-3" style={{ color: "#012354" }}>
                            Forgot Password?
                        </h2>
                        <p style={{ fontSize: "1rem", color: "#6c757d", marginBottom: "1.5rem" }}>
                            Enter your email address below, and we'll send you a reset link.
                        </p>

                        <Form onSubmit={handleForgetPassword}>
                            <CustomField
                                label="Email Address"
                                variant="outlined"
                                fullWidth
                                required
                                sx={{ mb: 3 }}
                                value={email}
                                onChange={(e) => {
                                    setEmail(e.target.value);
                                    setError("");
                                    setSuccess(false);
                                }}
                                error={!!error}
                                helperText={error}
                            />
                            <Button className="btn w-100 mb-3" type="submit" variant="contained">Submit</Button>
                        </Form>
                    </>
                ) : (
                    /* Email Sent Confirmation */
                    <>
                        <h2 className="fw-bold mb-3" style={{ color: "#012354" }}>Check Your Email</h2>
                        <p style={{ fontSize: "1rem", color: "#6c757d", marginBottom: "1.5rem" }}>
                            We've sent a password reset link to <b>{email}</b>.
                            Please check your inbox and follow the instructions.
                        </p>

                        <Button
                            variant="primary"
                            className="btn w-100"
                            onClick={() => navigate("/")}
                        >
                            Back to Login
                        </Button>
                    </>
                )}
            </Card>
        </Container>
    );
};

export default ForgotPassword;
