import "../assets/styles/loader.css";
const loader = () => {
    return (
        <>
            <div className="d-flex align-center" style={{ height: "90vh" }}>
                <span className="spinloader"></span>
            </div>
        </>
    )
}
export default loader;
