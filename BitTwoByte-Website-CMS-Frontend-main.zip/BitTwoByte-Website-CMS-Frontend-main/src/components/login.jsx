import React, { useState } from "react";
import { Card, Form } from "react-bootstrap";
import Swal from "sweetalert2";
import {
    Typography,
    Box,
} from "@mui/material";
import Logo from "../assets/images/logo.svg";
import CustomField from "./CustomField";
import PasswordField from "./PasswordField";
import apiFunctions from "../api/apiFunctions";
import { pageRoutes } from "../routes/pageRoutes";
import messages from "../constants/messages";
import { Link } from "react-router-dom";

const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

const Login = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState({ email: "", password: "" });
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({ email: "", password: "" });

        if (!validateEmail(username)) {
            setErrors((prev) => ({ ...prev, email: "Invalid email format" }));
            return;
        }
        if (password.length < 6) {
            setErrors((prev) => ({ ...prev, password: "Password must be at least 6 characters" }));
            return;
        }

        setIsLoading(true);
        const json = { mail_id: username, password: password };
        try {
            const res = await apiFunctions.adminLogin(json);

            if (res?.status === 200) {
                localStorage.clear();
                localStorage.setItem("access-token", res.data.token);
                localStorage.setItem("mail", res.data.mail_id);

                Swal.fire({
                    text: messages?.auth?.loginSuccess,
                    icon: "success",
                    showConfirmButton: false,
                    timer: 900
                });

                setTimeout(() => window.location.replace(pageRoutes.dashboard), 1000);
            } else {
                throw new Error(messages?.auth?.loginError);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoading(false);
        }
    };


    return (
        <div className="Bg"
            style={{
                height: "100vh",
                width: "100vw",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                // background: '#F2F1F6',
                // background: '#E0F6E4 0% 0% no-repeat padding-box',
                padding: "20px",
            }}
        >
            <Card
                className="shadow-lg border-0 p-4 d-flex flex-column align-items-center"
                style={{
                    width: "100%",
                    maxWidth: "400px",
                    borderRadius: "12px",
                    backgroundColor: "#fff",
                    minHeight: "380px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                }}
            >
                {/* Logo Section */}
                <Box display="flex" justifyContent="center" width="100%" mb={2}>
                    <img src={Logo} alt="Logo"
                        style={{ maxWidth: "50%", height: "auto", objectFit: "contain" }} />
                </Box>

                {/* Title */}
                <Typography
                    variant="h5"
                    fontWeight="bold"
                    textAlign="center"
                    className="mb-4"
                    color="#012354"
                    sx={{ fontFamily: "boldertxt" }}
                >
                    Login to continue
                </Typography>

                {/* Form Section */}
                <Form onSubmit={handleSubmit} style={{ width: "100%", display: "flex", flexDirection: "column", gap: "15px" }}>
                    {/* Email Field */}
                    <CustomField
                        label="Email Address"
                        variant="outlined"
                        fullWidth
                        required
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        error={!!errors.email}
                        helperText={errors.email}
                    />

                    {/* Password Field */}
                    <PasswordField
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        error={errors.password}
                    />

                    {/* Login Button */}
                    <button
                        type="submit"
                        className="btn w-100 py-2"
                        disabled={isLoading}
                    >
                        {isLoading ? "Logging in..." : "Login"}
                    </button>
                </Form>
                {/* Forget Password */}
                <Link to="/forgot-password" className="forgot-password mt-3">
                    Forgot Password?
                </Link>
            </Card>
        </div>
    );
};

export default Login;
