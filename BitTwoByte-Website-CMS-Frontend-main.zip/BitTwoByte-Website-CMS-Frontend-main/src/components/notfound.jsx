import { Button, Card, CardContent } from "@mui/material";
import React from "react";

function NotFound() {
  return (
    <div
      className="Bg"
      style={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        // backgroundColor: "#e9f4ee",
        padding: "20px",
      }}
    >
      <Card
        sx={{
          textAlign: "center",
          padding: "40px 30px",
          boxShadow: "0px 6px 20px rgba(41, 137, 57, 0.2)",
          borderRadius: "16px",
          maxWidth: "420px",
          width: "100%",
          backgroundColor: "#ffffff",
        }}
      >
        <CardContent>
          <h1 style={{ color: "#298939", fontSize: "64px", fontWeight: "700", margin: 0 }}>
            404
          </h1>
          <h2 style={{ fontSize: "24px", fontWeight: "600", marginTop: "16px", color: "#012354" }}>
            Page Not Found
          </h2>
          <p style={{ color: "#666", fontSize: "16px", margin: "16px 0 24px" }}>
            The page you are looking for doesn’t exist or has been moved.
          </p>
          <Button className="btn"
            onClick={() => window.history.back()}
            variant="contained"
          >
            Go Back
          </Button>

        </CardContent>
      </Card>
    </div>
  );
}

export default NotFound;
