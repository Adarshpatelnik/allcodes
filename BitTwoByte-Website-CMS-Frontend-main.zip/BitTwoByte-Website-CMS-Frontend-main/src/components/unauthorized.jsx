import React from "react";
import { Container, Button, Card } from "react-bootstrap";
import { Typography, Box } from "@mui/material";
import GppBadOutlinedIcon from "@mui/icons-material/GppBadOutlined";
import { useNavigate } from "react-router-dom";

const Unauthorized = () => {
    const navigate = useNavigate();

    return (
        <div
            style={{
                height: "100vh",
                width: "100vw",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: "#e5e8e8",
                padding: "20px",
            }}
        >
            <Card
                className="shadow-lg border-0 p-4 text-center"
                style={{
                    width: "100%",
                    maxWidth: "450px",
                    borderRadius: "12px",
                    backgroundColor: "#fff",
                    boxShadow: "0px 10px 30px rgba(0, 0, 0, 0.1)",
                }}
            >
                {/* Icon Section */}
                <Box
                    display="flex"
                    justifyContent="center"
                    alignItems="center"
                    sx={{
                        backgroundColor: "#FFDCDC",
                        borderRadius: "50%",
                        width: "80px",
                        height: "80px",
                        margin: "0 auto",
                        mb: 3,
                    }}
                >
                    <GppBadOutlinedIcon fontSize="large" sx={{ color: "#D32F2F", fontSize: "3rem" }} />
                </Box>

                {/* Unauthorized Message */}
                <Typography variant="h4" fontWeight="bold" color="#D32F2F" gutterBottom sx={{ fontFamily: "boldertxt" }}>
                    Access Denied!
                </Typography>
                <Typography
                    variant="body1"
                    color="textSecondary"
                    sx={{ fontSize: "1rem", mb: 3, color: "#6c757d", fontFamily: "mediumtxt" }}
                >
                    You don't have permission to view this page.
                </Typography>
                
                {/* Back to Home Button */}
                <Button
                    // variant="primary"
                    // className="w-100 py-2 fw-bold"
                    onClick={() => navigate("/dashboard")}
                >
                    Go to Home
                </Button>
            </Card>
        </div>
    );
};

export default Unauthorized;