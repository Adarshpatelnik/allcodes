export const appConstants = {
  baseUrl: "https://bittwobyte.dci.in/v1/",
  imageUrl: "https://bittwobyte.dci.in/",
  userbaseUrl: "https://bittwobyte-web.dci.in",
  appName: "Bittwobyte",
  login: "Admin Login",
  emailAddress: "Email Address",
  yes: "Yes",
  no: "No",
  email: "Email",
  dashboard: "Dashboard",
  // offlineMessage: "You are offline. Please check your internet connection and try again."
};

