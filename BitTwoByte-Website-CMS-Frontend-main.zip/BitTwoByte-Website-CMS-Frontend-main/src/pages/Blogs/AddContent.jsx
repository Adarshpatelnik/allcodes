import React, { useState, useRef, useEffect } from "react";
import { Avatar, Button } from "@mui/material";
import "../../assets/styles/custom.css"
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import CustomField from "../../components/CustomField";
import Swal from "sweetalert2";
import apiFunctions from "../../api/apiFunctions";
import { ArrowBack } from "@mui/icons-material";
import Loader from "../../components/loader";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import CustomDatePicker from "../../components/CustomDatePicker";
import CustomSelect from "../../components/CustomSelect";
import ChipInput from "../../components/ChipInput";
import messages from "../../constants/messages";

const AddContent = ({ onBack, refreshBlogs }) => {
    const [isOpen, setIsopen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoader, setIsLoader] = useState(false);
    const [categories, setCategories] = useState([]);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    const formats = [
        "header", "bold", "italic", "underline", "color", "list", "align",
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, 4, false] }],
            ["bold", "italic", "underline"],
            [{ color: ["#298939", "#FFFFFF", "#4A4A4A", "#012354"] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    //Overview Section
    const [overview, setOverview] = useState({
        img: "",
        imgFile: "",
        bloggerimg: "",
        bloggerimgFile: "",
        blogtitle: "",
        bloggername: "",
        date: new Date().toISOString().split("T")[0],
        category: 0,
        description: "",
    });

    const [chips, setChips] = useState([]);

    const handleChipChange = (newChips) => {
        setChips(newChips);
    };

    const handleOverviewChange = (field, subfield, value) => {
        setOverview((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleOverviewSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            bloggername: overview?.bloggername,
            date: overview?.date,
        }


        if (overview?.imgFile instanceof File) {
            form.append("cover_image", overview?.imgFile);
        }
        if (overview?.bloggerimgFile instanceof File) {
            form.append("profile_img", overview?.bloggerimgFile);
        }

        form.append("title", overview?.blogtitle);
        form.append("description", overview?.description);
        form.append("content", JSON.stringify(json));
        form.append("status", "active");
        form.append("tags", JSON.stringify(chips));
        form.append("category_id", overview?.category);

        try {
            const res = await apiFunctions.addBlogs(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });
                onBack();
                refreshBlogs();

            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const getCategoriesData = () => {
        apiFunctions.getBlogCategories()
            .then((res) => {

                if (res?.status === 200 && Array.isArray(res?.data?.data) && res?.data?.data?.length > 0) {

                    const formattedData = res?.data?.data.map((item, index) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }

                        // const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            id: item?.id || null,
                            technology: item?.category_name || "",
                        };
                    });

                    setCategories(formattedData);
                } else {
                    setCategories([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setCategories([]);
            });
    };


    const isFetched = useRef(false);
    useEffect(() => {
        let timeout = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        if (!isFetched.current) {
            getCategoriesData();
            isFetched.current = true;
        }

        return () => clearTimeout(timeout);
    }, []);


    return (
        <>
            {isLoading ?
                <Loader /> : <>
                    <div className="row">
                        <div className="col-12 d-flex justify-content-end">
                            <Button className="btn mb-2" variant="contained" onClick={onBack} startIcon={<ArrowBack />}>
                                Back
                            </Button>
                        </div>
                        <div className="col-lg-6 col-12">
                            <h5 style={{ color: "#012354" }}>
                                Add New Blog
                            </h5>
                        </div>
                    </div>
                    <form onSubmit={handleOverviewSave}>
                        <div className="row mt-2">
                            <div className="col-lg-6 col-12">
                                <label className="fw-medium mb-2" style={{ color: "#012354" }}>Upload Blog Cover Image</label>
                                {overview?.img ? (
                                    <div className="mb-2">
                                        <img src={overview?.img} alt="" className="input-img" />
                                    </div>
                                ) : (
                                    ""
                                )}
                                <div className="foot-input-wrapper mb-2">
                                    <input
                                        className="form-control foot-input"
                                        accept="image/*"
                                        onChange={(e) => {
                                            const file = e.target.files[0];
                                            if (file) {
                                                const objectUrl = URL.createObjectURL(file);
                                                handleOverviewChange("imgFile", null, file);
                                                handleOverviewChange("img", null, objectUrl);
                                            }
                                        }}
                                        type="file"
                                        required
                                    />
                                    <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                        (520×250)
                                    </span>
                                </div>
                            </div>
                            <div className="col-lg-6 col-12">
                                <label className="fw-medium mb-2" style={{ color: "#012354" }}>Upload Blogger Profile Image</label>
                                {overview?.bloggerimg ? (
                                    <div className="mt-2 mb-3">
                                        <Avatar
                                            src={overview?.bloggerimg}
                                            alt="Uploaded"
                                            sx={{ width: 150, height: 150, boxShadow: "0px 4px 10px rgba(41, 137, 57, 0.5)" }}
                                        />
                                    </div>
                                ) : (
                                    ""
                                )}
                                <div className="foot-input-wrapper mb-2">
                                    <input
                                        className="form-control foot-input"
                                        accept="image/*"
                                        onChange={(e) => {
                                            const file = e.target.files[0];
                                            if (file) {
                                                const objectUrl = URL.createObjectURL(file);
                                                handleOverviewChange("bloggerimgFile", null, file);
                                                handleOverviewChange("bloggerimg", null, objectUrl);
                                            }
                                        }}
                                        type="file"
                                        required
                                    />
                                    <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                        (520×250)
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div className="row mt-2">
                            {/* Left Column */}
                            <div className="col-lg-6 col-12">
                                <CustomField
                                    required
                                    value={overview?.blogtitle || ""}
                                    onChange={(e) => handleOverviewChange("blogtitle", null, e.target.value)}
                                    margin="dense" label="Blog Title" type="text" size="small" fullWidth className="mb-2" />
                                {/* <LocalizationProvider dateAdapter={AdapterDayjs}>
                                    <CustomDatePicker
                                        required
                                        fullWidth
                                        size="small"
                                        label="Choose Date"
                                        className="mt-2 mb-2"
                                        // value={overview?.date ? dayjs(overview.date) : null}
                                        // onChange={(newValue) =>
                                        //     handleOverviewChange("date", null, newValue)
                                        // }
                                        value={overview.date ? dayjs(overview.date) : null}
                                        onChange={(newValue) => {
                                            const isoDate = newValue ? dayjs(newValue).toISOString() : "";
                                            handleOverviewChange("date", null, isoDate);
                                        }}
                                    />
                                </LocalizationProvider> */}
                                <CustomField
                                    focused
                                    required
                                    disabled
                                    value={overview?.date || new Date().toISOString().split("T")[0]}
                                    onChange={(e) => handleOverviewChange("date", null, e.target.value)}
                                    margin="dense"
                                    label="Date"
                                    type="date"
                                    size="small"
                                    fullWidth
                                    className="mb-2"
                                />


                            </div>

                            {/* Right Column */}
                            <div className="col-lg-6 col-12">
                                <CustomField
                                    required
                                    value={overview?.bloggername || ""}
                                    onChange={(e) => handleOverviewChange("bloggername", null, e.target.value)}
                                    margin="dense" label="Blogger Name" type="text" size="small" fullWidth className="mb-2" />
                                <CustomSelect
                                    className="mb-2"
                                    value={overview?.category || ""}
                                    onChange={(e) => handleOverviewChange("category", null, e.target.value)}
                                    label="Categories"
                                    options={categories ? categories : ""}
                                    id="tech-select"
                                    size="small"
                                    required={true}
                                    optionLabelKey="technology"
                                    optionValueKey="id"
                                // showNoneOption={true}
                                />
                            </div>
                        </div>
                        <div className="row mt-2">
                            <div className="col-lg-12 col-12">
                                <ReactQuill
                                    modules={modules}
                                    formats={formats}
                                    value={overview?.description}
                                    onChange={(value) => handleOverviewChange("description", null, value)}
                                    placeholder="Blog Description"
                                />
                            </div>
                        </div>
                        <div className="row mt-2">
                            <div className="col-lg col-12">
                                <ChipInput
                                    fieldLabel="Blog Tags"
                                    label="Enter Tags"
                                    value={chips}
                                    onChange={handleChipChange}
                                    helperText="Enter each tag and press Enter."
                                />
                            </div>
                        </div>
                        <div className="text-end">
                            {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                            <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                {isLoader ? "Saving..." : "Save"}
                            </Button>
                        </div>
                    </form>
                </>
            }
        </>

    )
}
export default AddContent;