import { Button, ButtonGroup, IconButton, Switch } from "@mui/material";
import React, { useEffect, useState, useRef } from "react";
import Swal from "sweetalert2";
import Table from "../../components/Table";
import Loader from "../../components/loader";
import "../../assets/styles/loader.css"
import { appConstants } from "../../constants/appConstants";
import apiFunctions from "../../api/apiFunctions";
import {
    Delete,
    Edit,
    Visibility,
    Add,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import AddContent from "./AddContent";
import EditContent from "./EditContent";
import ViewContent from "./ViewContent";
import CategoriesTable from "./CategoriesTable";
import messages from "../../constants/messages";

const BlogsTable = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [showAddForm, setShowAddForm] = useState(false);
    const [showEditForm, setShowEditForm] = useState(false);
    const [showViewForm, setShowViewForm] = useState(false);
    const [showAddCategory, setShowAddCategory] = useState(false);
    const [banners, setBanners] = useState([]);
    const [isLoader, setIsLoader] = useState(false);
    const [categories, setCategories] = useState([]);

    const CustomSwitch = styled(Switch)({
        "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#298939",
        },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#298939",
        },
    });

    // Formats allowed in the editor
    const formats = [
        "header",
        "bold",
        "italic",
        "underline",
        "color",
        "background",
        "list",
        "bullet",
        "link",
        "align"
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: [] }, { background: [] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    const [services, setServices] = useState({
        image: null,
        imageUrl: "",
        title: "",
        description: ""
    });

    const [selectedRow, setSelectedRow] = useState({
        image: null,
        imageUrl: "",
        title: "",
        description: ""
    });

    const handleServicesChange = (field, subfield, value, event = null) => {
        setServices((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setServices((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }

        setSelectedRow((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setSelectedRow((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }
    };

    const handleViewOpen = (row) => {
        setSelectedRow(row);
        setShowViewForm(true);
    };

    const handleViewClose = () => {
        setSelectedRow({});
        setServices({});
        setShowViewForm(false);
    };

    const handleAddOpen = () => {
        setShowAddForm(true);
    };

    const handleAddClose = () => {
        setShowAddForm(false);
    };

    const handleEditOpen = (row) => {
        setSelectedRow(row);
        setShowEditForm(true);
    };

    const handleEditClose = () => {
        setSelectedRow({});
        setShowEditForm(false);
    };

    const handleAddCategoryOpen = () => {
        setShowAddCategory(true);
    };

    const handleAddCategoryClose = () => {
        setShowAddCategory(false);
    };


    //region Get
    const getInitialData = () => {
        setIsLoading(true);
        apiFunctions.getBlogs()
            .then((res) => {

                if (res?.status === 200 && Array.isArray(res?.data?.data) && res?.data?.data.length > 0) {
                    const formattedData = res.data.data.map((item) => {
                        let contentData = {};
                        try {
                            contentData = item?.content ? JSON.parse(item?.content) : {};
                        } catch (error) {
                            console.error("Error parsing content:", error);
                        }

                        const blogImg = item?.cover_image_path ? appConstants.imageUrl + item.cover_image_path : null;
                        const bloggerImg = item?.profileImagePath ? appConstants.imageUrl + item.profileImagePath : null;

                        return {
                            id: item?.id || null,
                            img: blogImg,
                            bloggerimg: bloggerImg,
                            blogtitle: item?.title || "",
                            bloggername: contentData?.bloggername || "",
                            date: contentData?.date || "",
                            category: item?.category_id || null,
                            categoryname: item?.category_name || "",
                            description: item?.description || "",
                            status: item?.status || "",
                            tags: item?.tags
                        };
                    });

                    setBanners(formattedData);
                } else {
                    setBanners([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Blogs Data:", err);
                setBanners([]);
            })
            .finally(() => {
                setTimeout(() => setIsLoading(false), 1500);
            });
    };

    const getCategoriesData = () => {
        apiFunctions.getBlogCategories()
            .then((res) => {

                if (res?.status === 200 && Array.isArray(res?.data?.data) && res?.data?.data?.length > 0) {

                    const formattedData = res?.data?.data.map((item, index) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }

                        // const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            id: item?.id || null,
                            technology: item?.category_name || "",
                        };
                    });

                    setCategories(formattedData);
                } else {
                    setCategories([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setCategories([]);
            });
    };

    //region Table Columns
    const columns = [
        { field: "blogtitle", headerName: "Title", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: "bloggername", headerName: "Blogger Name", flex: 1, disableColumnMenu: true, sortable: false,
        },
        { field: "categoryname", headerName: "Category", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: "date", headerName: "Created At", flex: 1, disableColumnMenu: true, sortable: false,
            renderCell: (params) => {
                const date = new Date(params.value);
                const options = { day: '2-digit', month: 'long', year: 'numeric' };
                const formattedDate = date.toLocaleDateString('en-GB', options);
                return <span>{formattedDate}</span>;
            },
        },
        { field: "status", headerName: "Status", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: 'Action',
            flex: 1,
            headerName: 'Action',
            disableColumnMenu: true,
            sortable: false,
            renderCell: (params) => (
                params.row && (
                    <ButtonGroup>
                        <IconButton onClick={() => handleEditOpen(params?.row)}><Edit /></IconButton>
                        <IconButton onClick={() => handleViewOpen(params?.row)}><Visibility /></IconButton>
                        <IconButton onClick={() => handleRemove(params?.row)} disabled={isLoader}><Delete /></IconButton>
                    </ButtonGroup>
                )
            )
        },
    ];

    //region Delete
    const handleRemove = (row) => {
        if (!row?.id) {
            console.error("Invalid row ID");
            return;
        }


        Swal.fire({
            text: messages?.delete?.confirm,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
        }).then(async (result) => {
            if (result.isConfirmed) {
                setIsLoading(true);

                try {
                    const res = await apiFunctions.deleteBlogs({ id: row.id });

                    if (res.status === 200) {
                        await Swal.fire({
                            text: messages?.delete?.success,
                            icon: "success"
                        });
                        getInitialData();
                    } else {
                        await Swal.fire({
                            text: messages?.delete?.error,
                            icon: "error"
                        });
                    }
                } catch (error) {
                    console.error("Error deleting case study:", error);
                    await Swal.fire({ text: messages?.catchError, icon: "error" });
                } finally {
                    setIsLoading(false);
                }
            }
        });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        setIsLoader(false);
        setTimeout(() => {
            setIsLoading(false);
        }, 1500);
        if (!isFetched.current) {
            getInitialData();
            getCategoriesData();
            isFetched.current = true;
        }
    }, []);

    return (
        <>
            <div className="row">
                <div className="col-12 w-100">
                    {isLoading ?
                        <Loader /> : <>
                            <div className="row">
                                <div className="col-lg-6 col-12">
                                    {/* <h4 className="fw-medium" style={{ color: "#298939" }}>Blogs Detail Page</h4> */}
                                    <h5 style={{ color: "#012354" }}>{showAddCategory ? "Category Section" : "Blogs Details Section"}</h5>
                                </div>
                            </div>
                            {showAddForm ? (
                                <AddContent onBack={handleAddClose} refreshBlogs={getInitialData} />
                            ) : showEditForm ? (
                                <EditContent data={selectedRow} onBack={handleEditClose} refreshBlogs={getInitialData} />
                            ) : showViewForm ? (
                                <ViewContent data={selectedRow} onBack={handleViewClose} />
                            ) : showAddCategory ? (
                                <CategoriesTable onBack={handleAddCategoryClose} />
                            ) : (
                                <>
                                    <div className="text-end">
                                        <Button
                                            className="btn mb-3 me-3"
                                            onClick={handleAddCategoryOpen}
                                            endIcon={<Add />}
                                            variant="contained"
                                        >
                                            Add Category
                                        </Button>
                                        <Button
                                            className="btn mb-3"
                                            onClick={handleAddOpen}
                                            endIcon={<Add />}
                                            variant="contained"
                                        >
                                            Add new
                                        </Button>
                                    </div>
                                    <Table rows={banners} columns={columns} />
                                </>
                            )}

                        </>
                    }
                </div>
            </div>
        </>
    )
}
export default BlogsTable;