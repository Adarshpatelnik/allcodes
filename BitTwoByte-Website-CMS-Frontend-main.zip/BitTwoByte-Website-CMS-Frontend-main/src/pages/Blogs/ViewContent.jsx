import React, { useState, useRef, useEffect } from "react";
import { Card, Switch, Button, Avatar, CardMedia } from "@mui/material";
import "../../assets/styles/custom.css"
import "react-quill/dist/quill.snow.css";
import Swal from "sweetalert2";
import apiFunctions from "../../api/apiFunctions";
import {
    ToggleOff,
    ToggleOn,
} from "@mui/icons-material";
import { ArrowBack } from "@mui/icons-material";
import Loader from "../../components/loader";
import dayjs from "dayjs";
import { styled } from "@mui/material/styles";
import messages from "../../constants/messages";

const EditContent = ({ data, onBack, refreshBlogs }) => {
    const [isOpen, setIsopen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoader, setIsLoader] = useState(false);
    const [categories, setCategories] = useState([]);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    const formats = [
        "header", "bold", "italic", "underline", "color", "list", "align",
    ];

    const CustomSwitch = styled(Switch)({
        "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#298939",
        },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#298939",
        },
    });

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: ["#298939", "#FFFFFF", "#4A4A4A", "#012354"] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    //Overview Section
    const [overview, setOverview] = useState({
        img: "",
        imgFile: "",
        bloggerimg: "",
        bloggerimgFile: "",
        blogtitle: "",
        bloggername: "",
        date: "",
        category: 0,
        description: "",
    });

    const [chips, setChips] = useState([]);

    const handleChipChange = (newChips) => {
        setChips(newChips);
    };

    const handleOverviewChange = (field, subfield, value) => {
        setOverview((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [selectedRow, setSelectedRow] = useState({
        status: ""
    });


    const handleEditSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            bloggername: overview?.bloggername,
            date: overview?.date,
        }


        if (overview?.imgFile instanceof File) {
            form.append("cover_image", overview?.imgFile);
        }
        if (overview?.bloggerimgFile instanceof File) {
            form.append("profile_img", overview?.bloggerimgFile);
        }

        form.append("title", overview?.blogtitle);
        form.append("description", overview?.description);
        form.append("content", JSON.stringify(json));
        form.append("status", selectedRow?.status);
        form.append("tags", JSON.stringify(chips));
        form.append("category_id", overview?.category);
        form.append("id", data?.id);

        try {
            const res = await apiFunctions.updateBlogs(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.update?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });
                onBack();
                refreshBlogs();
            } else {
                throw new Error(messages?.update?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const getCategoriesData = () => {
        apiFunctions.getBlogCategories()
            .then((res) => {

                if (res?.status === 200 && Array.isArray(res?.data?.data) && res?.data?.data?.length > 0) {

                    const formattedData = res?.data?.data.map((item, index) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }

                        // const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            id: item?.id || null,
                            technology: item?.category_name || "",
                        };
                    });

                    setCategories(formattedData);
                } else {
                    setCategories([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setCategories([]);
            });
    };


    const isFetched = useRef(false);
    useEffect(() => {
        let timeout = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        if (!isFetched.current) {
            getCategoriesData();
            isFetched.current = true;
        }

        return () => clearTimeout(timeout);
    }, []);

    useEffect(() => {
        if (data) {
            setOverview({
                img: data?.img || "",
                imgFile: "",
                bloggerimg: data?.bloggerimg || "",
                bloggerimgFile: "",
                blogtitle: data?.blogtitle || "",
                bloggername: data?.bloggername || "",
                date: data?.date ? dayjs(data?.date) : null,
                category: data?.category || 0,
                description: data?.description || "",
            });
            setChips(data?.tags);
            setSelectedRow({
                status: data?.status
            });
        }
    }, [data]);



    return (
        <>
            {isLoading ?
                <Loader /> :
                <>
                    <div className="row">
                        <div className="col-12 d-flex justify-content-end">
                            <Button className="btn mb-2" variant="contained" onClick={onBack} startIcon={<ArrowBack />}>
                                Back
                            </Button>
                        </div>
                        <div className="col-lg-6 col-12 mb-3">
                            <h5 style={{ color: "#012354" }}>
                                View Blog
                            </h5>
                        </div>
                    </div>
                    <div
                        style={{
                            background:
                                "transparent linear-gradient(180deg, #D3F8DF 0%, #FFFFFF 100%) 0% 0% no-repeat padding-box",
                            minHeight: "100vh",
                            padding: "48px 24px",
                            borderRadius: "10px"
                        }}
                    >
                        <div style={{ maxWidth: "1024px", margin: "0 auto" }}>
                            <div className="d-lg-flex d-block"
                                style={{
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    marginBottom: "32px",
                                    flexWrap: "wrap",
                                }}
                            >
                                <h1
                                    style={{
                                        fontWeight: 700,
                                        fontSize: "2.5rem",
                                        marginBottom: "24px",
                                        color: "#012354",
                                        flex: 1,
                                        minWidth: 0,
                                    }}
                                >
                                    {data?.blogtitle}
                                </h1>

                                <div
                                    style={{
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "12px",
                                        flexShrink: 1,
                                        whiteSpace: "nowrap",
                                    }}
                                >
                                    <Avatar alt={data?.bloggername} src={data?.bloggerimg} />
                                    <div style={{ overflow: "hidden", textOverflow: "ellipsis" }}>
                                        <p style={{ margin: 0, fontWeight: 600 }}>{data?.bloggername}</p>
                                        <p style={{ margin: 0, color: "#666" }}>{new Date(data?.date).toLocaleDateString("en-US", {
                                            year: "numeric",
                                            month: "long",
                                            day: "2-digit",
                                        })}</p>
                                    </div>
                                </div>
                            </div>


                            <Card sx={{ borderRadius: 4, boxShadow: 3 }}>
                                <CardMedia
                                    component="img"
                                    sx={{
                                        height: { xs: 200, sm: 300, md: 350 },
                                        width: "100%",
                                        objectFit: "cover"
                                    }}
                                    image={data?.img}
                                    alt="Data Integration"
                                />
                            </Card>
                            <p className="col-lg pt-1">
                                <div className="mt-3"
                                    dangerouslySetInnerHTML={{ __html: data?.description }}
                                />
                            </p>
                            <div className="project_overview rounded-4 p-lg-4 p-2 mt-lg-5 mt-3 mb-3 mb-lg-5 w-100" style={{ backgroundColor: '#F2F1F6' }}>
                                <h3 className="fw-medium">Tags</h3>
                                <div className="mt-lg-4 mt-3 pb-3 d-flex flex-wrap gap-2">
                                    {data?.tags?.map((item, index) => (
                                        <span className="tag-item" key={index}>{item}</span>
                                    ))}
                                </div>
                            </div>


                        </div>
                    </div>
                </>
            }
        </>

    )
}
export default EditContent;