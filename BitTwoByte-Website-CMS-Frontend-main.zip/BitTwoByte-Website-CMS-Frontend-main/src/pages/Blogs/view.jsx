import React, { useEffect, useRef, useState } from "react";
import Header from "../../components/header";
import Footer from "../../components/footer";
import blog from "../../assets/Images/blog.png";
import '../../assets/css/blog.css';
import { Helmet } from 'react-helmet';
import banner from '../../assets/Images/medical-banner.png';
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import KeyboardDoubleArrowRightOutlinedIcon from '@mui/icons-material/KeyboardDoubleArrowRightOutlined';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import SubscribeForm from "../../components/subscribe";
import ChevronRightOutlinedIcon from '@mui/icons-material/ChevronRightOutlined';
import apiFunctions from "../../apiKit/api";
import { appConstants } from "../../apiKit/appconstant";
import { useNavigate } from "react-router-dom";
import { pageRoutes } from "../../config/route";
const Blog_detail = ({ title, description }) => {
    const [cmsdata, setCmsdata] = useState([]);
    const [catdata, setCatdata] = useState([]);

    const [recentdata, setRecentdata] = useState([]);
    const [loading, setLoading] = useState(true);
    const getInitialData = () => {
        apiFunctions.getDataBlogsCMS().then((res) => {
            if (res.status === 200) {
                setCmsdata(res?.data?.data?.[0]);
            } else {
                setCmsdata([]);
            }
        }).catch((err) => {
        });
        apiFunctions.getDataCategoryCMS().then((res) => {
            if (res.status === 200) {
                setCatdata(res?.data?.data);
            } else {
                setCatdata([]);
            }
        }).catch((err) => {
            console.log(err);
        });
        setTimeout(() => {
            setLoading(false);
        }, 1500);
    }
    const getRecentData = () => {
        apiFunctions.getDataRecentBlogsCMS().then((res) => {
            if (res.status === 200) {
                setRecentdata(res?.data?.data);
            } else {
                setRecentdata([]);
            }
        }).catch((err) => {
            console.log(err);
        });
    }
    const isFetched = useRef(false);
    useEffect(() => {
        // if (!isFetched.current) {
        getInitialData();
        getRecentData();
        // }
    }, [])


    const navigate = useNavigate();
    const handleViewClick = (item) => {
        navigate(pageRoutes.blog_details, { state: item });
        window.scrollTo(0, 0);
    };
    return (
        <>
            <div className="container-fluid p-0 m-0" style={{ background: '#F2F1F6 0% 0% no-repeat padding-box' }}>
                <Helmet>
                    <title>{title}</title>
                    <meta name="description" content={description} />
                </Helmet>
                <div className="sticky-top">
                    <Header />
                </div>
                <div className="casestudy_banners bottom">
                    <div className="px-lg-5 px-3 mx-lg-4 pt-lg-5 pt-3">
                        <div className="casestudy_banner_texts pt-lg-4">
                            <h6>Home<ChevronRightOutlinedIcon style={{ fontSize: '15px' }} />Blog<ChevronRightOutlinedIcon style={{ fontSize: '15px' }} />
                                <span className="datas_brickss">{cmsdata?.title}</span> </h6>
                            <div className="row inte_challenge pb-lg-4">
                                <div className="col-lg-9 col-12">
                                    <h5 className="pt-1">{cmsdata?.title}</h5>
                                    <div className="data_integration">
                                    </div>
                                </div>
                                <div className="col-lg-3 col-12 text-start">
                                    <div className="d-flex align-items-center pb-3" style={{ justifyContent: 'start' }}>
                                        <img className="rounded-circle" style={{ height: '61px', width: '61px' }} src={cmsdata?.profileImagePath ? appConstants.imageUrl + cmsdata?.profileImagePath : banner} alt="" />

                                        {(() => {
                                            let content = {};
                                            try {
                                                content = JSON.parse(cmsdata?.content || '{}');
                                            } catch (e) {
                                                console.error("Invalid JSON in content", e);
                                            }

                                            const formattedDate = content.date
                                                ? new Date(content.date).toLocaleDateString('en-US', {
                                                    year: 'numeric',
                                                    month: 'long',
                                                    day: '2-digit',
                                                    timeZone: 'UTC' // Ensures consistent output
                                                })
                                                : '';

                                            return (
                                                <span className="col-lg-7 ms-2">
                                                    <span className="bold fs-5">{content.bloggername}</span><br />
                                                    <span className="regular grey" style={{ fontSize: '14px' }}>{formattedDate}</span>
                                                    <br />
                                                </span>
                                            );
                                        })()}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* IMAGE */}
                <div className="position-relative px-lg-5 px-3 mx-lg-4 pt-lg-5 pt-3">
                    <div className="casestudy_banner_texts pt-lg-5 pb-lg-5">
                        <div className="casestudy_images top bottom">
                            {/* Optional top text or elements here */}
                        </div>
                    </div>

                    {/* Image Floating Absolute */}
                    <div className="position-absolute w-100 d-flex" style={{ top: '-20%', zIndex: 2 }}>
                        <div className="casestudy_images px-lg-3">
                            <img src={cmsdata?.cover_image_path ? appConstants.imageUrl + cmsdata?.cover_image_path : banner} alt="banner" className="img-fluid rounded" style={{ maxWidth: "100%", borderRadius: "12px" }} />
                        </div>
                    </div>
                </div>
                {/* CONTENT */}
                <div className="project_overview container-fluid mt-lg-5 mt-3 mb-lg-5 mb-3 top" style={{ backgroundColor: 'white', borderRadius: '19px', position: 'relative', zIndex: 1 }}>
                    <div className="px-lg-5 px-3 mx-lg-4 pt-lg-5 pt-3 mt-lg-5 mt-3">
                        <div className="row ">
                            <div className="col-lg-7 col-12">
                                <div className="project_overview_texts pb-lg-4 pb-2">
                                    <p className="col-lg-11 pt-1">
                                        <div className="mt-3"
                                            dangerouslySetInnerHTML={{ __html: cmsdata?.description }}
                                        />
                                    </p>

                                </div>
                            </div>
                            <div className="col-lg-5 pe-lg-5 col-12 mt-lg-0 mt-4">
                                <div className="project_overview rounded-4 p-lg-4 p-2" style={{ backgroundColor: '#F2F1F6' }}>
                                    <div className="input-group subs-div ms-lg-0  mt-2" style={{ height: '60px', borderRadius: '14px', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                        <input className="form-control" style={{ height: '54px', border: 'none', outline: 'none', boxShadow: 'none' }} placeholder="Search..." />
                                        <div className="input-group-append subs-append">
                                            <button className="btn btn-primary"
                                                style={{ background: '#2A8939', height: '60px', width: '60px', borderRadius: '12px', border: 'none', color: 'white' }}
                                                type="submit"><SearchOutlinedIcon /></button>
                                        </div>
                                    </div>
                                </div>
                                <div className="project_overview rounded-4 p-lg-4 p-2 mt-lg-5 mt-3" style={{ backgroundColor: '#F2F1F6' }}>
                                    <h3 className="bolder">Categories</h3>
                                    {catdata?.map((item, index) =>
                                        <div key={index} className="d-flex align-items-center mt-3 pb-3" style={{ justifyContent: 'space-between', borderBottom: '0.1px solid #585858' }}>
                                            <span className="bold"><KeyboardDoubleArrowRightOutlinedIcon className="me-2" />{item?.category_name}</span>
                                            <span className="bold">({item?.blog_count})</span>
                                        </div>
                                    )}
                                </div>
                                <div className="project_overview rounded-4 p-lg-4 p-2 mt-lg-5 mt-3" style={{ backgroundColor: '#F2F1F6' }}>
                                    <h3 className="bolder">Recent Blogs</h3>
                                    {recentdata?.map((item, index) =>
                                        <div className="d-flex align-items-start mt-lg-5 mt-3 pb-3" key={index} style={{ justifyContent: 'start', borderBottom: '0.1px solid #585858' }}>
                                            <img className="rounded-3" style={{ height: '91px', width: '91px' }} src={item?.cover_image_path ? appConstants.imageUrl + item?.cover_image_path : banner} alt="" />
                                            <span className="col-lg-7 ms-3 ms-lg-4">
                                                {/* <span className="regular grey" style={{ fontSize: '14px' }}>
                                                    <FiberManualRecordIcon className="me-2" style={{ color: '#2A8939', fontSize: '10px' }} />{item?.created_timestamp}</span> */}
                                                <span className="regular grey" style={{ fontSize: '14px' }}>
                                                    {item?.created_timestamp && new Date(item.created_timestamp).toLocaleDateString('en-US', {
                                                        year: 'numeric',
                                                        month: 'long',
                                                        day: '2-digit',
                                                        timeZone: 'UTC' // to avoid timezone shifts
                                                    })}
                                                    <FiberManualRecordIcon className="me-2 ms-2" style={{ color: '#2A8939', fontSize: '10px' }} />
                                                </span>
                                                <br />
                                                <span className="bold fs-5" role="button" onClick={() => handleViewClick(item)} >{item?.title}</span>
                                            </span>
                                        </div>
                                    )}
                                </div>
                                <div className="project_overview rounded-4 p-lg-4 p-2 mt-lg-5 mt-3 mb-3 mb-lg-5 w-100" style={{ backgroundColor: '#F2F1F6' }}>
                                    <h3 className="bolder">Tags</h3>
                                    <div className="mt-lg-4 mt-3 pb-3 d-flex flex-wrap gap-2">
                                        {cmsdata?.tags?.map((item, index) =>
                                            <span className="tag-item" key={index}>{item}</span>
                                        )}
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div className="px-lg-5 px-2 pt-lg-5 bottom mt-3">
                    <SubscribeForm />
                </div>
                <div style={{ background: '#F2F1F6 0% 0% no-repeat padding-box' }}>
                    <Footer />
                </div>
            </div></>
    )
}
export default Blog_detail;