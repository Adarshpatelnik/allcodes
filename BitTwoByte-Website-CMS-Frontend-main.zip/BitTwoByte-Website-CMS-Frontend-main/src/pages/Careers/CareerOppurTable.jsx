import { Button, ButtonGroup, IconButton, Dialog, DialogTitle, Card, CardContent, DialogContent, DialogActions, FormControlLabel, Switch, Rating, Avatar } from "@mui/material";
import React, { useEffect, useState, useRef } from "react";
import WorkOutlineIcon from "@mui/icons-material/WorkOutline";
import BusinessCenterIcon from "@mui/icons-material/BusinessCenter";
import PlaceIcon from "@mui/icons-material/Place";
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from "sweetalert2";
import Table from "../../components/Table";
import ReactQuill from "react-quill";
import DOMPurify from 'dompurify';
import Loader from "../../components/loader";
import "../../assets/styles/loader.css"
import { appConstants } from "../../constants/appConstants";
import CustomField from "../../components/CustomField";
import apiFunctions from "../../api/apiFunctions";
import {
    ToggleOff,
    ToggleOn,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import messages from "../../constants/messages";


const CareerOppurTable = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [isEditOpen, setIsEditOpen] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [banners, setBanners] = useState([]);
    const [isLoader, setIsLoader] = useState(false);

    const CustomSwitch = styled(Switch)({
        "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#298939",
        },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#298939",
        },
    });

    // Formats allowed in the editor
    const formats = [
        "header",
        "bold",
        "italic",
        "underline",
        "color",
        "background",
        "list",
        "bullet",
        "link",
        "align"
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: [] }, { background: [] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    const [services, setServices] = useState({
        jobtitle: "",
        jobdescription: "",
        role: "",
        workmode: "",
        location: "",
        applynow: "",
        link: ""
    });

    const [selectedRow, setSelectedRow] = useState({
        jobtitle: "",
        jobdescription: "",
        role: "",
        workmode: "",
        location: "",
        applynow: "",
        link: ""
    });

    const handleServicesChange = (field, subfield, value, event = null) => {
        setServices((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setServices((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }

        setSelectedRow((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setSelectedRow((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }
    };

    const handleAddOpen = () => {
        setServices({});
        setSelectedRow({});
        setIsAddOpen(true);
    };

    const handleAddClose = () => {
        setSelectedRow({});
        setServices({});
        setIsAddOpen(false);
    };

    const handleViewOpen = (row) => {
        setSelectedRow(row);
        setIsViewOpen(true);
    };

    const handleViewClose = () => {
        setSelectedRow({});
        setServices({});
        setIsViewOpen(false);
    };

    const handleEditOpen = (row) => {
        setSelectedRow(row);
        setIsEditOpen(true);
    };

    const handleEditClose = () => {
        setSelectedRow({});
        setServices({});
        setIsEditOpen(false);
    };

    //region Get
    const getInitialData = () => {
        apiFunctions.getCOpp()
            .then((res) => {

                if (res?.status === 200 && Array.isArray(res?.data?.data?.images) && res?.data?.data?.images?.length > 0) {

                    const formattedData = res?.data?.data?.images.map((item) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }

                        const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            id: item?.id || null,
                            jobtitle: descriptionData?.jobtitle,
                            jobdescription: descriptionData?.jobdescription,
                            role: descriptionData?.role,
                            workmode: descriptionData?.workmode,
                            location: descriptionData?.location,
                            applynow: descriptionData?.applynow,
                            link: descriptionData?.link,
                            status: item?.status || ""
                        };
                    });

                    setBanners(formattedData);
                } else {
                    setBanners([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setBanners([]);
            });
    };

    //region Table Columns
    const columns = [
        { field: "jobtitle", headerName: "Job Title", flex: 1, disableColumnMenu: true, sortable: false, },
        { field: "jobdescription", headerName: "Job Description", flex: 1, disableColumnMenu: true, sortable: false, },
        { field: "role", headerName: "Role", flex: 1, disableColumnMenu: true, sortable: false, },
        { field: "status", headerName: "Status", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: 'Action',
            flex: 1,
            headerName: 'Action',
            disableColumnMenu: true,
            sortable: false,
            renderCell: (params) => (
                params.row && (
                    <ButtonGroup>
                        <IconButton onClick={() => handleEditOpen(params.row)}><EditIcon /></IconButton>
                        <IconButton onClick={() => handleViewOpen(params.row)}><VisibilityIcon /></IconButton>
                        <IconButton onClick={() => handleRemove(params.row)} disabled={isLoader}><DeleteIcon /></IconButton>
                    </ButtonGroup>
                )
            )
        },
    ];

    //region Insert
    const handleAddSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            jobtitle: services?.jobtitle,
            jobdescription: services?.jobdescription,
            role: services?.role,
            workmode: services?.workmode,
            location: services?.location,
            applynow: services?.applynow,
            link: services?.link
        };


        form.append("status", "active");
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCOpp(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleAddClose();
        }
    };

    //region Update
    const handleEditSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            jobtitle: selectedRow?.jobtitle,
            jobdescription: selectedRow?.jobdescription,
            role: selectedRow?.role,
            workmode: selectedRow?.workmode,
            location: selectedRow?.location,
            applynow: selectedRow?.applynow,
            link: selectedRow?.link
        };


        form.append("id", selectedRow?.id)
        form.append("status", selectedRow?.status)
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.updateCOpp(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.update?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.update?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleEditClose();
        }
    };

    //region Delete
    const handleRemove = (row) => {
        if (!row?.id) {
            console.error("Invalid row ID");
            return;
        }


        Swal.fire({
            text: messages?.delete?.confirm,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
        }).then(async (result) => {
            if (result.isConfirmed) {
                setIsLoading(true);

                try {
                    const res = await apiFunctions.deleteCOpp({ id: row.id });

                    if (res.status === 200) {
                        await Swal.fire({
                            text: messages?.delete?.success,
                            icon: "success"
                        });
                        getInitialData();
                    } else {
                        await Swal.fire({
                            text: messages?.delete?.error,
                            icon: "error"
                        });
                    }
                } catch (error) {
                    console.error("Error deleting service:", error);
                    await Swal.fire({ text: messages?.catchError, icon: "error" });
                } finally {
                    setIsLoading(false);
                }
            }
        });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        setIsLoader(false);
        setTimeout(() => {
            setIsLoading(false);
        }, 1500);
        if (!isFetched.current) {
            getInitialData();
            isFetched.current = true;
        }
    }, []);

    return (
        <>
            <div className="row">
                <div className="col-12 w-100">
                    {isLoading ?
                        <Loader /> : <>
                            <div className="text-end">
                                <Button className="btn mb-3" onClick={handleAddOpen} endIcon={<AddIcon />} variant="contained">Add new</Button>
                            </div>
                            <Table rows={banners} columns={columns} />
                        </>
                    }
                </div>
            </div>

            {/* View Modal */}
            <Dialog open={isViewOpen} onClose={handleViewClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>View Career Oppurtunity </DialogTitle>
                <DialogContent>
                    <Card
                        sx={{
                            borderRadius: "12px",
                            boxShadow: "none",
                            backgroundColor: "#f8f9fa",
                            p: 2,
                            maxWidth: 900,
                            display: "flex",
                            flexDirection: { xs: "column", sm: "row" },
                            justifyContent: "space-between",
                            alignItems: { xs: "flex-start", sm: "center" },
                            gap: 2,
                        }}
                    >
                        <CardContent sx={{ flexGrow: 1, p: 0, width: "100%" }}>
                            {/* Job Title */}
                            <h5 style={{ color: "#0a2540", fontWeight: "bold", margin: 0 }}>
                                {selectedRow?.jobtitle}
                            </h5>

                            {/* Job Description */}
                            <p
                                style={{
                                    color: "#6c757d",
                                    marginTop: "4px",
                                    width: "100%",
                                    wordWrap: "break-word",
                                }}
                            >
                                {selectedRow?.jobdescription}
                            </p>

                            {/* Icons with text */}
                            <div
                                style={{
                                    display: "flex",
                                    flexWrap: "wrap",
                                    alignItems: "center",
                                    gap: "24px",
                                    marginTop: "16px",
                                    color: "#6c757d",
                                }}
                            >
                                <div style={{ display: "flex", alignItems: "center" }}>
                                    <BusinessCenterIcon style={{ fontSize: "16px", marginRight: "4px" }} />
                                    <p style={{ margin: 0, fontSize: "14px" }}>{selectedRow?.role}</p>
                                </div>
                                <div style={{ display: "flex", alignItems: "center" }}>
                                    <WorkOutlineIcon style={{ fontSize: "16px", marginRight: "4px" }} />
                                    <p style={{ margin: 0, fontSize: "14px" }}>{selectedRow?.workmode}</p>
                                </div>
                                <div style={{ display: "flex", alignItems: "center" }}>
                                    <PlaceIcon style={{ fontSize: "16px", marginRight: "4px" }} />
                                    <p style={{ margin: 0, fontSize: "14px" }}>{selectedRow?.location}</p>
                                </div>
                            </div>
                        </CardContent>

                        {/* Apply Now Button */}
                        <Button
                            className="btn"
                            variant="contained"
                            onClick={() => {
                                if (selectedRow?.applynow) {
                                    window.open(selectedRow?.link, "_blank");
                                }
                            }}
                            sx={{
                                borderRadius: "20px",
                                textTransform: "none",
                                px: 3,
                                whiteSpace: "nowrap",
                                alignSelf: { xs: "flex-end", sm: "center" },
                                flexShrink: 0,
                                mt: { xs: 2, sm: 0 },
                            }}
                            endIcon={<ArrowForwardIcon />}
                        >
                            {selectedRow?.applynow}
                        </Button>
                    </Card>
                </DialogContent>

                <DialogActions style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                    <span className="p-2" style={{ fontSize: "16px", fontWeight: "500", display: "flex", alignItems: "center", gap: "5px" }}>
                        Status: {selectedRow?.status === "active" ?
                            <ToggleOn style={{ color: "#298939", fontSize: "40px" }} /> :
                            <ToggleOff style={{ color: "grey", fontSize: "40px" }} />
                        }
                    </span>
                    <Button className="grey-btn" onClick={handleViewClose}>Close</Button>
                </DialogActions>

            </Dialog>

            {/* Edit Modal */}
            <Dialog open={isEditOpen} onClose={handleEditClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>Edit Career Oppurtunity </DialogTitle>
                <form onSubmit={handleEditSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        {/* <label>Upload Image:</label><br />
                        {selectedRow?.imageUrl && (
                            // <div className="mt-2 mb-3">
                            //     <img src={selectedRow?.imageUrl} alt="Uploaded" className="input-img" />
                            // </div>
                            <div className="mt-2 mb-3">
                                <Avatar
                                    src={selectedRow?.imageUrl}
                                    alt="Uploaded"
                                    sx={{ width: 150, height: 150, boxShadow: "0px 4px 10px rgba(41, 137, 57, 0.5)" }}
                                />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div> */}

                        <label className="mt-2">Job Title</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Job Title"
                            type="text"
                            fullWidth
                            value={selectedRow?.jobtitle || ""}
                            onChange={(e) => handleServicesChange("jobtitle", null, e.target.value)}
                        />
                        <label className="mt-2">Job Description</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Job Description"
                            type="text"
                            fullWidth
                            value={selectedRow?.jobdescription || ""}
                            onChange={(e) => handleServicesChange("jobdescription", null, e.target.value)}
                        />
                        <label className="mt-2">Role</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Role"
                            type="text"
                            fullWidth
                            value={selectedRow?.role || ""}
                            onChange={(e) => handleServicesChange("role", null, e.target.value)}
                        />
                        <div className="row">
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Work Mode</label>
                                <CustomField
                                    className="mt-2"
                                    margin="dense"
                                    label="Work Mode"
                                    type="text"
                                    fullWidth
                                    value={selectedRow?.workmode || ""}
                                    onChange={(e) => handleServicesChange("workmode", null, e.target.value)}
                                />
                            </div>
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Location</label>
                                <CustomField
                                    className="mt-2"
                                    margin="dense"
                                    label="Location"
                                    type="text"
                                    fullWidth
                                    value={selectedRow?.location || ""}
                                    onChange={(e) => handleServicesChange("location", null, e.target.value)}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Apply Now</label>
                                <CustomField
                                    className="mt-2"
                                    margin="dense"
                                    label="Apply Now"
                                    type="text"
                                    fullWidth
                                    value={selectedRow?.applynow || ""}
                                    onChange={(e) => handleServicesChange("applynow", null, e.target.value)}
                                />
                            </div>
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Apply Now Link</label>
                                <CustomField
                                    className="mt-2"
                                    margin="dense"
                                    label="Apply Now Link"
                                    type="text"
                                    fullWidth
                                    value={selectedRow?.link || ""}
                                    onChange={(e) => handleServicesChange("link", null, e.target.value)}
                                />
                            </div>
                        </div>

                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                        <FormControlLabel
                            control={
                                <CustomSwitch
                                    checked={selectedRow?.status === "active"}
                                    onChange={(e) =>
                                        setSelectedRow((prevRow) => ({
                                            ...prevRow,
                                            status: e.target.checked ? "active" : "inactive",
                                        }))
                                    }
                                />
                            }
                            label={selectedRow?.status === "active" ? "Active" : "Inactive"}
                            labelPlacement="end"
                            style={{ marginTop: "1rem" }}
                        />
                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleEditClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

            {/* Add Modal */}
            <Dialog open={isAddOpen} onClose={handleAddClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>Add New Career Oppurtunity </DialogTitle>
                <form onSubmit={handleAddSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        {/* <label>Upload Image:</label><br />
                        {services.image && (
                            // <div className="mt-2 mb-3">
                            //     <img src={services.imageUrl} alt="Uploaded" className="input-img" />
                            // </div>
                            <div className="mt-2 mb-3">
                                <Avatar
                                    src={services.imageUrl}
                                    alt="Uploaded"
                                    sx={{ width: 150, height: 150, boxShadow: "0px 4px 10px rgba(41, 137, 57, 0.5)" }}
                                />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div> */}

                        <label className="mt-2">Job Title</label>
                        <CustomField
                            required
                            className="mt-2"
                            margin="dense"
                            label="Job Title"
                            type="text"
                            fullWidth
                            value={services?.jobtitle || ""}
                            onChange={(e) => handleServicesChange("jobtitle", null, e.target.value)}
                        />
                        <label className="mt-2">Job Description</label>
                        <CustomField
                            required
                            className="mt-2"
                            margin="dense"
                            label="Job Description"
                            type="text"
                            fullWidth
                            value={services?.jobdescription || ""}
                            onChange={(e) => handleServicesChange("jobdescription", null, e.target.value)}
                        />
                        <label className="mt-2">Role</label>
                        <CustomField
                            required
                            className="mt-2"
                            margin="dense"
                            label="Role"
                            type="text"
                            fullWidth
                            value={services?.role || ""}
                            onChange={(e) => handleServicesChange("role", null, e.target.value)}
                        />
                        <div className="row">
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Work Mode</label>
                                <CustomField
                                    required
                                    className="mt-2"
                                    margin="dense"
                                    label="Work Mode"
                                    type="text"
                                    fullWidth
                                    value={services?.workmode || ""}
                                    onChange={(e) => handleServicesChange("workmode", null, e.target.value)}
                                />
                            </div>
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Location</label>
                                <CustomField
                                    required
                                    className="mt-2"
                                    margin="dense"
                                    label="Location"
                                    type="text"
                                    fullWidth
                                    value={services?.location || ""}
                                    onChange={(e) => handleServicesChange("location", null, e.target.value)}
                                />
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Apply Now</label>
                                <CustomField
                                    required
                                    className="mt-2"
                                    margin="dense"
                                    label="Apply Now"
                                    type="text"
                                    fullWidth
                                    value={services?.applynow || ""}
                                    onChange={(e) => handleServicesChange("applynow", null, e.target.value)}
                                />
                            </div>
                            <div className="col-lg-6 col-12">
                                <label className="mt-2">Apply Now Link</label>
                                <CustomField
                                    required
                                    className="mt-2"
                                    margin="dense"
                                    label="Apply Now Link"
                                    type="text"
                                    fullWidth
                                    value={services?.link || ""}
                                    onChange={(e) => handleServicesChange("link", null, e.target.value)}
                                />
                            </div>
                        </div>


                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleAddClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

        </>
    )
}
export default CareerOppurTable;