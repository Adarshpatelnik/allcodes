import React, { useState, useRef, useEffect } from "react";
import SideBar from "../Sidebar/Sidebar";
import { Card, CardContent, IconButton, Button } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import "../../assets/styles/custom.css"
import Dropdown from "../../components/Dropdown";
import Loader from "../../components/loader";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import CustomField from "../../components/CustomField";
import Swal from "sweetalert2";
import apiFunctions from "../../api/apiFunctions";
import { appConstants } from "../../constants/appConstants";
import CareerOppurTable from "./CareerOppurTable";
import messages from "../../constants/messages";

const Careers = () => {
    const [isOpen, setIsopen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoader, setIsLoader] = useState(false);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    const formats = [
        "header", "bold", "italic", "underline", "color", "list", "align",
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: ["#298939", "#FFFFFF", "#4A4A4A", "#012354"] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    //Banner Section
    const [topBanner, setTopBanner] = useState({
        headline: "",
        headlinelink: "",
        mainheadline: "",
        subheadline: "",
        button: "",
        link: ""
    });

    const handleTopBannerChange = (field, subfield, value) => {
        setTopBanner((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [media, setMedia] = useState(null);
    const [mediaFile, setMediaFile] = useState(null);
    const [mediaType, setMediaType] = useState(null);

    const handleFileChange = (e) => {
        const file = e.target.files[0];

        if (file) {
            if (file.type.split("/")[0] === "video" && file.size > 10 * 1024 * 1024) {
                Swal.fire({
                    text: "The video file size should be under 10MB.",
                    icon: 'error'
                });
                return;
            }

            setMediaFile(file);
            const fileType = file.type.split("/")[0];
            setMediaType(fileType);

            if (fileType === "image") {
                const reader = new FileReader();
                reader.onload = () => {
                    setMedia(reader.result);
                };
                reader.readAsDataURL(file);
            } else if (fileType === "video") {
                setMedia(URL.createObjectURL(file));
            }
        }
    };

    const handleTopBannerSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            headline: topBanner?.headline,
            headlinelink: topBanner?.headlinelink,
            mainheadline: topBanner?.mainheadline,
            subheadline: topBanner?.subheadline,
            button: topBanner?.button,
            link: topBanner?.link
        }


        if (mediaFile && mediaFile instanceof File) {
            form.append("image", mediaFile);
        }

        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCareer(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.banner?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getTopBannerData();
            } else {
                throw new Error(messages?.banner?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const getTopBannerData = () => {
        apiFunctions.getCareer()
            .then((res) => {

                if (res?.status === 200 && res?.data?.data?.length > 0) {

                    const contentData = JSON.parse(res?.data?.data[0]?.content || "");
                    const imageData = res?.data?.data[0]?.images;
                    const imageUrl = imageData ? appConstants?.imageUrl + imageData : null;

                    setMedia(imageUrl);
                    setMediaType(imageData ? "image" : null);

                    setTopBanner({
                        headline: contentData?.headline,
                        headlinelink: contentData?.headlinelink,
                        mainheadline: contentData?.mainheadline,
                        subheadline: contentData?.subheadline,
                        button: contentData?.button,
                        link: contentData?.link
                    });
                } else {
                    setTopBanner({});
                }
            })
            .catch((err) => {
                console.error("Error fetching Top Banner Data:", err);
                setTopBanner({});
            });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        let timeout = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        if (!isFetched.current) {
            getTopBannerData();
            isFetched.current = true;
        }

        return () => clearTimeout(timeout);
    }, []);


    return (
        <>
            <div className="container-fluid p-0 " style={{ overflow: 'hidden' }}>
                <div className="row">
                    <div className={`${isOpen ? "col-lg-2  mob-nav p-0" : "d-none"} sidebar_layout`}>
                        <SideBar />
                    </div>
                    <div className={`${isOpen ? "col-lg-10 col-12  " : "col-12 w-100"} dashboard_card main_layout`} >

                        <div className="d-flex w-100 justify mob-sticky mb-2">
                            <IconButton className="web-btn" onClick={handleOpen} >
                                <MenuIcon />
                            </IconButton>
                            <IconButton className="mob-btn" data-bs-toggle="offcanvas" data-bs-target="#mob-canvas" aria-controls="mob-canvas">
                                <MenuIcon />
                            </IconButton>
                            <div className="logout_dropdown">
                                <Dropdown />
                            </div>
                        </div>
                        {isLoading ?
                            <Loader /> :
                            <>
                                <Card className="p-lg-2 p-1">
                                    <CardContent>
                                        {/* Banner Section */}
                                        <div className="row">
                                            <div className="col-lg-6 col-12">
                                                <h4 className="fw-medium" style={{ color: "#298939" }}>Careers Page</h4>
                                                <h5 style={{ color: "#012354" }}>Banner Section</h5>
                                            </div>
                                        </div>
                                        <form onSubmit={handleTopBannerSave}>
                                            <div className="row mt-2">
                                                <div className="col-lg-8 col-12">
                                                    {media && (
                                                        <>
                                                            {mediaType === "image" ? (
                                                                <div className="mb-2">
                                                                    <img src={media} alt="" className="input-img" />
                                                                </div>
                                                            ) : (
                                                                <div className="mb-2">
                                                                    <video
                                                                        className="input-img"
                                                                        controls
                                                                        key={media}
                                                                    >
                                                                        <source src={media} type="video/mp4" />
                                                                        Your browser does not support the video tag.
                                                                    </video>
                                                                </div>
                                                            )}
                                                        </>
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={handleFileChange}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                {/* Left Column */}
                                                {/* <div className="col-lg-6 col-12">
                                                    <CustomField
                                                        value={topBanner?.headline || ""}
                                                        onChange={(e) => handleTopBannerChange("headline", null, e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={topBanner?.headlinelink || ""}
                                                        onChange={(e) => handleTopBannerChange("headlinelink", null, e.target.value)}
                                                        margin="dense" label="Head Line Link" type="text" size="small" fullWidth className="mb-2" />
                                                </div> */}

                                                {/* Right Column */}
                                                <div className="col-lg-6 col-12">
                                                    <CustomField
                                                        value={topBanner?.mainheadline || ""}
                                                        onChange={(e) => handleTopBannerChange("mainheadline", null, e.target.value)}
                                                        margin="dense" label="Main Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={topBanner?.subheadline || ""}
                                                        onChange={(e) => handleTopBannerChange("subheadline", null, e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                <div className="text-end">
                                                    {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                                    <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                                        {isLoader ? "Saving..." : "Save"}
                                                    </Button>
                                                </div>
                                            </div>
                                        </form>
                                        {/* Career Oppurtunities */}
                                        <div className="row mt-3 mb-3">
                                            <div className="col-lg-6 col-12">
                                                <h5 style={{ color: "#012354" }}>Career Oppurtunities</h5>
                                            </div>
                                        </div>
                                        <CareerOppurTable />
                                    </CardContent>
                                </Card>
                            </>
                        }
                    </div>
                </div>
            </div>
            <div className="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabIndex="-1" id="mob-canvas" aria-labelledby="mob-canvaslabel">
                <div className="offcanvas-header" style={{ background: "transparent" }}>
                    <IconButton data-bs-dismiss="offcanvas" aria-label="Close">
                        <CloseIcon style={{ height: '40px', width: '40px', color: 'black', marginTop: "20px" }} />
                    </IconButton>
                </div>
                <div className="offcanvas-body p-0">
                    <SideBar />
                </div>
            </div>
        </>
    )
}
export default Careers;