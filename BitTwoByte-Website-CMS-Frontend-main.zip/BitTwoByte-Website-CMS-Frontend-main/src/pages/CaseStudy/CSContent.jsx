import React, { useState, useRef, useEffect } from "react";
import SideBar from "../Sidebar/Sidebar";
import { Card, CardContent, IconButton, Button, Alert } from "@mui/material";
import "../../assets/styles/custom.css"
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import CustomField from "../../components/CustomField";
import Swal from "sweetalert2";
import apiFunctions from "../../api/apiFunctions";
import { appConstants } from "../../constants/appConstants";
import { ArrowBack, Delete, ControlPoint } from "@mui/icons-material";
import arrow from "../../assets/images/arrow.png";
import Loader from "../../components/loader";
import messages from "../../constants/messages";

const CSContent = ({ onBack, data }) => {
    const [isOpen, setIsopen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoader, setIsLoader] = useState(false);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    const formats = [
        "header", "bold", "italic", "underline", "color", "list", "align",
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: ["#298939", "#FFFFFF", "#4A4A4A", "#012354"] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    //Overview Section
    const [overview, setOverview] = useState({
        img: "",
        imgFile: "",
        context: "",
        industy: "",
        serviceused: "",
        region: "",
        funcDepart: "",
        Engmodel: ""
    });

    const handleOverviewChange = (field, subfield, value) => {
        setOverview((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleOverviewSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            context: overview?.context,
            industy: overview?.industy,
            serviceused: overview?.serviceused,
            region: overview?.region,
            funcDepart: overview?.funcDepart,
            Engmodel: overview?.Engmodel
        }


        if (overview?.imgFile instanceof File) {
            form.append("image", overview?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecOne(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Challenges Section
    const [challenges, setChallenges] = useState({
        cardone: {
            headline: "",
            subheadline: ""
        },
        cardtwo: {
            headline: "",
            subheadline: ""
        },
        cardthree: {
            headline: "",
            subheadline: ""
        },
        cardfour: {
            headline: "",
            subheadline: ""
        },
    });

    const handleChallengesChange = (field, subfield, value) => {
        setChallenges((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleChallengesSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = challenges


        // if (overview?.imgFile instanceof File) {
        //     form.append("image", overview?.imgFile);
        // }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecTwo(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Solution Design and Implementation Section
    const [solution, setSolution] = useState({
        img: "",
        imgFile: "",
        cardone: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
        cardtwo: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
        cardthree: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
        cardfour: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
    });

    const handleSolutionChange = (field, subfield, value) => {
        setSolution((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [fields, setFields] = useState([{ id: 1, value: "" }]);

    const handleAddField = () => {
        if (fields.length >= 10) {
            Swal.fire({
                icon: 'warning',
                text: 'Maximum content limit reached. You can add only up to 10 contents.',
            });
            return;
        }
        const newId = fields.length > 0 ? Math.max(...fields.map(f => f.id)) + 1 : 1;
        setFields([...fields, { id: newId, value: "" }]);
    };

    const handleDeleteField = (id) => {
        setFields(fields.filter(field => field.id !== id));
    };

    const handleFieldChange = (id, newValue) => {
        setFields(fields.map(field =>
            field.id === id ? { ...field, value: newValue } : field
        ));
    };

    const [cardcontent, setCardContent] = useState([
        {
            id: 1,
            headline: "",
            subheadlineone: "",
            subheadlinetwo: "",
            subheadlinethree: ""
        },
    ]);

    const handleAddCardContent = () => {
        if (cardcontent.length >= 5) {
            Swal.fire({
                icon: 'warning',
                text: 'Maximum content limit reached. You can add only up to 5 contents.',
            });
            return;
        }
        setCardContent(prev => [
            ...prev,
            {
                id: prev.length > 0 ? prev[prev.length - 1].id + 1 : 1,
                headline: "",
                subheadline: "",
                subheadlinetwo: "",
                subheadlinethree: ""
            },
        ]);
    };

    const handleDeleteCardContent = (id) => {
        setCardContent(prev => prev.filter(item => item.id !== id));
    };

    const handleCardContentChange = (id, key, value) => {
        setCardContent(prev =>
            prev.map(item =>
                item.id === id ? { ...item, [key]: value } : item
            )
        );
    };


    const handleSolutionSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const filteredfieldspoints = fields.filter(item => {
            const isValue = !item.value || item.value.trim() === "";
            return !(isValue); // Only keep if at least one is filled
        });

        const filteredCardpoints = cardcontent.filter(item => {
            return Object.values(item).some(val =>
                typeof val === "string" && val.trim() !== ""
            );
        });

        // 🔍 Check bullet points
        if (filteredfieldspoints.length === 0) {
            Swal.fire({
                text: "Please enter at least one bullet point.",
                icon: 'warning'
            });
            setIsLoader(false);
            return;
        }

        // 🔍 Check card content
        if (filteredCardpoints.length === 0) {
            Swal.fire({
                text: "Please enter at least one card content.",
                icon: 'warning'
            });
            setIsLoader(false);
            return;
        }


        const form = new FormData();
        const json = {
            bulletpoints: filteredfieldspoints,
            cardcontent: filteredCardpoints
        }


        if (solution?.imgFile instanceof File) {
            form.append("image", solution?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecThree(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Key Achievements
    const [keyAchieve, setKeyAchieve] = useState({
        img: "",
        imgFile: "",
    });

    const handleKeyAchieveChange = (field, subfield, value) => {
        setKeyAchieve((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [keypoints, setKeypoints] = useState([
        { id: 1, headline: "", subheadline: "" },
    ]);

    const handleAddKeypoint = () => {
        if (keypoints.length >= 7) {
            Swal.fire({
                icon: 'warning',
                text: 'Maximum content limit reached. You can add only up to 7 contents.',
            });
            return;
        }
        setKeypoints(prev => [
            ...prev,
            {
                id: prev.length > 0 ? prev[prev.length - 1].id + 1 : 1,
                headline: "",
                subheadline: "",
            },
        ]);
    };

    const handleDeleteKeypoint = (id) => {
        setKeypoints(prev => prev.filter(item => item.id !== id));
    };

    const handleKeypointChange = (id, key, value) => {
        setKeypoints(prev =>
            prev.map(item =>
                item.id === id ? { ...item, [key]: value } : item
            )
        );
    };

    const handleKeyAchieveSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const filteredKeypoints = keypoints.filter(item => {
            const isHeadlineEmpty = !item.headline || item.headline.trim() === "";
            const isSubheadlineEmpty = !item.subheadline || item.subheadline.trim() === "";
            return !(isHeadlineEmpty && isSubheadlineEmpty); // Only keep if at least one is filled
        });

        // 🔍 Check if there are no valid keypoints
        if (filteredKeypoints.length === 0) {
            Swal.fire({
                text: "Please enter at least one key achievement.",
                icon: 'warning'
            });
            setIsLoader(false);
            return;
        }


        const form = new FormData();
        const json = {
            bulletpoints: filteredKeypoints,
        }


        if (keyAchieve?.imgFile instanceof File) {
            form.append("image", keyAchieve?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecFour(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Technical Skills and Tools Used:
    const [techSkills, setTechSkills] = useState({
        img: "",
        imgFile: "",
    });

    const handleTechSkillsChange = (field, subfield, value) => {
        setTechSkills((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [techpoints, setTechPoints] = useState([
        { id: 1, headline: "", subheadline: "" },
    ]);

    const handleAddTechpoint = () => {
        if (techpoints.length >= 7) {
            Swal.fire({
                icon: 'warning',
                text: 'Maximum content limit reached. You can add only up to 7 contents.',
            });
            return;
        }
        setTechPoints(prev => [
            ...prev,
            {
                id: prev.length > 0 ? prev[prev.length - 1].id + 1 : 1,
                headline: "",
                subheadline: "",
            },
        ]);
    };

    const handleDeleteTechpoint = (id) => {
        setTechPoints(prev => prev.filter(item => item.id !== id));
    };

    const handleTechpointChange = (id, key, value) => {
        setTechPoints(prev =>
            prev.map(item =>
                item.id === id ? { ...item, [key]: value } : item
            )
        );
    };

    const handleTechSkillsSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const filteredTechPoints = techpoints.filter(item => {
            const isHeadlineEmpty = !item.headline || item.headline.trim() === "";
            const isSubheadlineEmpty = !item.subheadline || item.subheadline.trim() === "";
            return !(isHeadlineEmpty && isSubheadlineEmpty); // Only keep if at least one is filled
        });

        // 🔍 Check if there are no valid keypoints
        if (filteredTechPoints.length === 0) {
            Swal.fire({
                text: "Please enter at least one key achievement.",
                icon: 'warning'
            });
            setIsLoader(false);
            return;
        }


        const form = new FormData();
        const json = {
            bulletpoints: filteredTechPoints,
        }


        if (techSkills?.imgFile instanceof File) {
            form.append("image", techSkills?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecFive(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //BusinessImpact
    const [BusinessImpact, setBusinessImpact] = useState({
        img: "",
        imgFile: "",
    });

    const handleBusinessImpactChange = (field, subfield, value) => {
        setBusinessImpact((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [BusinessImpactPoints, setBusinessImpactPoints] = useState([
        { id: 1, headline: "", subheadline: "" },
    ]);

    const handleAddBusinesspoint = () => {
        if (BusinessImpactPoints.length >= 7) {
            Swal.fire({
                icon: 'warning',
                text: 'Maximum content limit reached. You can add only up to 7 contents.',
            });
            return;
        }
        setBusinessImpactPoints(prev => [
            ...prev,
            {
                id: prev.length > 0 ? prev[prev.length - 1].id + 1 : 1,
                headline: "",
                subheadline: "",
            },
        ]);
    };

    const handleDeleteBusinesspoint = (id) => {
        setBusinessImpactPoints(prev => prev.filter(item => item.id !== id));
    };

    const handleBusinessChange = (id, key, value) => {
        setBusinessImpactPoints(prev =>
            prev.map(item =>
                item.id === id ? { ...item, [key]: value } : item
            )
        );
    };

    const handleBusinessImpactSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const filteredBusinessPoints = BusinessImpactPoints.filter(item => {
            const isHeadlineEmpty = !item.headline || item.headline.trim() === "";
            const isSubheadlineEmpty = !item.subheadline || item.subheadline.trim() === "";
            return !(isHeadlineEmpty && isSubheadlineEmpty); // Only keep if at least one is filled
        });

        // 🔍 Check if there are no valid keypoints
        if (filteredBusinessPoints.length === 0) {
            Swal.fire({
                text: "Please enter at least one key achievement.",
                icon: 'warning'
            });
            setIsLoader(false);
            return;
        }


        const form = new FormData();
        const json = {
            bulletpoints: filteredBusinessPoints,
        }


        if (BusinessImpact?.imgFile instanceof File) {
            form.append("image", BusinessImpact?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecSix(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Keytakeaways
    const [KeyTakeaways, setKeyTakeAways] = useState({
        img: "",
        imgFile: "",
    });

    const handleKeyTakeAwaysChange = (field, subfield, value) => {
        setKeyTakeAways((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [KeyTakeAwaysPoints, setKeyTakeAwaysPoints] = useState([
        { id: 1, headline: "", subheadline: "" },
    ]);

    const handleAddKeyTakeAwaysPoints = () => {
        if (KeyTakeAwaysPoints.length >= 7) {
            Swal.fire({
                icon: 'warning',
                text: 'Maximum content limit reached. You can add only up to 7 contents.',
            });
            return;
        }
        setKeyTakeAwaysPoints(prev => [
            ...prev,
            {
                id: prev.length > 0 ? prev[prev.length - 1].id + 1 : 1,
                headline: "",
                subheadline: "",
            },
        ]);
    };

    const handleDeleteKeyTakeAwaysPoints = (id) => {
        setKeyTakeAwaysPoints(prev => prev.filter(item => item.id !== id));
    };

    const handleKeyTakeAwaysPointsChange = (id, key, value) => {
        setKeyTakeAwaysPoints(prev =>
            prev.map(item =>
                item.id === id ? { ...item, [key]: value } : item
            )
        );
    };

    const handleKeyTakeAwaysSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const filteredKeyTakeAwaysPoints = KeyTakeAwaysPoints.filter(item => {
            const isHeadlineEmpty = !item.headline || item.headline.trim() === "";
            const isSubheadlineEmpty = !item.subheadline || item.subheadline.trim() === "";
            return !(isHeadlineEmpty && isSubheadlineEmpty); // Only keep if at least one is filled
        });

        // 🔍 Check if there are no valid keypoints
        if (filteredKeyTakeAwaysPoints.length === 0) {
            Swal.fire({
                text: "Please enter at least one key achievement.",
                icon: 'warning'
            });
            setIsLoader(false);
            return;
        }


        const form = new FormData();
        const json = {
            bulletpoints: filteredKeyTakeAwaysPoints,
        }


        if (KeyTakeaways?.imgFile instanceof File) {
            form.append("image", KeyTakeaways?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecSeven(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Conclusion Section
    const [conclusion, setConclusion] = useState({
        conclusion: ""
    });

    const handleConclusionChange = (field, subfield, value) => {
        setConclusion((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleConclusionSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            conclusion: conclusion?.conclusion,
        }


        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecEight(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };
    const [enabledSections, setEnabledSections] = useState({
        overview: true,
        challenges: false,
        solution: false,
        keyAchievements: false,
        techskills: false,
        businessImpact: false,
        keytakeaways: false,
        conclusion: false
    });



    const getAllData = () => {
        // Safe JSON parse utility
        const safeParse = (json) => {
            try {
                return JSON.parse(json);
            } catch {
                return {};
            }
        };

        // Safe image URL generator
        const getImageUrl = (imgData) => {
            if (!imgData) return "";
            if (typeof imgData === "string") return appConstants?.imageUrl + imgData;
            if (Array.isArray(imgData) && imgData.length > 0) return appConstants?.imageUrl + imgData[0];
            return "";
        };

        apiFunctions.getAllCSContent(data)
            .then((res) => {
                if (res?.status === 200 && res?.data?.length > 0) {

                    // ---------------- Overview Section ----------------
                    const overviewData = safeParse(res?.data?.[0]?.content || "");
                    const overviewimgData = res?.data?.[0]?.images;

                    const hasOverview = !!(
                        overviewData?.context?.trim() ||
                        overviewData?.industy?.trim() ||
                        overviewData?.serviceused?.trim() ||
                        overviewData?.region?.trim() ||
                        overviewData?.funcDepart?.trim() ||
                        overviewData?.Engmodel?.trim()
                    );

                    setOverview({
                        img: getImageUrl(overviewimgData),
                        imgFile: "",
                        context: overviewData?.context,
                        industy: overviewData?.industy,
                        serviceused: overviewData?.serviceused,
                        region: overviewData?.region,
                        funcDepart: overviewData?.funcDepart,
                        Engmodel: overviewData?.Engmodel
                    });


                    // Overview is always enabled, so Challenges section depends on Overview
                    if (hasOverview) {
                        setEnabledSections((prev) => ({ ...prev, challenges: true }));
                    }

                    // ---------------- Challenges Section ----------------
                    const challengesData = safeParse(res?.data?.[1]?.content || "");
                    const challengesimgData = res?.data?.[1]?.images;

                    const hasChallenges = !!(
                        challengesData?.cardone?.headline?.trim() ||
                        challengesData?.cardtwo?.headline?.trim() ||
                        challengesData?.cardthree?.headline?.trim() ||
                        challengesData?.cardfour?.headline?.trim()
                    );

                    setChallenges({
                        cardone: {
                            headline: challengesData?.cardone?.headline,
                            subheadline: challengesData?.cardone?.subheadline
                        },
                        cardtwo: {
                            headline: challengesData?.cardtwo?.headline,
                            subheadline: challengesData?.cardtwo?.subheadline
                        },
                        cardthree: {
                            headline: challengesData?.cardthree?.headline,
                            subheadline: challengesData?.cardthree?.subheadline
                        },
                        cardfour: {
                            headline: challengesData?.cardfour?.headline,
                            subheadline: challengesData?.cardfour?.subheadline
                        },
                    });

                    if (hasOverview && hasChallenges) {
                        setEnabledSections((prev) => ({ ...prev, solution: true }));
                    }

                    // ---------------- Solutions Section ----------------
                    const solutionsData = safeParse(res?.data?.[2]?.content || "");

                    const solutionsimgData = res?.data?.[2]?.images;

                    const hasBulletpoints = Array.isArray(solutionsData?.bulletpoints) &&
                        solutionsData.bulletpoints.some(bp => bp.value && bp.value.trim() !== "");

                    const hasSolution = hasBulletpoints || (
                        Array.isArray(solutionsData?.cardcontent) &&
                        solutionsData.cardcontent.some(card =>
                            (card.headline && card.headline.trim() !== "") ||
                            (card.subheadlineone && card.subheadlineone.trim() !== "") ||
                            (card.subheadlinetwo && card.subheadlinetwo.trim() !== "") ||
                            (card.subheadlinethree && card.subheadlinethree.trim() !== "")
                        )
                    );

                    setSolution({
                        img: getImageUrl(solutionsimgData),
                        imgFile: "",
                    });

                    setCardContent(solutionsData?.cardcontent || [{
                        id: 1,
                        headline: "",
                        subheadlineone: "",
                        subheadlinetwo: "",
                        subheadlinethree: ""
                    }]);

                    setFields(solutionsData?.bulletpoints || [{ id: 1, value: "" }]);

                    if (hasOverview && hasChallenges && hasSolution) {
                        setEnabledSections((prev) => ({ ...prev, keyAchievements: true }));
                    }

                    // ---------------- Key Achievements Section ----------------
                    const keyAchieveData = safeParse(res?.data?.[3]?.content || "");

                    const keyAchieveimgData = res?.data?.[3]?.images;

                    const hasKeyAchievements = Array.isArray(keyAchieveData?.bulletpoints) && keyAchieveData?.bulletpoints.length > 0;

                    setKeyAchieve({
                        img: getImageUrl(keyAchieveimgData),
                        imgFile: "",
                    });

                    setKeypoints(keyAchieveData?.bulletpoints || [{ id: 1, headline: "", subheadline: "" }]);

                    if (hasOverview && hasChallenges && hasSolution && hasKeyAchievements) {
                        setEnabledSections((prev) => ({ ...prev, techskills: true }));
                    }

                    // ---------------- Technical Skills Section ----------------
                    const TechSkillsData = safeParse(res?.data?.[4]?.content || "");

                    const TechSkillsimgData = res?.data?.[4]?.images;

                    const hasTechnicalSkills = Array.isArray(TechSkillsData?.bulletpoints) && TechSkillsData?.bulletpoints.length > 0;

                    setTechSkills({
                        img: getImageUrl(TechSkillsimgData),
                        imgFile: "",
                    });

                    setTechPoints(TechSkillsData?.bulletpoints || [{ id: 1, headline: "", subheadline: "" }]);

                    if (hasOverview && hasChallenges && hasSolution && hasKeyAchievements && hasTechnicalSkills) {
                        setEnabledSections((prev) => ({ ...prev, businessImpact: true }));
                    }

                    // ---------------- Business Impact  Section ----------------
                    const BusinessImpactData = safeParse(res?.data?.[5]?.content || "");

                    const BusinessImpactimgData = res?.data?.[5]?.images;

                    const hasBusinessImpact = Array.isArray(TechSkillsData?.bulletpoints) && TechSkillsData?.bulletpoints.length > 0;

                    setBusinessImpact({
                        img: getImageUrl(BusinessImpactimgData),
                        imgFile: "",
                    });

                    setBusinessImpactPoints(BusinessImpactData?.bulletpoints || [{ id: 1, headline: "", subheadline: "" }]);

                    if (hasOverview && hasChallenges && hasSolution && hasKeyAchievements && hasTechnicalSkills && hasBusinessImpact) {
                        setEnabledSections((prev) => ({ ...prev, keytakeaways: true }));
                    }

                    // ---------------- Key Takeaways  Section ----------------
                    const KeyTakeAwaysData = safeParse(res?.data?.[6]?.content || "");

                    const KeyTakeAwaysimgData = res?.data?.[6]?.images;

                    const hasKeyTakeAways = Array.isArray(KeyTakeAwaysData?.bulletpoints) && KeyTakeAwaysData?.bulletpoints.length > 0;

                    setKeyTakeAways({
                        img: getImageUrl(KeyTakeAwaysimgData),
                        imgFile: "",
                    });

                    setKeyTakeAwaysPoints(KeyTakeAwaysData?.bulletpoints || [{ id: 1, headline: "", subheadline: "" }]);

                    if (hasOverview && hasChallenges && hasSolution && hasKeyAchievements && hasTechnicalSkills && hasBusinessImpact && hasKeyTakeAways) {
                        setEnabledSections((prev) => ({ ...prev, conclusion: true }));
                    }

                    // ---------------- Conclusion  Section ----------------
                    const ConclusionData = safeParse(res?.data?.[7]?.content || "");

                    const ConclusionimgData = res?.data?.[7]?.images;

                    const hasConclusion = Array.isArray(TechSkillsData?.bulletpoints) && TechSkillsData?.bulletpoints.length > 0;

                    setConclusion({
                        conclusion: ConclusionData?.conclusion || ""
                    })

                } else {
                    setOverview({});
                    setChallenges({});
                }
            })
            .catch((err) => {
                console.error("Error fetching All Context Data:", err);
                setOverview({});
                setChallenges({});
            });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        let timeout = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        if (!isFetched.current) {
            getAllData();
            isFetched.current = true;
        }

        return () => clearTimeout(timeout);
    }, []);


    return (
        <>
            {
                isLoading ?
                    <Loader /> :
                    <>
                        {/* Banner Section */}
                        <div className="row">
                            <div className="col-lg-6 col-12">
                                {/* <h4 className="fw-medium" style={{ color: "#298939" }}>Data Analytics Service</h4> */}
                                {/* <h5 style={{ color: "#012354" }}>Banner Section</h5> */}
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-12 d-flex justify-content-end">
                                <Button className="btn mt-2 mb-2" variant="contained" onClick={onBack} startIcon={<ArrowBack />}>
                                    Back
                                </Button>
                            </div>
                            <div className="row mb-2 mt-2">
                                <div className="col-lg col-12">
                                    <Alert severity="info">
                                        Each section will become available <strong>only after saving the previous section</strong>. Please complete and save each section one by one.
                                    </Alert>
                                </div>
                            </div>
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>
                                    Project Overview Section
                                </h5>
                            </div>
                        </div>
                        <form onSubmit={handleOverviewSave}>
                            <div className="row mt-2">
                                <div className="col-lg-8 col-12">
                                    {overview?.img ? (
                                        <div className="mb-2">
                                            <img src={overview?.img} alt="" className="input-img" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleOverviewChange("imgFile", null, file);
                                                    handleOverviewChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            required={!overview?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                {/* Left Column */}
                                <div className="col-lg-6 col-12">
                                    <CustomField
                                        required
                                        multiline
                                        rows={3}
                                        value={overview?.context || ""}
                                        onChange={(e) => handleOverviewChange("context", null, e.target.value)}
                                        margin="dense" label="Context" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.industy || ""}
                                        onChange={(e) => handleOverviewChange("industy", null, e.target.value)}
                                        margin="dense" label="Industry" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.serviceused || ""}
                                        onChange={(e) => handleOverviewChange("serviceused", null, e.target.value)}
                                        margin="dense" label="Service Used" type="text" size="small" fullWidth className="mb-2" />
                                </div>

                                {/* Right Column */}
                                <div className="col-lg-6 col-12">
                                    <CustomField
                                        required
                                        value={overview?.region || ""}
                                        onChange={(e) => handleOverviewChange("region", null, e.target.value)}
                                        margin="dense" label="Region" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.funcDepart || ""}
                                        onChange={(e) => handleOverviewChange("funcDepart", null, e.target.value)}
                                        margin="dense" label="Function / Department" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.Engmodel || ""}
                                        onChange={(e) => handleOverviewChange("Engmodel", null, e.target.value)}
                                        margin="dense" label="Engagement Model" type="text" size="small" fullWidth className="mb-2" />
                                </div>

                                <div className="text-end">
                                    {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                    <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                        {isLoader ? "Saving..." : "Save"}
                                    </Button>
                                </div>
                            </div>
                        </form>
                        {/* Challenges Addressed */}
                        <div className="row mt-3 mb-3">
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Challenges Addressed Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleChallengesSave}>
                            <div className="row">
                                {/* Left Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge One</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardone?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardone", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardone?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardone", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                                {/* Right Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge Two</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardtwo?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardtwo", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardtwo?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardtwo", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                            </div>
                            <div className="row">
                                {/* Left Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge Three</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardthree?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardthree", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardthree?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardthree", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                                {/* Right Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge Four</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardfour?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardfour", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardfour?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardfour", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                            </div>
                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.challenges}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>
                        {/* Solution Design and Implementation */}
                        <div className="row mt-3 mb-3">
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Solution Design and Implementation Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleSolutionSave}>
                            <div className="row">
                                <div className="col-lg-8 col-12">
                                    {solution?.img ? (
                                        <div className="mb-2">
                                            <img src={solution?.img} alt="" className="input-img" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleSolutionChange("imgFile", null, file);
                                                    handleSolutionChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            disabled={!enabledSections.solution}
                                            required={!solution?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                <div className="col-lg col-12">
                                    <div style={{ border: "1px dashed #707070", borderRadius: '22px', padding: '16px' }}>
                                        {fields.map((field, index) => (
                                            <div key={field.id} className="d-flex align-items-center mb-2">
                                                <div className="col-lg me-2">
                                                    <img src={arrow} alt="arrow" className="me-2" style={{ width: '16px', height: '16px' }} />
                                                </div>
                                                <CustomField
                                                    disabled={!enabledSections.solution}
                                                    margin="dense"
                                                    label="Bullet Point"
                                                    type="text"
                                                    size="small"
                                                    fullWidth
                                                    value={field.value}
                                                    onChange={(e) => handleFieldChange(field.id, e.target.value)}
                                                />

                                                {fields.length === 1 || index === fields.length - 1 ? (
                                                    <IconButton className="ms-2" onClick={handleAddField}>
                                                        <ControlPoint />
                                                    </IconButton>
                                                ) : (
                                                    <IconButton className="ms-2" onClick={() => handleDeleteField(field.id)}>
                                                        <Delete />
                                                    </IconButton>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {Array.from({ length: Math.ceil(cardcontent.length / 2) }).map((_, rowIndex) => (
                                <div className="row mt-2" key={rowIndex}>
                                    {/* Left Column */}
                                    <div className="col-lg-6 col-12">
                                        {(() => {
                                            const index = rowIndex * 2;
                                            const item = cardcontent[index];
                                            if (!item) return null;

                                            return (
                                                <>
                                                    <p style={{ color: "#012354" }} className="mb-2">Content {index + 1}</p>
                                                    <div className="d-flex">
                                                        {/* Left side: Fields */}
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                value={item?.headline || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "headline", e.target.value)}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={item?.subheadlineone || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "subheadlineone", e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line One"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={item?.subheadlinetwo || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "subheadlinetwo", e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line Two"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={item?.subheadlinethree || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "subheadlinethree", e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line Three"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                        </div>
                                                        <div className="ms-2 d-flex flex-column">
                                                            {index === cardcontent.length - 1 ? (
                                                                <IconButton className="mt-2" disabled={!enabledSections.solution} onClick={handleAddCardContent}>
                                                                    <ControlPoint />
                                                                </IconButton>
                                                            ) : (
                                                                <IconButton className="mt-2" onClick={() => handleDeleteCardContent(item.id)}>
                                                                    <Delete />
                                                                </IconButton>
                                                            )}
                                                        </div>
                                                    </div>
                                                </>
                                            );
                                        })()}
                                    </div >
                                    {/* Right Column */}
                                    < div className="col-lg-6 col-12" >
                                        {(() => {
                                            const index = rowIndex * 2 + 1;
                                            const item = cardcontent[index];
                                            if (!item) return null;

                                            return (
                                                <>
                                                    <p style={{ color: "#012354" }} className="mb-2">Content {index + 1}</p>
                                                    <div className="d-flex">
                                                        {/* Left side: Fields */}
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                value={item?.headline || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "headline", e.target.value)}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={item?.subheadlineone || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "subheadlineone", e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line One"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={item?.subheadlinetwo || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "subheadlinetwo", e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line Two"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={item?.subheadlinethree || ""}
                                                                onChange={(e) => handleCardContentChange(item.id, "subheadlinethree", e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line Three"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                        </div>
                                                        <div className="ms-2 d-flex flex-column">
                                                            {index === cardcontent.length - 1 ? (
                                                                <IconButton className="mt-2" disabled={!enabledSections.solution} onClick={handleAddCardContent}>
                                                                    <ControlPoint />
                                                                </IconButton>
                                                            ) : (
                                                                <IconButton className="mt-2" onClick={() => handleDeleteCardContent(item.id)}>
                                                                    <Delete />
                                                                </IconButton>
                                                            )}
                                                        </div>
                                                    </div>
                                                </>
                                            );
                                        })()
                                        }
                                    </div >
                                </div>
                            ))}

                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.solution}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>
                        {/* Key Achievements */}
                        < div className="row mt-3 mb-3" >
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Key Achievements Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleKeyAchieveSave}>
                            <div className="row">
                                <div className="col-lg-8 col-12">
                                    {keyAchieve?.img ? (
                                        <div className="mb-2">
                                            <img src={keyAchieve?.img} alt="" className="input-img-potrait" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleKeyAchieveChange("imgFile", null, file);
                                                    handleKeyAchieveChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            disabled={!enabledSections.keyAchievements}
                                            required={!keyAchieve?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                {Array.from({ length: Math.ceil(keypoints.length / 2) }).map((_, rowIndex) => (
                                    <div className="row mb-2" key={rowIndex}>
                                        {/* Left Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2;
                                                const item = keypoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === keypoints.length - 1 ? (
                                                            <IconButton className="mt-2" disabled={!enabledSections.keyAchievements} onClick={handleAddKeypoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteKeypoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>

                                        {/* Right Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2 + 1;
                                                const item = keypoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === keypoints.length - 1 ? (
                                                            <IconButton className="mt-2" onClick={handleAddKeypoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteKeypoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.keyAchievements}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>

                        {/* Technical Skills and Tools Used: */}
                        < div className="row mt-3 mb-3" >
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Technical Skills and Tools Used Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleTechSkillsSave}>
                            <div className="row">
                                <div className="col-lg-8 col-12">
                                    {techSkills?.img ? (
                                        <div className="mb-2">
                                            <img src={techSkills?.img} alt="" className="input-img-potrait" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleTechSkillsChange("imgFile", null, file);
                                                    handleTechSkillsChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            disabled={!enabledSections.techskills}
                                            required={!techSkills?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                {Array.from({ length: Math.ceil(techpoints.length / 2) }).map((_, rowIndex) => (
                                    <div className="row mb-2" key={rowIndex}>
                                        {/* Left Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2;
                                                const item = techpoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.techskills}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleTechpointChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.techskills}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleTechpointChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === techpoints.length - 1 ? (
                                                            <IconButton className="mt-2" disabled={!enabledSections.techskills} onClick={handleAddTechpoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteTechpoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>

                                        {/* Right Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2 + 1;
                                                const item = techpoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.techskills}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleTechpointChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.techskills}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleTechpointChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === techpoints.length - 1 ? (
                                                            <IconButton className="mt-2" onClick={handleAddTechpoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteTechpoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.techskills}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>

                        {/* Business Impact and Outcomes: */}
                        < div className="row mt-3 mb-3" >
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Business Impact and Outcomes Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleBusinessImpactSave}>
                            <div className="row">
                                <div className="col-lg-8 col-12">
                                    {BusinessImpact?.img ? (
                                        <div className="mb-2">
                                            <img src={BusinessImpact?.img} alt="" className="input-img-potrait" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleBusinessImpactChange("imgFile", null, file);
                                                    handleBusinessImpactChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            disabled={!enabledSections.businessImpact}
                                            required={!BusinessImpact?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                {Array.from({ length: Math.ceil(BusinessImpactPoints.length / 2) }).map((_, rowIndex) => (
                                    <div className="row mb-2" key={rowIndex}>
                                        {/* Left Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2;
                                                const item = BusinessImpactPoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.businessImpact}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleBusinessChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.businessImpact}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleBusinessChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === BusinessImpactPoints.length - 1 ? (
                                                            <IconButton className="mt-2" disabled={!enabledSections.businessImpact} onClick={handleAddBusinesspoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteBusinesspoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>

                                        {/* Right Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2 + 1;
                                                const item = BusinessImpactPoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.businessImpact}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleBusinessChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.businessImpact}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleBusinessChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === BusinessImpactPoints.length - 1 ? (
                                                            <IconButton className="mt-2" onClick={handleAddBusinesspoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteBusinesspoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.businessImpact}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>

                        {/* Key Takeaways: */}
                        < div className="row mt-3 mb-3" >
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Key Takeaways Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleKeyTakeAwaysSave}>
                            <div className="row">
                                <div className="col-lg-8 col-12">
                                    {KeyTakeaways?.img ? (
                                        <div className="mb-2">
                                            <img src={KeyTakeaways?.img} alt="" className="input-img-potrait" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleKeyTakeAwaysChange("imgFile", null, file);
                                                    handleKeyTakeAwaysChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            disabled={!enabledSections.keytakeaways}
                                            required={!KeyTakeaways?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                {Array.from({ length: Math.ceil(KeyTakeAwaysPoints.length / 2) }).map((_, rowIndex) => (
                                    <div className="row mb-2" key={rowIndex}>
                                        {/* Left Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2;
                                                const item = KeyTakeAwaysPoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.keytakeaways}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleKeyTakeAwaysPointsChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.keytakeaways}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleKeyTakeAwaysPointsChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === KeyTakeAwaysPoints.length - 1 ? (
                                                            <IconButton className="mt-2" disabled={!enabledSections.keytakeaways} onClick={handleAddKeyTakeAwaysPoints}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteKeyTakeAwaysPoints(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>

                                        {/* Right Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2 + 1;
                                                const item = KeyTakeAwaysPoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.keytakeaways}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleKeyTakeAwaysPointsChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.keytakeaways}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleKeyTakeAwaysPointsChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === KeyTakeAwaysPoints.length - 1 ? (
                                                            <IconButton className="mt-2" onClick={handleAddKeyTakeAwaysPoints}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteKeyTakeAwaysPoints(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.keytakeaways}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>

                        {/* Conclusion: */}
                        < div className="row mt-3 mb-3" >
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Conclusion Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleConclusionSave}>
                            <div className="row mt-2">
                                {/* Left Column */}
                                <div className="col-lg col-12">
                                    <CustomField
                                        disabled={!enabledSections.conclusion}
                                        required
                                        multiline
                                        rows={5}
                                        value={conclusion?.conclusion || ""}
                                        onChange={(e) => handleConclusionChange("conclusion", null, e.target.value)}
                                        margin="dense" label="Conclusion" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                                <div className="text-end">
                                    {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                    <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader || !enabledSections.conclusion}>
                                        {isLoader ? "Saving..." : "Save"}
                                    </Button>
                                </div>
                            </div>
                        </form>
                    </>
            }
        </>

    )
}
export default CSContent;