import React, { useState, useRef, useEffect } from "react";
import SideBar from "../Sidebar/Sidebar";
import { Card, CardContent, IconButton, Button, Alert } from "@mui/material";
import "../../assets/styles/custom.css"
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import CustomField from "../../components/CustomField";
import Swal from "sweetalert2";
import apiFunctions from "../../api/apiFunctions";
import { appConstants } from "../../constants/appConstants";
import { ArrowBack, Delete, ControlPoint } from "@mui/icons-material";
import arrow from "../../assets/images/arrow.png";
import Loader from "../../components/loader";
import messages from "../../constants/messages";

const CSContent = ({ onBack, data }) => {
    const [isOpen, setIsopen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoader, setIsLoader] = useState(false);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    const formats = [
        "header", "bold", "italic", "underline", "color", "list", "align",
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: ["#298939", "#FFFFFF", "#4A4A4A", "#012354"] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    //Overview Section
    const [overview, setOverview] = useState({
        img: "",
        imgFile: "",
        context: "",
        industy: "",
        serviceused: "",
        region: "",
        funcDepart: "",
        Engmodel: ""
    });

    const handleOverviewChange = (field, subfield, value) => {
        setOverview((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleOverviewSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            context: overview?.context,
            industy: overview?.industy,
            serviceused: overview?.serviceused,
            region: overview?.region,
            funcDepart: overview?.funcDepart,
            Engmodel: overview?.Engmodel
        }


        if (overview?.imgFile instanceof File) {
            form.append("image", overview?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecOne(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Challenges Section
    const [challenges, setChallenges] = useState({
        cardone: {
            headline: "",
            subheadline: ""
        },
        cardtwo: {
            headline: "",
            subheadline: ""
        },
        cardthree: {
            headline: "",
            subheadline: ""
        },
        cardfour: {
            headline: "",
            subheadline: ""
        },
    });

    const handleChallengesChange = (field, subfield, value) => {
        setChallenges((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleChallengesSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = challenges


        // if (overview?.imgFile instanceof File) {
        //     form.append("image", overview?.imgFile);
        // }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecTwo(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Solution Design and Implementation Section
    const [solution, setSolution] = useState({
        img: "",
        imgFile: "",
        cardone: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
        cardtwo: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
        cardthree: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
        cardfour: {
            headline: "",
            shone: "",
            shtwo: "",
            shthree: ""
        },
    });

    const handleSolutionChange = (field, subfield, value) => {
        setSolution((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [fields, setFields] = useState([{ id: 1, value: "" }]);

    const handleAddField = () => {
        const newId = fields.length > 0 ? Math.max(...fields.map(f => f.id)) + 1 : 1;
        setFields([...fields, { id: newId, value: "" }]);
    };

    const handleDeleteField = (id) => {
        setFields(fields.filter(field => field.id !== id));
    };

    const handleFieldChange = (id, newValue) => {
        setFields(fields.map(field =>
            field.id === id ? { ...field, value: newValue } : field
        ));
    };

    const [cardcontent, setCardContent] = useState([
        { id: 1, headline: "", subheadline: "" },
    ]);

    const handleAddCardContent = () => {
        setCardContent(prev => [
            ...prev,
            {
                id: prev.length > 0 ? prev[prev.length - 1].id + 1 : 1,
                headline: "",
                subheadline: "",
            },
        ]);
    };

    const handleDeleteCardContent = (id) => {
        setCardContent(prev => prev.filter(item => item.id !== id));
    };

    const handleCardContentChange = (id, key, value) => {
        setCardContent(prev =>
            prev.map(item =>
                item.id === id ? { ...item, [key]: value } : item
            )
        );
    };


    const handleSolutionSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const filteredfieldspoints = fields.filter(item => {
            const isValue = !item.value || item.value.trim() === "";
            return !(isValue); // Only keep if at least one is filled
        });


        const form = new FormData();
        const json = {
            bulletpoints: filteredfieldspoints,
            cardcontent: cardcontent
        }


        if (solution?.imgFile instanceof File) {
            form.append("image", solution?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecThree(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    //Key Achievements
    const [keyAchieve, setKeyAchieve] = useState({
        img: "",
        imgFile: "",
    });

    const handleKeyAchieveChange = (field, subfield, value) => {
        setKeyAchieve((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [keypoints, setKeypoints] = useState([
        { id: 1, headline: "", subheadline: "" },
    ]);

    const handleAddKeypoint = () => {
        setKeypoints(prev => [
            ...prev,
            {
                id: prev.length > 0 ? prev[prev.length - 1].id + 1 : 1,
                headline: "",
                subheadline: "",
            },
        ]);
    };

    const handleDeleteKeypoint = (id) => {
        setKeypoints(prev => prev.filter(item => item.id !== id));
    };

    const handleKeypointChange = (id, key, value) => {
        setKeypoints(prev =>
            prev.map(item =>
                item.id === id ? { ...item, [key]: value } : item
            )
        );
    };

    const handleKeyAchieveSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const filteredKeypoints = keypoints.filter(item => {
            const isHeadlineEmpty = !item.headline || item.headline.trim() === "";
            const isSubheadlineEmpty = !item.subheadline || item.subheadline.trim() === "";
            return !(isHeadlineEmpty && isSubheadlineEmpty); // Only keep if at least one is filled
        });


        const form = new FormData();
        const json = {
            bulletpoints: filteredKeypoints,
        }


        if (keyAchieve?.imgFile instanceof File) {
            form.append("image", keyAchieve?.imgFile);
        }

        form.append("parent_id", data);
        form.append("status", "Active");
        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCSContentSecFour(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getAllData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const [enabledSections, setEnabledSections] = useState({
        overview: true,
        challenges: false,
        solution: false,
        keyAchievements: false,
    });



    const getAllData = () => {
        // Safe JSON parse utility
        const safeParse = (json) => {
            try {
                return JSON.parse(json);
            } catch {
                return {};
            }
        };

        // Safe image URL generator
        const getImageUrl = (imgData) => {
            if (!imgData) return "";
            if (typeof imgData === "string") return appConstants?.imageUrl + imgData;
            if (Array.isArray(imgData) && imgData.length > 0) return appConstants?.imageUrl + imgData[0];
            return "";
        };

        apiFunctions.getAllCSContent(data)
            .then((res) => {
                if (res?.status === 200 && res?.data?.length > 0) {

                    // ---------------- Overview Section ----------------
                    const overviewData = safeParse(res?.data?.[0]?.content || "");
                    const overviewimgData = res?.data?.[0]?.images;

                    const hasOverview = !!(
                        overviewData?.context?.trim() ||
                        overviewData?.industy?.trim() ||
                        overviewData?.serviceused?.trim() ||
                        overviewData?.region?.trim() ||
                        overviewData?.funcDepart?.trim() ||
                        overviewData?.Engmodel?.trim()
                    );

                    setOverview({
                        img: getImageUrl(overviewimgData),
                        imgFile: "",
                        context: overviewData?.context,
                        industy: overviewData?.industy,
                        serviceused: overviewData?.serviceused,
                        region: overviewData?.region,
                        funcDepart: overviewData?.funcDepart,
                        Engmodel: overviewData?.Engmodel
                    });


                    // Overview is always enabled, so Challenges section depends on Overview
                    if (hasOverview) {
                        setEnabledSections((prev) => ({ ...prev, challenges: true }));
                    }

                    // ---------------- Challenges Section ----------------
                    const challengesData = safeParse(res?.data?.[1]?.content || "");
                    const challengesimgData = res?.data?.[1]?.images;

                    const hasChallenges = !!(
                        challengesData?.cardone?.headline?.trim() ||
                        challengesData?.cardtwo?.headline?.trim() ||
                        challengesData?.cardthree?.headline?.trim() ||
                        challengesData?.cardfour?.headline?.trim()
                    );

                    setChallenges({
                        cardone: {
                            headline: challengesData?.cardone?.headline,
                            subheadline: challengesData?.cardone?.subheadline
                        },
                        cardtwo: {
                            headline: challengesData?.cardtwo?.headline,
                            subheadline: challengesData?.cardtwo?.subheadline
                        },
                        cardthree: {
                            headline: challengesData?.cardthree?.headline,
                            subheadline: challengesData?.cardthree?.subheadline
                        },
                        cardfour: {
                            headline: challengesData?.cardfour?.headline,
                            subheadline: challengesData?.cardfour?.subheadline
                        },
                    });

                    if (hasOverview && hasChallenges) {
                        setEnabledSections((prev) => ({ ...prev, solution: true }));
                    }

                    // ---------------- Solutions Section ----------------
                    const solutionsData = safeParse(res?.data?.[2]?.content || "");
                    const solutionsimgData = res?.data?.[2]?.images;

                    const hasSolution = !!(
                        solutionsData?.cardone?.headline?.trim() ||
                        solutionsData?.cardtwo?.headline?.trim() ||
                        solutionsData?.cardthree?.headline?.trim() ||
                        solutionsData?.cardfour?.headline?.trim()
                    );

                    setSolution({
                        img: getImageUrl(solutionsimgData),
                        imgFile: "",
                        cardone: {
                            headline: solutionsData?.cardone?.headline,
                            shone: solutionsData?.cardone?.shone,
                            shtwo: solutionsData?.cardone?.shtwo,
                            shthree: solutionsData?.cardone?.shthree
                        },
                        cardtwo: {
                            headline: solutionsData?.cardtwo?.headline,
                            shone: solutionsData?.cardtwo?.shone,
                            shtwo: solutionsData?.cardtwo?.shtwo,
                            shthree: solutionsData?.cardtwo?.shthree
                        },
                        cardthree: {
                            headline: solutionsData?.cardthree?.headline,
                            shone: solutionsData?.cardthree?.shone,
                            shtwo: solutionsData?.cardthree?.shtwo,
                            shthree: solutionsData?.cardthree?.shthree
                        },
                        cardfour: {
                            headline: solutionsData?.cardfour?.headline,
                            shone: solutionsData?.cardfour?.shone,
                            shtwo: solutionsData?.cardfour?.shtwo,
                            shthree: solutionsData?.cardfour?.shthree
                        },
                    });

                    setFields(solutionsData?.bulletpoints || [{ id: 1, value: "" }]);

                    if (hasOverview && hasChallenges && hasSolution) {
                        setEnabledSections((prev) => ({ ...prev, keyAchievements: true }));
                    }

                    // ---------------- Key Achievements Section ----------------
                    const keyAchieveData = safeParse(res?.data?.[3]?.content || "");

                    const keyAchieveimgData = res?.data?.[3]?.images;

                    const hasKeyAchievements = Array.isArray(keyAchieveData?.bulletpoints) && keyAchieveData?.bulletpoints.length > 0;

                    setKeyAchieve({
                        img: getImageUrl(keyAchieveimgData),
                        imgFile: "",
                    });

                    setKeypoints(keyAchieveData?.bulletpoints || [{ id: 1, headline: "", subheadline: "" }]);

                } else {
                    setOverview({});
                    setChallenges({});
                }
            })
            .catch((err) => {
                console.error("Error fetching All Context Data:", err);
                setOverview({});
                setChallenges({});
            });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        let timeout = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        if (!isFetched.current) {
            getAllData();
            isFetched.current = true;
        }

        return () => clearTimeout(timeout);
    }, []);


    return (
        <>
            {
                isLoading ?
                    <Loader /> :
                    <>
                        {/* Banner Section */}
                        <div className="row">
                            <div className="col-lg-6 col-12">
                                {/* <h4 className="fw-medium" style={{ color: "#298939" }}>Data Analytics Service</h4> */}
                                {/* <h5 style={{ color: "#012354" }}>Banner Section</h5> */}
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-12 d-flex justify-content-end">
                                <Button className="btn mt-2 mb-2" variant="contained" onClick={onBack} startIcon={<ArrowBack />}>
                                    Back
                                </Button>
                            </div>
                            <div className="row mb-2 mt-2">
                                <div className="col-lg col-12">
                                    <Alert severity="info">
                                        Each section will become available <strong>only after saving the previous section</strong>. Please complete and save each section one by one.
                                    </Alert>
                                </div>
                            </div>
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>
                                    Project Overview Section
                                </h5>
                            </div>
                        </div>
                        <form onSubmit={handleOverviewSave}>
                            <div className="row mt-2">
                                <div className="col-lg-8 col-12">
                                    {overview?.img ? (
                                        <div className="mb-2">
                                            <img src={overview?.img} alt="" className="input-img" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleOverviewChange("imgFile", null, file);
                                                    handleOverviewChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            required={!overview?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                {/* Left Column */}
                                <div className="col-lg-6 col-12">
                                    <CustomField
                                        required
                                        multiline
                                        rows={3}
                                        value={overview?.context || ""}
                                        onChange={(e) => handleOverviewChange("context", null, e.target.value)}
                                        margin="dense" label="Context" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.industy || ""}
                                        onChange={(e) => handleOverviewChange("industy", null, e.target.value)}
                                        margin="dense" label="Industry" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.serviceused || ""}
                                        onChange={(e) => handleOverviewChange("serviceused", null, e.target.value)}
                                        margin="dense" label="Service Used" type="text" size="small" fullWidth className="mb-2" />
                                </div>

                                {/* Right Column */}
                                <div className="col-lg-6 col-12">
                                    <CustomField
                                        required
                                        value={overview?.region || ""}
                                        onChange={(e) => handleOverviewChange("region", null, e.target.value)}
                                        margin="dense" label="Region" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.funcDepart || ""}
                                        onChange={(e) => handleOverviewChange("funcDepart", null, e.target.value)}
                                        margin="dense" label="Function / Department" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        required
                                        value={overview?.Engmodel || ""}
                                        onChange={(e) => handleOverviewChange("Engmodel", null, e.target.value)}
                                        margin="dense" label="Engagement Model" type="text" size="small" fullWidth className="mb-2" />
                                </div>

                                <div className="text-end">
                                    {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                    <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                        {isLoader ? "Saving..." : "Save"}
                                    </Button>
                                </div>
                            </div>
                        </form>
                        {/* Challenges Addressed */}
                        <div className="row mt-3 mb-3">
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Challenges Addressed Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleChallengesSave}>
                            <div className="row">
                                {/* Left Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge One</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardone?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardone", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardone?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardone", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                                {/* Right Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge Two</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardtwo?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardtwo", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardtwo?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardtwo", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                            </div>
                            <div className="row">
                                {/* Left Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge Three</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardthree?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardthree", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardthree?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardthree", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                                {/* Right Column */}
                                <div className="col-lg-6 col-12">
                                    <p style={{ color: "#012354" }} className="mb-2">Challenge Four</p>
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardfour?.headline || ""}
                                        onChange={(e) => handleChallengesChange("cardfour", "headline", e.target.value)}
                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                    <CustomField
                                        disabled={!enabledSections.challenges}
                                        required
                                        value={challenges?.cardfour?.subheadline || ""}
                                        onChange={(e) => handleChallengesChange("cardfour", "subheadline", e.target.value)}
                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                </div>
                            </div>
                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.challenges}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>
                        {/* Solution Design and Implementation */}
                        <div className="row mt-3 mb-3">
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Solution Design and Implementation Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleSolutionSave}>
                            <div className="row">
                                <div className="col-lg-8 col-12">
                                    {solution?.img ? (
                                        <div className="mb-2">
                                            <img src={solution?.img} alt="" className="input-img" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleSolutionChange("imgFile", null, file);
                                                    handleSolutionChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            disabled={!enabledSections.solution}
                                            required={!solution?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                <div className="col-lg col-12">
                                    <div style={{ border: "1px dashed #707070", borderRadius: '22px', padding: '16px' }}>
                                        {fields.map((field, index) => (
                                            <div key={field.id} className="d-flex align-items-center mb-2">
                                                <div className="col-lg me-2">
                                                    <img src={arrow} alt="arrow" className="me-2" style={{ width: '16px', height: '16px' }} />
                                                </div>
                                                <CustomField
                                                    disabled={!enabledSections.solution}
                                                    margin="dense"
                                                    label="Bullet Point"
                                                    type="text"
                                                    size="small"
                                                    fullWidth
                                                    value={field.value}
                                                    onChange={(e) => handleFieldChange(field.id, e.target.value)}
                                                />

                                                {fields.length === 1 || index === fields.length - 1 ? (
                                                    <IconButton className="ms-2" onClick={handleAddField}>
                                                        <ControlPoint />
                                                    </IconButton>
                                                ) : (
                                                    <IconButton className="ms-2" onClick={() => handleDeleteField(field.id)}>
                                                        <Delete />
                                                    </IconButton>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            {Array.from({ length: Math.ceil(cardcontent.length / 2) }).map((_, rowIndex) => (
                                <div className="row mt-2" key={rowIndex}>
                                    {/* Left Column */}
                                    <div className="col-lg-6 col-12">
                                        {(() => {
                                            const index = rowIndex * 2;
                                            const item = cardcontent[index];
                                            if (!item) return null;

                                            return (
                                                <>
                                                    <p style={{ color: "#012354" }} className="mb-2">Content {index + 1}</p>
                                                    <div className="d-flex">
                                                        {/* Left side: Fields */}
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                required
                                                                disabled={!enabledSections.solution}
                                                                value={cardcontent?.headline || ""}
                                                                onChange={(e) => handleCardContentChange("headline", null, e.target.value)}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                required
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={cardcontent?.subheadline || ""}
                                                                onChange={(e) => handleCardContentChange("subheadline", null, e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line One"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                        </div>
                                                        <div className="ms-2 d-flex flex-column">
                                                            {index === cardcontent.length - 1 ? (
                                                                <IconButton className="mt-2" disabled={!enabledSections.solution} onClick={handleAddCardContent}>
                                                                    <ControlPoint />
                                                                </IconButton>
                                                            ) : (
                                                                <IconButton className="mt-2" onClick={() => handleDeleteCardContent(item.id)}>
                                                                    <Delete />
                                                                </IconButton>
                                                            )}
                                                        </div>
                                                    </div>
                                                </>
                                            );
                                        })()}
                                    </div >
                                    {/* Right Column */}
                                    < div className="col-lg-6 col-12" >
                                        {(() => {
                                            const index = rowIndex * 2 + 1;
                                            const item = cardcontent[index];
                                            if (!item) return null;

                                            return (
                                                <>
                                                    <p style={{ color: "#012354" }} className="mb-2">Content {index + 1}</p>
                                                    <div className="d-flex">
                                                        {/* Left side: Fields */}
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                required
                                                                disabled={!enabledSections.solution}
                                                                value={cardcontent?.headline || ""}
                                                                onChange={(e) => handleCardContentChange("headline", null, e.target.value)}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                            <CustomField
                                                                required
                                                                disabled={!enabledSections.solution}
                                                                multiline
                                                                rows={2}
                                                                value={cardcontent?.subheadline || ""}
                                                                onChange={(e) => handleCardContentChange("subheadline", null, e.target.value)}
                                                                margin="dense"
                                                                label="Sub Head Line One"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                className="mb-2"
                                                            />
                                                        </div>
                                                        <div className="ms-2 d-flex flex-column">
                                                            {index === cardcontent.length - 1 ? (
                                                                <IconButton className="mt-2" disabled={!enabledSections.solution} onClick={handleAddCardContent}>
                                                                    <ControlPoint />
                                                                </IconButton>
                                                            ) : (
                                                                <IconButton className="mt-2" onClick={() => handleDeleteCardContent(item.id)}>
                                                                    <Delete />
                                                                </IconButton>
                                                            )}
                                                        </div>
                                                    </div>
                                                </>
                                            );
                                        })()
                                        }
                                    </div >
                                </div>
                            ))}

                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.solution}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>
                        {/* Key Achievements */}
                        < div className="row mt-3 mb-3" >
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Key Achievements Section</h5>
                            </div>
                        </div>
                        <form onSubmit={handleKeyAchieveSave}>
                            <div className="row">
                                <div className="col-lg-8 col-12">
                                    {keyAchieve?.img ? (
                                        <div className="mb-2">
                                            <img src={keyAchieve?.img} alt="" className="input-img-potrait" />
                                        </div>
                                    ) : (
                                        ""
                                    )}
                                    <div className="foot-input-wrapper mb-2">
                                        <input
                                            className="form-control foot-input"
                                            accept="image/*"
                                            onChange={(e) => {
                                                const file = e.target.files[0];
                                                if (file) {
                                                    const objectUrl = URL.createObjectURL(file);
                                                    handleKeyAchieveChange("imgFile", null, file);
                                                    handleKeyAchieveChange("img", null, objectUrl);
                                                }
                                            }}
                                            type="file"
                                            // required
                                            disabled={!enabledSections.keyAchievements}
                                            required={!keyAchieve?.img}
                                        />
                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                            (520×250)
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="row mt-2">
                                {Array.from({ length: Math.ceil(keypoints.length / 2) }).map((_, rowIndex) => (
                                    <div className="row mb-2" key={rowIndex}>
                                        {/* Left Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2;
                                                const item = keypoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === keypoints.length - 1 ? (
                                                            <IconButton className="mt-2" disabled={!enabledSections.keyAchievements} onClick={handleAddKeypoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteKeypoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>

                                        {/* Right Column */}
                                        <div className="col-lg-6 col-12">
                                            {(() => {
                                                const index = rowIndex * 2 + 1;
                                                const item = keypoints[index];
                                                if (!item) return null;

                                                return (
                                                    <div className="d-flex align-items-start">
                                                        <img src={arrow} alt="arrow" className="me-2 mt-3" style={{ width: '17px', height: '17px' }} />
                                                        <div className="flex-grow-1">
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.headline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "headline", e.target.value)
                                                                }
                                                            />
                                                            <CustomField
                                                                disabled={!enabledSections.keyAchievements}
                                                                margin="dense"
                                                                label="Sub Head Line"
                                                                type="text"
                                                                size="small"
                                                                fullWidth
                                                                value={item.subheadline}
                                                                onChange={(e) =>
                                                                    handleKeypointChange(item.id, "subheadline", e.target.value)
                                                                }
                                                            />
                                                        </div>
                                                        {index === keypoints.length - 1 ? (
                                                            <IconButton className="mt-2" onClick={handleAddKeypoint}>
                                                                <ControlPoint />
                                                            </IconButton>
                                                        ) : (
                                                            <IconButton className="mt-2" onClick={() => handleDeleteKeypoint(item.id)}>
                                                                <Delete />
                                                            </IconButton>
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="text-end">
                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                <Button className="mt-3 btn" type="submit" variant="contained"
                                    // disabled={isLoader}
                                    disabled={isLoader || !enabledSections.keyAchievements}
                                >
                                    {isLoader ? "Saving..." : "Save"}
                                </Button>
                            </div>
                        </form>
                    </>
            }
        </>

    )
}
export default CSContent;