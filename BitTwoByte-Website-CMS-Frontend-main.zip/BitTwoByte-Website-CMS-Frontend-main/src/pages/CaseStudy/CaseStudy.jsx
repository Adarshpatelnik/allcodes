import React, { useState } from "react";
import SideBar from "../Sidebar/Sidebar";
import { Card, CardContent, IconButton } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import "../../assets/styles/custom.css"
import Dropdown from "../../components/Dropdown";
import CSTable from "./CSTable";

const CaseStudy = () => {
    const [isOpen, setIsopen] = useState(true);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    return (
        <>
            <div className="container-fluid p-0 " style={{ overflow: 'hidden' }}>
                <div className="row">
                    <div className={`${isOpen ? "col-lg-2  mob-nav p-0" : "d-none"} sidebar_layout`}>
                        <SideBar />
                    </div>
                    <div className={`${isOpen ? "col-lg-10 col-12  " : "col-12 w-100"} dashboard_card main_layout`} >

                        <div className="d-flex w-100 justify mob-sticky mb-2">
                            <IconButton className="web-btn" onClick={handleOpen} >
                                <MenuIcon />
                            </IconButton>
                            <IconButton className="mob-btn" data-bs-toggle="offcanvas" data-bs-target="#mob-canvas" aria-controls="mob-canvas">
                                <MenuIcon />
                            </IconButton>
                            <div className="logout_dropdown">
                                <Dropdown />
                            </div>
                        </div>

                        <Card className="p-lg-2 p-1">
                            <CardContent>
                                {/* Banner Section */}
                                <div className="row">
                                    <div className="col-lg-6 col-12">
                                        <h4 className="fw-medium" style={{ color: "#298939" }}>Case Study Detail Page</h4>
                                        {/* <h5 style={{ color: "#012354" }}>Case Study Details Section</h5> */}
                                    </div>
                                </div>
                                <CSTable />
                            </CardContent>
                        </Card>

                    </div>
                </div>
            </div>
            <div className="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabIndex="-1" id="mob-canvas" aria-labelledby="mob-canvaslabel">
                <div className="offcanvas-header" style={{ background: "transparent" }}>
                    <IconButton data-bs-dismiss="offcanvas" aria-label="Close">
                        <CloseIcon style={{ height: '40px', width: '40px', color: 'black', marginTop: "20px" }} />
                    </IconButton>
                </div>
                <div className="offcanvas-body p-0">
                    <SideBar />
                </div>
            </div>
        </>
    )
}
export default CaseStudy;