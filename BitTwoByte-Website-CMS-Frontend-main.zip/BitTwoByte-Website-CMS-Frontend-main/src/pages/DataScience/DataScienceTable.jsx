import { Button, ButtonGroup, IconButton, Dialog, DialogTitle, Card, CardContent, DialogContent, DialogActions, FormControlLabel, Switch } from "@mui/material";
import React, { useEffect, useState, useRef } from "react";
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from "sweetalert2";
import Table from "../../components/Table";
import ReactQuill from "react-quill";
import DOMPurify from 'dompurify';
import Loader from "../../components/loader";
import "../../assets/styles/loader.css"
import { appConstants } from "../../constants/appConstants";
import CustomField from "../../components/CustomField";
import apiFunctions from "../../api/apiFunctions";
import {
    ToggleOff,
    ToggleOn,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import messages from "../../constants/messages";

const DataScienceTable = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [isEditOpen, setIsEditOpen] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [banners, setBanners] = useState([]);
    const [isLoader, setIsLoader] = useState(false);

    const CustomSwitch = styled(Switch)({
        "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#298939",
        },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#298939",
        },
    });

    // Formats allowed in the editor
    const formats = [
        "header",
        "bold",
        "italic",
        "underline",
        "color",
        "background",
        "list",
        "bullet",
        "link",
        "align"
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: [] }, { background: [] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    const [services, setServices] = useState({
        image: null,
        imageUrl: "",
        title: "",
        description: ""
    });

    const [selectedRow, setSelectedRow] = useState({
        image: null,
        imageUrl: "",
        title: "",
        description: ""
    });

    const handleServicesChange = (field, subfield, value, event = null) => {
        setServices((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setServices((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }

        setSelectedRow((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setSelectedRow((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }
    };

    const handleAddOpen = () => {
        setServices({});
        setSelectedRow({});
        setIsAddOpen(true);
    };

    const handleAddClose = () => {
        setSelectedRow({});
        setServices({});
        setIsAddOpen(false);
    };

    const handleViewOpen = (row) => {
        setSelectedRow(row);
        setIsViewOpen(true);
    };

    const handleViewClose = () => {
        setSelectedRow({});
        setServices({});
        setIsViewOpen(false);
    };

    const handleEditOpen = (row) => {
        setSelectedRow(row);
        setIsEditOpen(true);
    };

    const handleEditClose = () => {
        setSelectedRow({});
        setServices({});
        setIsEditOpen(false);
    };

    //region Get
    const getInitialData = () => {
        apiFunctions.getSciServices()
            .then((res) => {
                if (res?.status === 200 && Array.isArray(res?.data?.data?.images) && res?.data?.data?.images?.length > 0) {

                    const formattedData = res?.data?.data?.images.map((item) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }

                        const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            id: item?.id || null,
                            title: descriptionData?.title || "",
                            description: descriptionData?.description || "",
                            imageUrl: imageUrl,
                            status: item?.status || ""
                        };
                    });

                    setBanners(formattedData);
                } else {
                    setBanners([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setBanners([]);
            });
    };

    //region Table Columns
    const columns = [
        { field: "title", headerName: "Title", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: "description", headerName: "Description", flex: 1, disableColumnMenu: true, sortable: false,

        },
        { field: "status", headerName: "Status", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: 'Action',
            flex: 1,
            headerName: 'Action',
            disableColumnMenu: true,
            sortable: false,
            renderCell: (params) => (
                params.row && (
                    <ButtonGroup>
                        <IconButton onClick={() => handleEditOpen(params.row)}><EditIcon /></IconButton>
                        <IconButton onClick={() => handleViewOpen(params.row)}><VisibilityIcon /></IconButton>
                        <IconButton onClick={() => handleRemove(params.row)} disabled={isLoader}><DeleteIcon /></IconButton>
                    </ButtonGroup>
                )
            )
        },
    ];

    //region Insert
    const handleAddSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            title: services?.title,
            description: services?.description,
        };

        if (services?.image instanceof File) {
            form.append("image", services.image);
        }


        form.append("status", "active");
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.addSciServices(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleAddClose();
        }
    };

    //region Update
    const handleEditSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            title: selectedRow?.title,
            description: selectedRow?.description,
        };

        if (selectedRow?.image instanceof File) {
            form.append("image", selectedRow?.image);
        }


        form.append("id", selectedRow?.id)
        form.append("status", selectedRow?.status)
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.updateSciServices(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.update?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.update?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleEditClose();
        }
    };

    //region Delete
    const handleRemove = (row) => {
        if (!row?.id) {
            console.error("Invalid row ID");
            return;
        }


        Swal.fire({
            text: messages?.delete?.confirm,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
        }).then(async (result) => {
            if (result.isConfirmed) {
                setIsLoading(true);

                try {
                    const res = await apiFunctions.deleteSciServices({ id: row.id });

                    if (res.status === 200) {
                        await Swal.fire({
                            text: messages?.delete?.success,
                            icon: "success"
                        });
                        getInitialData();
                    } else {
                        await Swal.fire({
                            text: messages?.delete?.error,
                            icon: "error"
                        });
                    }
                } catch (error) {
                    console.error("Error deleting service:", error);
                    await Swal.fire({ text: messages?.catchError, icon: "error" });
                } finally {
                    setIsLoading(false);
                }
            }
        });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        setIsLoader(false);
        setTimeout(() => {
            setIsLoading(false);
        }, 1500);
        if (!isFetched.current) {
            getInitialData();
            isFetched.current = true;
        }
    }, []);

    return (
        <>
            <div className="row">
                <div className="col-12 w-100">
                    {isLoading ?
                        <Loader /> : <>
                            <div className="text-end">
                                <Button className="btn mb-3" onClick={handleAddOpen} endIcon={<AddIcon />} variant="contained">Add new</Button>
                            </div>
                            <Table rows={banners} columns={columns} />
                        </>
                    }
                </div>
            </div>

            {/* View Modal */}
            <Dialog open={isViewOpen} onClose={handleViewClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>View Data Engineering Solutions</DialogTitle>
                <DialogContent>
                    <Card elevation={0}>
                        <CardContent>
                            <div className="row">
                                <div className="col-lg-6 col-12 text-start d-flex align-items-center">
                                    <div className="px-3 position-relative">
                                        <h2 style={{ fontFamily: 'boldtxt', color: '#012354' }} className="title">{selectedRow?.title}</h2>
                                        <p className="regular position-relative" style={{ zIndex: '2', color: '#959595' }}>
                                            {selectedRow?.description}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6 col-12 text-start ">
                                    <img src={selectedRow?.imageUrl} alt="" className="card_img" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </DialogContent>
                <DialogActions style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                    <span className="p-2" style={{ fontSize: "16px", fontWeight: "500", display: "flex", alignItems: "center", gap: "5px" }}>
                        Status: {selectedRow?.status === "active" ?
                            <ToggleOn style={{ color: "#298939", fontSize: "40px" }} /> :
                            <ToggleOff style={{ color: "grey", fontSize: "40px" }} />
                        }
                    </span>
                    <Button className="grey-btn" onClick={handleViewClose}>Close</Button>
                </DialogActions>

            </Dialog>

            {/* Edit Modal */}
            <Dialog open={isEditOpen} onClose={handleEditClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>Edit Data Engineering Solutions</DialogTitle>
                <form onSubmit={handleEditSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        <label>Upload Image:</label><br />
                        {selectedRow?.imageUrl && (
                            <div className="mt-2 mb-3">
                                <img src={selectedRow?.imageUrl} alt="Uploaded" className="input-img" />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div>

                        <label className="mt-2">Title</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Title"
                            type="text"
                            fullWidth
                            value={selectedRow?.title}
                            onChange={(e) => handleServicesChange("title", null, e.target.value)}
                        />
                        <label className="mt-2">Description</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Description"
                            type="text"
                            fullWidth
                            multiline
                            rows={3}
                            value={selectedRow?.description}
                            onChange={(e) => handleServicesChange("description", null, e.target.value)}
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                        <FormControlLabel
                            control={
                                <CustomSwitch
                                    checked={selectedRow?.status === "active"}
                                    onChange={(e) =>
                                        setSelectedRow((prevRow) => ({
                                            ...prevRow,
                                            status: e.target.checked ? "active" : "inactive",
                                        }))
                                    }
                                />
                            }
                            label={selectedRow?.status === "active" ? "Active" : "Inactive"}
                            labelPlacement="end"
                            style={{ marginTop: "1rem" }}
                        />
                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleEditClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

            {/* Add Modal */}
            <Dialog open={isAddOpen} onClose={handleAddClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>Add New Data Engineering Solutions</DialogTitle>
                <form onSubmit={handleAddSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        <label>Upload Image:</label><br />
                        {services.image && (
                            <div className="mt-2 mb-3">
                                <img src={services.imageUrl} alt="Uploaded" className="input-img" />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                required
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div>

                        <label className="mt-2">Title</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Title"
                            type="text"
                            required
                            fullWidth
                            value={services?.title}
                            onChange={(e) => handleServicesChange("title", null, e.target.value)}
                        />
                        <label className="mt-2">Description</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Description"
                            type="text"
                            fullWidth
                            multiline
                            required
                            rows={3}
                            value={services?.description}
                            onChange={(e) => handleServicesChange("description", null, e.target.value)}
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleAddClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

        </>
    )
}
export default DataScienceTable;