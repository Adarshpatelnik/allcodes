import { Box, Button, ButtonGroup, IconButton, Dialog, DialogTitle, Card, CardContent, DialogContent, DialogActions, FormControlLabel, Switch, Rating, Avatar } from "@mui/material";
import React, { useEffect, useState, useRef } from "react";
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from "sweetalert2";
import Table from "../../components/Table";
import ReactQuill from "react-quill";
import DOMPurify from 'dompurify';
import Loader from "../../components/loader";
import "../../assets/styles/loader.css"
import { appConstants } from "../../constants/appConstants";
import CustomField from "../../components/CustomField";
import apiFunctions from "../../api/apiFunctions";
import {
    ToggleOff,
    ToggleOn,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import messages from "../../constants/messages";

const CustomerSaysTable = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [isEditOpen, setIsEditOpen] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [banners, setBanners] = useState([]);
    const [isLoader, setIsLoader] = useState(false);

    const CustomSwitch = styled(Switch)({
        "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#298939",
        },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#298939",
        },
    });

    // Formats allowed in the editor
    const formats = [
        "header",
        "bold",
        "italic",
        "underline",
        "color",
        "background",
        "list",
        "bullet",
        "link",
        "align"
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: [] }, { background: [] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    const [services, setServices] = useState({
        image: null,
        imageUrl: "",
        customerName: "",
        companyName: "",
        ratings: 0,
        testiTitle: "",
        testiDescription: ""
    });

    const [selectedRow, setSelectedRow] = useState({
        image: null,
        imageUrl: "",
        customerName: "",
        companyName: "",
        ratings: 0,
        testiTitle: "",
        testiDescription: ""
    });

    const handleServicesChange = (field, subfield, value, event = null) => {
        setServices((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setServices((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }

        setSelectedRow((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setSelectedRow((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }
    };

    const handleAddOpen = () => {
        setServices({});
        setSelectedRow({});
        setIsAddOpen(true);
    };

    const handleAddClose = () => {
        setSelectedRow({});
        setServices({});
        setIsAddOpen(false);
    };

    const handleViewOpen = (row) => {
        setSelectedRow(row);
        setIsViewOpen(true);
    };

    const handleViewClose = () => {
        setSelectedRow({});
        setServices({});
        setIsViewOpen(false);
    };

    const handleEditOpen = (row) => {
        setSelectedRow(row);
        setIsEditOpen(true);
    };

    const handleEditClose = () => {
        setSelectedRow({});
        setServices({});
        setIsEditOpen(false);
    };

    //region Get
    const getInitialData = () => {
        apiFunctions.getCustomerSays()
            .then((res) => {

                if (res?.status === 200 && Array.isArray(res?.data?.data?.images) && res?.data?.data?.images?.length > 0) {

                    const formattedData = res?.data?.data?.images.map((item) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }

                        const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            id: item?.id || null,
                            customerName: descriptionData?.customerName,
                            companyName: descriptionData?.companyName,
                            ratings: descriptionData?.ratings,
                            testiTitle: descriptionData?.testiTitle,
                            testiDescription: descriptionData?.testiDescription,
                            imageUrl: imageUrl,
                            status: item?.status || ""
                        };
                    });

                    setBanners(formattedData);
                } else {
                    setBanners([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setBanners([]);
            });
    };

    //region Table Columns
    const columns = [
        {
            field: "imageUrl", headerName: "Profile Image", flex: 1, disableColumnMenu: true, sortable: false, renderCell: (params) =>
                params.row && (
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                        <Avatar alt="Remy Sharp" src={params.row.imageUrl} sx={{ width: 60, height: 60 }} />
                    </div>

                )
        },
        { field: "customerName", headerName: "Customer Name", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: "companyName", headerName: "Company Name", flex: 1, disableColumnMenu: true, sortable: false,
        },
        { field: "status", headerName: "Status", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: 'Action',
            flex: 1,
            headerName: 'Action',
            disableColumnMenu: true,
            sortable: false,
            renderCell: (params) => (
                params.row && (
                    <ButtonGroup>
                        <IconButton onClick={() => handleEditOpen(params.row)}><EditIcon /></IconButton>
                        <IconButton onClick={() => handleViewOpen(params.row)}><VisibilityIcon /></IconButton>
                        <IconButton onClick={() => handleRemove(params.row)} disabled={isLoader}><DeleteIcon /></IconButton>
                    </ButtonGroup>
                )
            )
        },
    ];

    //region Insert
    const handleAddSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            customerName: services?.customerName,
            companyName: services?.companyName,
            ratings: services?.ratings,
            testiTitle: services?.testiTitle,
            testiDescription: services?.testiDescription
        };

        if (services?.image instanceof File) {
            form.append("image", services.image);
        }


        form.append("status", "active");
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.addCustomerSays(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleAddClose();
        }
    };

    //region Update
    const handleEditSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            customerName: selectedRow?.customerName,
            companyName: selectedRow?.companyName,
            ratings: selectedRow?.ratings,
            testiTitle: selectedRow?.testiTitle,
            testiDescription: selectedRow?.testiDescription
        };

        if (selectedRow?.image instanceof File) {
            form.append("image", selectedRow?.image);
        }

        

        form.append("id", selectedRow?.id)
        form.append("status", selectedRow?.status)
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.updateCustomerSays(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.update?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.update?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleEditClose();
        }
    };

    //region Delete
    const handleRemove = (row) => {
        if (!row?.id) {
            console.error("Invalid row ID");
            return;
        }


        Swal.fire({
            text: messages?.delete?.confirm,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
        }).then(async (result) => {
            if (result.isConfirmed) {
                setIsLoading(true);

                try {
                    const res = await apiFunctions.deleteCustomerSays({ id: row.id });

                    if (res.status === 200) {
                        await Swal.fire({
                            text: messages?.delete?.success,
                            icon: "success"
                        });
                        getInitialData();
                    } else {
                        await Swal.fire({
                            text: messages?.delete?.error,
                            icon: "error"
                        });
                    }
                } catch (error) {
                    console.error("Error deleting service:", error);
                    await Swal.fire({ text: messages?.catchError, icon: "error" });
                } finally {
                    setIsLoading(false);
                }
            }
        });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        setIsLoader(false);
        setTimeout(() => {
            setIsLoading(false);
        }, 1500);
        if (!isFetched.current) {
            getInitialData();
            isFetched.current = true;
        }
    }, []);

    return (
        <>
            <div className="row">
                <div className="col-12 w-100">
                    {isLoading ?
                        <Loader /> : <>
                            <div className="text-end">
                                <Button className="btn mb-3" onClick={handleAddOpen} endIcon={<AddIcon />} variant="contained">Add new</Button>
                            </div>
                            <Table rows={banners} columns={columns} />
                        </>
                    }
                </div>
            </div>

            {/* View Modal */}
            <Dialog open={isViewOpen} onClose={handleViewClose} maxWidth={"sm"} fullWidth={true}>
                <DialogTitle>View What Our Customers Say </DialogTitle>
                <DialogContent>
                    <Card
                        sx={{
                            p: 2,
                            borderRadius: "12px",
                            boxShadow: "0px 4px 10px rgba(41, 137, 57, 0.5)"
                        }}
                    >
                        <CardContent>
                            {/* Avatar and Name Section */}
                            <Box display="flex" alignItems="center" gap={2}>
                                <Avatar
                                    src={selectedRow?.imageUrl}
                                    alt="User Image"
                                    sx={{
                                        width: 50,
                                        height: 50,
                                        border: "2px solid #ddd",
                                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.2)",
                                    }}
                                />
                                <Box>
                                    <h5 style={{ fontFamily: 'boldtxt', color: '#012354' }} className="title">
                                        {selectedRow?.customerName}
                                    </h5>
                                    <p className="regular position-relative" style={{ zIndex: '2', color: '#959595' }}>
                                        {selectedRow?.companyName}
                                    </p>
                                </Box>
                            </Box>

                            {/* Star Rating */}
                            <Box mt={2} mb={2}>
                                <Rating name="rating" value={selectedRow?.ratings} readOnly />
                            </Box>

                            {/* Testimonial Title */}
                            <h5 style={{ fontWeight: "bold", margin: "8px 0" }}>
                                {selectedRow?.testiTitle}
                            </h5>


                            {/* Testimonial Description */}
                            <p style={{ color: "rgba(0, 0, 0, 0.6)", fontSize: "14px", margin: "8px 0" }}>
                                {selectedRow?.testiDescription}
                            </p>

                        </CardContent>
                    </Card>
                </DialogContent>
                <DialogActions style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                    <span className="p-2" style={{ fontSize: "16px", fontWeight: "500", display: "flex", alignItems: "center", gap: "5px" }}>
                        Status: {selectedRow?.status === "active" ?
                            <ToggleOn style={{ color: "#298939", fontSize: "40px" }} /> :
                            <ToggleOff style={{ color: "grey", fontSize: "40px" }} />
                        }
                    </span>
                    <Button className="grey-btn" onClick={handleViewClose}>Close</Button>
                </DialogActions>

            </Dialog>

            {/* Edit Modal */}
            <Dialog open={isEditOpen} onClose={handleEditClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>Edit What Our Customers Say </DialogTitle>
                <form onSubmit={handleEditSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        <label>Upload Image:</label><br />
                        {selectedRow?.imageUrl && (
                            // <div className="mt-2 mb-3">
                            //     <img src={selectedRow?.imageUrl} alt="Uploaded" className="input-img" />
                            // </div>
                            <div className="mt-2 mb-3">
                                <Avatar
                                    src={selectedRow?.imageUrl}
                                    alt="Uploaded"
                                    sx={{ width: 150, height: 150, boxShadow: "0px 4px 10px rgba(41, 137, 57, 0.5)" }}
                                />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div>

                        <label className="mt-2">Customer Name</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Customer Name"
                            type="text"
                            fullWidth
                            value={selectedRow?.customerName}
                            onChange={(e) => handleServicesChange("customerName", null, e.target.value)}
                        />
                        <label className="mt-2">Customer Company Name</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Customer Company Name"
                            type="text"
                            fullWidth
                            value={selectedRow?.companyName}
                            onChange={(e) => handleServicesChange("companyName", null, e.target.value)}
                        />
                        <div className="mt-2 d-flex flex-column align-items-start">
                            <label>Rating</label>
                            <Rating
                                name="rating"
                                className="mt-1"
                                value={selectedRow?.ratings || 0}
                                // onChange={(event, newValue) => handleServicesChange("rating", null, newValue)}
                                onChange={(e) => handleServicesChange("ratings", null, e.target.value)}
                            />
                        </div>
                        <label className="mt-2">Testimonial Title</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Testimonial Title"
                            type="text"
                            fullWidth
                            value={selectedRow?.testiTitle}
                            onChange={(e) => handleServicesChange("testiTitle", null, e.target.value)}
                        />
                        <label className="mt-2">Testimonial Description</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Testimonial Description"
                            type="text"
                            fullWidth
                            value={selectedRow?.testiDescription}
                            onChange={(e) => handleServicesChange("testiDescription", null, e.target.value)}
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                        <FormControlLabel
                            control={
                                <CustomSwitch
                                    checked={selectedRow?.status === "active"}
                                    onChange={(e) =>
                                        setSelectedRow((prevRow) => ({
                                            ...prevRow,
                                            status: e.target.checked ? "active" : "inactive",
                                        }))
                                    }
                                />
                            }
                            label={selectedRow?.status === "active" ? "Active" : "Inactive"}
                            labelPlacement="end"
                            style={{ marginTop: "1rem" }}
                        />
                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleEditClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

            {/* Add Modal */}
            <Dialog open={isAddOpen} onClose={handleAddClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>Add New What Our Customers Say </DialogTitle>
                <form onSubmit={handleAddSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        <label>Upload Image:</label><br />
                        {services.image && (
                            // <div className="mt-2 mb-3">
                            //     <img src={services.imageUrl} alt="Uploaded" className="input-img" />
                            // </div>
                            <div className="mt-2 mb-3">
                                <Avatar
                                    src={services.imageUrl}
                                    alt="Uploaded"
                                    sx={{ width: 150, height: 150, boxShadow: "0px 4px 10px rgba(41, 137, 57, 0.5)" }}
                                />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                required
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div>

                        <label className="mt-2">Customer Name</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Customer Name"
                            type="text"
                            fullWidth
                            required
                            value={services?.customerName}
                            onChange={(e) => handleServicesChange("customerName", null, e.target.value)}
                        />
                        <label className="mt-2">Customer Company Name</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Customer Company Name"
                            type="text"
                            fullWidth
                            required
                            value={services?.companyName}
                            onChange={(e) => handleServicesChange("companyName", null, e.target.value)}
                        />
                        <div className="mt-2 d-flex flex-column align-items-start">
                            <label>Rating</label>
                            <Rating
                                name="rating"
                                className="mt-1"
                                value={services?.ratings || 0}
                                // onChange={(event, newValue) => handleServicesChange("rating", null, newValue)}
                                onChange={(e) => handleServicesChange("ratings", null, e.target.value)}
                            />
                        </div>
                        <label className="mt-2">Testimonial Title</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Testimonial Title"
                            type="text"
                            fullWidth
                            required
                            value={services?.testiTitle}
                            onChange={(e) => handleServicesChange("testiTitle", null, e.target.value)}
                        />
                        <label className="mt-2">Testimonial Description</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Testimonial Description"
                            type="text"
                            fullWidth
                            required
                            value={services?.testiDescription}
                            onChange={(e) => handleServicesChange("testiDescription", null, e.target.value)}
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleAddClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

        </>
    )
}
export default CustomerSaysTable;