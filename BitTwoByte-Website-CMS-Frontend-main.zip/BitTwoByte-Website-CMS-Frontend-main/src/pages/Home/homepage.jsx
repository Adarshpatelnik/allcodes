import React, { useState, useRef, useEffect } from "react";
import SideBar from "../Sidebar/Sidebar";
import { Card, CardContent, IconButton, Button } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import "../../assets/styles/custom.css"
import Dropdown from "../../components/Dropdown";
import Loader from "../../components/loader";
import "react-quill/dist/quill.snow.css";
import CustomField from "../../components/CustomField";
import Swal from "sweetalert2";
import apiFunctions from "../../api/apiFunctions";
import { appConstants } from "../../constants/appConstants";
import CollabTable from "./CollabTable";
import IndustryExpertiseTable from "./IndustryExpertiseTable";
import CustomerSaysTable from "./CustomerSaysTable";
import messages from "../../constants/messages";

const HomePage = () => {
    const [isOpen, setIsopen] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [isLoader, setIsLoader] = useState(false);

    const handleOpen = () => {
        setIsopen(!isOpen);
    }

    //region Banner Section
    const [topBanner, setTopBanner] = useState({
        headline: "",
        headlinelink: "",
        mainheadlinePri: "",
        mainheadlineSec: "",
        subheadline: "",
        button: "",
        link: "",
        captionPri: "",
        captionSec: ""
    });

    const handleTopBannerChange = (field, subfield, value) => {
        setTopBanner((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const [media, setMedia] = useState(null);
    const [mediaFile, setMediaFile] = useState(null);
    const [mediaType, setMediaType] = useState(null);

    const handleFileChange = (e) => {
        const file = e.target.files[0];

        if (file) {
            if (file.type.split("/")[0] === "video" && file.size > 10 * 1024 * 1024) {
                Swal.fire({
                    text: "The video file size should be under 10MB.",
                    icon: 'error'
                });
                return;
            }

            setMediaFile(file);
            const fileType = file.type.split("/")[0];
            setMediaType(fileType);

            if (fileType === "image") {
                const reader = new FileReader();
                reader.onload = () => {
                    setMedia(reader.result); // set media *first*
                    setMediaType(fileType);  // only show image *after* it's ready
                };
                reader.readAsDataURL(file);
            } else if (fileType === "video") {
                setMedia(URL.createObjectURL(file));
            }
        }
    };

    const handleTopBannerSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            headline: topBanner?.headline,
            headlinelink: topBanner?.headlinelink,
            mainheadlinePri: topBanner?.mainheadlinePri,
            mainheadlineSec: topBanner?.mainheadlineSec,
            subheadline: topBanner?.subheadline,
            button: topBanner?.button,
            link: topBanner?.link,
            captionPri: topBanner?.captionPri,
            captionSec: topBanner?.captionSec
        }

       

        if (mediaFile && mediaFile instanceof File) {
            form.append("image", mediaFile);
        }

        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addHome(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.banner?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getTopBannerData();
            } else {
                throw new Error(messages?.banner?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const getTopBannerData = () => {
        apiFunctions.getHome()
            .then((res) => {

                if (res?.status === 200 && res?.data?.data?.length > 0) {

                    const contentData = JSON.parse(res?.data?.data[0]?.content || "");
                    const imageData = res?.data?.data[0]?.images;
                    const imageUrl = imageData ? appConstants?.imageUrl + imageData : null;
            

                    const isVideo = /\.(mp4|webm|ogg|mov|avi)$/i.test(imageData || "");
                    setMediaType(isVideo ? "video" : "image");


                    setMedia(imageUrl);
                    // setMediaType(imageData ? "image" : null);
                 
                    setTopBanner({
                        headline: contentData?.headline,
                        headlinelink: contentData?.headlinelink,
                        mainheadlinePri: contentData?.mainheadlinePri,
                        mainheadlineSec: contentData?.mainheadlineSec,
                        subheadline: contentData?.subheadline,
                        button: contentData?.button,
                        link: contentData?.link,
                        captionPri: contentData?.captionPri,
                        captionSec: contentData?.captionSec
                    });
                } else {
                    setTopBanner({});
                }
            })
            .catch((err) => {
                console.error("Error fetching Top Banner Data:", err);
                setTopBanner({});
            });
    };

    //region Our Innovative Section One
    const [innovateOne, setInnovateOne] = useState({
        cardone: {
            img: "",
            imgFile: "",
            headline: "",
            subheadline: "",
            link: ""
        },
        cardtwo: {
            img: "",
            imgFile: "",
            headline: "",
            subheadline: "",
            link: ""
        },
        cardthree: {
            img: "",
            imgFile: "",
            headline: "",
            subheadline: "",
            link: ""
        },
    });

    const handleInnovateOneChange = (field, subfield, value) => {
        setInnovateOne((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleInnovateOneSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            cardone: {
                headline: innovateOne?.cardone?.headline,
                subheadline: innovateOne?.cardone?.subheadline,
                link: innovateOne?.cardone?.link
            },
            cardtwo: {
                headline: innovateOne?.cardtwo?.headline,
                subheadline: innovateOne?.cardtwo?.subheadline,
                link: innovateOne?.cardtwo?.link
            },
            cardthree: {
                headline: innovateOne?.cardthree?.headline,
                subheadline: innovateOne?.cardthree?.subheadline,
                link: innovateOne?.cardthree?.link
            },
        }

       
        if (innovateOne?.cardone?.imgFile instanceof File) {
            form.append("image1", innovateOne.cardone.imgFile);
        }
        if (innovateOne?.cardtwo?.imgFile instanceof File) {
            form.append("image2", innovateOne.cardtwo.imgFile);
        }
        if (innovateOne?.cardthree?.imgFile instanceof File) {
            form.append("image3", innovateOne.cardthree.imgFile);
        }

        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addInOne(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getInnovateOneData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const getInnovateOneData = () => {
        apiFunctions.getInOne()
            .then((res) => {
                if (res?.status === 200 && res?.data?.data?.length > 0) {

                    const contentData = JSON.parse(res?.data?.data[0]?.content || "");
                    const imageData = JSON.parse(res?.data?.data[0]?.images || "");

                    setInnovateOne({
                        cardone: {
                            img: appConstants?.imageUrl + imageData?.image1,
                            imgFile: "",
                            headline: contentData?.cardone?.headline,
                            subheadline: contentData?.cardone?.subheadline,
                            link: contentData?.cardone?.link
                        },
                        cardtwo: {
                            img: appConstants?.imageUrl + imageData?.image2,
                            imgFile: "",
                            headline: contentData?.cardtwo?.headline,
                            subheadline: contentData?.cardtwo?.subheadline,
                            link: contentData?.cardtwo?.link
                        },
                        cardthree: {
                            img: appConstants?.imageUrl + imageData?.image3,
                            imgFile: "",
                            headline: contentData?.cardthree?.headline,
                            subheadline: contentData?.cardthree?.subheadline,
                            link: contentData?.cardthree?.link
                        },
                    });
                } else {
                    setInnovateOne({});
                }
            })
            .catch((err) => {
                console.error("Error fetching Top Banner Data:", err);
                setInnovateOne({});
            });
    };

    //region Our Innovative Section Two
    const [innovateTwo, setInnovateTwo] = useState({
        cardone: {
            img: "",
            imgFile: "",
            headline: "",
            subheadline: "",
            link: ""
        },
        cardtwo: {
            img: "",
            imgFile: "",
            headline: "",
            subheadline: "",
            link: ""
        },
        cardthree: {
            img: "",
            imgFile: "",
            headline: "",
            subheadline: "",
            link: ""
        },
    });

    const handleInnovateTwoChange = (field, subfield, value) => {
        setInnovateTwo((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleInnovateTwoSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            cardone: {
                headline: innovateTwo?.cardone?.headline,
                subheadline: innovateTwo?.cardone?.subheadline,
                link: innovateTwo?.cardone?.link
            },
            cardtwo: {
                headline: innovateTwo?.cardtwo?.headline,
                subheadline: innovateTwo?.cardtwo?.subheadline,
                link: innovateTwo?.cardtwo?.link
            },
            cardthree: {
                headline: innovateTwo?.cardthree?.headline,
                subheadline: innovateTwo?.cardthree?.subheadline,
                link: innovateTwo?.cardthree?.link
            },
        }

    
        if (innovateTwo?.cardone?.imgFile instanceof File) {
            form.append("image1", innovateTwo.cardone.imgFile);
        }
        if (innovateTwo?.cardtwo?.imgFile instanceof File) {
            form.append("image2", innovateTwo.cardtwo.imgFile);
        }
        if (innovateTwo?.cardthree?.imgFile instanceof File) {
            form.append("image3", innovateTwo.cardthree.imgFile);
        }

        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addInTwo(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getInnovateTwoData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const getInnovateTwoData = () => {
        apiFunctions.getInTwo()
            .then((res) => {
                if (res?.status === 200 && res?.data?.data?.length > 0) {

                    const contentData = JSON.parse(res?.data?.data[0]?.content || "");
                    const imageData = JSON.parse(res?.data?.data[0]?.images || "");

                    setInnovateTwo({
                        cardone: {
                            img: appConstants?.imageUrl + imageData?.image1,
                            imgFile: "",
                            headline: contentData?.cardone?.headline,
                            subheadline: contentData?.cardone?.subheadline,
                            link: contentData?.cardone?.link
                        },
                        cardtwo: {
                            img: appConstants?.imageUrl + imageData?.image2,
                            imgFile: "",
                            headline: contentData?.cardtwo?.headline,
                            subheadline: contentData?.cardtwo?.subheadline,
                            link: contentData?.cardtwo?.link
                        },
                        cardthree: {
                            img: appConstants?.imageUrl + imageData?.image3,
                            imgFile: "",
                            headline: contentData?.cardthree?.headline,
                            subheadline: contentData?.cardthree?.subheadline,
                            link: contentData?.cardthree?.link
                        },
                    });

                } else {
                    setInnovateTwo({});
                }
            })
            .catch((err) => {
                console.error("Error fetching Top Banner Data:", err);
                setInnovateTwo({});
            });
    };

    //region Why Choose us
    const [whychoose, setWhyChoose] = useState({
        img: "",
        imgFile: "",
        mainheadline: "",
        headline: "",
        subheadline: "",
        cardone: {
            headline: "",
            subheadline: "",
        },
        cardtwo: {
            headline: "",
            subheadline: "",
        },
        cardthree: {
            headline: "",
            subheadline: "",
        },
        cardfour: {
            headline: "",
            subheadline: "",
        },
    });

    const handleWhyChooseChange = (field, subfield, value) => {
        setWhyChoose((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));
    };

    const handleWhyChooseSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);


        const form = new FormData();
        const json = {
            mainheadline: whychoose?.mainheadline,
            headline: whychoose?.headline,
            subheadline: whychoose?.subheadline,
            cardone: {
                headline: whychoose?.cardone?.headline,
                subheadline: whychoose?.cardone?.subheadline,
            },
            cardtwo: {
                headline: whychoose?.cardtwo?.headline,
                subheadline: whychoose?.cardtwo?.subheadline,
            },
            cardthree: {
                headline: whychoose?.cardthree?.headline,
                subheadline: whychoose?.cardthree?.subheadline,
            },
            cardfour: {
                headline: whychoose?.cardfour?.headline,
                subheadline: whychoose?.cardfour?.subheadline,
            },
        }

       
        if (whychoose?.imgFile instanceof File) {
            form.append("image", whychoose.imgFile);
        }

        form.append("contents", JSON.stringify(json));

        try {
            const res = await apiFunctions.addWhyChoose(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: 'success'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Perform any additional actions if needed
                    }
                });

                getWhyChooseData();
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: 'error'
            });
        } finally {
            setTimeout(() => setIsLoader(false), 1500);
        }
    };

    const getWhyChooseData = () => {
        apiFunctions.getWhyChoose()
            .then((res) => {
                if (res?.status === 200 && res?.data?.data?.length > 0) {

                    const contentData = JSON.parse(res?.data?.data[0]?.content || "");
                    const imageData = res?.data?.data[0]?.images || "";

                    setWhyChoose({
                        img: appConstants?.imageUrl + imageData,
                        imgFile: "",
                        mainheadline: contentData?.mainheadline,
                        headline: contentData?.headline,
                        subheadline: contentData?.subheadline,
                        cardone: {
                            headline: contentData?.cardone?.headline,
                            subheadline: contentData?.cardone?.subheadline,
                        },
                        cardtwo: {
                            headline: contentData?.cardtwo?.headline,
                            subheadline: contentData?.cardtwo?.subheadline,
                        },
                        cardthree: {
                            headline: contentData?.cardthree?.headline,
                            subheadline: contentData?.cardthree?.subheadline,
                        },
                        cardfour: {
                            headline: contentData?.cardfour?.headline,
                            subheadline: contentData?.cardfour?.subheadline,
                        },
                    });

                } else {
                    setWhyChoose({});
                }
            })
            .catch((err) => {
                console.error("Error fetching Top Banner Data:", err);
                setWhyChoose({});
            });
    };

    //region useEffect
    const isFetched = useRef(false);
    useEffect(() => {
        let timeout = setTimeout(() => {
            setIsLoading(false);
        }, 1500);

        if (!isFetched.current) {
            getTopBannerData();
            getInnovateOneData();
            getInnovateTwoData();
            getWhyChooseData();
            isFetched.current = true;
        }

        return () => clearTimeout(timeout);
    }, []);


    return (
        <>
            <div className="container-fluid p-0 " style={{ overflow: 'hidden' }}>
                <div className="row">
                    <div className={`${isOpen ? "col-lg-2  mob-nav p-0" : "d-none"} sidebar_layout`}>
                        <SideBar />
                    </div>
                    <div className={`${isOpen ? "col-lg-10 col-12  " : "col-12 w-100"} dashboard_card main_layout`} >

                        <div className="d-flex w-100 justify mob-sticky mb-2">
                            <IconButton className="web-btn" onClick={handleOpen} >
                                <MenuIcon />
                            </IconButton>
                            <IconButton className="mob-btn" data-bs-toggle="offcanvas" data-bs-target="#mob-canvas" aria-controls="mob-canvas">
                                <MenuIcon />
                            </IconButton>
                            <div className="logout_dropdown">
                                <Dropdown />
                            </div>
                        </div>
                        {isLoading ?
                            <Loader /> :
                            <>
                                <Card className="p-lg-2 p-1">
                                    <CardContent>
                                        {/* Banner Section */}
                                        <div className="row">
                                            <h4 className="fw-medium" style={{ color: "#298939" }}>Home Page</h4>
                                            <div className="col-lg-6 col-12">
                                                <h5 style={{ color: "#012354" }}>Banner Section</h5>
                                            </div>
                                        </div>
                                        <form onSubmit={handleTopBannerSave}>
                                            <div className="row mt-2">
                                                <div className="col-lg-8 col-12">
                                                    {media && mediaType && (
                                                        <>
                                                            {mediaType === "image" ? (
                                                                <div className="mb-2">
                                                                    <img src={media} alt="" className="input-img" />
                                                                </div>
                                                            ) : (
                                                                <div className="mb-2">
                                                                    <video
                                                                        className="input-img"
                                                                        controls
                                                                        key={media}
                                                                    >
                                                                        {/* <source src={media} type="video/mp4" /> */}
                                                                        <source src={media} type={mediaFile?.type || "video/mp4"} />
                                                                        Your browser does not support the video tag.
                                                                    </video>
                                                                </div>
                                                            )}
                                                        </>
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/png, image/jpeg, video/*"
                                                            onChange={handleFileChange}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (1920x1080) | Video must be below 10MB
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                {/* Left Column */}
                                                <div className="col-lg-6 col-12">
                                                    {/* <CustomField
                                                        value={topBanner?.headline || ""}
                                                        onChange={(e) => handleTopBannerChange("headline", null, e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={topBanner?.headlinelink || ""}
                                                        onChange={(e) => handleTopBannerChange("headlinelink", null, e.target.value)}
                                                        margin="dense" label="Head Line Link" type="text" size="small" fullWidth className="mb-2" /> */}
                                                    <CustomField
                                                        value={topBanner?.mainheadlinePri || ""}
                                                        onChange={(e) => handleTopBannerChange("mainheadlinePri", null, e.target.value)}
                                                        margin="dense" label="Main Head Line Primary" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={topBanner?.mainheadlineSec || ""}
                                                        onChange={(e) => handleTopBannerChange("mainheadlineSec", null, e.target.value)}
                                                        margin="dense" label="Keyword to Highlight" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={topBanner?.subheadline || ""}
                                                        onChange={(e) => handleTopBannerChange("subheadline", null, e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                {/* Right Column */}
                                                <div className="col-lg-6 col-12">

                                                    {/* <CustomField
                                                        value={topBanner?.button || ""}
                                                        onChange={(e) => handleTopBannerChange("button", null, e.target.value)}
                                                        margin="dense" label="Button" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={topBanner?.link || ""}
                                                        onChange={(e) => handleTopBannerChange("link", null, e.target.value)}
                                                        margin="dense" label="Button Link" type="text" size="small" fullWidth className="mb-2" /> */}
                                                    <CustomField
                                                        value={topBanner?.captionPri || ""}
                                                        onChange={(e) => handleTopBannerChange("captionPri", null, e.target.value)}
                                                        margin="dense" label="Caption Primary" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={topBanner?.captionSec || ""}
                                                        onChange={(e) => handleTopBannerChange("captionSec", null, e.target.value)}
                                                        margin="dense" label="Caption Secondary" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                <div className="text-end">
                                                    {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                                    <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                                        {isLoader ? "Saving..." : "Save"}
                                                    </Button>
                                                </div>
                                            </div>
                                        </form>

                                        {/* Our trusted Collaborators */}
                                        <div className="row mt-3 mb-3">
                                            <div className="col-lg-6 col-12">
                                                <h5 style={{ color: "#012354" }}>Our Trusted Collaborators Section</h5>
                                            </div>
                                        </div>
                                        <CollabTable />
                                        {/* Our Innovative Service */}
                                        <div className="row mt-4 mb-4">
                                            <div className="col-lg-6 col-12">
                                                <h5 style={{ color: "#012354" }}>Our Innovative Service Section</h5>
                                            </div>
                                        </div>
                                        {/* Our Innovative Service 1 */}
                                        <form onSubmit={handleInnovateOneSave}>
                                            <div className="row mt-2">
                                                {/* Left Column */}
                                                <div className="col-lg-4 col-12">
                                                    {innovateOne?.cardone?.img ? (
                                                        <div className="mb-2">
                                                            <img src={innovateOne?.cardone?.img} alt="" className="input-img" />
                                                        </div>
                                                    ) : (
                                                        ""
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) {
                                                                    const objectUrl = URL.createObjectURL(file);
                                                                    handleInnovateOneChange("cardone", "imgFile", file);
                                                                    handleInnovateOneChange("cardone", "img", objectUrl);
                                                                }
                                                            }}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                    <CustomField
                                                        value={innovateOne?.cardone?.headline || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardone", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        multiline
                                                        rows={2}
                                                        value={innovateOne?.cardone?.subheadline || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardone", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={innovateOne?.cardone?.link || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardone", "link", e.target.value)}
                                                        margin="dense" label="Link To Navigate" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                {/* Center Column */}
                                                <div className="col-lg-4 col-12">
                                                    {innovateOne?.cardtwo?.img ? (
                                                        <div className="mb-2">
                                                            <img src={innovateOne?.cardtwo?.img} alt="" className="input-img" />
                                                        </div>
                                                    ) : (
                                                        ""
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) {
                                                                    const objectUrl = URL.createObjectURL(file);
                                                                    handleInnovateOneChange("cardtwo", "imgFile", file);
                                                                    handleInnovateOneChange("cardtwo", "img", objectUrl);
                                                                }
                                                            }}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                    <CustomField
                                                        value={innovateOne?.cardtwo?.headline || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardtwo", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        multiline
                                                        rows={2}
                                                        value={innovateOne?.cardtwo?.subheadline || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardtwo", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={innovateOne?.cardtwo?.link || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardtwo", "link", e.target.value)}
                                                        margin="dense" label="Link To Navigate" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                {/* Right Column */}
                                                <div className="col-lg-4 col-12">
                                                    {innovateOne?.cardthree?.img ? (
                                                        <div className="mb-2">
                                                            <img src={innovateOne?.cardthree?.img} alt="" className="input-img" />
                                                        </div>
                                                    ) : (
                                                        ""
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) {
                                                                    const objectUrl = URL.createObjectURL(file);
                                                                    handleInnovateOneChange("cardthree", "imgFile", file);
                                                                    handleInnovateOneChange("cardthree", "img", objectUrl);
                                                                }
                                                            }}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                    <CustomField
                                                        value={innovateOne?.cardthree?.headline || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardthree", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        multiline
                                                        rows={2}
                                                        value={innovateOne?.cardthree?.subheadline || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardthree", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={innovateOne?.cardthree?.link || ""}
                                                        onChange={(e) => handleInnovateOneChange("cardthree", "link", e.target.value)}
                                                        margin="dense" label="Link To Navigate" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                <div className="text-end">
                                                    {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                                    <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                                        {isLoader ? "Saving..." : "Save"}
                                                    </Button>
                                                </div>
                                            </div>
                                        </form>

                                        {/* Our Innovative Service 2 */}
                                        <form onSubmit={handleInnovateTwoSave}>
                                            <div className="row mt-4">
                                                {/* Left Column */}
                                                <div className="col-lg-4 col-12">
                                                    {innovateTwo?.cardone?.img ? (
                                                        <div className="mb-2">
                                                            <img src={innovateTwo?.cardone?.img} alt="" className="input-img" />
                                                        </div>
                                                    ) : (
                                                        ""
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) {
                                                                    const objectUrl = URL.createObjectURL(file);
                                                                    handleInnovateTwoChange("cardone", "imgFile", file);
                                                                    handleInnovateTwoChange("cardone", "img", objectUrl);
                                                                }
                                                            }}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                    <CustomField
                                                        value={innovateTwo?.cardone?.headline || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardone", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        multiline
                                                        rows={2}
                                                        value={innovateTwo?.cardone?.subheadline || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardone", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={innovateTwo?.cardone?.link || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardone", "link", e.target.value)}
                                                        margin="dense" label="Link To Navigate" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                {/* Center Column */}
                                                <div className="col-lg-4 col-12">
                                                    {innovateTwo?.cardtwo?.img ? (
                                                        <div className="mb-2">
                                                            <img src={innovateTwo?.cardtwo?.img} alt="" className="input-img" />
                                                        </div>
                                                    ) : (
                                                        ""
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) {
                                                                    const objectUrl = URL.createObjectURL(file);
                                                                    handleInnovateTwoChange("cardtwo", "imgFile", file);
                                                                    handleInnovateTwoChange("cardtwo", "img", objectUrl);
                                                                }
                                                            }}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                    <CustomField
                                                        value={innovateTwo?.cardtwo?.headline || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardtwo", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        multiline
                                                        rows={2}
                                                        value={innovateTwo?.cardtwo?.subheadline || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardtwo", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={innovateTwo?.cardtwo?.link || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardtwo", "link", e.target.value)}
                                                        margin="dense" label="Link To Navigate" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                {/* Right Column */}
                                                <div className="col-lg-4 col-12">
                                                    {innovateTwo?.cardthree?.img ? (
                                                        <div className="mb-2">
                                                            <img src={innovateTwo?.cardthree?.img} alt="" className="input-img" />
                                                        </div>
                                                    ) : (
                                                        ""
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) {
                                                                    const objectUrl = URL.createObjectURL(file);
                                                                    handleInnovateTwoChange("cardthree", "imgFile", file);
                                                                    handleInnovateTwoChange("cardthree", "img", objectUrl);
                                                                }
                                                            }}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                    <CustomField
                                                        value={innovateTwo?.cardthree?.headline || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardthree", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        multiline
                                                        rows={2}
                                                        value={innovateTwo?.cardthree?.subheadline || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardthree", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={innovateTwo?.cardthree?.link || ""}
                                                        onChange={(e) => handleInnovateTwoChange("cardthree", "link", e.target.value)}
                                                        margin="dense" label="Link To Navigate" type="text" size="small" fullWidth className="mb-2" />
                                                </div>

                                                <div className="text-end">
                                                    {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                                    <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                                        {isLoader ? "Saving..." : "Save"}
                                                    </Button>
                                                </div>
                                            </div>
                                        </form>

                                        {/* Industry Experience & Expertise */}
                                        <div className="row mt-4 mb-4">
                                            <div className="col-lg-6 col-12">
                                                <h5 style={{ color: "#012354" }}>Industry Experience & Expertise Section</h5>
                                            </div>
                                        </div>
                                        <IndustryExpertiseTable />

                                        {/* Why Choose us */}
                                        <div className="row mt-4 mb-4">
                                            <div className="col-lg-6 col-12">
                                                <h5 style={{ color: "#012354" }}>Why Choose us Section</h5>
                                            </div>
                                        </div>
                                        <form onSubmit={handleWhyChooseSave}>
                                            <div className="row mt-2">
                                                <div className="col-lg-8 col-12">
                                                    {whychoose?.img ? (
                                                        <div className="mb-2">
                                                            <img src={whychoose?.img} alt="" className="input-img" />
                                                        </div>
                                                    ) : (
                                                        ""
                                                    )}
                                                    <div className="foot-input-wrapper mb-2">
                                                        <input
                                                            className="form-control foot-input"
                                                            accept="image/*"
                                                            onChange={(e) => {
                                                                const file = e.target.files[0];
                                                                if (file) {
                                                                    const objectUrl = URL.createObjectURL(file);
                                                                    handleWhyChooseChange("imgFile", null, file);
                                                                    handleWhyChooseChange("img", null, objectUrl);
                                                                }
                                                            }}
                                                            type="file"
                                                        />
                                                        <span style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>
                                                            (520×250)
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                {/* Left Column */}
                                                <div className="col-lg-6 col-12">
                                                    <CustomField
                                                        value={whychoose?.mainheadline || ""}
                                                        onChange={(e) => handleWhyChooseChange("mainheadline", null, e.target.value)}
                                                        margin="dense" label="Main Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                    <CustomField
                                                        value={whychoose?.headline || ""}
                                                        onChange={(e) => handleWhyChooseChange("headline", null, e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>
                                                <div className="col-lg-6 col-12">
                                                    <CustomField
                                                        value={whychoose?.subheadline || ""}
                                                        onChange={(e) => handleWhyChooseChange("subheadline", null, e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                {/* Left Column */}
                                                <div className="col-lg-6 col-12">
                                                    <p style={{ color: "#012354" }} className="mb-2">Content One</p>
                                                    <CustomField
                                                        value={whychoose?.cardone?.headline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardone", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />

                                                    <CustomField
                                                        value={whychoose?.cardone?.subheadline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardone", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>
                                                {/* Right Column */}
                                                <div className="col-lg-6 col-12">
                                                    <p style={{ color: "#012354" }} className="mb-2">Content Two</p>
                                                    <CustomField
                                                        value={whychoose?.cardtwo?.headline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardtwo", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />

                                                    <CustomField
                                                        value={whychoose?.cardtwo?.subheadline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardtwo", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>
                                            </div>
                                            <div className="row mt-2">
                                                {/* Left Column */}
                                                <div className="col-lg-6 col-12">
                                                    <p style={{ color: "#012354" }} className="mb-2">Content Three</p>
                                                    <CustomField
                                                        value={whychoose?.cardthree?.headline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardthree", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />

                                                    <CustomField
                                                        value={whychoose?.cardthree?.subheadline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardthree", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>
                                                {/* Right Column */}
                                                <div className="col-lg-6 col-12">
                                                    <p style={{ color: "#012354" }} className="mb-2">Content Four</p>
                                                    <CustomField
                                                        value={whychoose?.cardfour?.headline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardfour", "headline", e.target.value)}
                                                        margin="dense" label="Head Line" type="text" size="small" fullWidth className="mb-2" />

                                                    <CustomField
                                                        value={whychoose?.cardfour?.subheadline || ""}
                                                        onChange={(e) => handleWhyChooseChange("cardfour", "subheadline", e.target.value)}
                                                        margin="dense" label="Sub Head Line" type="text" size="small" fullWidth className="mb-2" />
                                                </div>
                                            </div>
                                            <div className="text-end">
                                                {/* <Button className="mt-3 grey-btn me-2" variant="contained" >Cancel</Button> */}
                                                <Button className="mt-3 btn" type="submit" variant="contained" disabled={isLoader}>
                                                    {isLoader ? "Saving..." : "Save"}
                                                </Button>
                                            </div>
                                        </form>

                                        {/* What Our Customers Say */}
                                        <div className="row mt-4 mb-4">
                                            <div className="col-lg-6 col-12">
                                                <h5 style={{ color: "#012354" }}>What Our Customers Say Section</h5>
                                            </div>
                                        </div>
                                        <CustomerSaysTable />
                                    </CardContent>
                                </Card>
                            </>
                        }
                    </div>
                </div>
            </div>
            <div className="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabIndex="-1" id="mob-canvas" aria-labelledby="mob-canvaslabel">
                <div className="offcanvas-header" style={{ background: "transparent" }}>
                    <IconButton data-bs-dismiss="offcanvas" aria-label="Close">
                        <CloseIcon style={{ height: '40px', width: '40px', color: 'black', marginTop: "20px" }} />
                    </IconButton>
                </div>
                <div className="offcanvas-body p-0">
                    <SideBar />
                </div>
            </div>
        </>
    )
}
export default HomePage;