import { Button, ButtonGroup, IconButton, Dialog, DialogTitle, Card, CardContent, DialogContent, DialogActions, FormControlLabel, Switch } from "@mui/material";
import React, { useEffect, useState, useRef } from "react";
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from "sweetalert2";
import Table from "../../components/Table";
import ReactQuill from "react-quill";
import DOMPurify from 'dompurify';
import Loader from "../../components/loader";
import "../../assets/styles/loader.css"
import { appConstants } from "../../constants/appConstants";
import CustomField from "../../components/CustomField";
import apiFunctions from "../../api/apiFunctions";
import {
    ToggleOff,
    ToggleOn,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import CustomSelect from "../../components/CustomSelect";

const OurcommunityTable = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [isEditOpen, setIsEditOpen] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [banners, setBanners] = useState([]);
    const [isLoader, setIsLoader] = useState(false);

    const CustomSwitch = styled(Switch)({
        "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#298939",
        },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#298939",
        },
    });

    // Formats allowed in the editor
    const formats = [
        "header",
        "bold",
        "italic",
        "underline",
        "color",
        "background",
        "list",
        "bullet",
        "link",
        "align"
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: [] }, { background: [] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    const [services, setServices] = useState({
        id: "",
        username: "",
        email: "",
        phonenumber: "",
        companyname: "",
        topic: "",
        country: "",
        message: "",
        createdat: "",
    });

    const [selectedRow, setSelectedRow] = useState({
        id: "",
        username: "",
        email: "",
        phonenumber: "",
        companyname: "",
        topic: "",
        country: "",
        message: "",
        createdat: "",
    });

    const handleServicesChange = (field, subfield, value, event = null) => {
        setServices((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setServices((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }

        setSelectedRow((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setSelectedRow((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }
    };

    const handleAddOpen = () => {
        setServices({});
        setSelectedRow({});
        setIsAddOpen(true);
    };

    const handleAddClose = () => {
        setSelectedRow({});
        setServices({});
        setIsAddOpen(false);
    };

    const handleViewOpen = (row) => {
        setSelectedRow(row);
        setIsViewOpen(true);
    };

    const handleViewClose = () => {
        setSelectedRow({});
        setServices({});
        setIsViewOpen(false);
    };

    const handleEditOpen = (row) => {
        setSelectedRow(row);
        setIsEditOpen(true);
    };

    const handleEditClose = () => {
        setSelectedRow({});
        setServices({});
        setIsEditOpen(false);
    };

    const [filterStatus, setFilterStatus] = useState("");
    const handleChange = (event) => {
        const selectedValue = event.target.value;
        setFilterStatus(selectedValue);
    };

    useEffect(() => {
        getInitialData();
    }, [filterStatus]);

    //region Get
    const getInitialData = () => {
        apiFunctions.getJoinCommunity()
            .then((res) => {

                if (res?.status === 200 && Array.isArray(res?.data?.data) && res?.data?.data?.length > 0) {

                    const formattedData = res?.data?.data?.map((item, index) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }
                        return {
                            sno: index + 1,
                            id: item?.id,
                            email: item?.mail_id,
                            status: item?.send_mail_status,
                            createdat: item?.created_timestamp
                        };
                    });

                    const filteredData = filterStatus === ""
                        ? formattedData
                        : formattedData.filter(item => item.status === parseInt(filterStatus));

                    setBanners(filteredData);
                } else {
                    setBanners([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setBanners([]);
            });
    };

    //region Table Columns
    const columns = [
        { field: "sno", headerName: "S.No", flex: 1, disableColumnMenu: true, sortable: false, },
        { field: "email", headerName: "Email", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: "status", headerName: "Email Status", flex: 1, disableColumnMenu: true, sortable: false,
            renderCell: (params) => (
                params.row.status === 1 ? "Active" : "Inactive"
            )
        },
        {
            field: "createdat", headerName: "Joined At", flex: 1, disableColumnMenu: true, sortable: false,
            renderCell: (params) => {
                const date = new Date(params.value);
                const options = { day: '2-digit', month: 'long', year: 'numeric' };
                const formattedDate = date.toLocaleDateString('en-GB', options);
                return <span>{formattedDate}</span>;
            },
        },
    ];

    const isFetched = useRef(false);
    useEffect(() => {
        setIsLoader(false);
        setTimeout(() => {
            setIsLoading(false);
        }, 1500);
        if (!isFetched.current) {
            getInitialData();
            isFetched.current = true;
        }
    }, []);

    const status = [
        { key: 0, value: "Inactive" },
        { key: 1, value: "Active" }
    ];

    return (
        <>
            <div className="row">
                <div className="col-12 w-100">
                    {isLoading ?
                        <Loader /> : <>
                            <div className="d-flex justify-content-end">
                                <div style={{ width: 200 }} className="me-2 mb-3">
                                    {/* <CustomSelect
                                        className="mb-2"
                                        value={filterStatus}
                                        onChange={handleChange}
                                        label="Filter Status"
                                        options={status ? status : ""}
                                        // options={status && Array.isArray(status) ? status : []}
                                        id="tech-select"
                                        size="small"
                                        required={true}
                                        optionLabelKey="value"
                                        optionValueKey="key"
                                        showNoneOption={true}
                                    /> */}
                                </div>
                            </div>
                            <Table rows={banners} columns={columns} />
                        </>
                    }
                </div>
            </div>

            {/* View Query Modal */}
            <Dialog open={isViewOpen} onClose={handleViewClose} maxWidth="sm" fullWidth>
                <DialogTitle>
                    View User Query
                </DialogTitle>

                <DialogContent>
                    <Card elevation={0}>
                        <CardContent>
                            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                                <tbody>
                                    <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', padding: '8px 16px 8px 0', width: "30%" }}>Full Name:</td>
                                        <td style={{ color: '#555', padding: '8px 0' }}>{selectedRow?.fullname}</td>
                                    </tr>
                                    <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', padding: '8px 16px 8px 0', width: "30%" }}>Email:</td>
                                        <td style={{ color: '#555', padding: '8px 0' }}>{selectedRow?.email}</td>
                                    </tr>
                                    <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', padding: '8px 16px 8px 0', width: "30%" }}>Mobile Number:</td>
                                        <td style={{ color: '#555', padding: '8px 0' }}>{selectedRow?.phonenumber}</td>
                                    </tr>
                                    {/* <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', padding: '8px 0' }}>Company Name:</td>
                                        <td style={{ color: '#555', padding: '8px 0' }}>{selectedRow?.companyname}</td>
                                    </tr> */}
                                    {/* <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', padding: '8px 0' }}>Topic:</td>
                                        <td style={{ color: '#555', padding: '8px 0' }}>{selectedRow?.topic}</td>
                                    </tr> */}
                                    {/* <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', padding: '8px 0' }}>Country:</td>
                                        <td style={{ color: '#555', padding: '8px 0' }}>{selectedRow?.country}</td>
                                    </tr> */}
                                    <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', verticalAlign: 'top', padding: '8px 16px 8px 0', width: "30%" }}>Message:</td>
                                        <td style={{ color: '#555', padding: '8px 0', whiteSpace: 'pre-wrap', textAlign: 'justify' }}>{selectedRow?.message}</td>
                                    </tr>
                                    <tr>
                                        <td style={{ fontWeight: 'bold', color: '#012354', padding: '8px 16px 8px 0', width: "30%" }}>Date Submitted:</td>
                                        <td style={{ color: '#555', padding: '8px 0' }}>
                                            {selectedRow?.createdat && new Date(selectedRow.createdat).toLocaleDateString('en-GB', {
                                                day: '2-digit',
                                                month: 'long',
                                                year: 'numeric'
                                            })}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </CardContent>
                    </Card>
                </DialogContent>

                <DialogActions>
                    <Button className="grey-btn" onClick={handleViewClose}>Close</Button>
                </DialogActions>
            </Dialog>

        </>
    )
}
export default OurcommunityTable;