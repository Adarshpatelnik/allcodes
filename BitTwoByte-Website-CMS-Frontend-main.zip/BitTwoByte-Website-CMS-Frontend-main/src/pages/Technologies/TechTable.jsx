import { Button, MenuItem, ButtonGroup, IconButton, Dialog, DialogTitle, Card, CardContent, DialogContent, DialogActions, FormControlLabel, Switch } from "@mui/material";
import React, { useEffect, useState, useRef } from "react";
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import Swal from "sweetalert2";
import Table from "../../components/Table";
import ReactQuill from "react-quill";
import DOMPurify from 'dompurify';
import Loader from "../../components/loader";
import "../../assets/styles/loader.css"
import { appConstants } from "../../constants/appConstants";
import CustomField from "../../components/CustomField";
import apiFunctions from "../../api/apiFunctions";
import {
    ToggleOff,
    ToggleOn,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import CustomSelect from "../../components/CustomSelect"
import messages from "../../constants/messages";

const TechTable = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [isViewOpen, setIsViewOpen] = useState(false);
    const [isEditOpen, setIsEditOpen] = useState(false);
    const [isAddOpen, setIsAddOpen] = useState(false);
    const [banners, setBanners] = useState([]);
    const [isLoader, setIsLoader] = useState(false);

    const CustomSwitch = styled(Switch)({
        "& .MuiSwitch-switchBase.Mui-checked": {
            color: "#298939",
        },
        "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
            backgroundColor: "#298939",
        },
    });

    // Formats allowed in the editor
    const formats = [
        "header",
        "bold",
        "italic",
        "underline",
        "color",
        "background",
        "list",
        "bullet",
        "link",
        "align"
    ];

    const modules = {
        toolbar: [
            [{ header: [1, 2, 3, false] }],
            ["bold", "italic", "underline"],
            [{ color: [] }, { background: [] }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ align: [] }],
            ["clean"],
        ],
    };

    //region Categories
    const [isCateViewOpen, setIsCateViewOpen] = useState(false);
    const [isCateEditOpen, setIsCateEditOpen] = useState(false);
    const [isCateAddOpen, setIsCateAddOpen] = useState(false);
    const [catebanners, setCateBanners] = useState([]);

    const handleCateAddOpen = () => {
        setCategories({});
        setCateSelectedRow({});
        setIsCateAddOpen(true);
    };

    const handleCateAddClose = () => {
        setCateSelectedRow({});
        setCategories({});
        setIsCateAddOpen(false);
    };

    const handleCateViewOpen = (row) => {
        setCateSelectedRow(row);
        setIsCateViewOpen(true);
    };

    const handleCateViewClose = () => {
        setCateSelectedRow({});
        setCategories({});
        setIsCateViewOpen(false);
    };

    const handleCateEditOpen = (row) => {
        setCateSelectedRow(row);
        setIsCateEditOpen(true);
    };

    const handleCateEditClose = () => {
        setCateSelectedRow({});
        setCategories({});
        setIsCateEditOpen(false);
    };

    const [categories, setCategories] = useState({
        category: "",
    });

    const [cateselectedRow, setCateSelectedRow] = useState({
        category: "",
    });

    const [technology, setTechnology] = useState([]);


    const handleCategoryChange = (field, subfield, value, event = null) => {
        setCategories((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setCategories((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }

        setCateSelectedRow((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setCateSelectedRow((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }
    };

    //region Cate Get
    const getCateInitialData = () => {
        apiFunctions.getTechCategory()
            .then((res) => {
                if (res?.status === 200 && Array.isArray(res?.data?.data) && res?.data?.data?.length > 0) {

                    const formattedData = res?.data?.data.map((item, index) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }

                        // const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            sno: index + 1,
                            id: item?.id || null,
                            category: item?.technology || "",
                        };
                    });

                    setTechnology(res?.data?.data);
                    setTechFilter("");
                    setSelectedTech("");
                    setCateBanners(formattedData);
                } else {
                    setCateBanners([]);
                    setTechnology([]);
                    setTechFilter('');
                }
            })
            .catch((err) => {
                console.error("Error fetching Category Data:", err);
                setCateBanners([]);
                setTechnology([]);
                setTechFilter('');
            });
    };

    //region Cate Table Columns
    const catecolumns = [
        {
            field: "sno", headerName: "S.No", flex: 1, disableColumnMenu: true, sortable: false,
        },
        {
            field: "category", headerName: "Category", flex: 1, disableColumnMenu: true, sortable: false,
        },
        {
            field: 'Action',
            flex: 1,
            headerName: 'Action',
            disableColumnMenu: true,
            sortable: false,
            renderCell: (params) => (
                params.row && (
                    <ButtonGroup>
                        <IconButton onClick={() => handleCateEditOpen(params.row)}><EditIcon /></IconButton>
                        {/* <IconButton onClick={() => handleCateViewOpen(params.row)}><VisibilityIcon /></IconButton> */}
                        <IconButton onClick={() => handleCateRemove(params.row)} disabled={isLoader}><DeleteIcon /></IconButton>
                    </ButtonGroup>
                )
            )
        },
    ];

    //region Cate Insert
    const handleCateAddSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            "tech": categories?.category
        }

        // if (services?.image instanceof File) {
        //     form.append("image", services.image);
        // }


        // form.append("status", "active");
        // form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.addTechCategory(json);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: "success"
                });
                getCateInitialData();
                getInitialData();
                setTechFilter("");
                setSelectedTech("");
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleCateAddClose();
        }
    };

    //region Cate Update
    const handleCateEditSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            "id": cateselectedRow?.id,
            "tech": cateselectedRow?.category
        }

        // if (selectedRow?.image instanceof File) {
        //     form.append("image", selectedRow?.image);
        // }


        // form.append("id", selectedRow?.id)
        // form.append("status", selectedRow?.status)
        // form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.updateTechCategory(json);

            if (res?.status === 200) {
                Swal.fire({
                    text: res.message || "Category updated successfully!",
                    icon: "success"
                });
                getCateInitialData();
                getInitialData();
                setTechFilter("");
                setSelectedTech("");
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(res?.message || "Failed to update category.");
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleCateEditClose();
        }
    };

    //region Cate Delete
    const handleCateRemove = (row) => {
        if (!row?.id) {
            console.error("Invalid row ID");
            return;
        }


        Swal.fire({
            text: messages?.delete?.confirm,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
        }).then(async (result) => {
            if (result.isConfirmed) {
                setIsLoading(true);

                try {
                    const res = await apiFunctions.deleteTechCategory({ id: row.id });

                    if (res.status === 200) {
                        await Swal.fire({
                            text: messages?.delete?.success,
                            icon: "success"
                        });
                        getCateInitialData();
                        getInitialData();
                        setTechFilter("");
                        setSelectedTech("");
                    } else {
                        await Swal.fire({
                            text: messages?.delete?.error,
                            icon: "error"
                        });
                    }
                } catch (error) {
                    console.error("Error deleting category:", error);
                    await Swal.fire({ text: messages?.catchError, icon: "error" });
                } finally {
                    setIsLoading(false);
                }
            }
        });
    };

    const [services, setServices] = useState({
        image: null,
        imageUrl: "",
        title: "",
        description: ""
    });

    // Filter Technology
    const [TechFilter, setTechFilter] = useState(technology[0]?.id);


    const handleChange = (event) => {
        const selectedValue = event.target.value;
        setTechFilter(selectedValue);
        setSelectedTech(selectedValue ? selectedValue : '');
    };


    useEffect(() => {
        if (technology.length > 0 && !TechFilter) {
            const firstTechId = technology[0]?.id;
            setTechFilter(firstTechId);
            setSelectedTech(firstTechId);
        }
    }, [technology]);


    useEffect(() => {
        getInitialData();
    }, [TechFilter]);

    const [selectedTech, setSelectedTech] = useState();

    const handleSelectedTechChange = (event) => {
        setSelectedTech(event.target.value);
    };

    const [selectedRow, setSelectedRow] = useState({
        image: null,
        imageUrl: "",
        technology: "",
        title: "",
        description: ""
    });

    const handleServicesChange = (field, subfield, value, event = null) => {
        setServices((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setServices((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }

        setSelectedRow((prev) => ({
            ...prev,
            [field]: subfield
                ? {
                    ...prev[field],
                    [subfield]: value,
                }
                : value,
        }));

        if (field === "image" && event?.target?.files?.length) {
            const file = event.target.files[0];
            if (file) {
                const imagePreviewUrl = URL.createObjectURL(file);
                setSelectedRow((prev) => ({
                    ...prev,
                    image: file,
                    imageUrl: imagePreviewUrl,
                }));
            }
        }
    };

    //region Technologies
    const handleAddOpen = () => {
        setServices({});
        setSelectedRow({});
        setIsAddOpen(true);
    };

    const handleAddClose = () => {
        setSelectedRow({});
        setServices({});
        setIsAddOpen(false);
    };

    const handleViewOpen = (row) => {
        setSelectedRow(row);
        setIsViewOpen(true);
    };

    const handleViewClose = () => {
        setSelectedRow({});
        setServices({});
        setIsViewOpen(false);
    };

    const handleEditOpen = (row) => {
        setSelectedRow(row);
        setIsEditOpen(true);
    };

    const handleEditClose = () => {
        setSelectedRow({});
        setServices({});
        setIsEditOpen(false);
    };

    //region Get
    const getInitialData = () => {
        apiFunctions.getTechImg()
            .then((res) => {

                const imagesData = res?.data?.data?.images;

                if (res?.status === 200 && imagesData && typeof imagesData === 'object') {
                    // Step 1: Get the tech name from the TechFilter ID
                    const selectedTechName = TechFilter
                        ? technology.find((tech) => tech.id === TechFilter)?.technology
                        : null;

                    // Step 2: Get matching image data
                    const selectedTechImages = selectedTechName
                        ? imagesData[selectedTechName] || []
                        : Object.values(imagesData).flat(); // all data if no filter


                    const formattedData = selectedTechImages.map((item) => {
                        let descriptionData = {};
                        try {
                            descriptionData = item.description ? JSON.parse(item.description) : {};
                        } catch (error) {
                            console.error("Error parsing description:", error);
                        }
                        const imageUrl = item?.image_url ? appConstants.imageUrl + item?.image_url : null;
                        return {
                            id: item?.id || null,
                            technology: selectedTechName || "",
                            // description: descriptionData?.description || "",
                            imageUrl: imageUrl,
                            status: item?.status || ""
                        };
                    });

                    setBanners(formattedData);
                } else {
                    setBanners([]);
                }
            })
            .catch((err) => {
                console.error("Error fetching Services Data:", err);
                setBanners([]);
            });
    };

    //region Table Columns
    const columns = [
        {
            field: "imageUrl", headerName: "Tech Image", flex: 1, disableColumnMenu: true, sortable: false,
            renderCell: (params) => (
                <img
                    src={params.row.imageUrl}
                    alt="Tech"
                    style={{ width: 60, height: 60, objectFit: "cover", borderRadius: 8 }}
                />
            )
        },
        { field: "technology", headerName: "Technology", flex: 1, disableColumnMenu: true, sortable: false, },
        { field: "status", headerName: "Status", flex: 1, disableColumnMenu: true, sortable: false, },
        {
            field: 'Action',
            flex: 1,
            headerName: 'Action',
            disableColumnMenu: true,
            sortable: false,
            renderCell: (params) => (
                params.row && (
                    <ButtonGroup>
                        <IconButton onClick={() => handleEditOpen(params.row)}><EditIcon /></IconButton>
                        <IconButton onClick={() => handleViewOpen(params.row)}><VisibilityIcon /></IconButton>
                        <IconButton onClick={() => handleRemove(params.row)} disabled={isLoader}><DeleteIcon /></IconButton>
                    </ButtonGroup>
                )
            )
        },
    ];

    //region Insert
    const handleAddSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            "description": "description"
        };

        if (services?.image instanceof File) {
            form.append("image", services.image);
        }


        form.append("status", "active");
        form.append("technology_id", selectedTech);
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.addTechImg(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.insert?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.insert?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleAddClose();
        }
    };

    //region Update
    const handleEditSave = async (e) => {
        e.preventDefault();
        setIsLoader(true);

        const form = new FormData();
        const json = {
            "description": "description"
        };

        if (selectedRow?.image instanceof File) {
            form.append("image", selectedRow?.image);
        }


        form.append("id", selectedRow?.id)
        form.append("status", selectedRow?.status)
        form.append("description", JSON.stringify(json));

        try {
            const res = await apiFunctions.updateTechImg(form);

            if (res?.status === 200) {
                Swal.fire({
                    text: messages?.update?.success,
                    icon: "success"
                });
                getInitialData();
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                }, 1500);
            } else {
                throw new Error(messages?.update?.error);
            }
        } catch (error) {
            Swal.fire({
                text: error.message || messages?.catchError,
                icon: "error"
            });
        } finally {
            setIsLoader(false);
            handleEditClose();
        }
    };

    //region Delete
    const handleRemove = (row) => {
        if (!row?.id) {
            console.error("Invalid row ID");
            return;
        }


        Swal.fire({
            text: messages?.delete?.confirm,
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "OK",
            cancelButtonText: "Cancel",
        }).then(async (result) => {
            if (result.isConfirmed) {
                setIsLoading(true);

                try {
                    const res = await apiFunctions.deleteTechImg({ id: row.id });

                    if (res.status === 200) {
                        await Swal.fire({
                            text: messages?.delete?.success,
                            icon: "success"
                        });
                        getInitialData();
                    } else {
                        await Swal.fire({
                            text: messages?.delete?.error,
                            icon: "error"
                        });
                    }
                } catch (error) {
                    console.error("Error deleting service:", error);
                    await Swal.fire({ text: messages?.catchError, icon: "error" });
                } finally {
                    setIsLoading(false);
                }
            }
        });
    };

    const isFetched = useRef(false);
    useEffect(() => {
        setIsLoader(false);
        setTimeout(() => {
            setIsLoading(false);
        }, 1500);
        if (!isFetched.current) {
            getInitialData();
            getCateInitialData();
            isFetched.current = true;
        }
    }, []);

    return (
        <>
            {isLoading ?
                <Loader /> :
                <>
                    {/* Categories */}
                    <div className="row mt-3 mb-3">
                        <div className="row mt-3 mb-3">
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Categories Section</h5>
                            </div>
                        </div>
                        <div className="col-12 w-100">
                            <div className="text-end">
                                <Button className="btn mb-3" onClick={handleCateAddOpen} endIcon={<AddIcon />} variant="contained">Add new</Button>
                            </div>
                            <Table rows={catebanners} columns={catecolumns} />
                        </div>
                    </div>
                    {/* Technologies */}
                    <div className="row">
                        <div className="row mt-3 mb-3">
                            <div className="col-lg-6 col-12">
                                <h5 style={{ color: "#012354" }}>Technologies Section</h5>
                            </div>
                        </div>
                        <div className="col-12 w-100">
                            <div className="d-flex justify-content-end align-items-center">
                                <div style={{ width: 200 }} className="me-2 mb-3">
                                    <CustomSelect
                                        value={TechFilter}
                                        onChange={handleChange}
                                        label="Technology"
                                        options={technology ? technology : ""}
                                        id="tech-select"
                                        size="small"
                                        optionLabelKey="technology"
                                        optionValueKey="id"
                                    // showNoneOption={true}
                                    />
                                </div>
                                <Button className="btn mb-3" onClick={handleAddOpen} endIcon={<AddIcon />} variant="contained">Add new</Button>
                            </div>
                            <Table rows={banners} columns={columns} />
                        </div>
                    </div>
                </>
            }

            {/* Category View Modal */}
            <Dialog open={isCateViewOpen} onClose={handleCateViewClose} maxWidth={"sm"} fullWidth={true}>
                <DialogTitle>View Category</DialogTitle>
                <DialogContent>
                    <Card elevation={0}>
                        <CardContent>
                            <div className="row">
                                <div className="col-lg-6 col-12 text-start d-flex align-items-center">
                                    <div className="px-3 position-relative">
                                        <h2 style={{ fontFamily: 'boldtxt', color: '#012354' }} className="title">{selectedRow?.title}</h2>
                                        <p className="regular position-relative" style={{ zIndex: '2', color: '#959595' }}>
                                            {selectedRow?.description}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6 col-12 text-start ">
                                    <img src={selectedRow?.imageUrl} alt="" className="card_img" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </DialogContent>
                <DialogActions style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                    <span className="p-2" style={{ fontSize: "16px", fontWeight: "500", display: "flex", alignItems: "center", gap: "5px" }}>
                        Status: {selectedRow?.status === "active" ?
                            <ToggleOn style={{ color: "#298939", fontSize: "40px" }} /> :
                            <ToggleOff style={{ color: "grey", fontSize: "40px" }} />
                        }
                    </span>
                    <Button className="grey-btn" onClick={handleCateViewClose}>Close</Button>
                </DialogActions>

            </Dialog>

            {/* Category Edit Modal */}
            <Dialog open={isCateEditOpen} onClose={handleCateEditClose} maxWidth={"sm"} fullWidth={true}>
                <DialogTitle>Edit Category</DialogTitle>
                <form onSubmit={handleCateEditSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        {/* <label>Upload Image:</label><br />
                        {selectedRow?.imageUrl && (
                            <div className="mt-2 mb-3">
                                <img src={selectedRow?.imageUrl} alt="Uploaded" className="input-img" />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div> */}

                        <label className="mt-2">Category Name</label>
                        <CustomField
                            className="mt-2"
                            margin="dense"
                            label="Category Name"
                            type="text"
                            fullWidth
                            value={cateselectedRow?.category}
                            onChange={(e) => handleCategoryChange("category", null, e.target.value)}
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                        {/* <FormControlLabel
                            control={
                                <CustomSwitch
                                    checked={selectedRow?.status === "active"}
                                    onChange={(e) =>
                                        setSelectedRow((prevRow) => ({
                                            ...prevRow,
                                            status: e.target.checked ? "active" : "inactive",
                                        }))
                                    }
                                />
                            }
                            label={selectedRow?.status === "active" ? "Active" : "Inactive"}
                            labelPlacement="end"
                            style={{ marginTop: "1rem" }}
                        /> */}
                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleCateEditClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

            {/* Category Add Modal */}
            <Dialog open={isCateAddOpen} onClose={handleCateAddClose} maxWidth={"sm"} fullWidth={true}>
                <DialogTitle>Add New Category</DialogTitle>
                <form onSubmit={handleCateAddSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }
                        <label className="mt-2">Category Name</label>
                        <CustomField
                            required
                            className="mt-2"
                            margin="dense"
                            label="Category Name"
                            type="text"
                            fullWidth
                            value={categories?.category}
                            onChange={(e) => handleCategoryChange("category", null, e.target.value)}
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleCateAddClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

            {/* Technology View Modal */}
            <Dialog open={isViewOpen} onClose={handleViewClose} maxWidth={"md"} fullWidth={true}>
                <DialogTitle>View Technology</DialogTitle>
                <DialogContent>
                    <Card elevation={0}>
                        <CardContent>
                            <div className="row">
                                <div className="col-lg-6 col-12 text-start d-flex align-items-center">
                                    <div className="px-3 position-relative">
                                        <h2 style={{ fontFamily: 'boldtxt', color: '#012354' }} className="title">{selectedRow?.technology}</h2>
                                        <p className="regular position-relative" style={{ zIndex: '2', color: '#959595' }}>
                                            {selectedRow?.description}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6 col-12 text-start ">
                                    <img src={selectedRow?.imageUrl} alt="" className="card_img" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </DialogContent>
                <DialogActions style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                    <span className="p-2" style={{ fontSize: "16px", fontWeight: "500", display: "flex", alignItems: "center", gap: "5px" }}>
                        Status: {selectedRow?.status === "active" ?
                            <ToggleOn style={{ color: "#298939", fontSize: "40px" }} /> :
                            <ToggleOff style={{ color: "grey", fontSize: "40px" }} />
                        }
                    </span>
                    <Button className="grey-btn" onClick={handleViewClose}>Close</Button>
                </DialogActions>

            </Dialog>

            {/* Technology Edit Modal */}
            <Dialog open={isEditOpen} onClose={handleEditClose} maxWidth={"sm"} fullWidth={true}>
                <DialogTitle>Edit Technology</DialogTitle>
                <form onSubmit={handleEditSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        <label>Upload Image:</label><br />
                        {selectedRow?.imageUrl && (
                            <div className="mt-2 mb-3">
                                <img src={selectedRow?.imageUrl} alt="Uploaded" className="input-img" />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div>

                        <label className="mt-2">Selected Technology</label>
                        <CustomField
                            size="small"
                            focused
                            disabled
                            className="mt-2"
                            margin="dense"
                            label="Selected Technology"
                            type="text"
                            fullWidth
                            value={selectedRow?.technology || ""}
                            onChange={(e) => handleServicesChange("title", null, e.target.value)}
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                        <FormControlLabel
                            control={
                                <CustomSwitch
                                    checked={selectedRow?.status === "active"}
                                    onChange={(e) =>
                                        setSelectedRow((prevRow) => ({
                                            ...prevRow,
                                            status: e.target.checked ? "active" : "inactive",
                                        }))
                                    }
                                />
                            }
                            label={selectedRow?.status === "active" ? "Active" : "Inactive"}
                            labelPlacement="end"
                            style={{ marginTop: "1rem" }}
                        />
                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleEditClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>

            {/* Technology Add Modal */}
            <Dialog open={isAddOpen} onClose={handleAddClose} maxWidth={"sm"} fullWidth={true}>
                <DialogTitle>Add New Technology</DialogTitle>
                <form onSubmit={handleAddSave}>
                    <DialogContent style={{ position: "relative" }}>
                        {isLoader ?
                            <>
                                <div style={{
                                    position: "absolute",
                                    top: 0, left: 0, right: 0, bottom: 0,
                                    background: "rgba(255, 255, 255, 0.7)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 10
                                }}>
                                    <div className="dotloader"></div>
                                </div>
                            </> :
                            ""
                        }

                        <label>Upload Image:</label><br />
                        {services?.image && (
                            <div className="mt-2 mb-3">
                                <img src={services?.imageUrl} alt="Uploaded" className="input-img" />
                            </div>
                        )}
                        <div className="d-flex mt-2">
                            <input
                                className="form-control foot-input"
                                type="file"
                                id="image-upload"
                                accept="image/*"
                                required
                                onChange={(e) => handleServicesChange("image", null, e.target.files[0], e)}
                            />
                            <span className="mt-2 ms-2" style={{ fontWeight: "lighter", fontSize: "14px", color: "grey" }}>(520×250)</span>
                        </div>
                        <label className="mt-2">Select Technology</label>
                        <CustomSelect
                            required
                            value={selectedTech || ""}
                            onChange={handleSelectedTechChange}
                            label="Select Technology"
                            options={technology}
                            id="tech-select"
                            size="small"
                        />
                        {/* <div className="border border-rounded mt-2">
                            <ReactQuill
                                modules={modules}
                                formats={formats}
                                value={childlpone.description}
                                onChange={(value) => handleServicesChange("description", null, value)}
                                placeholder="Description"
                            />
                        </div> */}

                    </DialogContent>
                    <DialogActions>
                        <Button className="btn" type="submit" variant="contained" disabled={isLoader}>Save</Button>
                        <Button variant="contained" className="grey-btn" onClick={handleAddClose} disabled={isLoader}>Cancel</Button>
                    </DialogActions>
                </form>
            </Dialog>


        </>
    )
}
export default TechTable;