export const pageRoutes = {
    login: "/",
    unauthorized: "/unauthorized",
    forgotpassword: "/forgot-password",
    resetpassword: "/reset-password",
    changepassword: "/change-password",
    dashboard: "/dashboard",
    blogs: "/blogs",
    casestudy: "/case-study",
    userqueries: "/user-queries",
    worktogether: "/work-together",
    ourcommunity: "/our-community",
    subscribedusers: "/subscribed-users",


    //cms
    home: "/cms/home",
    aboutus: "/cms/about-us",
    faqs: "/cms/faqs",

    //Services
    dataanalytics: "/cms/services/data-analytics",
    cloudservices: "/cms/services/cloud-services",
    datagovernance: "/cms/services/data-governance",
    dataengineering: "/cms/services/data-engineering",
    datascience: "/cms/services/data-science",

    //SCM Services
    supplychain: "/cms/scm/supply-chain",
    managementconsulting: "/cms/scm/management-consulting",
    implementation: "/cms/scm/implementation",
    migration: "/cms/scm/upgrade-and-migration",
    managed: "/cms/scm/managed",
    staffing: "/cms/scm/staffing-IS-IT",

    //Indusries
    mediaandentertainment: "/cms/industries/media-and-entertainment",
    healthcare: "/cms/industries/healthcare",
    banking: "/cms/industries/banking",
    retail: "/cms/industries/retail",
    manufacturing: "/cms/industries/manufacturing",

    technologies: "/cms/technologies",
    getintouch: "/cms/get-in-touch",
    careers: "/cms/careers",

    termsandconditions: "/terms-and-conditions",
    privacypolicy: "/privacy-policy",
    settings: "/settings",
}