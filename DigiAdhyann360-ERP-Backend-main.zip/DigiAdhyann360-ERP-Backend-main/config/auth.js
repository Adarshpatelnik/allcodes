// ------------------------ JWT / Session / OAuth settings ----------------------------------//
const jwt = require('jsonwebtoken');
require('dotenv').config();

const secret = process.env.JWT_SECRET; // Removed fallback for security

// Token Generate Function
function generateToken(payload, expiresIn = '1h') {
  if (!secret) {
    throw new Error('JWT_SECRET is not defined in environment variables');
  }
  return jwt.sign(payload, secret, { expiresIn });
}

// Token Verify Function
function verifyToken(token) {
  try {
    return jwt.verify(token, secret);
  } catch (err) {
    return null; // Invalid or expired token
  }
}

module.exports = {
  generateToken,
  verifyToken,
};