const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const mime = require('mime-types');
const multer = require('multer');

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY, // Corrected variable name
  },
});

console.log('Loaded AWS Credentials:', {
  region: process.env.AWS_REGION,
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ? '***' : 'undefined',
  bucket: process.env.AWS_BUCKET_NAME,
});

const createS3FolderStructure = async (UDISE_CODE) => {
  const folderStructure = [
    `${UDISE_CODE}/Students/Applicants/`,
    `${UDISE_CODE}/Students/Enrolled/`,
    `${UDISE_CODE}/Staff/Applicants/`,
    `${UDISE_CODE}/Staff/Enrolled/`,
    `${UDISE_CODE}/School-details/`,
  ];

  try {
    const createFolderPromises = folderStructure.map((folder) =>
      s3Client.send(
        new PutObjectCommand({
          Bucket: process.env.AWS_BUCKET_NAME,
          Key: folder,
          Body: '',
        })
      )
    );

    await Promise.all(createFolderPromises);
    console.log(`Folder structure for ${UDISE_CODE} created successfully in S3.`);
  } catch (error) {
    console.error('S3 Error Details:', error);
    throw new Error('Failed to create folder structure in S3: ' + error.message);
  }
};

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB limit
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype === 'text/csv' ||
      file.mimetype === 'application/vnd.ms-excel' ||
      file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ) {
      cb(null, true);
    } else {
      cb(new Error('Only .csv, .xls, and .xlsx files are allowed!'), false);
    }
  },
});
const uploadSchoolLogoToS3 = upload.single('SCHOOL_LOGO'); // ✅ matches frontend


module.exports = { s3Client, createS3FolderStructure, uploadSchoolLogoToS3, };