const { S3Client, PutObjectCommand, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const logger = require('../logger/logger');

let s3Client = null;

const initializeS3Client = () => {
  if (!s3Client) {
    if (!process.env.AWS_REGION || !process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) {
      logger.error('AWS credentials not found in the .env file');
      throw new Error('AWS credentials not found in the .env file');
    }
    s3Client = new S3Client({
      region: process.env.AWS_REGION,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      },
    });
    logger.info('AWS S3 client initialized successfully');
  }
  return s3Client;
};

module.exports = { initializeS3Client, getSignedUrl, GetObjectCommand };