// ------------------- Database  config ---------------------------------------//


const mysql = require('mysql2/promise');
require('dotenv').config();
 
// Global pool cache for school databases
const schoolDbPools = new Map();
 
// Function to create MySQL pool using environment variables for the main database
const createPool = () => {
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    port: process.env.DB_PORT,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    waitForConnections: true,
    connectionLimit: 10, // Reasonable limit
    queueLimit: 0
  });
 
        pool.on('connection', async (connection) => {
    try {
      await connection.query(`USE ${process.env.DB_DATABASE}`);
      console.log(`Main pool: Switched to database ${process.env.DB_DATABASE}`);
    } catch (err) {
      console.error('Error setting default database:', err);
    }
  });
 
  pool.on('connection', () => console.log('Main pool: New connection created'));
  pool.on('release', () => console.log('Main pool: Connection released'));
  return pool;
};
 
// Main database pool
const pool = createPool();
 
// Function to connect to a specific school's database using provided credentials
const connectToSchoolDatabase = async (schoolDbCredentials) => {
  const poolKey = `${schoolDbCredentials.DATABASE_HOST}:${schoolDbCredentials.DATABASE_NAME}`;
  if (schoolDbPools.has(poolKey)) {
    return schoolDbPools.get(poolKey); // Reuse existing pool
  }
 
  try {
    const schoolPool = mysql.createPool({
      host: schoolDbCredentials.DATABASE_HOST,
      user: schoolDbCredentials.DATABASE_USERNAME,
      port: 3306,
      database: schoolDbCredentials.DATABASE_NAME,
      password: schoolDbCredentials.DATABASE_PASSWORD,
      waitForConnections: true,
      connectionLimit: 10, // Reasonable limit
      queueLimit: 0
    });
 
    // Test the connection
    const [rows] = await schoolPool.query('SELECT 1');
    console.log('Connected to school database successfully:', poolKey);
 
    // Debug connection usage
    schoolPool.on('connection', () => console.log(`School pool ${poolKey}: New connection created`));
    schoolPool.on('release', () => console.log(`School pool ${poolKey}: Connection released`));
 
    schoolDbPools.set(poolKey, schoolPool); // Cache the pool
    return schoolPool;
  } catch (error) {
    console.error('Error connecting to school database:', error.message, error.stack);
    throw error;
  }
};
 
// Function to create a new connection pool based on provided database details
const createNewDbPool = (dbDetails) => {
  const newDbPool = mysql.createPool({
    host: dbDetails.DATABASE_HOST,
    user: dbDetails.DATABASE_USERNAME,
    port: 3306,
    database: dbDetails.DATABASE_NAME,
    password: dbDetails.DATABASE_PASSWORD,
    waitForConnections: true,
    connectionLimit: 10, // Reasonable limit
    queueLimit: 0
  });
 
  newDbPool.on('connection', () => console.log('New DB pool: New connection created'));
  newDbPool.on('release', () => console.log('New DB pool: Connection released'));
  return newDbPool;
};
 
// Function to close all pools on shutdown
const closeAllPools = async () => {
  console.log('Closing all database pools...');
  await pool.end();
  console.log('Main pool closed');
 
  for (const [key, schoolPool] of schoolDbPools) {
    await schoolPool.end();
    console.log(`Closed school pool for ${key}`);
  }
};
 
module.exports = { pool, createPool, connectToSchoolDatabase, createNewDbPool, closeAllPools };