const multer = require("multer");
const multerS3 = require("multer-s3");
const { initializeS3Client } = require("./aws");
const { getCustomFileName, getContentType, getContentDisposition } = require("../utils/fileutils");

const uploadFileToS3 = multer({
  storage: multerS3({
    s3: initializeS3Client(),
    bucket: process.env.AWS_BUCKET_NAME,
    metadata: (req, file, cb) => {
      cb(null, { fieldName: file.fieldname });
    },
    key: (req, file, cb) => {
      const { applicantId } = req.body;
      if (!req.udiseCode || !applicantId) {
        cb(new Error("Missing required fields: udiseCode or applicantId."));
      } else {
        const customFileName = getCustomFileName(file.fieldname, file.originalname);
        const filePath = `${req.udiseCode}/Students/Applicants/${applicantId}/${customFileName}`;
        cb(null, filePath);
      }
    },
    acl: "private",
    contentType: (req, file, cb) => {
      cb(null, getContentType(file));
    },
    contentDisposition: (req, file, cb) => {
      cb(null, getContentDisposition(file));
    },
  }),
}).fields([
  { name: "STUDENT_AADHAAR", maxCount: 1 },
  { name: "STUDENT_PHOTO", maxCount: 1 },
  { name: "PREVIOUS_MARKSHEET", maxCount: 1 },
  { name: "TRANSFER_CERTIFICATE", maxCount: 1 },
  { name: "MIGRATION_CERTIFICATE", maxCount: 1 },
  { name: "BIRTH_CERTIFICATE", maxCount: 1 },
  { name: "CHARACTER_CERTIFICATE", maxCount: 1 },
  { name: "SAMAGRA_ID", maxCount: 1 },
]);

module.exports = { uploadFileToS3 };