// ------------------- Role-Based Access Control config ---------------------------------------//
const winston = require('winston');

// Logger setup
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/combined.log' }),
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.Console(),
  ],
});

// Function to set role-based context in AsyncLocalStorage
function setRoleContext(asyncLocalStorage, user) {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('AsyncLocalStorage store unavailable in setRoleContext');
    throw new Error('AsyncLocalStorage store unavailable');
  }

  let current_admin = null;
  let current_staff = null;
  let current_student = null;

  switch (user.ROLE_NAME.toLowerCase()) {
    case 'admin':
    case 'administrator':
      current_admin = user.USER_ID;
      break;
    case 'teacher':
      current_staff = user.USER_ID;
      break;
    case 'student':
      current_student = user.USER_ID;
      break;
    default:
      logger.warn('Unknown role encountered', { role: user.ROLE_NAME });
  }

  store.set('current_admin', current_admin);
  store.set('current_staff', current_staff);
  store.set('current_student', current_student);
  store.set('tenantId', user.TENANT_ID);

  logger.info('Role-based context set', {
    role: user.ROLE_NAME,
    userId: user.USER_ID,
    tenantId: user.TENANT_ID,
  });

  return { current_admin, current_staff, current_student };
}

module.exports = { setRoleContext };