

const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { uploadDocuments } = require('../../services/academic/applicationdocform');

const uploadDocumentsController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const current_staff = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!req.files || Object.keys(req.files).length === 0) {
      return res.status(400).json({ error: 'No files were uploaded.' });
    }

    const { applicantId } = req.body;

    if (!applicantId) {
      return res.status(400).json({ error: 'Missing applicantId' });
    }

    const result = await uploadDocuments(req.files, applicantId, schoolDbConnection);
    res.status(200).json(result);
  } catch (error) {
    console.error('Error uploading documents:', error.message);
    res.status(500).json({
      error: 'Document upload failed.',
      details: error.message,
    });
  }
};

module.exports = { uploadDocumentsController };