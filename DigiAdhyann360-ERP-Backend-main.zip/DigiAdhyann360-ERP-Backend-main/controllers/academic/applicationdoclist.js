
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { getDocuments } = require('../../services/academic/applicationdoclist');

const getDocumentsController = async (req, res) => {
  console.log('Received request for /api/get-documents/:udiseCode/:applicationId', req.params);
  const { udiseCode, applicationId } = req.params;

  try {
    if (!udiseCode || !applicationId) {
      return res.status(400).json({ error: 'Missing required parameters: udiseCode or applicationId.' });
    }

    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const current_staff = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log('GET /application: School database connection not established.');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    console.log('Processing request for UDISE Code:', udiseCode, 'ApplicationId:', applicationId);
    const result = await getDocuments(udiseCode, applicationId, schoolDbConnection);
    res.setHeader('Content-Type', 'application/json');
    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getDocumentsController:', error.message, error.stack);
    res.setHeader('Content-Type', 'application/json');
    res.status(500).json({
      error: 'Failed to retrieve documents.',
      details: error.message,
    });
  }
};

module.exports = { getDocumentsController };