const { getApplicationFormStatus, getApplicationClassFilter, updateApplication, createApplication } = require('../../services/academic/applicationform');
const logger = require('../../logger/logger');

const getApplicationFormStatusController = async (req, res) => {
  const { id } = req.params;
  if (!id) {
    logger.warn('Missing application ID in request');
    return res.status(400).json({ error: 'Missing application ID' });
  }

  try {
    logger.info('Fetching application status', { applicationId: id });
    const result = await getApplicationFormStatus(id);
    logger.info('Application status fetched successfully', { applicationId: id });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in getApplicationFormStatusController', { error: err.message, applicationId: id });
    if (err.message.includes('Application not found')) {
      return res.status(404).json({ error: 'Application not found' });
    }
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getApplicationClassFilterController = async (req, res) => {
  try {
    logger.info('Fetching class filter');
    const result = await getApplicationClassFilter();
    logger.info('Class filter fetched successfully');
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in getApplicationClassFilterController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const updateApplicationController = async (req, res) => {
  const { id } = req.params;
  const updatedData = req.body;

  if (!id || !updatedData) {
    logger.warn('Missing required fields in update application request', { applicationId: id });
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    logger.info('Updating application', { applicationId: id });
    const result = await updateApplication(id, updatedData);
    logger.info('Application updated successfully', { applicationId: id });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in updateApplicationController', { error: err.message, applicationId: id });
    if (err.message.includes('Application not found')) {
      return res.status(404).json({ error: 'Application not found' });
    }
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const createApplicationController = async (req, res) => {
  const applicationData = req.body;

  if (!applicationData || Object.keys(applicationData).length === 0) {
    logger.warn('Missing application data in request');
    return res.status(400).json({ error: 'Missing application data' });
  }

  try {
    logger.info('Creating new application');
    const result = await createApplication(applicationData);
    logger.info('Application created successfully', { applicantId: result.applicantId });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in createApplicationController', { error: err.message });
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
};

module.exports = {
  getApplicationFormStatusController,
  getApplicationClassFilterController,
  updateApplicationController,
  createApplicationController,
};