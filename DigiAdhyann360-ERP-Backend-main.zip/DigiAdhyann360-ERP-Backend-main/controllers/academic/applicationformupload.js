const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { bulkLoadData } = require('../../services/academic/applicationformupload');

const bulkLoadController = async (req, res) => {
  console.log("Controller: POST /BulkLoad");

  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    // Check database connection
    if (!schoolDbConnection) {
      console.log("Controller: POST /BulkLoad: School database connection not established.");
      return res.status(500).json({ error: "Database connection not established" });
    }

    const { data } = req.body;

    const result = await bulkLoadData(schoolDbConnection, data);
    return res.status(200).json(result);
  } catch (err) {
    console.error("Controller: POST /BulkLoad: Error uploading data:", err.message);
    try {
      const parsedError = JSON.parse(err.message);
      return res.status(400).json(parsedError);
    } catch (parseError) {
      return res.status(500).json({ error: "Database query error", details: err.message });
    }
  }
};

module.exports = { bulkLoadController };