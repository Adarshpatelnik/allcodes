const ApplicationListService = require('../../services/academic/applicationlist');

const getApplications = async (req, res) => {
  try {
    const applications = await ApplicationListService.getApplications();
    res.status(200).json({ data: applications });
  } catch (error) {
    console.error('Error fetching applications:', error);
    res.status(500).json({ message: 'Error fetching applications', error: error.message });
  }
};

module.exports = { getApplications };