const StudentStatusService = require('../../services/academic/applicationtracker');
const logger = require('../../logger/logger');

class StudentStatusController {
  async getApplicationStatus(req, res) {
    try {
      logger.info('Fetching application status', { appId: req.params.appId });
      const result = await StudentStatusService.getApplicationStatus(req.params.appId);
      res.status(200).json(result);
    } catch (err) {
      logger.error('Error fetching application status', { error: err.message });
      if (err.message === 'Application not found') {
        return res.status(404).json({ error: err.message });
      }
      res.status(500).json({ error: 'Database query error' });
    }
  }
}

module.exports = new StudentStatusController();