
const {
  getTeachers,
  getTeacherAssignments,
  assignClassTeacher,
  deleteTeacherAssignment,
} = require('../../services/academic/assignclassteacher');

// 📘 Get all teachers
const fetchTeachers = async (req, res) => {
  try {
    const teachers = await getTeachers();
    return res.status(200).json(teachers);
  } catch (error) {
    console.error('Controller: Error fetching teachers:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

// 📘 Get all teacher assignments
const fetchTeacherAssignments = async (req, res) => {
  try {
    const assignments = await getTeacherAssignments();
    return res.status(200).json(assignments);
  } catch (error) {
    console.error('Controller: Error fetching assignments:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

// 📘 Assign or update class teacher (no subject input required)
const updateAssignment = async (req, res) => {
  try {
    const { TEACHER_ID, CLASS_ID } = req.body;

    if (!TEACHER_ID || !CLASS_ID) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: TEACHER_ID and CLASS_ID',
      });
    }

    const [className, section] = CLASS_ID.trim().split(' ');

    if (!className || !section) {
      return res.status(400).json({
        success: false,
        error: 'Invalid CLASS_ID format. Expected format: "1 A", "UKG B", etc.',
      });
    }

    const result = await assignClassTeacher(TEACHER_ID, className, section);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Controller: Error assigning class teacher:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

// 📘 Delete all assignments for given class
const deleteAssignment = async (req, res) => {
  try {
    const { CLASS_ID } = req.body;

    if (!CLASS_ID) {
      return res.status(400).json({
        success: false,
        error: 'Missing required field: CLASS_ID',
      });
    }

    const result = await deleteTeacherAssignment(CLASS_ID);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Controller: Error deleting assignment:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

module.exports = {
  fetchTeachers,
  fetchTeacherAssignments,
  updateAssignment,
  deleteAssignment,
};

