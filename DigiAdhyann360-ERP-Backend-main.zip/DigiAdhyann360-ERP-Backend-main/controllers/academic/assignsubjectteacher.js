const logger = require('../../logger/logger');
const { getTeachers, getClasses, getSections, getSubjectsByClass, insertOrUpdateTeacherDetail, getTeacherDetails, deleteTeacherDetail } = require('../../services/academic/assignsubjectteacher');

const getTeachersController = async (req, res) => {
  try {
    logger.info('Fetching teachers');
    const teachers = await getTeachers();
    logger.info('Teachers fetched successfully');
    return res.status(200).json({ success: true, teachers });
  } catch (err) {
    logger.error('Error in getTeachersController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getClassesController = async (req, res) => {
  try {
    logger.info('Fetching classes');
    const classes = await getClasses();
    logger.info('Classes fetched successfully');
    return res.status(200).json({ success: true, classes });
  } catch (err) {
    logger.error('Error in getClassesController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getSectionsController = async (req, res) => {
  try {
    logger.info('Fetching sections');
    const sections = await getSections();
    logger.info('Sections fetched successfully');
    return res.status(200).json({ success: true, sections });
  } catch (err) {
    logger.error('Error in getSectionsController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getSubjectsController = async (req, res) => {
  const { class: selectedClass } = req.params;
  try {
    logger.info('Fetching subjects for class', { class: selectedClass });
    const subjects = await getSubjectsByClass(selectedClass);
    logger.info('Subjects fetched successfully');
    return res.status(200).json({ success: true, subjects });
  } catch (err) {
    logger.error('Error in getSubjectsController', { error: err.message });
    if (err.message.includes('Class parameter is required')) {
      return res.status(400).json({ error: err.message });
    }
    if (err.message.includes('No subjects found')) {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const insertOrUpdateTeacherDetailController = async (req, res) => {
  const teacherData = req.body;
  try {
    logger.info('Processing teacher detail', { teacherData });
    const result = await insertOrUpdateTeacherDetail(teacherData);
    logger.info('Teacher detail processed successfully', { message: result.message });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in insertOrUpdateTeacherDetailController', { error: err.message });
    if (err.message.includes('Missing required fields')) {
      return res.status(400).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getTeacherDetailsController = async (req, res) => {
  try {
    logger.info('Fetching teacher details');
    const teacherDetails = await getTeacherDetails();
    logger.info('Teacher details fetched successfully');
    return res.status(200).json({ success: true, teacherDetails });
  } catch (err) {
    logger.error('Error in getTeacherDetailsController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const deleteTeacherDetailController = async (req, res) => {
  const teacherData = req.body;
  try {
    logger.info('Deleting teacher detail', { teacherData });
    const result = await deleteTeacherDetail(teacherData);
    logger.info('Teacher detail deleted successfully', { message: result.message });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in deleteTeacherDetailController', { error: err.message });
    if (err.message.includes('Missing required fields')) {
      return res.status(400).json({ error: err.message });
    }
    if (err.message.includes('No matching teacher assignment found')) {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = {
  getTeachersController,
  getClassesController,
  getSectionsController,
  getSubjectsController,
  insertOrUpdateTeacherDetailController,
  getTeacherDetailsController,
  deleteTeacherDetailController,
};