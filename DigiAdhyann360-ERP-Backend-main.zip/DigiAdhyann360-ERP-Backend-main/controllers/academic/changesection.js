const { getAllStudents, updateStudentSection } = require('../../services/academic/changesection');
const logger = require('../../logger/logger');

// Handle GET request for all students
const getAllStudentsController = async (req, res) => {
  try {
    logger.info('Fetching all students');
    const students = await getAllStudents(); // Call service to get data
    logger.info('Students fetched successfully');
    return res.status(200).json(students); // Send data to client
  } catch (err) {
    logger.error('Error in getAllStudentsController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

// Handle PUT request to update a student's section
const updateStudentSectionController = async (req, res) => {
  const { studentId } = req.params;
  const { newSection } = req.body;

  if (!studentId || !newSection) {
    logger.warn('Missing required fields in update student section request', { studentId, newSection });
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    logger.info('Updating student section', { studentId, newSection });
    const result = await updateStudentSection(studentId, newSection); // Call service to update section
    logger.info('Student section updated successfully', { studentId });
    return res.status(200).json(result); // Send success message
  } catch (err) {
    logger.error('Error in updateStudentSectionController', { error: err.message, studentId });
    if (err.message === 'Student not found') {
      return res.status(404).json({ error: 'Student not found' });
    }
    return res.status(500).json({ error: 'Failed to update section' });
  }
};

module.exports = {
  getAllStudentsController,
  updateStudentSectionController,
};