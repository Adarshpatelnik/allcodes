const {
  getClasses,
  getSubjectsByClass,
  getSubjectNames,
  saveSubjects,
  deleteSubject,
  updateSubject,
} = require('../../services/academic/classmappingsubject');

const fetchClasses = async (req, res) => {
  try {
    const classes = await getClasses();
    return res.status(200).json({ success: true, classes });
  } catch (error) {
    console.error('Controller: Error fetching classes:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

const fetchSubjectNames = async (req, res) => {
  try {
    const { class: selectedClass } = req.query;
    const subjectNames = await getSubjectNames(selectedClass);
    return res.status(200).json({ success: true, subjectNames });
  } catch (error) {
    console.error('Controller: Error fetching subject names:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

const fetchSubjectsByClass = async (req, res) => {
  try {
    const { class: selectedClass } = req.query;
    if (!selectedClass) {
      return res.status(400).json({ success: false, error: 'class query parameter is required' });
    }
    const subjects = await getSubjectsByClass(selectedClass);
    return res.status(200).json({ success: true, subjects });
  } catch (error) {
    console.error('Controller: Error fetching subjects:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

const saveSubjectsHandler = async (req, res) => {
  try {
    const { className, addedSubjects, deletedSubjects } = req.body;
    if (!className || !Array.isArray(addedSubjects) || !Array.isArray(deletedSubjects)) {
      return res.status(400).json({ success: false, error: 'Invalid request body: className, addedSubjects, and deletedSubjects are required' });
    }
    const result = await saveSubjects(className, addedSubjects, deletedSubjects);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Controller: Error saving subjects:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

const deleteSubjectHandler = async (req, res) => {
  try {
    const { subjectCode } = req.params;
    if (!subjectCode) {
      return res.status(400).json({ success: false, error: 'subjectCode parameter is required' });
    }
    const result = await deleteSubject(subjectCode);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Controller: Error deleting subject:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

const updateSubjectHandler = async (req, res) => {
  try {
    const { subjectCode } = req.params;
    const { className, subjectName, subjectType } = req.body;
    if (!subjectCode || !className || !subjectName || !subjectType) {
      return res.status(400).json({ success: false, error: 'Invalid request: subjectCode, className, subjectName, and subjectType are required' });
    }
    const result = await updateSubject(subjectCode, { className, subjectName, subjectType });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Controller: Error updating subject:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
};

module.exports = {
  fetchClasses,
  fetchSubjectNames,
  fetchSubjectsByClass,
  saveSubjectsHandler,
  deleteSubjectHandler,
  updateSubjectHandler,
};
