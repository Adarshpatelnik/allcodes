const { body, validationResult } = require('express-validator');
const EnrollmentService = require('../../services/academic/enrollment');
const logger = require('../../logger/logger');

class EnrollmentController {
  async getApplications(req, res) {
    try {
      logger.info('Fetching student applications');
      const results = await EnrollmentService.getApplications();
      res.status(200).json({ message: 'Student data fetched successfully.', data: results });
    } catch (err) {
      logger.error('Error fetching data from ST_APPLICATION:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  async approveApplications(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation errors',
        errors: errors.array(),
      });
    }

    const { applicationId, approval_status, remarks } = req.body;

    if (!Array.isArray(applicationId) || applicationId.length === 0) {
      return res.status(400).json({ message: 'applicationId array cannot be empty' });
    }

    try {
      logger.info('Processing student approvals', { applicationId, approval_status });
      const result = await EnrollmentService.approveApplications({ applicationId, approval_status, remarks });
      res.status(200).json(result);
    } catch (err) {
      logger.error('Error in student approval:', err);
      res.status(500).json({
        success: false,
        message: 'Internal Server Error.',
      });
    }
  }

  validateApproveApplications() {
    return [
      body('applicationId').isArray().withMessage('Invalid application ID'),
      body('approval_status')
        .isIn(['APPROVED', 'REJECTED', 'PENDING'])
        .withMessage('Invalid approval status'),
    ];
  }
}

module.exports = new EnrollmentController();