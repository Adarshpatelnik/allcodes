

// backend/controllers/academic/exampattern.js
const logger = require('../../logger/logger');
const exampatternService = require('../../services/academic/exampattern');

const getExamTypes = async (req, res) => {
  try {
    const { lovId } = req.query;
    if (!lovId) {
      return res.status(400).json({ error: 'lovId parameter is required' });
    }
    const results = await exampatternService.getExamTypes(lovId);
    logger.info('Exam types fetched:', { results });
    res.json(results);
  } catch (err) {
    logger.error('Error fetching exam types:', { error: err.message });
    res.status(500).json({ error: 'Database query error' });
  }
};

const getAllExams = async (req, res) => {
  logger.info('GET /api/exams');
  try {
    const exams = await exampatternService.getAllExams();
    logger.info('Fetched exams:', { exams });
    res.status(200).json(exams);
  } catch (err) {
    logger.error('Error fetching exams:', { error: err.message });
    res.status(500).json({ error: 'Database query error' });
  }
};

const createExam = async (req, res) => {
  logger.info('POST /api/exams');
  try {
    const { name, type, startDate, endDate } = req.body;
    const newExam = await exampatternService.createExam({ name, type, startDate, endDate });
    logger.info('Exam created successfully:', { exam: newExam });
    res.status(201).json(newExam);
  } catch (err) {
    logger.error('Error creating exam:', { error: err.message });
    res.status(500).json({ error: 'Database query error' });
  }
};

const deleteExam = async (req, res) => {
  logger.info('DELETE /api/exams/:id');
  try {
    const { id } = req.params;
    const result = await exampatternService.deleteExam(id);
    logger.info('Exam deleted successfully:', { id });
    res.status(200).json(result);
  } catch (err) {
    logger.error('Error deleting exam:', { error: err.message });
    res.status(err.message === 'Exam not found' ? 404 : 500).json({ error: err.message });
  }
};

const updateExam = async (req, res) => {
  logger.info('PUT /api/exams/:id');
  try {
    const { id } = req.params;
    const { name, type, startDate, endDate } = req.body;
    const updatedExam = await exampatternService.updateExam(id, { name, type, startDate, endDate });
    logger.info('Exam updated successfully:', { exam: updatedExam });
    res.status(200).json({ message: 'Exam updated successfully', exam: updatedExam });
  } catch (err) {
    logger.error('Error updating exam:', { error: err.message });
    res.status(err.message === 'Exam not found' ? 404 : 500).json({ error: err.message });
  }
};

module.exports = {
  getExamTypes,
  getAllExams,
  createExam,
  deleteExam,
  updateExam,
};
