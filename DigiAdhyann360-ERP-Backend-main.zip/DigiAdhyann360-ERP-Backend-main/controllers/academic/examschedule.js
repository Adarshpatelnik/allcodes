
const {
  getClassesForExamSchedule,
  getSubjectsWithSchedule,
  getExamDetails,
  saveExamSchedule,
} = require('../../services/academic/examschedule');

const getClasses = async (req, res) => {
  try {
    const results = await getClassesForExamSchedule();
    res.status(200).json(results);
  } catch (err) {
    console.error('Error fetching classes in /api/getClasses:', err);
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getSubjects = async (req, res) => {
  try {
    const { class: selectedClass, examType, examName } = req.query;
    if (!selectedClass) {
      return res.status(400).json({ error: 'Class parameter is required' });
    }
    const results = await getSubjectsWithSchedule(selectedClass, examType, examName);
    res.status(200).json(results);
  } catch (err) {
    console.error('Error fetching subjects in /api/getSubjects:', err);
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getExam = async (req, res) => {
  try {
    const { examType, examName } = req.query;
    const result = await getExamDetails(examType, examName);
    if (examType && examName && !result.examStartDate) {
      return res.status(404).json({ error: 'Exam not found' });
    }
    res.status(200).json(result);
  } catch (err) {
    console.error('Error fetching exam data:', err);
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const saveExamScheduleController = async (req, res) => {
  try {
    const { studentClass, subjects, submit } = req.body;
    if (!studentClass || !subjects || !Array.isArray(subjects)) {
      return res.status(400).json({ error: 'Class and subjects array are required' });
    }
    const result = await saveExamSchedule({ studentClass, subjects, submit });
    res.status(201).json(result);
  } catch (err) {
    console.error('Error saving exam schedule:', err);
    if (err.message.includes('is required') || err.message.includes('Invalid dateTime format')) {
      return res.status(400).json({ error: err.message });
    }
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

module.exports = {
  getClasses,
  getSubjects,
  getExam,
  saveExamScheduleController,
};