const { getStudentForCertificate, getCharacterCertificateData, getAlumniStudents } = require('../../services/academic/generatecertificate');

const getStudentCertificate = async (req, res) => {
  try {
    console.log("Controller - getStudentCertificate: Fetching student...");
    const studentId = req.params.studentId;
    console.log(studentId);
    const studentdataResult = await getStudentForCertificate(studentId);
    console.log("Controller - getStudentCertificate: Retrieved student:", studentdataResult);

    if (studentdataResult.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    console.log("Controller - getStudentCertificate: generatestudent successfully.");
    return res.status(200).json(studentdataResult[0]);
  } catch (err) {
    console.error('Controller - getStudentCertificate: Error fetching generatestudent:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getCharacterCertificate = async (req, res) => {
  try {
    console.log("Controller - getCharacterCertificate: Fetching student...");
    const studentId = req.params.studentId;
    console.log("Requested Student ID:", studentId);
    const studentData = await getCharacterCertificateData(studentId);
    console.log("Controller - getCharacterCertificate: Retrieved student:", studentData);

    if (studentData.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    console.log("Controller - getCharacterCertificate: Character Certificate successfully retrieved.");
    return res.status(200).json(studentData[0]);
  } catch (err) {
    console.error('Controller - getCharacterCertificate: Error fetching Character Certificate:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getAlumniStudentsList = async (req, res) => {
  try {
    console.log("Controller - getAlumniStudentsList: /api/get-alumniStudents called");
    const getalumniResult = await getAlumniStudents();
    console.log("Controller - getAlumniStudentsList: alumniStudents fetched successfully.");
    return res.status(200).json(getalumniResult);
  } catch (err) {
    console.error('Controller - getAlumniStudentsList: Error fetching data:', err.message);
    return res.status(500).json({ error: 'Database query error' });
  }
};

module.exports = {
  getStudentCertificate,
  getCharacterCertificate,
  getAlumniStudentsList,
};