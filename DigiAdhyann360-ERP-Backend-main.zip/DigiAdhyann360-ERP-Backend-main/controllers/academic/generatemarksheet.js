const { getGenerateMarks } = require('../../services/academic/generatemarksheet');
const logger = require('../../logger/logger');
 
const getGenerateMarksController = async (req, res) => {
  logger.info('Controller: GET /api/getGenerateMarks', { query: req.query });
  try {
    const results = await getGenerateMarks();
    logger.info('Controller: Marks data fetched successfully', { count: results.length });
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Controller: Error in getGenerateMarksController', { error: err.message, stack: err.stack });
    if (err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    } else if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Error fetching marks data', details: err.message });
  }
};
 
module.exports = { getGenerateMarksController };