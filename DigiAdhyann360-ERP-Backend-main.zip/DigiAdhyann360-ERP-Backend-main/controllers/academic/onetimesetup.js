
const {
  saveConfigCode,
  saveConfigValues,
  getConfigCode,
  getConfigValues,
  deleteConfigCode,
  deleteConfigValues,
} = require('../../services/academic/onetimesetup');

const saveConfigCodeController = async (req, res) => {
  try {
    console.log('saveConfigCodeController: Request received', req.body);
    const result = await saveConfigCode(req.body);
    res.status(200).json(result);
  } catch (error) {
    console.error('saveConfigCodeController: Error:', error.message);
    res.status(500).json({ error: 'Failed to save configuration code', details: error.message });
  }
};

const saveConfigValuesController = async (req, res) => {
  try {
    console.log('saveConfigValuesController: Request received', req.body);
    const result = await saveConfigValues(req.body);
    res.status(200).json(result);
  } catch (error) {
    console.error('saveConfigValuesController: Error:', error.message);
    res.status(500).json({ error: 'Failed to save configuration values', details: error.message });
  }
};

const getConfigCodeController = async (req, res) => {
  try {
    console.log('getConfigCodeController: Request received');
    const rows = await getConfigCode();
    res.status(200).json(rows);
  } catch (error) {
    console.error('getConfigCodeController: Error:', error.message);
    res.status(500).json({ error: 'Failed to fetch configuration code', details: error.message });
  }
};

const getConfigValuesController = async (req, res) => {
  try {
    console.log('getConfigValuesController: Request received');
    const rows = await getConfigValues();
    res.status(200).json(rows);
  } catch (error) {
    console.error('getConfigValuesController: Error:', error.message);
    res.status(500).json({ error: 'Failed to fetch configuration values', details: error.message });
  }
};

const deleteConfigCodeController = async (req, res) => {
  try {
    const { lovId } = req.params;
    console.log('deleteConfigCodeController: Request received', { lovId });
    if (!lovId || isNaN(lovId)) {
      return res.status(400).json({ error: 'Invalid LOV_ID' });
    }
    const result = await deleteConfigCode(parseInt(lovId));
    res.status(200).json(result);
  } catch (error) {
    console.error('deleteConfigCodeController: Error:', error.message);
    res.status(500).json({ error: 'Failed to delete configuration code', details: error.message });
  }
};

const deleteConfigValuesController = async (req, res) => {
  try {
    const { listId } = req.params;
    console.log('deleteConfigValuesController: Request received', { listId });
    if (!listId || isNaN(listId)) {
      return res.status(400).json({ error: 'Invalid LIST_ID' });
    }
    const result = await deleteConfigValues(parseInt(listId));
    res.status(200).json(result);
  } catch (error) {
    console.error('deleteConfigValuesController: Error:', error.message);
    res.status(500).json({ error: 'Failed to delete configuration values', details: error.message });
  }
};

module.exports = {
  saveConfigCodeController,
  saveConfigValuesController,
  getConfigCodeController,
  getConfigValuesController,
  deleteConfigCodeController,
  deleteConfigValuesController,
};