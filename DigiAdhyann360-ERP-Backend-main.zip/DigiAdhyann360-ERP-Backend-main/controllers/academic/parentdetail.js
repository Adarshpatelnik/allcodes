const ParentDetailService = require('../../services/academic/parentdetail');
const logger = require('../../logger/logger');

class ParentDetailController {
  async getParentDetails(req, res) {
    const { parentId } = req.params;

    try {
      logger.info('Processing parent details retrieval', { parentId });
      const parentDetails = await ParentDetailService.getParentDetails(parentId);
      res.status(200).json(parentDetails);
    } catch (error) {
      logger.error('Error getting parent details', { error: error.message });
      if (error.message === 'Parent not found') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to retrieve parent details', details: error.message });
    }
  }

  async getAllParentProfiles(req, res) {
    try {
      logger.info('Processing all parent profiles retrieval');
      const parentProfiles = await ParentDetailService.getAllParentProfiles();
      res.status(200).json(parentProfiles);
    } catch (error) {
      logger.error('Error getting all parent profiles', { error: error.message });
      res.status(500).json({ error: 'Failed to retrieve parent profiles', details: error.message });
    }
  }

  async updateParentDetails(req, res) {
    const { parentId } = req.params;
    const updatedData = req.body;

    try {
      logger.info('Processing parent details update', { parentId });
      const result = await ParentDetailService.updateParentDetails(parentId, updatedData);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error updating parent details', { error: error.message });
      if (error.message === 'Parent not found or no changes made' || error.message === 'No valid fields provided for update') {
        return res.status(400).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update parent details', details: error.message });
    }
  }
}

module.exports = new ParentDetailController();