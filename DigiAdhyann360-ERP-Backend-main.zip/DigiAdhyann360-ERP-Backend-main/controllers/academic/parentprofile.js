// backend/controllers/academic/parentprofile.js
const { getParentProfiles } = require('../../services/academic/parentprofile');
const logger = require('../../logger/logger');

// Handle GET request for Parent profiles
const getParentProfile = async (req, res) => {
  try {
    logger.info('Fetching Parent profiles');
    const parents = await getParentProfiles(); 
    logger.info('Parent profiles fetched successfully');
    return res.status(200).json(parents); 
  } catch (err) {
    logger.error('Error in getParentProfile controller', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = { getParentProfile };