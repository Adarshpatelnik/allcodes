
const logger = require('../../logger/logger');
const gradeEntryService = require('../../services/academic/recordmarks');

const getClassesForGradeEntry = async (req, res) => {
  logger.info('GET /api/getClassesforgradeentry');
  try {
    const results = await gradeEntryService.getClassesForGradeEntry();
    logger.info('Classes fetched:', { results });
    res.json(results);
  } catch (err) {
    logger.error('Error fetching classes:', { error: err.message });
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getExamNameAndExamType = async (req, res) => {
  logger.info('GET /api/getexamnameexamtype');
  try {
    const { class: className } = req.query;
    if (!className) {
      return res.status(400).json({ error: 'Class parameter is required' });
    }
    const results = await gradeEntryService.getExamNameAndExamType(className);
    logger.info('Exam data fetched:', { results });
    res.json(results);
  } catch (err) {
    logger.error('Error fetching exam data:', { error: err.message });
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getSubjectsForGradeEntry = async (req, res) => {
  logger.info('GET /api/getSubjectsforgradeentry');
  try {
    const { class: selectedClass } = req.query;
    if (!selectedClass) {
      return res.status(400).json({ error: 'Class parameter is required' });
    }
    const results = await gradeEntryService.getSubjectsForGradeEntry(selectedClass);
    logger.info('Subjects fetched:', { results });
    res.json(results);
  } catch (err) {
    logger.error('Error fetching subjects:', { error: err.message });
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getStudentsWithClass = async (req, res) => {
  logger.info('GET /api/getStudentsWithClass');
  try {
    const { class: selectedClass } = req.query;
    if (!selectedClass) {
      return res.status(400).json({ error: 'Class parameter is required' });
    }
    const results = await gradeEntryService.getStudentsWithClass(selectedClass);
    logger.info('Students fetched:', { results });
    res.json(results);
  } catch (err) {
    logger.error('Error fetching students:', { error: err.message });
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getSavedData = async (req, res) => {
  logger.info('GET /api/getSavedData');
  try {
    const { class: className, examName, examType } = req.query;
    if (!className || !examName || !examType) {
      return res.status(400).json({ error: 'Class, examName, and examType parameters are required' });
    }
    const results = await gradeEntryService.getSavedData(className, examName, examType);
    logger.info('Saved data fetched:', { results });
    res.json(results);
  } catch (err) {
    logger.error('Error fetching saved data:', { error: err.message });
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const submitTotalMarks = async (req, res) => {
  logger.info('POST /api/submittotalmarks');
  try {
    const { CLASS, Subject, EXAM_NAME, EXAM_TYPE, TOTAL_MARKS } = req.body;
    if (!CLASS || !Subject || !EXAM_NAME || !EXAM_TYPE || !TOTAL_MARKS) {
      return res.status(400).json({ error: 'All fields are required' });
    }
    const result = await gradeEntryService.submitTotalMarks({ CLASS, Subject, EXAM_NAME, EXAM_TYPE, TOTAL_MARKS });
    logger.info('Total marks saved:', { result });
    res.status(200).json(result);
  } catch (err) {
    logger.error('Error saving total marks:', { error: err.message });
    res.status(500).json({ error: 'Failed to save total marks', details: err.message });
  }
};

const getTotalMarks = async (req, res) => {
  logger.info('GET /api/getTotalMarks');
  try {
    const { class: className, examName, examType } = req.query;
    if (!className || !examName || !examType) {
      return res.status(400).json({ error: 'Class, examName, and examType parameters are required' });
    }
    const results = await gradeEntryService.getTotalMarks(className, examName, examType);
    logger.info('Total marks fetched:', { results });
    res.json(results);
  } catch (err) {
    logger.error('Error fetching total marks:', { error: err.message });
    res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const saveGradeEntry = async (req, res) => {
  logger.info('POST /api/saveGradeEntry');
  try {
    const grades = req.body;
    if (!Array.isArray(grades) || grades.length === 0) {
      return res.status(400).json({ error: 'No grades provided' });
    }
    const result = await gradeEntryService.saveGradeEntry(grades);
    logger.info('Grade entries saved:', { result });
    res.status(200).json(result);
  } catch (err) {
    logger.error('Error saving grades:', { error: err.message });
    res.status(500).json({ error: 'Failed to save or update grade entries', details: err.message });
  }
};

const submitGradeEntry = async (req, res) => {
  logger.info('POST /api/submitGradeEntry');
  try {
    const grades = req.body;
    if (!Array.isArray(grades) || grades.length === 0) {
      return res.status(400).json({ error: 'No grades provided' });
    }
    const result = await gradeEntryService.submitGradeEntry(grades);
    logger.info('Grade entries submitted:', { result });
    res.status(200).json(result);
  } catch (err) {
    logger.error('Error submitting grades:', { error: err.message });
    res.status(500).json({ error: 'Failed to submit grade entries', details: err.message });
  }
};

module.exports = {
  getClassesForGradeEntry,
  getExamNameAndExamType,
  getSubjectsForGradeEntry,
  getStudentsWithClass,
  getSavedData,
  submitTotalMarks,
  getTotalMarks,
  saveGradeEntry,
  submitGradeEntry,
};

