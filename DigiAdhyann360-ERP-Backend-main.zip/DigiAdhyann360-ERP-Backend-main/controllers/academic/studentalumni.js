const { getAlumniStudents, promoteToAlumni } = require('../../services/academic/studentalumni');

const getAlumniStudentsList = async (req, res) => {
  try {
    console.log("Controller - getAlumniStudentsList: /api/get-alumniStudents called");
    const getalumniResult = await getAlumniStudents();
    console.log("Controller - getAlumniStudentsList: alumniStudents fetched successfully.");
    return res.status(200).json(getalumniResult);
  } catch (err) {
    console.error('Controller - getAlumniStudentsList: Error fetching data:', err.message);
    return res.status(500).json({ error: 'Database query error' });
  }
};

const promoteStudentsToAlumni = async (req, res) => {
  const { selectedStudents } = req.body;

  if (!selectedStudents || !Array.isArray(selectedStudents)) {
    return res.status(400).json({ error: "Invalid request data" });
  }

  try {
    console.log("Controller - promoteStudentsToAlumni: Promoting students...");
    const currentStudent = selectedStudents[0]; // Assuming single student for frontend compatibility
    const { promotedCount, errorCount, errors } = await promoteToAlumni(selectedStudents, currentStudent);

    if (errorCount > 0) {
      return res.status(500).json({
        message: `${promotedCount} students promoted successfully. ${errorCount} errors occurred.`,
        promotedCount,
        errorCount,
        errors,
      });
    }

    console.log("Controller - promoteStudentsToAlumni: Students promoted successfully.");
    return res.json({
      message: `${promotedCount} students promoted successfully.`,
      promotedCount,
      errorCount: 0,
    });
  } catch (err) {
    console.error("Controller - promoteStudentsToAlumni: Error promoting students:", err);
    return res.status(500).json({ error: "Internal server error", details: err.message });
  }
};

module.exports = {
  getAlumniStudentsList,
  promoteStudentsToAlumni,
};