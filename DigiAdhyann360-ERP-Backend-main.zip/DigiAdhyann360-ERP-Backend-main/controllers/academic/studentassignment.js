const { getStudentAssignmentRecords } = require('../../services/academic/studentassignment');
const logger = require('../../logger/logger');

// Handle GET request for student assignment records
const getStudentAssignmentRecord = async (req, res) => {
  try {
    logger.info('Fetching student assignment records');
    const assignments = await getStudentAssignmentRecords(); // Call service to get data
    logger.info('Student assignment records fetched successfully');
    return res.status(200).json(assignments); // Send data to client
  } catch (err) {
    logger.error('Error in getStudentAssignmentRecord controller', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = { getStudentAssignmentRecord };