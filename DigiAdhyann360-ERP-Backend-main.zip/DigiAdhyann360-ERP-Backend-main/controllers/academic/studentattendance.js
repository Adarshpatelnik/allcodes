const logger = require('../../logger/logger');
const { getClassList, getAttendanceList, submitAttendance, checkAttendanceStatus, getAttendanceCounts } = require('../../services/academic/studentattendance');

const getClassListController = async (req, res) => {
  const { staffId } = req.query;

  try {
    logger.info('Fetching class list', { staffId });
    const result = await getClassList(staffId);
    logger.info('Class list fetched successfully', { classesCount: result.classes.length, teacherClass: result.teacherClass });
    return res.status(200).json({ success: true, ...result });
  } catch (err) {
    logger.error('Error in getClassListController', { error: err.message, stack: err.stack });
    if (err.message.includes('Invalid or missing staffId')) {
      return res.status(400).json({ success: false, error: err.message });
    }
    if (err.message.includes('Unauthorized') || err.message.includes('Database connection')) {
      return res.status(503).json({ success: false, error: err.message });
    }
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
};

const getAttendanceListController = async (req, res) => {
  const { class_name: className } = req.query;

  try {
    logger.info('Fetching attendance list', { className });
    const result = await getAttendanceList(className);
    logger.info('Attendance list fetched successfully', { className, studentsCount: result.students.length });
    return res.status(200).json({ success: true, ...result });
  } catch (err) {
    logger.error('Error in getAttendanceListController', { error: err.message, stack: err.stack });
    if (err.message.includes('Invalid or missing className')) {
      return res.status(400).json({ success: false, error: err.message });
    }
    if (err.message.includes('No teacher found') || err.message.includes('No students found')) {
      return res.status(404).json({ success: false, error: err.message });
    }
    if (err.message.includes('Unauthorized') || err.message.includes('Database connection')) {
      return res.status(503).json({ success: false, error: err.message });
    }
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
};

const submitAttendanceController = async (req, res) => {
  const { class_name: className, attendanceData } = req.body;

  try {
    logger.info('Submitting attendance', { className, attendanceData });
    const result = await submitAttendance(className, attendanceData);
    logger.info('Attendance submitted successfully', { className, records: attendanceData.length });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in submitAttendanceController', { error: err.message, stack: err.stack });
    if (err.message.includes('Invalid or missing') || err.message.includes('Each attendance record must have') || err.message.includes('Invalid status value')) {
      return res.status(400).json({ success: false, error: err.message });
    }
    if (err.message.includes('Class not found')) {
      return res.status(404).json({ success: false, error: err.message });
    }
    if (err.message.includes('Attendance for this class on this date has already been submitted')) {
      return res.status(409).json({ success: false, error: err.message });
    }
    if (err.message.includes('Unauthorized') || err.message.includes('Database connection')) {
      return res.status(503).json({ success: false, error: err.message });
    }
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
};

const checkAttendanceStatusController = async (req, res) => {
  const { class_name: className, date } = req.query;

  try {
    logger.info('Checking attendance status', { className, date });
    const result = await checkAttendanceStatus(className, date);
    logger.info('Attendance status checked successfully', { className, date, isSubmitted: result.isSubmitted });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in checkAttendanceStatusController', { error: err.message, stack: err.stack });
    if (err.message.includes('Invalid or missing')) {
      return res.status(400).json({ success: false, error: err.message });
    }
    if (err.message.includes('Class not found')) {
      return res.status(404).json({ success: false, error: err.message });
    }
    if (err.message.includes('Unauthorized') || err.message.includes('Database connection')) {
      return res.status(503).json({ success: false, error: err.message });
    }
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
};

const getAttendanceCountsController = async (req, res) => {
  const { class_name: className } = req.query;

  try {
    logger.info('Fetching attendance counts', { className });
    const result = await getAttendanceCounts(className);
    logger.info('Attendance counts fetched successfully', { className, ...result });
    return res.status(200).json({ success: true, ...result });
  } catch (err) {
    logger.error('Error in getAttendanceCountsController', { error: err.message, stack: err.stack });
    if (err.message.includes('Invalid or missing className')) {
      return res.status(400).json({ success: false, error: err.message });
    }
    if (err.message.includes('Class not found')) {
      return res.status(404).json({ success: false, error: err.message });
    }
    if (err.message.includes('Unauthorized') || err.message.includes('Database connection')) {
      return res.status(503).json({ success: false, error: err.message });
    }
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
};

module.exports = { getClassListController, getAttendanceListController, submitAttendanceController, checkAttendanceStatusController, getAttendanceCountsController };