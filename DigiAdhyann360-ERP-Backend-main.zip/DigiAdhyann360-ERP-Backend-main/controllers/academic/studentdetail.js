const { getStudentProfiles, getStudentById, updateStudentById, setStudentId } = require('../../services/academic/studentdetail');

const getAllStudents = async (req, res) => {
  try {
    console.log("Controller - getAllStudents: Fetching all students...");
    const students = await getStudentProfiles();
    console.log("Controller - getAllStudents: Students fetched successfully.");
    return res.status(200).json(students);
  } catch (err) {
    console.error('Controller - getAllStudents: Error fetching students:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const getStudent = async (req, res) => {
  try {
    console.log("Controller - getStudent: Fetching student...");
    const studentId = req.params.studentId;
    console.log("Student ID:", studentId);
    const studentdataResult = await getStudentById(studentId);
    console.log("Controller - getStudent: Retrieved student:", studentdataResult);

    if (studentdataResult.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    console.log("Controller - getStudent: Student fetched successfully.");
    return res.status(200).json(studentdataResult[0]);
  } catch (err) {
    console.error('Controller - getStudent: Error fetching student:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const updateStudent = async (req, res) => {
  try {
    console.log("Controller - updateStudent: Updating student...");
    const studentId = req.params.studentId;
    const updatedData = req.body;

    const result = await updateStudentById(studentId, updatedData);
    console.log('Controller - updateStudent: Student updated successfully.');
    return res.status(200).json({ message: 'Student updated successfully' });
  } catch (err) {
    console.error('Controller - updateStudent: Error updating student:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const setStudentIdToken = async (req, res) => {
  try {
    console.log("Controller - setStudentIdToken: Setting student ID...");
    const studentId = req.params.studentId;
    const result = await setStudentId(studentId);
    console.log("Controller - setStudentIdToken: Token generated successfully.");
    return res.status(200).json(result);
  } catch (err) {
    console.error('Controller - setStudentIdToken: Error setting student ID:', err.message);
    return res.status(404).json({ error: err.message });
  }
};

module.exports = {
  getAllStudents,
  getStudent,
  updateStudent,
  setStudentIdToken,
};