// backend/controllers/academic/studentprofile.js
const { getStudentProfiles } = require('../../services/academic/Studentprofile');
const logger = require('../../logger/logger');

// Handle GET request for student profiles
const getStudentProfile = async (req, res) => {
  try {
    logger.info('Fetching student profiles');
    const students = await getStudentProfiles(); // Call service to get data
    logger.info('Student profiles fetched successfully');
    return res.status(200).json(students); // Send data to client
  } catch (err) {
    logger.error('Error in getStudentProfile controller', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = { getStudentProfile };