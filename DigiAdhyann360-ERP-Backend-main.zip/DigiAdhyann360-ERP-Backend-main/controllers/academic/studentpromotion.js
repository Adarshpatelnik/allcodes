const logger = require('../../logger/logger');
const { getPromotableStudents, promoteStudents } = require('../../services/academic/studentpromotion');

const getPromotableStudentsController = async (req, res) => {
  try {
    logger.info('Fetching promotable students');
    const students = await getPromotableStudents();
    logger.info('Promotable students fetched successfully');
    return res.status(200).json({ success: true, students });
  } catch (err) {
    logger.error('Error in getPromotableStudentsController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const promoteStudentsController = async (req, res) => {
  const { selectedStudents } = req.body;
  try {
    logger.info('Processing student promotion', { selectedStudents });
    const result = await promoteStudents(selectedStudents);
    logger.info('Students promoted successfully', { message: result.message });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in promoteStudentsController', { error: err.message });
    if (err.message.includes('Invalid request data')) {
      return res.status(400).json({ error: err.message });
    }
    if (err.message.includes('No students meet the promotion criteria')) {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = {
  getPromotableStudentsController,
  promoteStudentsController,
};