// backend/controllers/accounting/expense/budgetanalysis.js
const {
  getTotalBudget,
  getCategoryWiseTotalBudget,
} = require('../../../services/accounting/expenses/budgetanalysis');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

// Controller for fetching total budget and expenses by month
const getTotalBudgetController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const rows = await getTotalBudget(schoolDbConnection);
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error fetching budget records:', error.message);
    res.status(500).json({ error: 'Error fetching budget records: ' + error.message });
  }
};

// Controller for fetching total budget by category
const getCategoryWiseTotalBudgetController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const rows = await getCategoryWiseTotalBudget(schoolDbConnection);
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error fetching budget records:', error.message);
    res.status(500).json({ error: 'Error fetching budget records: ' + error.message });
  }
};

module.exports = {
  getTotalBudgetController,
  getCategoryWiseTotalBudgetController,
};