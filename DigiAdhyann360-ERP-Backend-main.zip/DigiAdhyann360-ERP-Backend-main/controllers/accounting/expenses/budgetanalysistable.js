// backend/controllers/accounting/expense/budgetanalysistable.js
const { getTotalBudgetTotalExpense } = require('../../../services/accounting/expenses/budgetanalysistable');

const getTotalBudgetTotalExpenseController = async (req, res) => {
  try {
    const rows = await getTotalBudgetTotalExpense();
    res.status(200).json(rows);
  } catch (error) {
    console.error('Controller error fetching budget records:', error.message);
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  getTotalBudgetTotalExpenseController,
};