const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const {
  submitAcctExpenseCategory,
  getAcctExpenseCategory,
  deleteAcctExpenseCategory,
} = require('../../../services/accounting/expenses/expensecategories');

const submitAcctExpenseCategoryController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: "Unauthorized or missing context" });
    }

    const schoolDbConnection = store.get("schoolDbConnection");

    // Check if database connection is established
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: "School database connection not established" });
    }

    // Extracting data from request body
    const { CATEGORY_ID, CATEGORY_NAME, BUDGET, DESCRIPTION } = req.body;

    console.log("Received data:", { CATEGORY_ID, CATEGORY_NAME, BUDGET, DESCRIPTION });

    // Input validation
    if (!CATEGORY_NAME || !BUDGET || !DESCRIPTION) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const result = await submitAcctExpenseCategory(schoolDbConnection, { CATEGORY_ID, CATEGORY_NAME, BUDGET, DESCRIPTION });

    if (CATEGORY_ID) {
      if (result.affectedRows === 0) {
        logger.warn('Component not found for update', { CATEGORY_ID });
        return res.status(404).json({ error: "Component not found for update" });
      }
      logger.info('Expense category updated successfully', { CATEGORY_ID });
      res.status(200).json({ message: "Expense category updated successfully" });
    } else {
      logger.info('Expense category submitted successfully', { insertId: result.insertId });
      res.status(200).json({
        message: "Expense category submitted successfully",
        id: result.insertId,
      });
    }
  } catch (error) {
    console.error("Error processing acctexpensecategory:", error.message);
    logger.error('Error processing acctexpensecategory in controller:', { error: error.message });
    res.status(500).json({ error: "Error processing acctexpensecategory: " + error.message });
  }
};

const getAcctExpenseCategoryController = async (req, res) => {
  console.log("/api/get-acctexpensecategory");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: "Unauthorized or missing context" });
    }

    const schoolDbConnection = store.get("schoolDbConnection");

    // Check database connection
    if (!schoolDbConnection) {
      console.log("/api/get-acctexpensecategory: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: "School database connection not established" });
    }

    const result = await getAcctExpenseCategory(schoolDbConnection);

    console.log("/api/get-acctexpensecategory: Data fetched successfully.");
    logger.info('Expense categories fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (err) {
    console.error("Error fetching categories:", err.message);
    logger.error('Error fetching expense categories in controller:', { error: err.message });
    res.status(500).json({ error: "Database query error: " + err.message });
  }
};

const deleteAcctExpenseCategoryController = async (req, res) => {
  console.log("/api/delete-acctexpensecategory");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: "Unauthorized or missing context" });
    }

    const schoolDbConnection = store.get("schoolDbConnection");

    // Check database connection
    if (!schoolDbConnection) {
      console.log("/api/delete-acctexpensecategory: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: "School database connection not established" });
    }

    const { id } = req.params;

    if (!id) {
      logger.warn('Missing category ID in delete request');
      return res.status(400).json({ error: "Missing category ID" });
    }

    console.log("Deleting category with ID:", id);

    const result = await deleteAcctExpenseCategory(schoolDbConnection, id);

    if (result.affectedRows === 0) {
      logger.warn('Category not found for deletion', { id });
      return res.status(404).json({ error: "Category not found" });
    }

    console.log("/api/delete-acctexpensecategory: Category deleted successfully.");
    logger.info('Category deleted successfully', { id });
    return res.status(200).json({ message: "Category deleted successfully" });
  } catch (err) {
    console.error("Error deleting category:", err.message);
    logger.error('Error deleting expense category in controller:', { error: err.message });
    res.status(500).json({ error: "Database query error: " + err.message });
  }
};

module.exports = {
  submitAcctExpenseCategoryController,
  getAcctExpenseCategoryController,
  deleteAcctExpenseCategoryController,
};