
const {
  getExpenseCategory,
  deleteExpenseCategory,
  submitExpenseCategory,
  getExpenseCategories,
} = require('../../../services/accounting/expenses/expensedetail');

const getExpenseCategoryController = async (req, res) => {
  try {
    const { month, year } = req.query;
    const rows = await getExpenseCategory(month, year);
    res.status(200).json(rows);
  } catch (error) {
    console.error('Controller error fetching expense records:', error.message);
    const status = error.message.includes('required') ? 400 : 500;
    res.status(status).json({ error: error.message });
  }
};

const deleteExpenseCategoryController = async (req, res) => {
  try {
    const { categoryId } = req.params;
    const result = await deleteExpenseCategory(categoryId);
    res.status(200).json(result);
  } catch (error) {
    console.error('Controller error deleting expense record:', error.message);
    const status = error.message.includes('not found') ? 404 : 500;
    res.status(status).json({ error: error.message });
  }
};

const submitExpenseCategoryController = async (req, res) => {
  try {
    const result = await submitExpenseCategory(req.body);
    res.status(200).json(result);
  } catch (error) {
    console.error('Controller error processing expense category:', error.message);
    const status = error.message.includes('Missing') ? 400 : error.message.includes('not found') ? 404 : 500;
    res.status(status).json({ error: error.message });
  }
};

const getExpenseCategoriesController = async (req, res) => {
  try {
    const categories = await getExpenseCategories();
    res.status(200).json(categories);
  } catch (error) {
    console.error('Controller error fetching expense categories:', error.message);
    const status = error.message.includes('required') ? 400 : 500;
    res.status(status).json({ error: error.message });
  }
};

module.exports = {
  getExpenseCategoryController,
  deleteExpenseCategoryController,
  submitExpenseCategoryController,
  getExpenseCategoriesController,
};



