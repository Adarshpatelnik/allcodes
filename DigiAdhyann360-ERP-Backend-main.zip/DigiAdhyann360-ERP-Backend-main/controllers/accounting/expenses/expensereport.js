// backend/controllers/account/expense/expensereport.js
const {
  getAcctTotalExpense,
  getAcctTotalBudgetThisMonth,
  getExpenseFromBudget,
  getAcctExpenseByCategory,
} = require('../../../services/accounting/expenses/expensereport');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

// Controller for fetching total expenses (year-to-date)
const getAcctTotalExpenseController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const rows = await getAcctTotalExpense(schoolDbConnection);
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error fetching budget records:', error.message);
    res.status(500).json({ error: 'Error fetching budget records: ' + error.message });
  }
};

// Controller for fetching total expenses for the current month
const getAcctTotalBudgetThisMonthController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const rows = await getAcctTotalBudgetThisMonth(schoolDbConnection);
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error fetching budget records:', error.message);
    res.status(500).json({ error: 'Error fetching budget records: ' + error.message });
  }
};

// Controller for fetching expense percentage relative to budget
const getExpenseFromBudgetController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const rows = await getExpenseFromBudget(schoolDbConnection);
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error fetching budget records:', error.message);
    res.status(500).json({ error: 'Error fetching budget records: ' + error.message });
  }
};

// Controller for fetching expenses by category and month
const getAcctExpenseByCategoryController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const rows = await getAcctExpenseByCategory(schoolDbConnection);
    res.status(200).json(rows);
  } catch (error) {
    console.error('Error fetching budget records:', error.message);
    res.status(500).json({ error: 'Error fetching budget records: ' + error.message });
  }
};

module.exports = {
  getAcctTotalExpenseController,
  getAcctTotalBudgetThisMonthController,
  getExpenseFromBudgetController,
  getAcctExpenseByCategoryController,
};