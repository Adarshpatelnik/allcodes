const { createCategory, getCategories, deleteCategory, updateCategory } = require('../../../services/accounting/fees/feecategories');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger'); // Fixed path

const createCategoryController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(500).json({ error: 'AsyncLocalStorage context unavailable' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const categoryData = await createCategory(schoolDbConnection, req.body);
    logger.info('Category created successfully', { categoryId: categoryData.CATEGORY_ID });
    res.status(200).json(categoryData);
  } catch (error) {
    logger.error('Error creating category', { error: error.message });
    res.status(500).json({ message: error.message || 'Error submitting category' });
  }
};

const getCategoriesController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(500).json({ error: 'AsyncLocalStorage context unavailable' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const categories = await getCategories(schoolDbConnection);
    logger.info('Categories fetched successfully', { count: categories.length });
    res.status(200).json(categories);
  } catch (error) {
    logger.error('Error fetching categories', { error: error.message });
    res.status(500).json({ message: error.message || 'Error fetching categories' });
  }
};

const deleteCategoryController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(500).json({ error: 'AsyncLocalStorage context unavailable' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const result = await deleteCategory(schoolDbConnection, req.params.id);
    logger.info('Category deleted successfully', { id: req.params.id });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error deleting category', { error: error.message });
    res.status(error.message === 'Category not found' ? 404 : 500).json({ message: error.message || 'Failed to delete category' });
  }
};

const updateCategoryController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(500).json({ error: 'AsyncLocalStorage context unavailable' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const updatedCategory = await updateCategory(schoolDbConnection, req.params.id, req.body);
    logger.info('Category updated successfully', { id: req.params.id });
    res.status(200).json(updatedCategory);
  } catch (error) {
    logger.error('Error updating category', { error: error.message });
    res.status(error.message === 'Category not found' ? 404 : 500).json({ message: error.message || 'Failed to update category' });
  }
};

module.exports = {
  createCategoryController,
  getCategoriesController,
  deleteCategoryController,
  updateCategoryController,
};