
const logger = require('../../../logger/logger');
  const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
  const {
    getClasses,
    getFrequencies,
    getStudentFeesByClassAndFrequency,
    insertFeeRecords,
    updateFeeRecord,
    deleteFeeRecord,
  } = require('../../../services/accounting/fees/feecollection');

  const getClassesController = async (req, res) => {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        logger.error('AsyncLocalStorage context unavailable');
        return res.status(403).json({ error: 'Unauthorized or missing context' });
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        return res.status(500).json({ error: 'School database connection not established' });
      }

      const classes = await getClasses(schoolDbConnection);
      logger.info('Classes fetched successfully', { count: classes.length });
      res.json({ classes });
    } catch (error) {
      logger.error('Error fetching classes in controller:', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch classes', details: error.message });
    }
  };

  const getFrequenciesController = async (req, res) => {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        logger.error('AsyncLocalStorage context unavailable');
        return res.status(403).json({ error: 'Unauthorized or missing context' });
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        return res.status(500).json({ error: 'School database connection not established' });
      }

      const frequencies = await getFrequencies(schoolDbConnection);
      logger.info('Frequencies fetched successfully', { count: frequencies.length });
      res.json({ frequencies });
    } catch (error) {
      logger.error('Error fetching frequencies in controller:', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch frequencies', details: error.message });
    }
  };

  const getStudentFeesByClassAndFrequencyController = async (req, res) => {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        logger.error('AsyncLocalStorage context unavailable');
        return res.status(403).json({ error: 'Unauthorized or missing context' });
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        return res.status(500).json({ error: 'School database connection not established' });
      }

      const { class: className, frequency } = req.params;

      if (!className?.trim() || !frequency?.trim()) {
        logger.warn('Missing required parameters');
        return res.status(400).json({ error: 'Class and Frequency are required' });
      }

      const studentFees = await getStudentFeesByClassAndFrequency(schoolDbConnection, className, frequency);
      logger.info('Student fees fetched successfully', { className, frequency, count: studentFees.length });
      res.json({ students: studentFees });
    } catch (error) {
      logger.error('Error fetching student fees in controller:', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch student fees', details: error.message });
    }
  };

  const insertFeeRecordsController = async (req, res) => {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        logger.error('AsyncLocalStorage context unavailable');
        return res.status(403).json({ error: 'Unauthorized or missing context' });
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        return res.status(500).json({ error: 'School database connection not established' });
      }

      const records = Array.isArray(req.body) ? req.body : [req.body];

      for (const record of records) {
        const {
          FREQUENCY,
          CLASS,
          STUDENT_ID,
          STUDENT_NAME,
          TOTAL_FEES,
          TOTAL_FEES_DISCOUNT,
          NET_FEES,
          STATUS,
          DUE_START_DATE,
          DUE_END_DATE,
        } = record;

        const missingFields = [];
        if (!FREQUENCY?.trim()) missingFields.push('FREQUENCY');
        if (!CLASS?.trim()) missingFields.push('CLASS');
        if (!STUDENT_ID?.trim()) missingFields.push('STUDENT_ID');
        if (!STUDENT_NAME?.trim()) missingFields.push('STUDENT_NAME');
        if (TOTAL_FEES === undefined || TOTAL_FEES === null) missingFields.push('TOTAL_FEES');
        if (NET_FEES === undefined || NET_FEES === null) missingFields.push('NET_FEES');

        if (missingFields.length > 0) {
          logger.warn('Missing required fields:', { fields: missingFields });
          return res.status(400).json({ error: `Missing required fields: ${missingFields.join(', ')}` });
        }

        const parsedTotalFees = parseFloat(TOTAL_FEES);
        const parsedDiscount = parseFloat(TOTAL_FEES_DISCOUNT || 0);
        let parsedNetFees = parseFloat(NET_FEES);

        if (isNaN(parsedTotalFees) || parsedTotalFees < 0) {
          logger.warn('Invalid total fees provided:', { totalFees: TOTAL_FEES });
          return res.status(400).json({ error: 'TOTAL_FEES must be a non-negative number' });
        }
        if (isNaN(parsedDiscount) || parsedDiscount < 0) {
          logger.warn('Invalid discount provided:', { discount: TOTAL_FEES_DISCOUNT });
          return res.status(400).json({ error: 'TOTAL_FEES_DISCOUNT must be a non-negative number' });
        }
        if (isNaN(parsedNetFees) || parsedNetFees < 0) {
          parsedNetFees = parsedTotalFees - parsedDiscount; // Auto-calculate if invalid
        }

        if (DUE_START_DATE && !/^\d{4}-\d{2}-\d{2}$/.test(DUE_START_DATE)) {
          logger.warn('Invalid DUE_START_DATE format:', { DUE_START_DATE });
          return res.status(400).json({ error: 'DUE_START_DATE must be in YYYY-MM-DD format' });
        }
        if (DUE_END_DATE && !/^\d{4}-\d{2}-\d{2}$/.test(DUE_END_DATE)) {
          logger.warn('Invalid DUE_END_DATE format:', { DUE_END_DATE });
          return res.status(400).json({ error: 'DUE_END_DATE must be in YYYY-MM-DD format' });
        }
      }

      const result = await insertFeeRecords(schoolDbConnection, records);
      logger.info('Fee records inserted successfully', { count: records.length });
      res.json(result);
    } catch (error) {
      logger.error('Error inserting fee records in controller:', { error: error.message, requestBody: req.body });
      res.status(error.message.includes('already exists') ? 400 : 500).json({ error: 'Failed to insert fee records', details: error.message });
    }
  };

  const updateFeeRecordController = async (req, res) => {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        logger.error('AsyncLocalStorage context unavailable');
        return res.status(403).json({ error: 'Unauthorized or missing context' });
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        return res.status(500).json({ error: 'School database connection not established' });
      }

      const {
        RECORD_ID,
        TOTAL_FEES_DISCOUNT,
        NET_FEES,
        STATUS,
        DUE_START_DATE,
        DUE_END_DATE,
      } = req.body;

      const missingFields = [];
      if (!RECORD_ID) missingFields.push('RECORD_ID');
      if (TOTAL_FEES_DISCOUNT === undefined || TOTAL_FEES_DISCOUNT === null) missingFields.push('TOTAL_FEES_DISCOUNT');
      if (NET_FEES === undefined || NET_FEES === null) missingFields.push('NET_FEES');
      if (!STATUS?.trim()) missingFields.push('STATUS');

      if (missingFields.length > 0) {
        logger.warn('Missing required fields:', { fields: missingFields });
        return res.status(400).json({ error: `Missing required fields: ${missingFields.join(', ')}` });
      }

      const [existingRows] = await schoolDbConnection.execute(
        'SELECT TOTAL_FEES FROM ACC_FEE_COLLECTION_STATUS WHERE RECORD_ID = ?',
        [RECORD_ID]
      );
      if (existingRows.length === 0) {
        logger.warn('Record not found:', { recordId: RECORD_ID });
        return res.status(404).json({ error: 'Record not found' });
      }
      const existingRecord = existingRows[0];
      const existingTotalFees = parseFloat(existingRecord.TOTAL_FEES) || 0;

      const parsedDiscount = parseFloat(TOTAL_FEES_DISCOUNT);
      let parsedNetFees = parseFloat(NET_FEES);

      if (isNaN(parsedDiscount) || parsedDiscount < 0) {
        logger.warn('Invalid discount provided:', { discount: TOTAL_FEES_DISCOUNT });
        return res.status(400).json({ error: 'TOTAL_FEES_DISCOUNT must be a non-negative number' });
      }
      if (isNaN(parsedNetFees) || parsedNetFees < 0) {
        parsedNetFees = existingTotalFees - parsedDiscount; // Auto-calculate if invalid
      }

      if (DUE_START_DATE && !/^\d{4}-\d{2}-\d{2}$/.test(DUE_START_DATE)) {
        logger.warn('Invalid DUE_START_DATE format:', { DUE_START_DATE });
        return res.status(400).json({ error: 'DUE_START_DATE must be in YYYY-MM-DD format' });
      }
      if (DUE_END_DATE && !/^\d{4}-\d{2}-\d{2}$/.test(DUE_END_DATE)) {
        logger.warn('Invalid DUE_END_DATE format:', { DUE_END_DATE });
        return res.status(400).json({ error: 'DUE_END_DATE must be in YYYY-MM-DD format' });
      }

      const result = await updateFeeRecord(schoolDbConnection, {
        RECORD_ID,
        TOTAL_FEES_DISCOUNT: parsedDiscount,
        NET_FEES: parsedNetFees,
        STATUS,
        DUE_START_DATE: DUE_START_DATE || null,
        DUE_END_DATE: DUE_END_DATE || null,
      });
      logger.info('Fee record updated successfully', { recordId: RECORD_ID });
      res.json(result);
    } catch (error) {
      logger.error('Error updating fee record in controller:', { error: error.message, requestBody: req.body });
      res.status(error.message.includes('not found') ? 404 : 500).json({ error: 'Failed to update fee record', details: error.message });
    }
  };

  const deleteFeeRecordController = async (req, res) => {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        logger.error('AsyncLocalStorage context unavailable');
        return res.status(403).json({ error: 'Unauthorized or missing context' });
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        return res.status(500).json({ error: 'School database connection not established' });
      }

      const { recordId } = req.params;
      if (!recordId) {
        logger.warn('Missing recordId parameter');
        return res.status(400).json({ error: 'Record ID is required' });
      }

      const result = await deleteFeeRecord(schoolDbConnection, recordId);
      logger.info('Fee record deleted successfully', { recordId });
      res.json(result);
    } catch (error) {
      logger.error('Error deleting fee record in controller:', { error: error.message });
      res.status(error.message.includes('not found') ? 404 : 500).json({ error: 'Failed to delete fee record', details: error.message });
    }
  };

  module.exports = {
    getClassesController,
    getFrequenciesController,
    getStudentFeesByClassAndFrequencyController,
    insertFeeRecordsController,
    updateFeeRecordController,
    deleteFeeRecordController,
  };