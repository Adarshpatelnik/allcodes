const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const {
  getFeeCollectionData,
  updateFeeCollectionData,
  deleteFeeCollectionData,
} = require('../../../services/accounting/fees/feemethod');

const getFeeCollectionController = async (req, res) => {
  try {
    console.log('Received GET request for /api/fee-collectiontype');
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const { collectionType, rows } = await getFeeCollectionData(schoolDbConnection);
    logger.info('Fee collection data fetched successfully', { rowCount: rows.length });

    res.json({
      COLLECTION_TYPE: collectionType,
      rows,
    });
  } catch (error) {
    logger.error('Error fetching fee collection data in controller:', { error: error.message });
    res.status(500).json({ error: `Failed to fetch fee collection data: ${error.message}` });
  }
};

const updateFeeCollectionController = async (req, res) => {
  try {
    console.log('Received POST request for /api/fee-collection:', req.body);
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const { COLLECTION_TYPE, rows } = req.body;
    if (!COLLECTION_TYPE || !rows || !Array.isArray(rows) || rows.length === 0) {
      logger.error('Invalid request body for updating fee collection:', req.body);
      return res.status(400).json({ error: 'Invalid request body: COLLECTION_TYPE and rows are required' });
    }

    const updatedRows = await updateFeeCollectionData(schoolDbConnection, { COLLECTION_TYPE, rows });
    logger.info('Fee collection data saved successfully', { rowCount: updatedRows.length });

    res.json({ message: 'Fee collection data successfully saved.', rows: updatedRows });
  } catch (error) {
    logger.error('Error saving fee collection data in controller:', { error: error.message });
    res.status(500).json({ error: `Failed to save fee collection data: ${error.message}` });
  }
};

const deleteFeeCollectionController = async (req, res) => {
  try {
    console.log('Received DELETE request for /api/fee-collection/:collectionId', req.params);
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const { collectionId } = req.params;
    if (!collectionId) {
      logger.error('Missing collectionId in request');
      return res.status(400).json({ error: 'Missing collectionId' });
    }

    const result = await deleteFeeCollectionData(schoolDbConnection, { COLLECTION_ID: collectionId });
    logger.info('Fee collection record deleted successfully', { collectionId });

    res.json(result);
  } catch (error) {
    logger.error('Error deleting fee collection data in controller:', { error: error.message });
    res.status(error.message === 'Record not found' ? 404 : 500).json({ error: error.message });
  }
};

module.exports = {
  getFeeCollectionController,
  updateFeeCollectionController,
  deleteFeeCollectionController,
};