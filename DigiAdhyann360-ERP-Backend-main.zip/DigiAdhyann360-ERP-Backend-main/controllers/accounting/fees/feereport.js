const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const { getFeeCollectionByCategory } = require('../../../services/accounting/fees/feereport');

const getFeeCollectionByCategoryController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const result = await getFeeCollectionByCategory(schoolDbConnection);
    logger.info('Fee collection data fetched successfully', { count: result.length });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error fetching fee collection data in controller:', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch fee collection data', details: error.message });
  }
};

module.exports = {
  getFeeCollectionByCategoryController,
};