

const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const {
  getClasses,
  getCategories,
  getFeeStructure,
  getCollectionTypes,
  getFrequencies,
  addFeeStructure,
  updateFeeStructure,
  deleteFeeStructureByClassFrequencyAndCollection,
} = require('../../../services/accounting/fees/feestructure');

const getClassesController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const result = await getClasses(schoolDbConnection);
    logger.info('Classes fetched successfully', { count: result.length });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error fetching classes in controller:', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch classes', details: error.message });
  }
};

const getCategoriesController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const result = await getCategories(schoolDbConnection);
    logger.info('Categories fetched successfully', { count: result.length });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error fetching categories in controller:', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch categories', details: error.message });
  }
};

const getFeeStructureController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const fees = await getFeeStructure(schoolDbConnection);
    logger.info('Fee structure fetched successfully', { count: fees.length });
    res.status(200).json(fees);
  } catch (error) {
    logger.error('Error fetching fee structure in controller:', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch fee structure', details: error.message });
  }
};

const getCollectionTypesController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const result = await getCollectionTypes(schoolDbConnection);
    logger.info('Collection types fetched successfully', { count: result.length });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error fetching collection types in controller:', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch collection types', details: error.message });
  }
};

const getFrequenciesController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
    const result = await getFrequencies(schoolDbConnection);
    logger.info('Frequencies fetched successfully', { count: result.length });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error fetching frequencies in controller:', { error: error.message });
    res.status(500).json({ error: 'Failed to fetch frequencies', details: error.message });
  }
};

const addFeeStructureController = async (req, res) => {
  const feeStructures = Array.isArray(req.body) ? req.body : [req.body];
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    for (const {
      COLLECTION_TYPE,
      FREQUENCY,
      CLASS,
      CATEGORY_NAME,
      AMOUNT,
      TOTAL_AMOUNT,
    } of feeStructures) {
      const missingFields = [];
      if (!COLLECTION_TYPE?.trim()) missingFields.push('COLLECTION_TYPE');
      if (!FREQUENCY?.trim()) missingFields.push('FREQUENCY');
      if (!CLASS?.trim()) missingFields.push('CLASS');
      if (!CATEGORY_NAME?.trim()) missingFields.push('CATEGORY_NAME');
      if (AMOUNT === undefined || AMOUNT === null) missingFields.push('AMOUNT');
      if (TOTAL_AMOUNT === undefined || TOTAL_AMOUNT === null) missingFields.push('TOTAL_AMOUNT');

      if (missingFields.length > 0) {
        logger.warn('Missing required fields:', { fields: missingFields });
        return res.status(400).json({ error: `Missing required fields: ${missingFields.join(', ')}` });
      }

      const parsedAmount = parseFloat(AMOUNT);
      const parsedTotalAmount = parseFloat(TOTAL_AMOUNT);
      if (isNaN(parsedAmount) || parsedAmount <= 0) {
        logger.warn('Invalid amount provided:', { amount: AMOUNT });
        return res.status(400).json({ error: 'AMOUNT must be a positive number' });
      }
      if (isNaN(parsedTotalAmount) || parsedTotalAmount <= 0) {
        logger.warn('Invalid total amount provided:', { totalAmount: TOTAL_AMOUNT });
        return res.status(400).json({ error: 'TOTAL_AMOUNT must be a positive number' });
      }
    }

    const insertedIds = await addFeeStructure(schoolDbConnection, feeStructures);
    logger.info('Fee structures added successfully', { insertedIds });
    res.status(201).json({ ids: insertedIds });
  } catch (error) {
    logger.error('Error adding fee structure in controller:', { error: error.message, requestBody: req.body });
    res.status(error.message.includes('already exists') ? 409 : 500).json({ error: 'Failed to add fee structure', details: error.message });
  }
};

const updateFeeStructureController = async (req, res) => {
  const feeStructures = Array.isArray(req.body) ? req.body : [req.body];
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    for (const {
      COLLECTION_TYPE,
      FREQUENCY,
      CLASS,
      CATEGORY_NAME,
      AMOUNT,
      TOTAL_AMOUNT,
    } of feeStructures) {
      const missingFields = [];
      if (!COLLECTION_TYPE?.trim()) missingFields.push('COLLECTION_TYPE');
      if (!FREQUENCY?.trim()) missingFields.push('FREQUENCY');
      if (!CLASS?.trim()) missingFields.push('CLASS');
      if (!CATEGORY_NAME?.trim()) missingFields.push('CATEGORY_NAME');
      if (AMOUNT === undefined || AMOUNT === null) missingFields.push('AMOUNT');
      if (TOTAL_AMOUNT === undefined || TOTAL_AMOUNT === null) missingFields.push('TOTAL_AMOUNT');

      if (missingFields.length > 0) {
        logger.warn('Missing required fields:', { fields: missingFields });
        return res.status(400).json({ error: `Missing required fields: ${missingFields.join(', ')}` });
      }

      const parsedAmount = parseFloat(AMOUNT);
      const parsedTotalAmount = parseFloat(TOTAL_AMOUNT);
      if (isNaN(parsedAmount) || parsedAmount <= 0) {
        logger.warn('Invalid amount provided:', { amount: AMOUNT });
        return res.status(400).json({ error: 'AMOUNT must be a positive number' });
      }
      if (isNaN(parsedTotalAmount) || parsedTotalAmount <= 0) {
        logger.warn('Invalid total amount provided:', { totalAmount: TOTAL_AMOUNT });
        return res.status(400).json({ error: 'TOTAL_AMOUNT must be a positive number' });
      }
    }

    const result = await updateFeeStructure(schoolDbConnection, feeStructures);
    logger.info('Fee structures updated successfully', { updatedIds: result.updatedIds });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error updating fee structure in controller:', { error: error.message, requestBody: req.body });
    res.status(error.message.includes('not found') ? 404 : 500).json({ error: 'Failed to update fee structure', details: error.message });
  }
};

const deleteFeeStructureByClassFrequencyAndCollectionController = async (req, res) => {
  const { class: className, frequency, collection } = req.params;
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    if (!className?.trim() || !frequency?.trim() || !collection?.trim()) {
      logger.warn('Missing required parameters');
      return res.status(400).json({ error: 'CLASS, FREQUENCY, and COLLECTION_TYPE are required' });
    }

    const result = await deleteFeeStructureByClassFrequencyAndCollection(schoolDbConnection, className, frequency, collection);
    logger.info('Fee structures deleted successfully', { className, frequency, collection, deletedCount: result.deletedCount });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error deleting fee structures in controller:', { error: error.message });
    res.status(error.message.includes('not found') ? 404 : 500).json({ error: 'Failed to delete fee structures', details: error.message });
  }
};

module.exports = {
  getClassesController,
  getCategoriesController,
  getFeeStructureController,
  getCollectionTypesController,
  getFrequenciesController,
  addFeeStructureController,
  updateFeeStructureController,
  deleteFeeStructureByClassFrequencyAndCollectionController,
};