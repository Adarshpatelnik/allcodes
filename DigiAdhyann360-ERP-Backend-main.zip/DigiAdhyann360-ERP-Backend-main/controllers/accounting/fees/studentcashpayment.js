const logger = require('../../../logger/logger');
const { getStudentPaymentDetailsById, insertFeeTransaction } = require('../../../services/accounting/fees/studentcashpayment');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const fetchStudentPaymentDetails = async (req, res) => {
  const { studentId } = req.params;

  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const result = await getStudentPaymentDetailsById(schoolDbConnection, studentId);

    logger.info('Student Payment Details fetched successfully', { count: result.length });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error in fetchStudentPaymentDetails Controller:', { error: error.message });
    res.status(500).json({
      message: 'Failed to fetch student payment details',
      error: error.message,
    });
  }
};

const submitFeeTransaction = async (req, res) => {
  const transactionData = req.body;

  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    // Basic validation
    if (!transactionData.studentId || !transactionData.studentName || 
        !transactionData.className || !transactionData.transactionDate || 
        !transactionData.amount || !transactionData.status) {
      logger.error('Missing required fields in transaction data', { transactionData });
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Validate status
    if (transactionData.status !== 'Paid') {
      logger.error('Invalid status value', { status: transactionData.status });
      return res.status(400).json({ error: 'Status must be "Paid"' });
    }

    const result = await insertFeeTransaction(schoolDbConnection, transactionData);

    logger.info('Fee transaction submitted successfully', { insertId: result.insertId });
    res.status(200).json({
      message: result.message,
      insertId: result.insertId,
    });
  } catch (error) {
    logger.error('Error in submitFeeTransaction Controller:', { error: error.message });
    res.status(500).json({
      message: 'Failed to submit fee transaction',
      error: error.message,
    });
  }
};

module.exports = {
  fetchStudentPaymentDetails,
  submitFeeTransaction,
};