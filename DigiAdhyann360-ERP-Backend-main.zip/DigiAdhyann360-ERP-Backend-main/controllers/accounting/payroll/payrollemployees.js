const logger = require('../../../logger/logger');
const {
  fetchAcctStaffDetails,
  fetchStaffById,
  updateAcctStaff,
  deleteAcctStaffDetails,
} = require('../../../services/accounting/payroll/payrollemployees');

const getAcctStaffDetails = async (req, res) => {
  try {
    logger.info('Fetching all staff details', { url: req.url });
    const staffDetails = await fetchAcctStaffDetails();
    logger.info('Staff details fetched successfully', { count: staffDetails.length });
    return res.status(200).json(staffDetails);
  } catch (error) {
    logger.error('Error in getAcctStaffDetails', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to fetch staff details', details: error.message });
  }
};

const getStaffById = async (req, res) => {
  try {
    logger.info('Fetching staff by ID', { url: req.url, body: req.body });
    const { STAFF_ID } = req.body;
    if (!STAFF_ID) {
      logger.error('STAFF_ID is required', { body: req.body });
      return res.status(400).json({ error: 'STAFF_ID is required' });
    }

    const staff = await fetchStaffById(STAFF_ID);
    if (!staff) {
      logger.warn('Staff not found', { STAFF_ID });
      return res.status(404).json({ error: 'Staff not found with provided STAFF_ID' });
    }

    logger.info('Staff fetched successfully', { STAFF_ID });
    return res.status(200).json(staff);
  } catch (error) {
    logger.error('Error in getStaffById', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to fetch staff details', details: error.message });
  }
};

const updateAcct = async (req, res) => {
  try {
    logger.info('Updating staff status', { url: req.url, params: req.params, body: req.body });
    const { id } = req.params;
    const { STATUS } = req.body;

    if (!STATUS || STATUS === '') {
      logger.error('STATUS is required', { body: req.body });
      return res.status(400).json({ error: 'STATUS is required' });
    }

    const result = await updateAcctStaff(id, { STATUS });
    if (!result) {
      logger.warn('Staff record not found', { id });
      return res.status(404).json({ error: 'Staff record not found' });
    }

    logger.info('Staff status updated successfully', { id });
    return res.status(200).json({ message: 'Staff status updated successfully' });
  } catch (error) {
    logger.error('Error in updateAcct', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to update staff status', details: error.message });
  }
};

const deleteAcctStaff = async (req, res) => {
  try {
    logger.info('Deleting staff details', { url: req.url, params: req.params });
    const { id } = req.params;

    const result = await deleteAcctStaffDetails(id);
    if (!result) {
      logger.warn('Staff record not found', { id });
      return res.status(404).json({ error: 'Staff record not found' });
    }

    logger.info('Staff details deleted successfully', { id });
    return res.status(200).json({ message: 'Staff details deleted successfully' });
  } catch (error) {
    logger.error('Error in deleteAcctStaffDetails', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to delete staff details', details: error.message });
  }
};

module.exports = {
  getAcctStaffDetails,
  getStaffById,
  updateAcct,
  deleteAcctStaff,
};