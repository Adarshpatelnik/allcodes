// const PayrollRecordStaffService = require('../../../services/accounting/payroll/payrollrecordstaff');
// const logger = require('../../../logger/logger');

// class PayrollRecordStaffController {
//   // Get dynamic salary components
//   async getDynamicSalaryComponents(req, res) {
//     try {
//       logger.info('Processing request to fetch dynamic salary components');
//       const data = await PayrollRecordStaffService.getDynamicSalaryComponents();
//       res.status(200).json(data);
//     } catch (error) {
//       logger.error('Error fetching dynamic salary components', { error: error.message });
//       res.status(500).json({
//         error: 'Failed to fetch dynamic salary components',
//         details: error.message,
//       });
//     }
//   }

//   // Get staff list for payroll
//   async getPayrollStaffList(req, res) {
//     try {
//       logger.info('Processing request to fetch staff list');
//       const staff = await PayrollRecordStaffService.getStaffList();
//       res.status(200).json(staff);
//     } catch (error) {
//       logger.error('Error fetching staff list', { error: error.message });
//       if (error.message === 'No staff found') {
//         return res.status(404).json({ message: error.message });
//       }
//       res.status(500).json({
//         error: 'Failed to fetch staff list',
//         details: error.message,
//       });
//     }
//   }

//   // Get payroll records for a specific month and year
//   async getPayrollRecords(req, res) {
//     try {
//       const { month, year } = req.query;

//       logger.info('Processing request to fetch payroll records', { month, year });

//       const records = await PayrollRecordStaffService.getPayrollRecords({ month, year });

//       res.status(200).json(records);
//     } catch (error) {
//       logger.error('Error fetching payroll records', { error: error.message });
//       if (error.message === 'Month and year are required') {
//         return res.status(400).json({ error: error.message });
//       }
//       res.status(500).json({
//         error: 'Failed to fetch payroll records',
//         details: error.message,
//       });
//     }
//   }
// }

// module.exports = new PayrollRecordStaffController();




const PayrollRecordStaffService = require('../../../services/accounting/payroll/payrollrecordstaff');

class PayrollRecordStaffController {
  async getDynamicSalaryComponents(req, res) {
    try {
      const result = await PayrollRecordStaffService.getDynamicSalaryComponents();
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getPayrollStaffList(req, res) {
    try {
      const result = await PayrollRecordStaffService.getStaffList();
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async getPayrollRecords(req, res) {
    try {
      const { month, year } = req.query;
      if (!month || !year) {
        return res.status(400).json({ error: 'Month and year are required' });
      }
      const result = await PayrollRecordStaffService.getPayrollRecords({ month, year });
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async submitPayrollRecord(req, res) {
    try {
      const payload = req.body;
      const result = await PayrollRecordStaffService.submitPayrollRecord(payload);
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}

module.exports = new PayrollRecordStaffController();