const logger = require('../../../logger/logger');
const { getStaffPayrollRecords } = require('../../../services/accounting/payroll/payrollrecordstaffview');

const getStaffPayrollRecordsController = async (req, res) => {
  try {
    const { staff_id, month, year } = req.query;

    if (!staff_id) {
      logger.warn('Staff ID is required', { query: req.query });
      return res.status(400).json({ error: 'Staff ID is required' });
    }

    const result = await getStaffPayrollRecords(staff_id, month, year);
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error in getStaffPayrollRecordsController', { error: error.message, stack: error.stack });
    if (error.message.includes('No payroll records found')) {
      return res.status(404).json({ error: error.message });
    }
    res.status(500).json({ error: 'Error fetching payroll records: ' + error.message });
  }
};

module.exports = {
  getStaffPayrollRecordsController,
};