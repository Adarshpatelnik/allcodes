const payrollService = require("../../../services/accounting/payroll/processsalary");

const getPayrollRecords = async (req, res) => {
  try {
    const { month, year } = req.query;
    if (!month || !year) {
      return res.status(400).json({ error: "Month and year are required" });
    }
    const records = await payrollService.fetchPayrollRecords(month, year, ["PENDING", "INPROGRESS"]);
    res.status(200).json(records);
  } catch (error) {
    console.error("Error fetching payroll records:", error.message);
    res.status(500).json({ error: `Error: ${error.message}` });
  }
};

const getInProgressPayrollRecords = async (req, res) => {
  try {
    const { month, year } = req.query;
    if (!month || !year) {
      return res.status(400).json({ error: "Month and year are required" });
    }
    const records = await payrollService.fetchPayrollRecords(month, year, ["INPROGRESS"]);
    res.status(200).json(records);
  } catch (error) {
    console.error("Error fetching in-progress payroll records:", error.message);
    res.status(500).json({ error: `Error: ${error.message}` });
  }
};

const getPaidPayrollRecords = async (req, res) => {
  try {
    const { month, year } = req.query;
    if (!month || !year) {
      return res.status(400).json({ error: "Month and year are required" });
    }
    const records = await payrollService.fetchPayrollRecords(month, year, ["PAID"]);
    res.status(200).json(records);
  } catch (error) {
    console.error("Error fetching paid payroll records:", error.message);
    res.status(500).json({ error: `Error: ${error.message}` });
  }
};

const updatePayrollStatus = async (req, res) => {
  try {
    const { staffIds, month, year, status } = req.body;
    if (!staffIds || !month || !year || !status) {
      return res.status(400).json({ error: "staffIds, month, year, and status are required" });
    }
    const staffIdArray = Array.isArray(staffIds) ? staffIds : [staffIds];
    if (staffIdArray.length === 0) {
      return res.status(400).json({ error: "At least one staffId is required" });
    }
    const validStatuses = ["PENDING", "INPROGRESS", "PAID"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: "Invalid status value" });
    }
    const result = await payrollService.updatePayrollStatus(staffIdArray, month, year, status);
    res.status(200).json({ message: "Payroll status updated successfully", affectedRows: result.affectedRows });
  } catch (error) {
    console.error("Error updating payroll status:", error.message);
    res.status(500).json({ error: "Error updating payroll status: " + error.message });
  }
};

const submitPayrollRecords = async (req, res) => {
  try {
    const payloads = req.body;
    if (!Array.isArray(payloads) || payloads.length === 0) {
      return res.status(400).json({ error: "Payload must be a non-empty array of records" });
    }
    for (const payload of payloads) {
      if (!payload.STAFF_ID || !payload.MONTH || !payload.YEAR) {
        return res.status(400).json({ error: "STAFF_ID, MONTH, and YEAR are required for all records" });
      }
    }
    const result = await payrollService.submitPayrollRecords(payloads);
    res.status(200).json({ message: "Payroll records updated successfully", affectedRows: result.affectedRows });
  } catch (error) {
    console.error("Error updating payroll records:", error.message);
    res.status(500).json({ error: "Error updating payroll records: " + error.message });
  }
};

module.exports = {
  getPayrollRecords,
  getInProgressPayrollRecords,
  getPaidPayrollRecords,
  updatePayrollStatus,
  submitPayrollRecords,
};