const SalaryComponentService = require('../../../services/accounting/payroll/salarycomponents');
const logger = require('../../../logger/logger');

class SalaryComponentController {
  async getSalaryComponents(req, res) {
    try {
      logger.info('Processing request to fetch salary components');
      const components = await SalaryComponentService.getSalaryComponents();
      res.status(200).json(components);
    } catch (error) {
      logger.error('Error fetching salary components', { error: error.message });
      res.status(500).json({ error: 'Failed to fetch salary components', details: error.message });
    }
  }

  async submitSalaryComponent(req, res) {
    try {
      logger.info('Processing request to submit salary component', { body: req.body });
      const result = await SalaryComponentService.submitSalaryComponent(req.body);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error submitting salary component', { error: error.message });
      if (error.message === 'Missing required fields') {
        return res.status(400).json({ error: error.message });
      }
      if (error.message === 'Component not found for update') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to submit salary component', details: error.message });
    }
  }

  async deleteSalaryComponent(req, res) {
    try {
      const { id } = req.params;
      logger.info('Processing request to delete salary component', { id });
      const result = await SalaryComponentService.deleteSalaryComponent(id);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error deleting salary component', { error: error.message });
      if (error.message === 'Missing component ID' || error.message === 'Component not found') {
        return res.status(400).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to delete salary component', details: error.message });
    }
  }
}

module.exports = new SalaryComponentController();
