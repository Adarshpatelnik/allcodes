const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const {
  getAcctGeneralLedger,
  getAcctLedger,
  getAcctExpenseCategories,
} = require('../../../services/accounting/smartledger/generalledger');

const getAcctGeneralLedgerController = async (req, res) => {
  console.log("/api/get-acctgeneralledger");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctgeneralledger: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const result = await getAcctGeneralLedger(schoolDbConnection);
    console.log("/api/get-acctgeneralledger: acctgeneralledger fetched successfully.");
    logger.info('General ledger fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching general ledger in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};


const getAcctLedgerController = async (req, res) => {
  console.log("/api/get-acctledger");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctledger: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const result = await getAcctLedger(schoolDbConnection);
    console.log("/api/get-acctledger: acctledger fetched successfully.");
    logger.info('Account ledger fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching account ledger in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};

const getAcctExpenseCategoriesController = async (req, res) => {
  console.log("/api/get-acctexpensecategories");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctexpensecategories: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    const result = await getAcctExpenseCategories(schoolDbConnection);
    console.log("/api/get-acctexpensecategories: acctexpensecategories fetched successfully.");
    logger.info('Expense categories fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching expense categories in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};

module.exports = {
  getAcctGeneralLedgerController,
  getAcctLedgerController,
  getAcctExpenseCategoriesController,
};