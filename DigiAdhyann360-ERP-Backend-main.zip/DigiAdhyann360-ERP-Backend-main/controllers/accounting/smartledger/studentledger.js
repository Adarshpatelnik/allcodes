const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const {
  getAcctGeneralLedger,
  getAcctLedger,
  getAcctExpenseCategories,
  getAcctStudentTrnsHistory,
  getAcctStudentTrnsFeeCategory,
  getAcctStudentProfile,
  getAcctClassDetail,
  getStudentClassMapping,
} = require('../../../services/accounting/smartledger/studentledger');
 
const getAcctGeneralLedgerController = async (req, res) => {
  console.log("/api/get-acctgeneralledger");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctgeneralledger: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getAcctGeneralLedger(schoolDbConnection);
    console.log("/api/get-acctgeneralledger: acctgeneralledger fetched successfully.");
    logger.info('General ledger fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching general ledger in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
const getAcctLedgerController = async (req, res) => {
  console.log("/api/get-acctledger");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctledger: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getAcctLedger(schoolDbConnection);
    console.log("/api/get-acctledger: acctledger fetched successfully.");
    logger.info('Account ledger fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching account ledger in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
const getAcctExpenseCategoriesController = async (req, res) => {
  console.log("/api/get-acctexpensecategories");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctexpensecategories: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getAcctExpenseCategories(schoolDbConnection);
    console.log("/api/get-acctexpensecategories: acctexpensecategories fetched successfully.");
    logger.info('Expense categories fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching expense categories in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
const getAcctStudentTrnsHistoryController = async (req, res) => {
  console.log("/api/get-acctstudenttrnshistory");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctstudenttrnshistory: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getAcctStudentTrnsHistory(schoolDbConnection);
    console.log("/api/get-acctstudenttrnshistory: acctstudenttrnshistory fetched successfully.");
    logger.info('Student transaction history fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching student transaction history in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
const getAcctStudentTrnsFeeCategoryController = async (req, res) => {
  console.log("/api/get-acctstudenttrnsfeecategory");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctstudenttrnsfeecategory: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getAcctStudentTrnsFeeCategory(schoolDbConnection);
    console.log("/api/get-acctstudenttrnsfeecategory: acctstudenttrnsfeecategory fetched successfully.");
    logger.info('Student transaction fee category fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching options:', error.message);
    logger.error('Error fetching student transaction fee category in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
const getAcctStudentProfileController = async (req, res) => {
  console.log("/api/get-acctstudentprofile");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctstudentprofile: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getAcctStudentProfile(schoolDbConnection);
    console.log("/api/get-acctstudentprofile: acctstudentprofile fetched successfully.");
    logger.info('Student profile fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching acctstudentprofile:', error.message);
    logger.error('Error fetching student profile in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
const getAcctClassDetailController = async (req, res) => {
  console.log("/api/get-acctclassdetail");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-acctclassdetail: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getAcctClassDetail(schoolDbConnection);
    console.log("/api/get-acctclassdetail: acctclassdetail fetched successfully.");
    logger.info('Class details fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching acctclassdetail:', error.message);
    logger.error('Error fetching class details in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
const getStudentClassMappingController = async (req, res) => {
  console.log("/api/get-student-class-mapping");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage context unavailable');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/get-student-class-mapping: School database connection not established.");
      logger.error('School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const result = await getStudentClassMapping(schoolDbConnection);
    console.log("/api/get-student-class-mapping: Student-class mapping fetched successfully.");
    logger.info('Student-class mapping fetched successfully', { count: result.length });
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching student-class mapping:', error.message);
    logger.error('Error fetching student-class mapping in controller:', { error: error.message });
    res.status(500).json({ error: 'Database query error' });
  }
};
 
module.exports = {
  getAcctGeneralLedgerController,
  getAcctLedgerController,
  getAcctExpenseCategoriesController,
  getAcctStudentTrnsHistoryController,
  getAcctStudentTrnsFeeCategoryController,
  getAcctStudentProfileController,
  getAcctClassDetailController,
  getStudentClassMappingController,
};