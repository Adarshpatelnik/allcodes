
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { getSchoolProfile, getSchoolLogo, uploadSchoolLogo, updateSchoolProfile } = require('../../services/adminprofile/schoolprofile');

const getSchoolProfileController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    const schoolDbConnection = store?.get('schoolDbConnection');
    if (!schoolDbConnection) return res.status(500).json({ error: 'DB connection not found' });

    const result = await getSchoolProfile(schoolDbConnection);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching profile', details: err.message });
  }
};

const getSchoolLogoController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    const schoolDbConnection = store?.get('schoolDbConnection');
    const udiseCode = req.udiseCode;
    if (!schoolDbConnection || !udiseCode) return res.status(400).json({ error: 'Invalid request' });

    const result = await getSchoolLogo(schoolDbConnection, udiseCode);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: 'Error fetching logo', details: err.message });
  }
};

const uploadSchoolLogoController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    const schoolDbConnection = store?.get('schoolDbConnection');
    if (!schoolDbConnection) return res.status(500).json({ error: 'DB connection not found' });

    const result = await uploadSchoolLogo(req, schoolDbConnection);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: 'Upload failed', details: err.message });
  }
};

const updateSchoolProfileController = async (req, res) => {
  try {
    const store = asyncLocalStorage.getStore();
    const schoolDbConnection = store?.get('schoolDbConnection');
    if (!schoolDbConnection) return res.status(500).json({ error: 'DB connection not found' });

    const result = await updateSchoolProfile(req);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: 'Error updating profile', details: err.message });
  }
};

module.exports = { getSchoolProfileController, getSchoolLogoController, uploadSchoolLogoController, updateSchoolProfileController };