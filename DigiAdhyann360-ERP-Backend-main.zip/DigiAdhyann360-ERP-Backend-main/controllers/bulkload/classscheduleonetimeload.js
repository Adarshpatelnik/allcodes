const { bulkLoadClassSchedule } = require('../../services/bulkload/classscheduleonetimeload');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

async function classScheduleOneTimeLoad(req, res) {
  console.log("POST /api/BulkLoadForClassSchedule");

  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      console.log("classScheduleOneTimeLoad: Unauthorized or missing context");
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    // Check database connection
    if (!schoolDbConnection) {
      console.log("classScheduleOneTimeLoad: School database connection not established.");
      return res.status(500).json({ error: "Database connection not established" });
    }

    const result = await bulkLoadClassSchedule(req, schoolDbConnection, asyncLocalStorage);
    return res.status(200).json(result);
  } catch (err) {
    console.error("classScheduleOneTimeLoad: Error:", err.message);
    return res.status(500).json({ error: err.message });
  }
}

module.exports = { classScheduleOneTimeLoad };