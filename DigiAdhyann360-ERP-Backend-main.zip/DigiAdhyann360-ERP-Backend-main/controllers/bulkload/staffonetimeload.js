const StaffBulkLoadService = require('../../services/bulkload/staffonetimeload');
const logger = require('../../logger/logger');

class StaffBulkLoadController {
  async bulkLoadStaff(req, res) {
    console.log("POST /api/StaffBulkLoad");

    try {
      const { data } = req.body;

      if (!data || !Array.isArray(data) || data.length === 0) {
        console.log("POST /StaffBulkLoad: Invalid or empty data provided.");
        return res.status(400).json({ error: "Invalid or empty data provided" });
      }

      const result = await StaffBulkLoadService.bulkLoadStaff(data);
      logger.info("POST /StaffBulkLoad: Data uploaded successfully into STAFF.");
      res.status(200).json(result);
    } catch (err) {
      logger.error("POST /StaffBulkLoad: Transaction error:", { error: err.message });
      res.status(500).json({ error: err.message });
    }
  }
}

module.exports = new StaffBulkLoadController();