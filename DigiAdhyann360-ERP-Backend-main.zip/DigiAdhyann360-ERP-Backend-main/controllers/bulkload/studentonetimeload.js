const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { bulkLoadStudents } = require('../../services/bulkload/studentonetimeload');
const { pool } = require('../../config/db'); // optional if you're not attaching pool to req

async function studentOneTimeLoad(req, res) {
  console.log("POST /api/StudentOnetimeload");

  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log("/api/StudentOnetimeload: School database connection not established.");
      return res.status(500).json({ error: "School database connection not established" });
    }

    const { data } = req.body;
    if (!data || !Array.isArray(data) || data.length === 0) {
      console.log("POST /api/StudentOnetimeload: Invalid or empty data provided.");
      return res.status(400).json({ error: "Invalid or empty data provided" });
    }

    const insertedRecords = await bulkLoadStudents(data, schoolDbConnection, pool);

    console.log("POST /api/StudentOnetimeload: Data uploaded successfully.");
    res.status(200).json({
      message: "Data uploaded successfully into STUDENT_PROFILE and related tables",
      insertedRecords
    });
  } catch (err) {
    console.error("POST /api/StudentOnetimeload: Error:", err.message, err.stack);
    res.status(500).json({ error: `Error inserting data: ${err.message}` });
  }
}

module.exports = { studentOneTimeLoad };
