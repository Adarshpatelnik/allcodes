// const { asyncLocalStorage } = require('../../middleware/authmiddleware');
// const { bulkLoadTeacherClassSubject } = require('../../services/bulkload/teachersubjectclassonetimeload');
// const mysql = require('mysql2/promise');

// async function teacherClassSubjectOneTimeLoad(req, res) {
//   console.log('POST /api/BulkLoadForTeacherClassSubject'); // Debug log
//   console.log('teacherClassSubjectOneTimeLoad: Starting request processing'); // Debug log
//   console.log('teacherClassSubjectOneTimeLoad: Request body:', JSON.stringify(req.body, null, 2)); // Debug log

//   try {
//     console.log('teacherClassSubjectOneTimeLoad: Checking AsyncLocalStorage availability'); // Debug log
//     let store;
//     try {
//       store = asyncLocalStorage.getStore();
//       console.log('teacherClassSubjectOneTimeLoad: AsyncLocalStorage store:', store ? Array.from(store.entries()) : 'Not found'); // Debug log
//     } catch (err) {
//       console.error('teacherClassSubjectOneTimeLoad: Error accessing asyncLocalStorage.getStore:', err.message, err.stack); // Debug log
//       store = null;
//     }

//     let schoolDbConnection;
//     if (!store || !store.get('schoolDbConnection')) {
//       console.warn('teacherClassSubjectOneTimeLoad: Warning: AsyncLocalStorage store or schoolDbConnection missing, creating fallback connection'); // Debug log
//       schoolDbConnection = await mysql.createPool({
//         host: process.env.DB_HOST || 'localhost',
//         user: process.env.DB_USER || 'root',
//         password: process.env.DB_PASSWORD || '',
//         database: process.env.DB_NAME || 'school_db',
//         waitForConnections: true,
//         connectionLimit: 10,
//         queueLimit: 0
//       });
//       console.log('teacherClassSubjectOneTimeLoad: Fallback schoolDbConnection created'); // Debug log
//     } else {
//       schoolDbConnection = store.get('schoolDbConnection');
//       console.log('teacherClassSubjectOneTimeLoad: SchoolDbConnection from AsyncLocalStorage:', schoolDbConnection ? 'Available' : 'Not available'); // Debug log
//     }

//     if (!schoolDbConnection) {
//       console.error('teacherClassSubjectOneTimeLoad: School database connection not established'); // Debug log
//       return res.status(500).json({ error: 'School database connection not established' });
//     }

//     console.log('teacherClassSubjectOneTimeLoad: Calling bulkLoadTeacherClassSubject service'); // Debug log
//     const result = await bulkLoadTeacherClassSubject(req, schoolDbConnection, asyncLocalStorage);

//     console.log('teacherClassSubjectOneTimeLoad: Data uploaded successfully:', result); // Debug log
//     res.status(200).json(result);
//   } catch (err) {
//     console.error('teacherClassSubjectOneTimeLoad: Error:', err.message, err.stack); // Debug log
//     res.status(500).json({ error: `Error inserting data: ${err.message}` });
//   }
// }

// module.exports = { teacherClassSubjectOneTimeLoad };



const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { bulkLoadTeacherClassSubject } = require('../../services/bulkload/teachersubjectclassonetimeload');
const { pool } = require('../../config/db'); // Shared connection pool

async function teacherClassSubjectOneTimeLoad(req, res) {
  console.log('POST /api/BulkLoadForTeacherClassSubject');

  try {
    // Check AsyncLocalStorage context
    const store = asyncLocalStorage.getStore();
    if (!store) {
      console.log('/api/BulkLoadForTeacherClassSubject: Unauthorized or missing context');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }

    // Get schoolDbConnection from AsyncLocalStorage
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log('/api/BulkLoadForTeacherClassSubject: School database connection not established');
      return res.status(500).json({ error: 'School database connection not established' });
    }

    // Validate request body
    const { data } = req.body;
    if (!data || !Array.isArray(data) || data.length === 0) {
      console.log('/api/BulkLoadForTeacherClassSubject: Invalid or empty data provided');
      return res.status(400).json({ error: 'Invalid or empty data provided' });
    }

    // Call the service with validated data
    const insertedRecords = await bulkLoadTeacherClassSubject(data, schoolDbConnection, pool);

    console.log('/api/BulkLoadForTeacherClassSubject: Data uploaded successfully');
    res.status(200).json({
      message: 'Data uploaded successfully into teacher-class-subject mappings',
      insertedRecords
    });
  } catch (err) {
    console.error('/api/BulkLoadForTeacherClassSubject: Error:', err.message, err.stack);
    res.status(500).json({ error: `Error inserting data: ${err.message}` });
  }
}

module.exports = { teacherClassSubjectOneTimeLoad };