const logger = require('../../logger/logger');
const { getClasses } = require('../../models/common/class');

const getClassesController = async (req, res) => {
  try {
    logger.info('Controller: Initiating fetch of classes for dropdown');
    const classes = await getClasses();
    return res.status(200).json(classes);
  } catch (err) {
    logger.error('Controller: Error in getClassesController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

module.exports = { getClassesController };