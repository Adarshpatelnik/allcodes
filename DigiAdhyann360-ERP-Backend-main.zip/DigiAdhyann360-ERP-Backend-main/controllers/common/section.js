const logger = require('../../logger/logger');
const { getSections } = require('../../models/common/section');

const getSectionsController = async (req, res) => {
  try {
    logger.info('Controller: Initiating fetch of sections for dropdown');
    const sections = await getSections();
    return res.status(200).json(sections);
  } catch (err) {
    logger.error('Controller: Error in getSectionsController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

module.exports = { getSectionsController };