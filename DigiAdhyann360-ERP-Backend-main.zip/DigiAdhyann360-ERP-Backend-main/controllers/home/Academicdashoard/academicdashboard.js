const { getStudentCount, getSchoolProfile, getStaffCount, getWorkingStaff } = require('../../../services/home/academicdashoard/academicdashboard');

const getStudentCountController = async (req, res) => {
  try {
    console.log("Controller: GET /api/studentcountdetails: Incoming request received");
    const result = await getStudentCount();
    res.status(200).json(result);
  } catch (error) {
    console.error("Controller: Error in getStudentCountController:", error.message);
    res.status(error.message.includes("context") || error.message.includes("store") ? 403 : 500).json({ error: error.message });
  }
};

const getSchoolProfileController = async (req, res) => {
  try {
    console.log("Controller: GET /api/SchoolProfile: Incoming request received");
    const result = await getSchoolProfile();
    res.status(200).json(result);
  } catch (error) {
    console.error("Controller: Error in getSchoolProfileController:", error.message);
    res.status(error.message.includes("context") || error.message.includes("store") ? 403 : error.message.includes("not found") ? 404 : 500).json({ error: error.message });
  }
};

const getStaffCountController = async (req, res) => {
  try {
    console.log("Controller: GET /api/staffcount: Incoming request received");
    const result = await getStaffCount();
    res.status(200).json(result);
  } catch (error) {
    console.error("Controller: Error in getStaffCountController:", error.message);
    res.status(error.message.includes("context") || error.message.includes("store") ? 403 : 500).json({ error: error.message });
  }
};

const getWorkingStaffController = async (req, res) => {
  try {
    console.log("Controller: GET /api/workingStaff: Incoming request received");
    const result = await getWorkingStaff();
    res.status(200).json(result);
  } catch (error) {
    console.error("Controller: Error in getWorkingStaffController:", error.message);
    res.status(error.message.includes("context") || error.message.includes("store") ? 403 : 500).json({ error: error.message });
  }
};

module.exports = {
  getStudentCountController,
  getSchoolProfileController,
  getStaffCountController,
  getWorkingStaffController
};