const { getEvents } = require('../../../services/home/academicdashoard/eventcalendar');
const logger = require('../../../logger/logger');

const getEventsController = async (req, res) => {
  try {
    logger.info('Fetching events');
    const events = await getEvents();
    logger.info('Events fetched successfully');
    return res.status(200).json(events);
  } catch (err) {
    logger.error('Error in getEvents controller', { error: err.message });
    return res.status(err.message === 'No events data found' ? 404 : 500).json({ error: err.message || 'Internal server error' });
  }
};

module.exports = {
  getEventsController,
};