const { getNoticeboard } = require('../../../services/home/academicdashoard/noticeboard');
const logger = require('../../../logger/logger');

const getNoticeboardController = async (req, res) => {
  try {
    logger.info('Fetching noticeboard');
    const noticeboard = await getNoticeboard();
    logger.info('Noticeboard fetched successfully');
    return res.status(200).json(noticeboard);
  } catch (err) {
    logger.error('Error in getNoticeboard controller', { error: err.message });
    return res.status(err.message === 'No noticeboard data found' ? 404 : 500).json({ error: err.message || 'Internal server error' });
  }
};

module.exports = {
  getNoticeboardController,
};