const logger = require('../../../logger/logger');
const { getAttendanceSummary } = require('../../../services/home/academicdashoard/studentattendancechart');

const getAttendanceSummaryController = async (req, res) => {
  try {
    let { filter, customStartDate, class: className, section } = req.query;
    filter = decodeURIComponent(filter?.trim() || "");
    logger.info('Controller: Initiating fetch of attendance summary', { filter, className, section });
    const attendance = await getAttendanceSummary(filter, customStartDate, className, section);
    return res.status(200).json(attendance);
  } catch (err) {
    logger.error('Controller: Error in getAttendanceSummaryController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

module.exports = { getAttendanceSummaryController };