const { getStudentAttendanceDetail } = require('../../../services/home/academicdashoard/studentattendancedetail');
const logger = require('../../../logger/logger');

const getStudentAttendanceDetailController = async (req, res) => {
  try {
    const { period } = req.query;
    logger.info('Fetching student attendance detail', { period });
    const attendanceData = await getStudentAttendanceDetail(period);
    logger.info('Student attendance detail fetched successfully', { period });
    return res.status(200).json(attendanceData);
  } catch (err) {
    logger.error('Error in getStudentAttendanceDetail controller', { error: err.message });
    return res.status(err.message === 'No student attendance detail data found' ? 404 : 500).json({ error: err.message || 'Internal server error' });
  }
};

module.exports = {
  getStudentAttendanceDetailController,
};