const { getStudentGender } = require('../../../services/home/academicdashoard/studentgendarchart');
const logger = require('../../../logger/logger');

const getStudentGenderController = async (req, res) => {
  try {
    logger.info('Fetching student gender');
    const studentGender = await getStudentGender();
    logger.info('Student gender fetched successfully');
    return res.status(200).json(studentGender);
  } catch (err) {
    logger.error('Error in getStudentGender controller', { error: err.message });
    return res.status(err.message === 'No student gender data found' ? 404 : 500).json({ error: err.message || 'Internal server error' });
  }
};

module.exports = {
  getStudentGenderController,
};