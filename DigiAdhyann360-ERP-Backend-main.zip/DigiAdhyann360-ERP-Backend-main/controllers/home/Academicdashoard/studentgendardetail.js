const studentGenderDetailService = require('../../../services/home/academicdashoard/studentgendardetail');
const logger = require('../../../logger/logger');

const studentGenderDetailController = {
  async getCasteDistribution(req, res) {
    try {
      logger.info('Fetching caste distribution');
      const students = await studentGenderDetailService.getCasteDistribution();
      logger.info('Caste distribution fetched successfully');
      return res.status(200).json(students);
    } catch (err) {
      logger.error('Error in getCasteDistribution controller', { error: err.message });
      return res.status(500).json({ error: 'Internal server error' });
    }
  },

  async getStudentDetailsByClass(req, res) {
    try {
      const { class: selectedClass } = req.query;
      logger.info(`Fetching student details for class: ${selectedClass || 'all'}`);
      const students = await studentGenderDetailService.getStudentDetailsByClass(selectedClass);
      logger.info('Student details fetched successfully');
      return res.status(200).json(students);
    } catch (err) {
      logger.error('Error in getStudentDetailsByClass controller', { error: err.message });
      return res.status(500).json({ error: 'Internal server error' });
    }
  },
};

module.exports = studentGenderDetailController;