const { getPerformanceSummary } = require('../../../services/home/academicdashoard/studentperformance');
const logger = require('../../../logger/logger');

const getPerformanceSummaryController = async (req, res) => {
  try {
    logger.info('Fetching performance summary');
    const results = await getPerformanceSummary(req.query);
    logger.info('Performance summary fetched successfully');
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Error in getPerformanceSummary controller', { error: err.message });
    return res.status(err.message === 'No performance summary data found' ? 404 : 500).json({ error: err.message || 'Internal server error' });
  }
};

module.exports = {
  getPerformanceSummaryController,
};