// backend/controllers/accounting/expense/accountdashboard.js
const {
  getTotalExpenseForDashboard,
  getFeeCollectionRateForDashboard,
} = require('../../../services/home/accountdashboard/accountdashboard');

const getTotalExpenseForDashboardController = async (req, res) => {
  try {
    const result = await getTotalExpenseForDashboard();
    res.status(200).json(result);
  } catch (error) {
    console.error('Controller error fetching total expense:', error.message);
    res.status(500).json({ error: 'Error fetching total expense', details: error.message });
  }
};

const getFeeCollectionRateForDashboardController = async (req, res) => {
  try {
    const result = await getFeeCollectionRateForDashboard();
    res.status(200).json(result);
  } catch (error) {
    console.error('Controller error fetching fee collection rate:', error.message);
    res.status(500).json({ error: 'Error fetching fee collection rate', details: error.message });
  }
};

module.exports = {
  getTotalExpenseForDashboardController,
  getFeeCollectionRateForDashboardController,
};