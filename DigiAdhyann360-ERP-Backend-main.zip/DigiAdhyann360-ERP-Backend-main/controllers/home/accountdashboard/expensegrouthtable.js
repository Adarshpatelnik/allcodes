const expenseGrouthService = require('../../../services/home/accountdashboard/expensegrouthtable');
const logger = require('../../../logger/logger');
class ExpenseGrouthController {
  async getExpenseGrouth(req, res) {
    try {
      logger.info('Processing request to fetch expense grouth data');
      const data = await expenseGrouthService.getExpenseGrouth();
      res.status(200).json(data);
    } catch (error) {
      logger.error('Error in controller while fetching expense grouth data', { error: error.message });
 if (error.message === 'Unauthorized or missing context') {
        return res.status(403).json({ error: error.message });
      }
if (error.message === 'School database connection not established') {
        return res.status(500).json({ error: error.message });}
 res.status(500).json({ error: 'Failed to fetch expense grouth data', details: error.message });
    }}}
module.exports = new ExpenseGrouthController();
