const TotalRevenueService = require('../../../services/home/accountdashboard/revenuebreakdown');
const logger = require('../../../logger/logger');

class TotalRevenueController {
  async getTotalRevenue(req, res) {
    try {
      logger.info('Processing request to fetch total revenue');
      const revenueData = await TotalRevenueService.getTotalRevenue();
      res.status(200).json(revenueData);
    } catch (error) {
      logger.error('Error fetching total revenue', { error: error.message });
      if (error.message === 'Unauthorized or missing context') {
        return res.status(403).json({ error: error.message });
      }
      if (error.message === 'School database connection not established') {
        return res.status(500).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to fetch total revenue', details: error.message });
    }
  }
}

module.exports = new TotalRevenueController();