const totalExpenseService = require('../../../services/home/accountdashboard/totalexpensetable');
const logger = require('../../../logger/logger');

class TotalExpenseController {
  async getTotalExpense(req, res) {
    try {
      logger.info('Processing request to fetch total expense');
      const expenseData = await totalExpenseService.getTotalExpense(); 
      res.status(200).json(expenseData);
    } catch (error) {
      logger.error('Error fetching total expense', { error: error.message });
if (error.message === 'Unauthorized or missing context') {
        return res.status(403).json({ error: error.message });}
if (error.message === 'School database connection not established') {
        return res.status(500).json({ error: error.message });}
res.status(500).json({
        error: 'Failed to fetch total expense',
        details: error.message,
      });}}}
module.exports = new TotalExpenseController();
