const logger = require('../../../logger/logger');
const { fetchStaffAttendance } = require('../../../services/home/hrdashboard/staffattendancechart');

const getStaffAttendance = async (req, res) => {
  try {
    logger.info('Fetching staff attendance', { url: req.url });
    const staffAttendance = await fetchStaffAttendance();
    logger.info('Staff attendance fetched successfully', { count: staffAttendance.length });
    return res.status(200).json(staffAttendance);
  } catch (error) {
    logger.error('Error in getStaffAttendance', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to fetch staff attendance', details: error.message });
  }
};

module.exports = {
  getStaffAttendance,
};