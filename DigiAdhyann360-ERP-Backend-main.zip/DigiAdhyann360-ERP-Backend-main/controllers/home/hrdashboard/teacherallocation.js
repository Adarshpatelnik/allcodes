const logger = require('../../../logger/logger');
const { fetchTeacherReassign } = require('../../../services/home/hrdashboard/teacherallocation');

const getTeacherReassign = async (req, res) => {
  try {
    logger.info('Fetching teacher reassignment', { url: req.url });
    const teacherReassign = await fetchTeacherReassign();
    logger.info('Teacher reassignment fetched successfully', { count: teacherReassign.length });
    return res.status(200).json(teacherReassign);
  } catch (error) {
    logger.error('Error in getTeacherReassign', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to fetch teacher reassignment', details: error.message });
  }
};

module.exports = {
  getTeacherReassign,
};