const StaffApprovalService = require('../../services/hr/staffapprovalstatus');
const logger = require('../../logger/logger');
const { body, validationResult } = require('express-validator');

class StaffApprovalController {
  async getPendingRegistrations(req, res) {
    try {
      logger.info('Processing fetch pending staff registrations');
      const registrations = await StaffApprovalService.getPendingRegistrations();
      res.status(200).json({ message: 'Staff data fetched successfully.', data: registrations });
    } catch (error) {
      logger.error('Error fetching pending registrations', { error: error.message });
      let errorMessage = 'Internal server error';
      if (error.message.includes('Table STAFF_REGISTRATION does not exist')) {
        errorMessage = 'Table STAFF_REGISTRATION does not exist';
      } else if (error.message.includes('Database access denied')) {
        errorMessage = 'Database access denied';
      } else if (error.message.includes('SQL query syntax error')) {
        errorMessage = 'SQL query syntax error';
      }
      res.status(500).json({ error: errorMessage, details: error.message });
    }
  }

  async processApproval(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      logger.warn('Validation errors in staff approval', { errors: errors.array() });
      return res.status(400).json({
        success: false,
        message: 'Validation errors',
        errors: errors.array(),
      });
    }

    const { applicationId, approval_status } = req.body;

    try {
      logger.info('Processing staff approval', { applicationId, approval_status });
      const result = await StaffApprovalService.processApproval(applicationId, approval_status);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error processing staff approval', { error: error.message });
      if (error.message === 'No staff found or already processed.') {
        return res.status(404).json({ success: false, message: error.message });
      }
      res.status(500).json({ error: 'Internal server error', details: error.message });
    }
  }

  // Validation middleware
  static validateApproval() {
    return [
      body('applicationId').isArray().withMessage('Application ID must be an array'),
      body('approval_status')
        .isIn(['APPROVED', 'REJECTED', 'PENDING'])
        .withMessage('Invalid approval status'),
    ];
  }
}

module.exports = StaffApprovalController;