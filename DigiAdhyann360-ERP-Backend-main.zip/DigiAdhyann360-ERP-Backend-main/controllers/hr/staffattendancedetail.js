const StaffAttendanceDetailService = require('../../services/hr/staffattendancedetail');
const logger = require('../../logger/logger');

class StaffAttendanceDetailController {
  async getAttendanceData(req, res) {
    const { period } = req.query;

    // Validate period
    const validPeriods = ['monthly', 'quarterly', 'half-yearly', 'yearly', 'all'];
    if (period && !validPeriods.includes(period)) {
      logger.warn('Invalid period provided', { period });
      return res.status(400).json({ error: 'Invalid period. Use: monthly, quarterly, half-yearly, yearly, or all' });
    }

    try {
      logger.info('Processing staff attendance data retrieval', { period });
      const attendanceData = await StaffAttendanceDetailService.getAttendanceData(period || 'all');
      res.status(200).json(attendanceData);
    } catch (error) {
      logger.error('Error getting staff attendance data', { error: error.message });
      res.status(500).json({ error: 'Failed to retrieve attendance data', details: error.message });
    }
  }
}

module.exports = new StaffAttendanceDetailController();