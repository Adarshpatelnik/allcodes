const StaffDetailService = require('../../services/hr/staffdetail');
const logger = require('../../logger/logger');

class StaffDetailController {
  async getStaffDetail(req, res) {
    const { staffId } = req.params;

    try {
      logger.info('Processing staff detail retrieval', { staffId });
      const staffDetail = await StaffDetailService.getStaffDetail(staffId);
      res.status(200).json(staffDetail);
    } catch (error) {
      logger.error('Error getting staff detail', { error: error.message, staffId });
      if (error.message === 'Staff not found') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to retrieve staff detail', details: error.message });
    }
  }

  async updateStaffDetail(req, res) {
    const { staffId } = req.params;
    const updatedData = req.body;

    try {
      logger.info('Processing staff detail update', { staffId });
      const result = await StaffDetailService.updateStaffDetail(staffId, updatedData);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error updating staff detail', { error: error.message, staffId });
      if (error.message === 'Staff not found or no changes made' || error.message === 'No valid fields provided for update') {
        return res.status(400).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update staff detail', details: error.message });
    }
  }
}

module.exports = new StaffDetailController();