const logger = require('../../logger/logger');
const { getStaffGenerateLetterData } = require('../../services/hr/staffgenerateletter');

const fetchStaffGenerateLetterData = async (req, res) => {
  try {
    logger.info('Fetching staff data for generate letter', { url: req.url });
    const staffData = await getStaffGenerateLetterData();
    return res.status(200).json(staffData);
  } catch (error) {
    logger.error('Error fetching staff data', { error: error.message, url: req.url });
    if (error.message.includes('No data found')) {
      return res.status(404).json({ message: 'No data found for the selected teachers' });
    }
    return res.status(500).json({ error: 'Failed to fetch staff data', details: error.message });
  }
};

module.exports = { fetchStaffGenerateLetterData };