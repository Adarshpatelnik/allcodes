const StaffLeaveBalanceService = require('../../services/hr/staffleavebalance');
const logger = require('../../logger/logger');

class StaffLeaveBalanceController {
  async getLeaveBalances(req, res) {
    try {
      logger.info('Processing staff leave balance retrieval');
      const leaveBalances = await StaffLeaveBalanceService.getLeaveBalances();
      res.status(200).json(leaveBalances);
    } catch (error) {
      logger.error('Error getting staff leave balances', { error: error.message });
      res.status(500).json({ error: 'Failed to retrieve leave balances', details: error.message });
    }
  }
}

module.exports = new StaffLeaveBalanceController();