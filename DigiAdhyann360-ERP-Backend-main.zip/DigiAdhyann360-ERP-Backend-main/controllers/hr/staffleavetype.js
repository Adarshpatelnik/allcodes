const StaffLeaveTypeService = require('../../services/hr/staffleavetype');
const logger = require('../../logger/logger');

class StaffLeaveTypeController {
  async getStaffRoles(req, res) {
    try {
      logger.info('Processing staff roles retrieval');
      const roles = await StaffLeaveTypeService.getStaffRoles();
      res.status(200).json(roles);
    } catch (error) {
      logger.error('Error getting staff roles', { error: error.message });
      res.status(500).json({ error: 'Failed to retrieve staff roles', details: error.message });
    }
  }

  async getLeaveData(req, res) {
    const { role } = req.query;

    try {
      logger.info('Processing leave data retrieval', { role });
      const leaveData = await StaffLeaveTypeService.getLeaveData(role);
      res.status(200).json(leaveData);
    } catch (error) {
      logger.error('Error getting leave data', { error: error.message });
      res.status(500).json({ error: 'Failed to retrieve leave data', details: error.message });
    }
  }

  async addLeaveType(req, res) {
    const { num, leaveType, maxAllowed, staffRole } = req.body;

    if (!num || !leaveType || !maxAllowed) {
      logger.warn('Missing required fields for adding leave type', { body: req.body });
      return res.status(400).json({ error: 'num, leaveType, and maxAllowed are required' });
    }

    try {
      logger.info('Processing add leave type', { num, leaveType, maxAllowed, staffRole });
      const result = await StaffLeaveTypeService.addLeaveType({ num, leaveType, maxAllowed, staffRole });
      res.status(201).json(result);
    } catch (error) {
      logger.error('Error adding leave type', { error: error.message });
      res.status(500).json({ error: 'Failed to add leave type', details: error.message });
    }
  }

  async updateLeaveType(req, res) {
    const { num } = req.params;
    const { leaveType, maxAllowed, staffRole } = req.body;

    if (!leaveType || !maxAllowed) {
      logger.warn('Missing required fields for updating leave type', { body: req.body });
      return res.status(400).json({ error: 'leaveType and maxAllowed are required' });
    }

    try {
      logger.info('Processing update leave type', { num, leaveType, maxAllowed, staffRole });
      const result = await StaffLeaveTypeService.updateLeaveType(num, { leaveType, maxAllowed, staffRole });
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error updating leave type', { error: error.message });
      if (error.message === 'Leave type not found') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update leave type', details: error.message });
    }
  }

  async deleteLeaveType(req, res) {
    const { num } = req.params;

    try {
      logger.info('Processing delete leave type', { num });
      const result = await StaffLeaveTypeService.deleteLeaveType(num);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error deleting leave type', { error: error.message });
      if (error.message === 'Leave type not found') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to delete leave type', details: error.message });
    }
  }
}

module.exports = new StaffLeaveTypeController();