const StaffProfileService = require('../../services/hr/staffprofile');
const logger = require('../../logger/logger');

class StaffProfileController {
  async getAllStaffProfiles(req, res) {
    try {
      logger.info('Processing all staff profiles retrieval');
      const staffProfiles = await StaffProfileService.getAllStaffProfiles();
      res.status(200).json(staffProfiles);
    } catch (error) {
      logger.error('Error getting staff profiles', { error: error.message });
      res.status(500).json({ error: 'Failed to retrieve staff profiles', details: error.message });
    }
  }

  async setStaffId(req, res) {
    const { staffId } = req.params;

    try {
      logger.info('Processing staff ID update', { staffId });
      const result = await StaffProfileService.setStaffId(staffId, req.user);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error setting staff ID', { error: error.message });
      if (error.message === 'Staff ID not found') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to set staff ID', details: error.message });
    }
  }
}

module.exports = new StaffProfileController();