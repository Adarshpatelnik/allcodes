const StaffRegistrationService = require('../../services/hr/staffregistrationform');
const logger = require('../../logger/logger');

class StaffRegistrationController {
  async addStaff(req, res) {
    const {
      STAFF_NAME,
      STAFF_INITIALS,
      PHONE_NUMBER,
      STAFF_ROLE,
      FATHER_HUSBAND_NAME,
      GENDER,
      EXPERIENCE,
      ADHAR_ID,
      RELIGION,
      EMAIL,
      EDUCATION,
      BLOOD_GROUP,
      DATE_OF_BIRTH,
      ADDRESS,
      CITY,
      STATE,
      POSTAL_CODE,
      MARITAL_STATUS,
    } = req.body;

    // Validate required fields
    const requiredFields = [
      'STAFF_NAME',
      'STAFF_INITIALS',
      'PHONE_NUMBER',
      'STAFF_ROLE',
      'FATHER_HUSBAND_NAME',
      'GENDER',
      'EXPERIENCE',
      'ADHAR_ID',
      'EMAIL',
      'EDUCATION',
      'BLOOD_GROUP',
      'DATE_OF_BIRTH',
    ];
    const missingFields = requiredFields.filter(
      (field) => !req.body[field] || req.body[field].toString().trim() === ''
    );
    if (missingFields.length > 0) {
      logger.warn('Missing required fields', { missingFields });
      return res.status(400).json({
        error: 'Validation failed',
        details: missingFields.reduce((acc, field) => {
          acc[field] = `${field.replace(/_/g, ' ')} is required`;
          return acc;
        }, {}),
      });
    }

    // Validate field formats and lengths
    const errors = {};

    if (STAFF_NAME.length > 100) {
      errors.STAFF_NAME = 'Staff Name must not exceed 100 characters';
    }

    const validStaffInitials = ['MR.', 'MRS.', 'MISS.', 'DR.'];
    if (!validStaffInitials.includes(STAFF_INITIALS)) {
      errors.STAFF_INITIALS = `Staff Initials must be one of: ${validStaffInitials.join(', ')}`;
    }

    if (!/^\d{10}$/.test(PHONE_NUMBER)) {
      errors.PHONE_NUMBER = 'Phone Number must be exactly 10 digits';
    }

    const validStaffRoles = [
      'PRINCIPAL',
      'TEACHER',
      'ACCOUNTANT',
      'MANAGEMENT STAFF',
      'STORE MANAGER',
      'OTHER',
      'ADMIN',
    ];
    if (!validStaffRoles.includes(STAFF_ROLE)) {
      errors.STAFF_ROLE = `Staff Role must be one of: ${validStaffRoles.join(', ')}`;
    }

    if (FATHER_HUSBAND_NAME.length > 100) {
      errors.FATHER_HUSBAND_NAME = 'Father/Husband Name must not exceed 100 characters';
    }

    const validGenders = ['MALE', 'FEMALE', 'OTHER'];
    if (!validGenders.includes(GENDER)) {
      errors.GENDER = `Gender must be one of: ${validGenders.join(', ')}`;
    }

    if (isNaN(EXPERIENCE) || EXPERIENCE < 0) {
      errors.EXPERIENCE = 'Experience must be a non-negative number';
    }

    if (!/^\d{12}$/.test(ADHAR_ID)) {
      errors.ADHAR_ID = 'Aadhaar ID must be exactly 12 digits';
    }

    const validReligions = [
      'HINDU',
      'MUSLIM',
      'CHRISTIAN',
      'SIKH',
      'BUDDHIST',
      'JAIN',
      'UNKNOWN',
      '',
    ];
    if (RELIGION && !validReligions.includes(RELIGION)) {
      errors.RELIGION = `Religion must be one of: ${validReligions.join(', ')}`;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(EMAIL)) {
      errors.EMAIL = 'Invalid email format';
    } else if (EMAIL.length > 50) {
      errors.EMAIL = 'Email must not exceed 50 characters';
    }

    const validEducations = [
      'MCA',
      'BCA',
      'B.ED',
      'M.ED',
      'B.TECH',
      'M.TECH',
      'MBA',
      'BBA',
      'BA',
      'MA',
      'PHD',
      'OTHER',
    ];
    if (!validEducations.includes(EDUCATION)) {
      errors.EDUCATION = `Education must be one of: ${validEducations.join(', ')}`;
    }

    const validBloodGroups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
    if (!validBloodGroups.includes(BLOOD_GROUP)) {
      errors.BLOOD_GROUP = `Blood Group must be one of: ${validBloodGroups.join(', ')}`;
    }

    const dob = new Date(DATE_OF_BIRTH);
    if (isNaN(dob.getTime()) || dob <= new Date('1900-01-01')) {
      errors.DATE_OF_BIRTH = 'Date of Birth must be a valid date after 1900-01-01';
    }

    if (ADDRESS && ADDRESS.length > 200) {
      errors.ADDRESS = 'Address must not exceed 200 characters';
    }

    if (CITY && CITY.length > 50) {
      errors.CITY = 'City must not exceed 50 characters';
    }

    if (STATE && STATE.length > 50) {
      errors.STATE = 'State must not exceed 50 characters';
    }

    if (POSTAL_CODE && !/^\d{6}$/.test(POSTAL_CODE)) {
      errors.POSTAL_CODE = 'Postal Code must be a 6-digit number';
    }

    if (MARITAL_STATUS && MARITAL_STATUS.length > 20) {
      errors.MARITAL_STATUS = 'Marital Status must not exceed 20 characters';
    }

    if (Object.keys(errors).length > 0) {
      logger.warn('Validation errors', { errors });
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }

    try {
      logger.info('Processing staff registration', { STAFF_NAME, STAFF_ROLE, EMAIL });
      const result = await StaffRegistrationService.addStaff(req.body);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error adding staff', { error: error.message });
      if (error.status === 400) {
        return res.status(400).json({ error: error.message, details: error.details });
      }
      res.status(500).json({ error: 'Failed to add staff', details: error.message });
    }
  }
}

module.exports = new StaffRegistrationController();