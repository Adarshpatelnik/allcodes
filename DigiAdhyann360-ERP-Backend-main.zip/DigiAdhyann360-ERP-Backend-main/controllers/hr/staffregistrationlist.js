const StaffRegistrationService = require('../../services/hr/staffregistrationlist');
const logger = require('../../logger/logger');

class StaffRegistrationController {
  async getAllStaffRegistrations(req, res) {
    try {
      logger.info('Controller: Fetching all staff registrations with all statuses');
      const registrations = await StaffRegistrationService.getAllStaffRegistrations();
      res.status(200).json({
        success: true,
        message: 'Staff registrations fetched successfully.',
        data: registrations,
      });
    } catch (error) {
      logger.error('Controller Error: Failed to fetch staff registrations', {
        error: error.message,
      });

      let errorMessage = 'Internal server error';
      if (error.message.includes('Table ACD_STAFF_REGISTRATION does not exist')) {
        errorMessage = 'Table ACD_STAFF_REGISTRATION does not exist';
      } else if (error.message.includes('Database access denied')) {
        errorMessage = 'Database access denied';
      } else if (error.message.includes('SQL query syntax error')) {
        errorMessage = 'SQL query syntax error';
      }

      res.status(500).json({
        success: false,
        error: errorMessage,
        details: error.message,
      });
    }
  }
}

module.exports = StaffRegistrationController;
