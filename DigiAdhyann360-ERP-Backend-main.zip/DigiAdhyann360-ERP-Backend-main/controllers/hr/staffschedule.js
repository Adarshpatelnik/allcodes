const StaffScheduleService = require('../../services/hr/staffschedule');
const logger = require('../../logger/logger');

class StaffScheduleController {
  async deleteSchedule(req, res) {
    const { PERIOD, CLASS, SECTION } = req.body;

    if (!PERIOD || !CLASS || !SECTION) {
      logger.warn('Missing required fields for schedule deletion', { body: req.body });
      return res.status(400).json({ error: 'PERIOD, CLASS, and SECTION are required' });
    }

    try {
      logger.info('Processing schedule deletion', { period: PERIOD, class: CLASS, section: SECTION });
      const result = await StaffScheduleService.deleteSchedule(PERIOD, CLASS, SECTION);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error deleting schedule', { error: error.message });
      if (error.message === 'No schedule found to delete') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to delete schedule', details: error.message });
    }
  }

  async upsertSchedule(req, res) {
    const { PERIOD, TIME_SLOT, CLASS, SECTION, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, DURATION } = req.body;

    if (!PERIOD || !CLASS || !SECTION || !TIME_SLOT || !DURATION) {
      logger.warn('Missing required fields for schedule upsert', { body: req.body });
      return res.status(400).json({ error: 'PERIOD, TIME_SLOT, DURATION, CLASS, and SECTION are required' });
    }

    if (!Monday && !Tuesday && !Wednesday && !Thursday && !Friday && !Saturday) {
      logger.warn('No day subjects provided for schedule upsert', { body: req.body });
      return res.status(400).json({ error: 'At least one day subject is required' });
    }

    try {
      logger.info('Processing schedule upsert', { period: PERIOD, class: CLASS, section: SECTION });
      const result = await StaffScheduleService.upsertSchedule(req.body);
      res.status(200).json(result);
    } catch (error) {
      logger.error('Error upserting schedule', { error: error.message });
      if (error.message === 'No valid day subjects provided') {
        return res.status(400).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to update schedule', details: error.message });
    }
  }

  async getClassSections(req, res) {
    try {
      logger.info('Processing class and section retrieval');
      const classSections = await StaffScheduleService.getClassSections();
      res.status(200).json(classSections);
    } catch (error) {
      logger.error('Error getting class sections', { error: error.message });
      if (error.message === 'No class and section data found') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to retrieve class sections', details: error.message });
    }
  }

  async getScheduleData(req, res) {
    const { class: selectedClasses, section: selectedSections } = req.query;

    try {
      logger.info('Processing schedule data retrieval', { classes: selectedClasses, sections: selectedSections });
      const scheduleData = await StaffScheduleService.getScheduleData(selectedClasses, selectedSections);
      res.status(200).json(scheduleData);
    } catch (error) {
      logger.error('Error getting schedule data', { error: error.message });
      if (error.message === 'No schedule data found for the selected classes and sections') {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to retrieve schedule data', details: error.message });
    }
  }
}

module.exports = new StaffScheduleController();