// ==============================================login=======================================================

const logger = require('../../logger/logger');
const { loginUser, developerLogin } = require('../../services/login/login');

const loginUserController = async (req, res) => {
  try {
    logger.info('Controller: Initiating user login', { body: req.body });
    const { UserName, Password } = req.body;
    const result = await loginUser({ UserName, Password });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Controller: Error in loginUserController', { error: err.message });
    if (err.message === 'Username and Password are required') {
      return res.status(400).json({ error: err.message });
    }
    if (err.message === 'Username or Email not registered') {
      return res.status(401).json({ error: err.message });
    }
    if (err.message === 'Invalid Password') {
      return res.status(401).json({ error: err.message });
    }
    if (err.message === 'School database not found') {
      return res.status(404).json({ error: err.message });
    }
    if (err.message.includes('Database query error') || err.message.includes('Database connection failed') || err.message.includes('Database access denied')) {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

const developerLoginController = async (req, res) => {
  try {
    logger.info('Controller: Initiating developer login', { body: req.body });
    const { school } = req.body;
    const result = await developerLogin({ school });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Controller: Error in developerLoginController', { error: err.message });
    if (err.message === 'School database credentials not found') {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

module.exports = { loginUserController, developerLoginController };