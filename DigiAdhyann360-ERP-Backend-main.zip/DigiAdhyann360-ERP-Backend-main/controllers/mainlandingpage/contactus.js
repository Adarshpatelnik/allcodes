const contactService = require('../../services/mainlandingpage/contactus');
const logger = require('../../logger/logger');

const createContact = async (req, res) => {
  logger.info("Controller: POST /api/contact", { body: req.body });
  try {
    const { fullName, email, phoneNumber, schoolName, schoolAddress } = req.body;
    const result = await contactService.createContact({ fullName, email, phoneNumber, schoolName, schoolAddress });
    res.status(201).json(result);
  } catch (error) {
    logger.error("Controller: Error creating contact", { error: error.message, stack: error.stack });
    if (error.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: error.message });
    } else if (error.message === "School database connection not established") {
      return res.status(500).json({ error: error.message });
    } else if (error.message === "All fields are required") {
      return res.status(400).json({ error: error.message });
    }
    return res.status(500).json({ error: "Failed to create contact", details: error.message });
  }
};

module.exports = {
  createContact,
};