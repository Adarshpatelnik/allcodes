const adminNotificationService = require('../../services/notification/adminnotification');

const getStaffNotification = async (req, res) => {
  try {
    const result = await adminNotificationService.getStaffNotification();
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getLeaveRequests = async (req, res) => {
  try {
    const result = await adminNotificationService.getLeaveRequests();
    res.status(200).json(result);
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
};

const getParentRaiseIssueCount = async (req, res) => {
  console.log("Controller: GET /api/getparentraiseissuecount");
  try {
    const results = await adminNotificationService.getParentRaiseIssueCount();
    return res.status(200).json(results);
  } catch (error) {
    console.error("Controller: Error fetching leave data:", error);
    return res.status(500).json({ error: "Failed to fetch leave data", details: error.message });
  }
};

const getStudentEditRequestCount = async (req, res) => {
  console.error("Controller: studenteditrequestcount call");
  try {
    const results = await adminNotificationService.getStudentEditRequestCount();
    res.json(results);
  } catch (error) {
    console.error('Controller: Error fetching student edit request:', error);
    res.status(500).send('Server error');
  }
};

module.exports = {
  getStaffNotification,
  getLeaveRequests,
  getParentRaiseIssueCount,
  getStudentEditRequestCount,
};