const raisedIssuesService = require('../../services/notification/raisedissues');

const getRaiseIssueList = async (req, res) => {
  console.log("Controller: GET /api/getraiseissuelist");
  try {
    const results = await raisedIssuesService.getRaiseIssueList();
    return res.status(200).json(results);
  } catch (error) {
    console.error("Controller: Error fetching leave data:", error);
    return res.status(500).json({ error: "Failed to fetch leave data", details: error.message });
  }
};

const updateRaiseIssueStatus = async (req, res) => {
  console.log("Controller: POST /api/updateraiseissuelist");
  const { student_id, status } = req.body;

  if (!student_id || !status) {
    return res.status(400).json({ error: "student_id and status are required" });
  }

  try {
    await raisedIssuesService.updateRaiseIssueStatus(student_id, status);
    return res.status(200).json({ message: "Status updated successfully" });
  } catch (error) {
    console.error("Controller: Error updating issue status:", error);
    return res.status(500).json({ error: "Failed to update issue status" });
  }
};

module.exports = {
  getRaiseIssueList,
  updateRaiseIssueStatus,
};