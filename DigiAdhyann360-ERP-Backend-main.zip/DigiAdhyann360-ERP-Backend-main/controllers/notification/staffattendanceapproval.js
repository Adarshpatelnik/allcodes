const staffAttendanceService = require('../../services/notification/staffattendanceapproval');

const getStaffAttendanceApproval = async (req, res) => {
  console.log("Controller: GET /api/getstaffattendanceapproval");
  try {
    const results = await staffAttendanceService.getStaffAttendanceApproval();
    return res.status(200).json(results);
  } catch (error) {
    console.error("Controller: Error fetching attendance data:", error);
    return res.status(500).json({ error: "Database query error", details: error.message });
  }
};

const getStaffLeaveApproval = async (req, res) => {
  console.log("Controller: GET /api/getstaffleaveapproval");
  try {
    const results = await staffAttendanceService.getStaffLeaveApproval();
    return res.status(200).json(results);
  } catch (error) {
    console.error("Controller: Error fetching leave data:", error);
    return res.status(500).json({ error: "Failed to fetch leave data", details: error.message });
  }
};

const updateStaffAttendanceApproval = async (req, res) => {
  console.log("Controller: POST /api/updatestaffattendanceapproval");
  const { staff_id, status } = req.body;

  if (!staff_id || !status) {
    return res.status(400).json({ error: "Staff ID and status are required" });
  }

  try {
    await staffAttendanceService.updateStaffAttendanceApproval(staff_id, status);
    return res.status(200).json({ message: "Status updated successfully" });
  } catch (error) {
    console.error("Controller: Error updating attendance status:", error);
    return res.status(500).json({ error: "Failed to update attendance status" });
  }
};

const updateStaffLeaveApproval = async (req, res) => {
  console.log("Controller: POST /api/updatestaffleaveapproval");
  const { staff_id, status } = req.body;

  if (!staff_id || !['APPROVED', 'REJECTED'].includes(status)) {
    console.log("Controller: Invalid staff_id or status provided.");
    return res.status(400).json({ error: 'Valid staff_id and status (APPROVED or REJECTED) are required' });
  }

  try {
    const result = await staffAttendanceService.updateStaffLeaveApproval(staff_id, status);
    return res.status(200).json(result);
  } catch (error) {
    console.error("Controller: Error updating leave status:", error);
    return res.status(500).json({ error: "Database query error" });
  }
};

module.exports = {
  getStaffAttendanceApproval,
  getStaffLeaveApproval,
  updateStaffAttendanceApproval,
  updateStaffLeaveApproval,
};