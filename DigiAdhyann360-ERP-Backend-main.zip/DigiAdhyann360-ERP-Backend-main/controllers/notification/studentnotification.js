const studentNotificationService = require('../../services/notification/studentnotification');

const getStudentData = async (req, res) => {
  console.log("Controller: GET /api/student-data");
  try {
    const rows = await studentNotificationService.getStudentData();
    res.json(rows);
  } catch (error) {
    console.error('Controller: Error fetching student data:', error);
    res.status(500).json({ message: 'Error fetching student data', error });
  }
};

const updateStatus = async (req, res) => {
  console.log("Controller: POST /api/update-status");
  const { REQUEST_ID, STATUS } = req.body;

  try {
    const result = await studentNotificationService.updateStatus(REQUEST_ID, STATUS);
    if (result.affectedRows > 0) {
      res.status(200).send('Status updated successfully');
    } else {
      console.log('Controller: Request not found for REQUEST_ID:', REQUEST_ID);
      res.status(404).send('Request not found');
    }
  } catch (error) {
    console.error('Controller: Error updating status:', error);
    res.status(500).send('Server error');
  }
};

const updateStudentProfile = async (req, res) => {
  console.log("Controller: POST /api/update-student-profile");
  const { REQUESTER_ID } = req.body;

  try {
    const result = await studentNotificationService.updateStudentProfile(REQUESTER_ID);
    if (result.affectedRows > 0) {
      res.status(200).send('Student profile updated successfully');
    } else {
      res.status(404).send('No profile found for the provided REQUESTER_ID');
    }
  } catch (error) {
    console.error('Controller: Error updating student profile:', error);
    res.status(500).send('Server error');
  }
};

module.exports = {
  getStudentData,
  updateStatus,
  updateStudentProfile,
};