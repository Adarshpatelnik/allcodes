const { createRazorpayOrder, verifyPaymentSignature, savePaymentDetails } = require('../../services/payment/razorpay');

const createRazorpayOrderController = async (req, res) => {
  try {
    console.log('Controller: POST /api/create-razorpay-order', req.body);
    const { Payload } = req.body;

    if (!Payload) {
      console.log('Controller: Missing Payload');
      return res.status(400).json({ error: 'Payload is required' });
    }

    const order = await createRazorpayOrder(Payload);
    console.log('Controller: Razorpay order created successfully:', order);
    return res.status(200).json(order);
  } catch (error) {
    console.error('Controller: Error creating Razorpay order:', error.message);
    return res.status(500).json({ error: error.message });
  }
};

const verifyRazorpaySignatureController = async (req, res) => {
  try {
    console.log('Controller: POST /api/verify-razorpay-signature', req.body);
    const { Payload } = req.body;

    if (!Payload) {
      console.log('Controller: Missing Payload');
      return res.status(400).json({ error: 'Payload is required' });
    }

    const { isValid, decryptedPayload } = await verifyPaymentSignature(Payload);

    if (isValid) {
      console.log('Controller: Payment verified successfully');
      const paymentResult = await savePaymentDetails(Payload);
      return res.status(200).json({ message: 'Payment verified successfully', payment: paymentResult.data, tenantId: paymentResult.tenantId });
    } else {
      console.log('Controller: Invalid signature');
      return res.status(400).json({ error: 'Invalid signature' });
    }
  } catch (error) {
    console.error('Controller: Error verifying Razorpay signature:', error.message);
    return res.status(500).json({ error: error.message });
  }
};

const savePaymentController = async (req, res) => {
  try {
    console.log('Controller: POST /api/save-payment', req.body);
    const { Payload } = req.body;

    if (!Payload) {
      console.log('Controller: Missing Payload');
      return res.status(400).json({ error: 'Payload is required' });
    }

    const paymentResult = await savePaymentDetails(Payload);
    console.log('Controller: Payment saved successfully');
    return res.status(200).json({
      message: 'Payment saved successfully',
      payment: paymentResult.data,
      tenantId: paymentResult.tenantId,
    });
  } catch (error) {
    console.error('Controller: Error saving payment:', error.message);
    return res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createRazorpayOrderController,
  verifyRazorpaySignatureController,
  savePaymentController,
};