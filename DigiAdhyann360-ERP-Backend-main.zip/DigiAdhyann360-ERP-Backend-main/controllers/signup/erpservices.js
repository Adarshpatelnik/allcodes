const { getServices, addTenantService } = require('../../services/signup/erpservices');
const { validateCoupon } = require('../../services/payment/razorpay');

const getServicesController = async (req, res) => {
  try {
    console.log('Controller: GET /api/get-services: Incoming request received');
    const services = await getServices();
    res.status(200).json(services);
  } catch (error) {
    console.error('Controller: Error in getServicesController:', error);
    res.status(error.message === 'No services data found' ? 404 : 500).json({ error: error.message });
  }
};

const addTenantServiceController = async (req, res) => {
  try {
    console.log('Controller: POST /api/add-tenant-service: Received body:', req.body);
    const { Payload } = req.body;

    if (!Payload) {
      console.log('Controller: Missing Payload');
      return res.status(400).json({ error: 'Payload is required' });
    }

    const result = await addTenantService(Payload);
    console.log('Controller: Tenant service added successfully:', result);
    res.status(200).json(result);
  } catch (error) {
    console.error('Controller: Error in addTenantServiceController:', error.message);
    res.status(error.message.includes('required') || error.message.includes('not found') ? 400 : 500).json({ error: error.message });
  }
};

const validateCouponController = async (req, res) => {
  try {
    console.log('Controller: POST /api/validate-coupon: Received body:', req.body);
    const { couponCode, serviceIds } = req.body;

    if (!couponCode) {
      console.log('Controller: Missing couponCode');
      return res.status(400).json({ error: 'couponCode is required' });
    }

    const coupon = await validateCoupon(couponCode, serviceIds);
    res.status(200).json(coupon);
  } catch (error) {
    console.error('Controller: Error in validateCouponController:', error.message);
    res.status(error.message.includes('invalid') || error.message.includes('expired') || error.message.includes('usage limit') ? 400 : 500).json({ error: error.message });
  }
};

module.exports = {
  getServicesController,
  addTenantServiceController,
  validateCouponController,
};