const { getLatestSchool } = require('../../services/signup/school');
const logger = require('../../logger/logger');

const getLatestSchoolController = async (req, res) => {
  try {
    logger.info('Controller: GET /api/get-latest-school');
    const schoolResult = await getLatestSchool();
    return res.status(200).json(schoolResult);
  } catch (error) {
    logger.error('Controller: Error fetching latest school:', { error: error.message });
    if (error.message === 'No school data found') {
      return res.status(404).json({ error: 'No school data found' });
    }
    return res.status(500).json({ error: 'Failed to fetch school data' });
  }
};

module.exports = { getLatestSchoolController };
