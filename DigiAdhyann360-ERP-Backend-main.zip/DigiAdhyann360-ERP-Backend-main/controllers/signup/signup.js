
// ==========================================signup==============================================================

const logger = require('../../logger/logger');
const { signupUser } = require('../../services/signup/signup');

const signupUserController = async (req, res) => {
  try {
    logger.info('Controller: Initiating user signup', { body: req.body });
    const { FullName, SchoolName, SchoolBranch, UdiseCode, City, State, PostalCode, Email, MobileNumber, Password, Role } = req.body;
    const result = await signupUser({
      FullName,
      SchoolName,
      SchoolBranch,
      UdiseCode,
      City,
      State,
      PostalCode,
      Email,
      MobileNumber,
      Password,
      Role
    });
    return res.status(201).json(result);
  } catch (err) {
    logger.error('Controller: Error in signupUserController', { error: err.message });
    if (err.message === 'Missing required fields') {
      return res.status(400).json({ error: err.message });
    }
    if (err.message === 'This Email is already registered.') {
      return res.status(409).json({ error: err.message });
    }
    if (err.message.includes('Database') && err.message.includes('already exists')) {
      return res.status(409).json({ error: err.message });
    }
    if (err.message === 'Tenant not found after insertion') {
      return res.status(404).json({ error: err.message });
    }
    if (err.message.includes('Database credentials not found') || err.message.includes('Failed to create tables')) {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

module.exports = { signupUserController };