const { getAssignmentData, updateAssignmentStatus } = require('../../services/staff/staffapproveassignment');
const logger = require('../../logger/logger');

const getAssignmentDataController = async (req, res) => {
  try {
    logger.info('Fetching assignment data in controller');
    const rows = await getAssignmentData();
    logger.info('Assignment data fetched successfully', { rows: rows.length });
    return res.status(200).json(rows);
  } catch (error) {
    logger.error('Error fetching assignment data', { error: error.message, stack: error.stack });
    if (error.code) {
      logger.error('Error code:', { code: error.code });
    }
    if (error.sqlMessage) {
      logger.error('SQL error message:', { sqlMessage: error.sqlMessage });
    }
    return res.status(500).json({
      error: 'Error fetching assignment data',
      details: error.message,
    });
  }
};

const teacherApprovalController = async (req, res) => {
  const { assignmentId, studentId, submittedDate, status } = req.body;

  if (!assignmentId || !studentId || !status) {
    logger.warn('Missing required fields in teacher approval request', { body: req.body });
    return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
    logger.info('Updating assignment status', { assignmentId, status });
    await updateAssignmentStatus({ assignmentId, studentId, submittedDate, status });
    logger.info('Assignment status updated successfully', { assignmentId, status });
    res.status(200).send({ message: 'Update successful!' });
  } catch (error) {
    logger.error('Error updating assignment status', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = {
  getAssignmentDataController,
  teacherApprovalController,
};