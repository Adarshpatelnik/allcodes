const staffAssignmentFormService = require('../../services/staff/staffassignmentform');
const logger = require('../../logger/logger');

exports.getAssignments = async (req, res) => {
  logger.info('Controller: GET /api/assignment', { query: req.query });
  try {
    const results = await staffAssignmentFormService.getAssignments();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Controller: Error in getAssignments', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'No valid staff ID found') {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

exports.submitAssignmentData = async (req, res) => {
  logger.info('Controller: POST /api/assignmentdata', { body: req.body });
  try {
    const { Class, AssignmentType, Subject, AssignmentDescription, SubmissionStartDate, SubmissionEndDate } = req.body;
    const result = await staffAssignmentFormService.submitAssignmentData({
      Class,
      AssignmentType,
      Subject,
      AssignmentDescription,
      SubmissionStartDate,
      SubmissionEndDate,
    });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Controller: Error in submitAssignmentData', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'No valid staff ID found' || err.message === 'Staff details not found' || err.message === 'No students found for the given class') {
      return res.status(404).json({ error: err.message });
    }
    if (err.message === 'Missing required fields') {
      return res.status(400).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Error inserting assignment data', details: err.message });
  }
};