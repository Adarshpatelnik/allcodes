
const staffAttendanceCalendarService = require('../../services/staff/staffattendancecalendar');
const logger = require('../../logger/logger');

const getAttendance = async (req, res) => {
  logger.info('GET /staffattendancecalendar/get-attendance', { query: req.query });
  try {
    const results = await staffAttendanceCalendarService.getAttendance();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Error in getAttendance', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getLeave = async (req, res) => {
  logger.info('GET /staffattendancecalendar/get-leave', { query: req.query });
  try {
    const results = await staffAttendanceCalendarService.getLeave();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Error in getLeave', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const getLeaveType = async (req, res) => {
  logger.info('GET /staffattendancecalendar/get-leave-type', { query: req.query });
  try {
    const results = await staffAttendanceCalendarService.getLeaveType();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Error in getLeaveType', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

const submitLeave = async (req, res) => {
  logger.info('POST /staffattendancecalendar/submit-leave', { body: req.body });
  try {
    const { leaveType, startDate, endDate, reason, contactNumber } = req.body;
    const result = await staffAttendanceCalendarService.submitLeave({ leaveType, startDate, endDate, reason, contactNumber });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in submitLeave', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established' || err.message === 'Staff not found') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Error submitting leave application', details: err.message });
  }
};

const submitAttendance = async (req, res) => {
  logger.info('POST /staffattendancecalendar/submitattendance', { body: req.body });
  try {
    const { STATUS, ATTENDANCE_DATE } = req.body;
    const result = await staffAttendanceCalendarService.submitAttendance({ STATUS, ATTENDANCE_DATE });
    return res.status(200).json(result);
  } catch (err) {
    logger.error('Error in submitAttendance', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established' || 
        err.message === 'STATUS and ATTENDANCE_DATE are required fields' ||
        err.message === 'ACADEMIC_YEAR not found in ACD_STUDENT_CLASS_MAPPING table' ||
        err.message === 'Staff name not found for the given STAFF_ID') {
      return res.status(400).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Error submitting attendance', details: err.message });
  }
};

const getStaffGender = async (req, res) => {
  logger.info('GET /staffattendancecalendar/get-staff-gender', { query: req.query });
  try {
    const result = await staffAttendanceCalendarService.getStaffGender();
    if (result) {
      res.status(200).json(result);
    } else {
      res.status(404).json({ error: 'Staff gender not found' });
    }
  } catch (err) {
    logger.error('Error in getStaffGender', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

module.exports = { getAttendance, getLeave, getLeaveType, submitLeave, submitAttendance, getStaffGender };