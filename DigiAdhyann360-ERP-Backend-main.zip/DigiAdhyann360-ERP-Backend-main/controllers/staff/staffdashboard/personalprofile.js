const logger = require('../../../logger/logger');
const { fetchStaffPersonalProfile } = require('../../../services/staff/staffdashboard/personalprofile');

const getStaffPersonalProfile = async (req, res) => {
  try {
    logger.info('Fetching staff personal profile', { url: req.url });
    const profile = await fetchStaffPersonalProfile();
    if (!profile) {
      logger.warn('No profile found for staff');
      return res.status(404).json({ error: 'Staff profile not found' });
    }
    logger.info('Staff personal profile fetched successfully', { staffId: profile.STAFF_ID });
    return res.status(200).json(profile);
  } catch (error) {
    logger.error('Error in getStaffPersonalProfile', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to fetch staff profile', details: error.message });
  }
};

module.exports = {
  getStaffPersonalProfile,
};