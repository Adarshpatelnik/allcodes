const logger = require('../../../logger/logger');
const { fetchStaffAssignmentDashboard } = require('../../../services/staff/staffdashboard/staffassignmentdashboard');

const getStaffAssignmentDashboard = async (req, res) => {
  try {
    logger.info('Fetching staff assignment dashboard', { url: req.url });
    const dashboardData = await fetchStaffAssignmentDashboard();
    logger.info('Staff assignment dashboard fetched successfully', { data: dashboardData });
    return res.status(200).json(dashboardData);
  } catch (error) {
    logger.error('Error in getStaffAssignmentDashboard', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to fetch assignment dashboard', details: error.message });
  }
};

module.exports = {
  getStaffAssignmentDashboard,
};