const logger = require('../../../logger/logger');
const { fetchClassSchedule } = require('../../../services/staff/staffdashboard/staffschedule');

const getClassSchedule = async (req, res) => {
  try {
    logger.info('Fetching class schedule', { url: req.url });
    const schedule = await fetchClassSchedule();
    logger.info('Class schedule fetched successfully', { count: schedule.length });
    return res.status(200).json(schedule);
  } catch (error) {
    logger.error('Error in getClassSchedule', { error: error.message, url: req.url });
    return res.status(500).json({ error: 'Failed to fetch class schedule', details: error.message });
  }
};

module.exports = {
  getClassSchedule,
};