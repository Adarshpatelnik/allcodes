const studentListService = require('../../../services/staff/staffdashboard/studentlist');
const logger = require('../../../logger/logger');

const getStudentList = async (req, res) => {
  logger.info('GET /studentlist', { query: req.query });
  try {
    const { classId, sectionId } = req.query;
    const results = await studentListService.getStudentList(classId, sectionId);
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Error in getStudentList', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

module.exports = { getStudentList };