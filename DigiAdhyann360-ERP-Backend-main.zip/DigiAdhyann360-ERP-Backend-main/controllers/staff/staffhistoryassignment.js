const staffApproveAssignmentService = require('../../services/staff/staffhistoryassignment');
const logger = require('../../logger/logger');
 
exports.getAssignmentRecord = async (req, res) => {
  logger.info('Controller: GET /api/get-assignmentrecord', { query: req.query });
  try {
    const results = await staffApproveAssignmentService.getAssignmentRecord();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Controller: Error in getAssignmentRecord', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'No valid staff ID found') {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Error fetching assignment records', details: err.message });
  }
};