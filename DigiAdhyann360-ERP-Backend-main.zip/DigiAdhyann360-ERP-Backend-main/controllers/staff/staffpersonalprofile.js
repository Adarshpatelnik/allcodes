const staffPersonalProfileService = require('../../services/staff/staffpersonalprofile');
const logger = require('../../logger/logger');

const getStaffPersonalProfile = async (req, res) => {
  logger.info('GET /staffpersonalprofile', { query: req.query });
  try {
    const results = await staffPersonalProfileService.getStaffPersonalProfile();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Error in getStaffPersonalProfile', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};

module.exports = { getStaffPersonalProfile };