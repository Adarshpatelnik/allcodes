// =========================================states===========================================================

const logger = require('../../logger/logger');
const { getIndianStates, getIndianDistricts, getIndianPincodes } = require('../../models/states/state');

const getIndianStatesController = async (req, res) => {
  try {
    logger.info('Controller: Initiating fetch of Indian states for dropdown');
    const states = await getIndianStates();
    return res.status(200).json(states);
  } catch (err) {
    logger.error('Controller: Error in getIndianStatesController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

const getIndianDistrictsController = async (req, res) => {
  try {
    const { state } = req.params;
    logger.info('Controller: Initiating fetch of Indian districts for dropdown', { state });
    const districts = await getIndianDistricts(state);
    return res.status(200).json(districts);
  } catch (err) {
    logger.error('Controller: Error in getIndianDistrictsController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

const getIndianPincodesController = async (req, res) => {
  try {
    const { district } = req.params;
    logger.info('Controller: Initiating fetch of Indian pincodes for dropdown', { district });
    const pincodes = await getIndianPincodes(district);
    return res.status(200).json(pincodes);
  } catch (err) {
    logger.error('Controller: Error in getIndianPincodesController', { error: err.message });
    return res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};

module.exports = { getIndianStatesController, getIndianDistrictsController, getIndianPincodesController };