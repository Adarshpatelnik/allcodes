const { getCurrentStudentDetails, raiseIssue } = require('../../services/student/parentchat');
 
exports.getCurrentStudentDetails = async (req, res) => {
  try {
    const studentDetails = await getCurrentStudentDetails(req);
    return res.status(200).json(studentDetails);
  } catch (error) {
    const status = error.message === 'No student found' ? 404 : error.message === 'User not authenticated' ? 401 : 500;
    return res.status(status).json({ error: error.message });
  }
};
 
exports.raiseIssue = async (req, res) => {
  try {
    const result = await raiseIssue(req);
    return res.status(200).json(result);
  } catch (error) {
    const status = error.message === 'No student found with the provided ID.' ? 404 : error.message === 'User not authenticated' ? 401 : 500;
    return res.status(status).json({ error: error.message });
  }
};