const { getSchoolDetails, getStudentDetails, getExamSchedule, generateAdmitCard } = require('../../services/student/studentadmitcard');
 
exports.getSchoolDetails = async (req, res) => {
  console.log('Controller: Handling getSchoolDetails request', { path: req.path });
  try {
    const results = await getSchoolDetails();
    console.log('Controller: Sending response', { results });
    res.status(200).json(results);
  } catch (error) {
    console.log('Controller: Error in getSchoolDetails', { error: error.message });
    const status = error.message.includes('Not found') ? 404 : error.message.includes('Unauthorized') ? 403 : 500;
    res.status(status).json({ error: error.message });
  }
};
 
exports.getStudentDetails = async (req, res) => {
  console.log('Controller: Handling getStudentDetails request', { path: req.path, query: req.query });
  try {
    const results = await getStudentDetails(req);
    console.log('Controller: Sending response', { results });
    res.status(200).json(results);
  } catch (error) {
    console.log('Controller: Error in getStudentDetails', { error: error.message });
    const status = error.message.includes('Not found') ? 404 : error.message.includes('Unauthorized') ? 401 : 400;
    res.status(status).json({ error: error.message });
  }
};
 
exports.getExamSchedule = async (req, res) => {
  console.log('Controller: Handling getExamSchedule request', { path: req.path, query: req.query });
  try {
    const results = await getExamSchedule(req);
    console.log('Controller: Sending response', { results });
    res.status(200).json(results);
  } catch (error) {
    console.log('Controller: Error in getExamSchedule', { error: error.message });
    const status = error.message.includes('Bad request') ? 400 : error.message.includes('Unauthorized') ? 403 : 500;
    res.status(status).json({ error: error.message });
  }
};
 
exports.generateAdmitCard = async (req, res) => {
  console.log('Controller: Handling generateAdmitCard request', { path: req.path, body: req.body });
  try {
    const result = await generateAdmitCard(req);
    console.log('Controller: Sending response', { result });
    res.status(200).json(result);
  } catch (error) {
    console.log('Controller: Error in generateAdmitCard', { error: error.message });
    const status = error.message.includes('Forbidden') ? 403 : error.message.includes('Unauthorized') ? 401 : error.message.includes('Bad request') ? 400 : 500;
    res.status(status).json({ error: error.message });
  }
};