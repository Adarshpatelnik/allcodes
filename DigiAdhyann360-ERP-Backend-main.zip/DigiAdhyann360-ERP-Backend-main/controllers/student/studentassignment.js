const logger = require('../../logger/logger');
const { getAssignments, submitAssignments } = require('../../services/student/studentassignment');

const getAssignmentsController = async (req, res) => {
  logger.info('GET /api/studenthistory/assignments', { query: req.query });
  try {
    const assignments = await getAssignments();
    logger.info('Assignments fetched successfully', { count: assignments.length });
    return res.status(200).json(assignments);
  } catch (err) {
    logger.error('Error in getAssignmentsController', { error: err.message, stack: err.stack });
    if (err.message === 'Unauthorized or missing context' || err.message === 'Unauthorized: Student not logged in') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (
      err.message === 'No class found for the provided student' ||
      err.message === 'No assignments found for the provided student and class'
    ) {
      return res.status(404).json({ message: err.message });
    }
    return res.status(500).json({ error: 'Internal server error' });
  }
};

const submitAssignmentsController = async (req, res) => {
  logger.info('POST /api/studenthistory/submit-assignment', { body: req.body });
  try {
    const assignments = req.body;
    const result = await submitAssignments(assignments);
    logger.info('Assignments submitted successfully', { count: assignments.length });
    return res.status(201).json(result);
  } catch (err) {
    logger.error('Error in submitAssignmentsController', { error: err.message, stack: err.stack });
    if (err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'No assignments provided' || err.message === 'Missing assignmentId or studentId') {
      return res.status(400).json({ error: err.message });
    }
    return res.status(500).json({ message: 'Internal server error' });
  }
};

module.exports = {
  getAssignmentsController,
  submitAssignmentsController,
};