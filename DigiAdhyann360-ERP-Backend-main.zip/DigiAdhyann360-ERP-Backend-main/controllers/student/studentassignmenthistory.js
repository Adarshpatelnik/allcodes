const logger = require('../../logger/logger');
const { getAssignmentHistory } = require('../../services/student/studentassignmenthistory');

const getAssignmentHistoryController = async (req, res) => {
  logger.info('GET /api/studentassignmenthistory/assignmenthistory', { query: req.query });
  try {
    const assignmentHistory = await getAssignmentHistory();
    logger.info('Assignment history fetched successfully', { count: assignmentHistory.length });
    return res.status(200).json(assignmentHistory);
  } catch (err) {
    logger.error('Error in getAssignmentHistoryController', { error: err.message, stack: err.stack });
    if (err.message === 'Unauthorized or missing context' || err.message === 'Unauthorized: Student not logged in') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'Database connection error') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Unexpected error occurred', details: err.message });
  }
};

module.exports = {
  getAssignmentHistoryController,
};