const dashboardStudentAttendanceService = require('../../../services/student/studentdashboard/studentattendancedashboard');
const logger = require('../../../logger/logger');

exports.getDashboardStudentAttendance = async (req, res) => {
  logger.info('Controller: GET /api/dashbordstudentattendance', { query: req.query });
  try {
    const results = await dashboardStudentAttendanceService.getDashboardStudentAttendance();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Controller: Error in getDashboardStudentAttendance', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'No attendance data found for the provided student ID.') {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};