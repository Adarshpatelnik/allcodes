const studentPerformanceChartService = require('../../../services/student/studentdashboard/studentperformancechart');
const logger = require('../../../logger/logger');


const getStudentPerformanceChart = async (req, res) => {
  logger.info('GET /studentperformancechart', { query: req.query });

  try {
    const results = await studentPerformanceChartService.getStudentPerformanceChart();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Error in getStudentPerformanceChart', { error: err.message, stack: err.stack });

    switch (err.message) {
      case 'AsyncLocalStorage is not properly initialized':
      case 'Unauthorized or missing context':
      case 'No student context found':
        return res.status(403).json({ error: err.message });
      case 'School database connection not established':
        return res.status(500).json({ error: err.message });
      case 'No student performance data found':
        return res.status(404).json({ error: err.message });
      default:
        return res.status(500).json({ error: 'Database query error', details: err.message });
    }
  }
};

module.exports = { getStudentPerformanceChart };