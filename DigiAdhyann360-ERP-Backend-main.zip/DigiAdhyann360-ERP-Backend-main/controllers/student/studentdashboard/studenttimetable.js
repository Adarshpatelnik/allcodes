const studentTimetableService = require('../../../services/student/studentdashboard/studenttimetable');
const logger = require('../../../logger/logger');

exports.getTimetable = async (req, res) => {
  logger.info('Controller: GET /api/timetable', { query: req.query });
  try {
    const results = await studentTimetableService.getTimetable();
    return res.status(200).json(results);
  } catch (err) {
    logger.error('Controller: Error in getTimetable', { error: err.message, stack: err.stack });
    if (err.message === 'AsyncLocalStorage is not properly initialized' || err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'No timetable found for the provided student ID.') {
      return res.status(404).json({ error: err.message });
    }
    return res.status(500).json({ error: 'Database query error', details: err.message });
  }
};