const logger = require('../../logger/logger');
const { getStudentData, updateStatus, updateStudentProfile } = require('../../services/student/studentdatatable');

const getStudentDataController = async (req, res) => {
  logger.info('GET /api/studentdatatable/student-data', { query: req.query });
  try {
    const rows = await getStudentData();
    logger.info('Student data fetched successfully', { count: rows.length });
    return res.status(200).json(rows);
  } catch (err) {
    logger.error('Error in getStudentDataController', { error: err.message, stack: err.stack });
    if (err.message === 'Unauthorized or missing context' || err.message === 'Unauthorized: Student not logged in') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    return res.status(500).json({ message: 'Error fetching student data', error: err.message });
  }
};

const updateStatusController = async (req, res) => {
  logger.info('POST /api/studentdatatable/update-status', { body: req.body });
  try {
    const { REQUEST_ID, STATUS } = req.body;
    const result = await updateStatus(REQUEST_ID, STATUS);
    logger.info('Status updated successfully', { REQUEST_ID, STATUS });
    return res.status(200).send(result);
  } catch (err) {
    logger.error('Error in updateStatusController', { error: err.message, stack: err.stack });
    if (err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'Invalid status') {
      return res.status(400).send(err.message);
    }
    if (err.message === 'Request not found') {
      return res.status(404).send(err.message);
    }
    return res.status(500).send('Server error');
  }
};

const updateStudentProfileController = async (req, res) => {
  logger.info('POST /api/studentdatatable/update-student-profile', { body: req.body });
  try {
    const { REQUESTER_ID } = req.body;
    const result = await updateStudentProfile(REQUESTER_ID);
    logger.info('Student profile updated successfully', { REQUESTER_ID });
    return res.status(200).send(result);
  } catch (err) {
    logger.error('Error in updateStudentProfileController', { error: err.message, stack: err.stack });
    if (err.message === 'Unauthorized or missing context') {
      return res.status(403).json({ error: err.message });
    }
    if (err.message === 'School database connection not established') {
      return res.status(500).json({ error: err.message });
    }
    if (err.message === 'REQUESTER_ID is required') {
      return res.status(400).json({ error: err.message });
    }
    if (err.message === 'No profile found for the provided REQUESTER_ID') {
      return res.status(404).send(err.message);
    }
    return res.status(500).send('Server error');
  }
};

module.exports = {
  getStudentDataController,
  updateStatusController,
  updateStudentProfileController,
};