const logger = require('../../logger/logger');
const PaymentService = require('../../services/student/studentfees');

const createOrder = async (req, res) => {
  try {
    logger.info('Entering createOrder Controller', { body: req.body });

    const { studentId, amount, frequency, financialYear } = req.body;

    if (!studentId || !amount || !frequency || !financialYear) {
      logger.error('Missing required fields in createOrder', { body: req.body });
      return res.status(400).json({ error: 'studentId, amount, frequency, and financialYear are required' });
    }

    const trimmedStudentId = studentId.trim();
    if (!trimmedStudentId.match(/^SID-\d+$/)) {
      logger.error('Invalid studentId format', { studentId });
      return res.status(400).json({ error: 'Invalid studentId format (e.g., SID-123)' });
    }

    if (!financialYear.match(/^\d{4}-\d{4}$/)) {
      logger.error('Invalid financialYear format', { financialYear });
      return res.status(400).json({ error: 'Invalid financialYear format (e.g., 2023-2024)' });
    }

    const order = await PaymentService.createOrder({ studentId: trimmedStudentId, amount, frequency, financialYear });
    logger.info('Order created successfully', { orderId: order.id, studentId: trimmedStudentId, financialYear });
    res.status(200).json(order);
  } catch (error) {
    logger.error('Error in createOrder Controller:', { error: error.message, stack: error.stack, body: req.body });
    res.status(500).json({
      error: 'Failed to create payment order',
      details: error.message,
    });
  }
};

const verifyPayment = async (req, res) => {
  try {
    logger.info('Entering verifyPayment Controller', { body: req.body });

    const { razorpayOrderId, razorpayPaymentId, razorpaySignature, frequency, studentId, financialYear } = req.body;

    if (!razorpayOrderId || !razorpayPaymentId || !razorpaySignature || !studentId || !frequency || !financialYear) {
      logger.error('Missing required fields in verifyPayment', { body: req.body });
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const trimmedStudentId = studentId.trim();
    if (!trimmedStudentId.match(/^SID-\d+$/)) {
      logger.error('Invalid studentId format', { studentId });
      return res.status(400).json({ error: 'Invalid studentId format (e.g., SID-123)' });
    }

    if (!financialYear.match(/^\d{4}-\d{4}$/)) {
      logger.error('Invalid financialYear format', { financialYear });
      return res.status(400).json({ error: 'Invalid financialYear format (e.g., 2023-2024)' });
    }

    const result = await PaymentService.verifyPayment({
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature,
      frequency,
      studentId: trimmedStudentId,
      financialYear,
    });

    logger.info('Payment verified successfully', { studentId: trimmedStudentId, insertId: result.insertId, financialYear });
    res.status(200).json(result);
  } catch (error) {
    logger.error('Error in verifyPayment Controller:', { error: error.message, stack: error.stack, body: req.body });
    res.status(500).json({
      success: false,
      error: 'Payment verification failed',
      details: error.message,
    });
  }
};

const fetchClasses = async (req, res) => {
  try {
    logger.info('Entering fetchClasses Controller');
    const classes = await PaymentService.getClasses();
    logger.info('Classes fetched successfully', { count: classes.length });
    res.status(200).json(classes);
  } catch (error) {
    logger.error('Error in fetchClasses Controller:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch classes' });
  }
};

const fetchFrequencies = async (req, res) => {
  try {
    logger.info('Entering fetchFrequencies Controller');
    const frequencies = await PaymentService.getFrequencies();
    logger.info('Frequencies fetched successfully', { count: frequencies.length });
    res.status(200).json(frequencies);
  } catch (error) {
    logger.error('Error in fetchFrequencies Controller:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch frequencies' });
  }
};

const fetchStudentsAndFees = async (req, res) => {
  try {
    logger.info('Entering fetchStudentsAndFees Controller', { query: req.query });
    const { class: className, frequency } = req.query;
    if (!className || !frequency) {
      logger.error('Missing class or frequency parameters', { className, frequency });
      return res.status(400).json({ error: 'Class and frequency parameters are required' });
    }

    const students = await PaymentService.getStudentsAndFees({ className, frequency });
    logger.info('Students and fees fetched successfully', { className, frequency, count: students.length });
    res.status(200).json({ students });
  } catch (error) {
    logger.error('Error in fetchStudentsAndFees Controller:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch student and fee data' });
  }
};

const fetchStudentById = async (req, res) => {
  try {
    logger.info('Entering fetchStudentById Controller', { params: req.params });
    const { studentId } = req.params;
    if (!studentId) {
      logger.error('Missing studentId parameter');
      return res.status(400).json({ error: 'studentId is required' });
    }

    const trimmedStudentId = studentId.trim();
    if (!trimmedStudentId.match(/^SID-\d+$/)) {
      logger.error('Invalid studentId format', { studentId: trimmedStudentId });
      return res.status(400).json({ error: 'Invalid studentId format (e.g., SID-123)' });
    }

    const studentData = await PaymentService.getStudentById(trimmedStudentId);
    logger.info('Student fetched successfully', { studentId: trimmedStudentId, count: studentData.length });
    res.status(200).json({ students: studentData });
  } catch (error) {
    logger.error('Error in fetchStudentById Controller:', { error: error.message, stack: error.stack, studentId });
    res.status(500).json({ error: 'Failed to fetch student data', details: error.message });
  }
};

const fetchFeeDetailsByStudentId = async (req, res) => {
  try {
    logger.info('Entering fetchFeeDetailsByStudentId Controller', { params: req.params });
    const { studentId } = req.params;
    if (!studentId) {
      logger.error('Missing studentId parameter');
      return res.status(400).json({ error: 'studentId is required' });
    }

    const trimmedStudentId = studentId.trim();
    if (!trimmedStudentId.match(/^SID-\d+$/)) {
      logger.error('Invalid studentId format', { studentId: trimmedStudentId });
      return res.status(400).json({ error: 'Invalid studentId format (e.g., SID-123)' });
    }

    const feeDetails = await PaymentService.getFeeDetailsByStudentId(trimmedStudentId);
    logger.info('Fee details fetched successfully', { studentId: trimmedStudentId, count: feeDetails.length });
    res.status(200).json({ feeDetails });
  } catch (error) {
    logger.error('Error in fetchFeeDetailsByStudentId Controller:', { error: error.message, stack: error.stack, studentId });
    res.status(500).json({ error: 'Failed to fetch fee details', details: error.message });
  }
};

const fetchCurrentStudent = async (req, res) => {
  try {
    logger.info('Entering fetchCurrentStudent Controller');
    const student = await PaymentService.getCurrentStudent();
    logger.info('Current student fetched successfully', { studentId: student.STUDENT_ID });
    res.status(200).json(student);
  } catch (error) {
    logger.error('Error in fetchCurrentStudent Controller:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch current student', details: error.message });
  }
};

const fetchFinancialYears = async (req, res) => {
  try {
    logger.info('Entering fetchFinancialYears Controller');
    const financialYears = await PaymentService.getFinancialYears();
    logger.info('Financial years fetched successfully', { count: financialYears.length });
    res.status(200).json({ financialYears });
  } catch (error) {
    logger.error('Error in fetchFinancialYears Controller:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch financial years' });
  }
};

module.exports = {
  createOrder,
  verifyPayment,
  fetchClasses,
  fetchFrequencies,
  fetchStudentsAndFees,
  fetchStudentById,
  fetchFeeDetailsByStudentId,
  fetchCurrentStudent,
  fetchFinancialYears,
};