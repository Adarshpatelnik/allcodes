
const { getStudentProfile, updateStudentProfile } = require('../../services/student/studentprofiledashboard');

exports.getStudentProfile = async (req, res) => {
  try {
    const results = await getStudentProfile(req);
    return res.status(200).json(results);
  } catch (error) {
    return res.status(500).json({ error: 'An error occurred while fetching data', details: error.message });
  }
};

exports.updateStudentProfile = async (req, res) => {
  try {
    const result = await updateStudentProfile(req);
    return res.status(200).json(result);
  } catch (error) {
    const status = error.message.includes('Missing') ? 400 : 500;
    return res.status(status).json({ error: 'An error occurred while updating data', details: error.message });
  }
};