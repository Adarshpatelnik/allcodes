 
const { asyncLocalStorage } = require('./authmiddleware');
 
const attachIdentifiers = async (req, res, next) => {
  try {
    const store = asyncLocalStorage.getStore();
 
    if (!store) {
      console.error('❌ No AsyncLocalStorage store found');
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
 
    if (!schoolDbConnection) {
      console.error('❌ School DB connection not found in AsyncLocalStorage');
      return res.status(500).json({ error: 'School database connection not established' });
    }
 
    const [rows] = await schoolDbConnection.query('SELECT UDISE_CODE FROM ACD_SCHOOL_PROFILE LIMIT 1');
 
    if (!rows.length) {
      return res.status(404).json({ error: 'UDISE_CODE not found in school profile' });
    }
 
    req.udiseCode = rows[0].UDISE_CODE;
    console.log('✅ Attached UDISE_CODE:', req.udiseCode);
 
    next();
  } catch (err) {
    console.error('❌ Error in attachIdentifiers:', err.message);
    res.status(500).json({ error: 'Internal server error', details: err.message });
  }
};
 
module.exports = attachIdentifiers;
 