const { AsyncLocalStorage } = require('node:async_hooks');
const { verifyToken } = require('../config/auth');
const { connectToSchoolDatabase } = require('../config/db');
const { setRoleContext } = require('../config/rbac');
const { pool } = require('../config/db');

// Create a single AsyncLocalStorage instance
const asyncLocalStorage = new AsyncLocalStorage();

// Middleware to initialize AsyncLocalStorage for each request
const tenantContextMiddleware = (req, res, next) => {
  console.log('AsyncLocalStorage context initialized', { path: req.path });
  asyncLocalStorage.run(new Map(), () => {
    next();
  });
};

// Middleware to handle PayloadTooLargeError
const payloadTooLargeMiddleware = (err, req, res, next) => {
  if (err.type === 'entity.too.large') {
    console.log('Payload too large', { path: req.path });
    res.status(413).json({ error: 'Payload too large. Please reduce the size of the data and try again.' });
  } else {
    next(err);
  }
};

// Authentication middleware
const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    console.log('Authorization token missing or malformed', { path: req.path });
    return res.status(401).json({ message: 'Authorization token missing or malformed' });
  }

  const token = authHeader.split(' ')[1];
  const decoded = verifyToken(token);

  if (!decoded) {
    console.log('Invalid or expired token', { path: req.path });
    return res.status(403).json({ message: 'Invalid or expired token' });
  }

  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      console.log('AsyncLocalStorage store unavailable', { path: req.path });
      return res.status(500).json({ message: 'AsyncLocalStorage context unavailable' });
    }

    // Fetch school database credentials
    const [schoolResult] = await pool.query(
      'SELECT * FROM SCHOOL_DB_CREDENTIALS WHERE TENANT_ID = ?',
      [decoded.tenantId]
    );
    if (schoolResult.length === 0) {
      console.log('School database not found', { path: req.path });
      return res.status(404).json({ error: 'School database not found' });
    }

    // Connect to school database
    const schoolDbConnection = await connectToSchoolDatabase(schoolResult[0]);
    store.set('schoolDbConnection', schoolDbConnection);
    store.set('tenantId', decoded.tenantId);

    // Set role context
    const user = {
      USER_ID: decoded.current_staff || decoded.current_admin || decoded.current_student,
      ROLE_NAME: decoded.roleAllowed,
      TENANT_ID: decoded.tenantId
    };
    const { current_admin, current_staff, current_student } = setRoleContext(asyncLocalStorage, user);
    store.set('current_admin', current_admin);
    store.set('current_staff', current_staff);
    store.set('current_student', current_student);

    req.user = decoded;
    console.log('Token verified successfully', { user: decoded.userName, path: req.path });
    next();
  } catch (error) {
    console.error('Error in authMiddleware:', error.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
};
const globalMiddleware = (req, res, next) => {
  const publicRoutes = [
    '/api/login',
    '/api/signup',
    '/api/indian-states',
    /^\/api\/indian-districts\/[^/]+$/,
    /^\/api\/indian-pincodes\/[^/]+$/,
    '/api/add-tenant-service',
    '/api/get-services',
    '/api/contact',
    '/login/developer',
    '/api/create-razorpay-order',
    '/api/verify-razorpay-signature',
    '/api/get-latest-school',
    '/api/validate-coupon',
    '/api/save-payment',
    
 ];

  //  Wrap everything inside asyncLocalStorage.run
  asyncLocalStorage.run(new Map(), () => {
    if (publicRoutes.some(route => route instanceof RegExp ? route.test(req.path) : route === req.path)) {
      return next();
    }
    return authMiddleware(req, res, next);
  });
};


module.exports = {
  tenantContextMiddleware,
  payloadTooLargeMiddleware,
  authMiddleware,
  globalMiddleware,
  asyncLocalStorage,
};