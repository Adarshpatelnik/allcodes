
const { S3Client, PutObjectCommand, GetObjectCommand } = require('@aws-sdk/client-s3');
const multer = require('multer');
const multerS3 = require('multer-s3');
const mime = require('mime-types');
const path = require('path');

const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype === 'text/csv' ||
      file.mimetype === 'application/vnd.ms-excel' ||
      file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ) {
      cb(null, true);
    } else {
      cb(new Error('Only .csv, .xls, and .xlsx files are allowed!'), false);
    }
  },
});

const express = require('express');
const app = express();
app.use('/uploads', express.static(path.join(__dirname, 'Uploads')));

const createS3FolderStructure = async (udiseCode) => {
  const folderStructure = [
    `${udiseCode}/Students/Applicants/`,
    `${udiseCode}/Students/Enrolled/`,
    `${udiseCode}/Staff/Applicants/`,
    `${udiseCode}/Staff/Enrolled/`,
    `${udiseCode}/School-details/`,
  ];

  try {
    const createFolderPromises = folderStructure.map((folder) =>
      s3Client.send(
        new PutObjectCommand({
          Bucket: process.env.AWS_BUCKET_NAME,
          Key: folder,
          Body: '',
        })
      )
    );
    await Promise.all(createFolderPromises);
    console.log(`Folder structure for ${udiseCode} created successfully in S3.`);
  } catch (error) {
    console.error('Error creating folder structure in S3:', error);
    throw new Error('Failed to create folder structure in S3');
  }
};

const getCustomFileName = (fieldName, originalName) => {
  const fileMappings = {
    STUDENT_AADHAAR: "STUDENT_AADHAAR",
    STUDENT_PHOTO: "STUDENT_PHOTO",
    PREVIOUS_MARKSHEET: "PREVIOUS_MARKSHEET",
    TRANSFER_CERTIFICATE: "TRANSFER_CERTIFICATE",
    MIGRATION_CERTIFICATE: "MIGRATION_CERTIFICATE",
    BIRTH_CERTIFICATE: "BIRTH_CERTIFICATE",
    CHARACTER_CERTIFICATE: "CHARACTER_CERTIFICATE",
    SAMAGRA_ID: "SAMAGRA_ID",
    SCHOOL_LOGO: "SCHOOL_LOGO",
  };
  const fileExtension = path.extname(originalName);
  return fileMappings[fieldName] ? `${fileMappings[fieldName]}${fileExtension}` : originalName;
};

const getContentType = (file) => mime.lookup(file.originalname) || "application/octet-stream";
const getContentDisposition = (file) =>
  ["image/png", "image/jpeg", "application/pdf"].includes(mime.lookup(file.originalname)) ? "inline" : "attachment";

const uploadFileToS3 = multer({
  storage: multerS3({
    s3: s3Client,
    bucket: process.env.AWS_BUCKET_NAME,
    metadata: (req, file, cb) => cb(null, { fieldName: file.fieldname }),
    key: (req, file, cb) => {
      const { applicantId } = req.body;
      if (!req.udiseCode || !applicantId) {
        cb(new Error("Missing required fields: udiseCode or applicantId."));
      } else {
        const customFileName = getCustomFileName(file.fieldname, file.originalname);
        const filePath = `${req.udiseCode}/Students/Applicants/${applicantId}/${customFileName}`;
        cb(null, filePath);
      }
    },
    acl: "private",
    contentType: getContentType,
    contentDisposition: getContentDisposition,
  }),
}).fields([
  { name: "STUDENT_AADHAAR", maxCount: 1 },
  { name: "STUDENT_PHOTO", maxCount: 1 },
  { name: "PREVIOUS_MARKSHEET", maxCount: 1 },
  { name: "TRANSFER_CERTIFICATE", maxCount: 1 },
  { name: "MIGRATION_CERTIFICATE", maxCount: 1 },
  { name: "BIRTH_CERTIFICATE", maxCount: 1 },
  { name: "CHARACTER_CERTIFICATE", maxCount: 1 },
  { name: "SAMAGRA_ID", maxCount: 1 },
]);

const uploadSchoolLogoToS3 = multer({
  storage: multerS3({
    s3: s3Client,
    bucket: process.env.AWS_BUCKET_NAME,
    metadata: (req, file, cb) => cb(null, { fieldName: file.fieldname }),
    key: (req, file, cb) => {
      if (!req.udiseCode) return cb(new Error('Missing required field: udiseCode.'), false);
      const filePath = `${req.udiseCode}/School-details/SCHOOL_LOGO${path.extname(file.originalname)}`;
      cb(null, filePath);
    },
    acl: 'private',
    contentType: (req, file, cb) => cb(null, file.mimetype),
    contentDisposition: (req, file, cb) => cb(null, 'inline'),
  }),
  fileFilter: (req, file, cb) => {
    const allowedMimeTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedMimeTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG and PNG are allowed.'), false);
    }
  },
}).single('SCHOOL_LOGO');

module.exports = { upload, createS3FolderStructure, uploadFileToS3, uploadSchoolLogoToS3, s3Client };
 