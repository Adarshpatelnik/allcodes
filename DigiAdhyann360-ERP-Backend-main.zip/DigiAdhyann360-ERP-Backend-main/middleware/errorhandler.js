const errorHandler = (err, req, res, next) => {
  if (err.type === 'entity.too.large') {
    res.status(413).json({ error: 'Payload too large. Please reduce the size of the data and try again.' });
  } else {
    console.error('Error:', err.message);
    res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = errorHandler;