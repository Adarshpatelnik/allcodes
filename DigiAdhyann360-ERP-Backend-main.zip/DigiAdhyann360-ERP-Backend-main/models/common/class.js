const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getClasses = async () => {
  // Check if context exists
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  // Get school database connection
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  // SQL query to fetch class details

  const classSql = ` SELECT DISTINCT class

    FROM ACD_STUDENT_CLASS_MAPPING
    WHERE class != 'Alumni'
    ORDER BY
      CASE
        WHEN class = 'LKG' THEN 0
        WHEN class = 'UKG' THEN 1
        WHEN class REGEXP '^[0-9]+$' THEN CAST(class AS UNSIGNED) + 1
        ELSE 999
      END`;
 

  try {
    logger.info('Executing SQL query for fetching classes');
    const [rows] = await schoolDbConnection.query(classSql);
    const classes = rows.map((row) => row.class);
    logger.info('Classes fetched successfully', { count: classes.length });
    return classes;
  } catch (err) {
    logger.error('Error fetching classes', { error: err.message });
    throw new Error(`Error fetching classes: ${err.message}`);
  }
};

module.exports = { getClasses };