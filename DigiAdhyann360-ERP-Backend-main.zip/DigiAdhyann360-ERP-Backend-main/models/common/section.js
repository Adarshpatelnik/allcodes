const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getSections = async () => {
  // Check if context exists
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  // Get school database connection
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  // SQL query to fetch section details
  const sectionSql = `
    SELECT DISTINCT SECTION
    FROM ACD_STUDENT_CLASS_MAPPING
    WHERE SECTION IS NOT NULL
    ORDER BY SECTION`;

  try {
    logger.info('Executing SQL query for fetching sections');
    const [rows] = await schoolDbConnection.query(sectionSql);
    const sections = rows.map((row) => row.SECTION);
    logger.info('Sections fetched successfully', { count: sections.length });
    return sections;
  } catch (err) {
    logger.error('Error fetching sections', { error: err.message });
    throw new Error(`Error fetching sections: ${err.message}`);
  }
};

module.exports = { getSections };