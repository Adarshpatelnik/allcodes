//=============================================state========================================

const { pool } = require('../../config/db');
const logger = require('../../logger/logger');

const getIndianStates = async () => {
  try {
    const statesSql = `SELECT DISTINCT STATE FROM INDIA_PINCODE_MASTER ORDER BY STATE`;
    logger.info('Executing query to fetch Indian states', { query: statesSql });
    const [statesSqlResult] = await pool.query(statesSql);
    const states = statesSqlResult.map((row) => row.STATE);
    logger.info('Indian states fetched successfully', { count: states.length });
    return states;
  } catch (err) {
    logger.error('Error fetching Indian states', { error: err.message, stack: err.stack });
    throw new Error('Database query error');
  }
};

const getIndianDistricts = async (state) => {
  try {
    const districtsSql = `SELECT DISTINCT DISTRICT FROM INDIA_PINCODE_MASTER WHERE STATE = ? ORDER BY DISTRICT`;
    logger.info('Executing query to fetch Indian districts', { query: districtsSql, state });
    const [districtsSqlResult] = await pool.query(districtsSql, [state]);
    const districts = districtsSqlResult.map((row) => row.DISTRICT);
    logger.info('Indian districts fetched successfully', { state, count: districts.length });
    return districts;
  } catch (err) {
    logger.error('Error fetching Indian districts', { error: err.message, stack: err.stack, state });
    throw new Error('Database query error');
  }
};

const getIndianPincodes = async (district) => {
  try {
    const pincodesSql = `SELECT PINCODE FROM INDIA_PINCODE_MASTER WHERE DISTRICT = ? ORDER BY PINCODE`;
    logger.info('Executing query to fetch Indian pincodes', { query: pincodesSql, district });
    const [pincodesSqlResult] = await pool.query(pincodesSql, [district]);
    const pincodes = pincodesSqlResult.map((row) => row.PINCODE);
    logger.info('Indian pincodes fetched successfully', { district, count: pincodes.length });
    return pincodes;
  } catch (err) {
    logger.error('Error fetching Indian pincodes', { error: err.message, stack: err.stack, district });
    throw new Error('Database query error');
  }
};

module.exports = { getIndianStates, getIndianDistricts, getIndianPincodes };