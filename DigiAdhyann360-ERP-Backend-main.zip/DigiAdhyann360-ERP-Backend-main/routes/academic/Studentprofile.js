// backend/routes/academic/studentprofile.js
const express = require('express');
const router = express.Router();
const { getStudentProfile } = require('../../controllers/academic/Studentprofile');

// Define GET endpoint for student profiles
router.get('/Studentprofile', getStudentProfile);

module.exports = router;