const express = require('express');
const router = express.Router();
const { attachIdentifiers, uploadFileToS3 } = require('../../services/academic/applicationdocform');
const { uploadDocumentsController } = require('../../controllers/academic/applicationdocform');

router.post('/upload-documents', attachIdentifiers, uploadFileToS3, uploadDocumentsController);

module.exports = router;