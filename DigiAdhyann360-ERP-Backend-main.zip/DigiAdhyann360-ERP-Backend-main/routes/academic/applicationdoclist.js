
const express = require('express');
const router = express.Router();
const { getDocumentsController } = require('../../controllers/academic/applicationdoclist');

router.get('/get-documents/:udiseCode/:applicationId', getDocumentsController);

module.exports = router;
