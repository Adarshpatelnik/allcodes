const express = require('express');
const router = express.Router();
const {
  getApplicationFormStatusController,
  getApplicationClassFilterController,
  updateApplicationController,
  createApplicationController,
} = require('../../controllers/academic/applicationform');

router.get('/get-applicationformstatus/:id', getApplicationFormStatusController);
router.get('/Applicationclassfilter', getApplicationClassFilterController);
router.put('/update-application/:id', updateApplicationController);
router.post('/application', createApplicationController);

module.exports = router;