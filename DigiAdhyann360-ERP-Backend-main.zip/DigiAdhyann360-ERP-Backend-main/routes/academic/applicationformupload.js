const express = require('express');
const router = express.Router();
const { globalMiddleware } = require('../../middleware/authmiddleware');
const { bulkLoadController } = require('../../controllers/academic/applicationformupload');

// POST /api/BulkLoad
router.post('/BulkLoad', globalMiddleware, bulkLoadController);

module.exports = router;