const express = require('express');
const router = express.Router();
const ApplicationListController = require('../../controllers/academic/applicationlist');

router.get('/applications', ApplicationListController.getApplications);

module.exports = router;