const express = require('express');
const router = express.Router();
const StudentStatusController = require('../../controllers/academic/applicationtracker');

router.get('/get-application-status/:appId', StudentStatusController.getApplicationStatus);

module.exports = router;