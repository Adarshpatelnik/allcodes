

const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../../middleware/authmiddleware');
const {
  fetchTeachers,
  fetchTeacherAssignments,
  updateAssignment,
  deleteAssignment,
} = require('../../controllers/academic/assignclassteacher');

// 📘 Route to fetch all available teachers (with role = TEACHER)
router.get('/assignstaff', authMiddleware, fetchTeachers);

// 📘 Route to fetch all class-teacher assignments
router.get('/teacher-data', authMiddleware, fetchTeacherAssignments);

// 📘 Route to assign or update a teacher for a class
router.post('/update-staff', authMiddleware, updateAssignment);

// 📘 Route to delete all teacher assignments for a class
router.post('/delete-staff', authMiddleware, deleteAssignment);

module.exports = router;


