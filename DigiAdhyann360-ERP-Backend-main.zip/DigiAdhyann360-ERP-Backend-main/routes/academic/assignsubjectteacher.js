const express = require('express');
const router = express.Router();
const {
  getTeachersController,
  getClassesController,
  getSectionsController,
  getSubjectsController,
  insertOrUpdateTeacherDetailController,
  getTeacherDetailsController,
  deleteTeacherDetailController,
} = require('../../controllers/academic/assignsubjectteacher');

router.get('/get-teachers', getTeachersController);
router.get('/get-classes', getClassesController);
router.get('/get-sections', getSectionsController);
router.get('/get-subject/:class', getSubjectsController);
router.post('/insert-or-update-teacher-detail', insertOrUpdateTeacherDetailController);
router.get('/get-teacher-details', getTeacherDetailsController);
router.delete('/delete-teacher-detail', deleteTeacherDetailController);

module.exports = router;