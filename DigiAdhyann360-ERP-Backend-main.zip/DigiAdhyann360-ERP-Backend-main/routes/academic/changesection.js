const express = require('express');
const router = express.Router();
const { getAllStudentsController, updateStudentSectionController } = require('../../controllers/academic/changesection');

// Define GET endpoint for all students
router.get('/students', getAllStudentsController);

// Define PUT endpoint to update a student's section
router.put('/students/:studentId', updateStudentSectionController);

module.exports = router;