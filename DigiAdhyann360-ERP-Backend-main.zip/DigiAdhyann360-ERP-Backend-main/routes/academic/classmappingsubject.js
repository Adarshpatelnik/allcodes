
const express = require('express');
const router = express.Router();
const {
  fetchClasses,
  fetchSubjectNames,
  fetchSubjectsByClass,
  saveSubjectsHandler,
  deleteSubjectHandler,
  updateSubjectHandler,
} = require('../../controllers/academic/classmappingsubject');

router.get('/classes', fetchClasses);
router.get('/subject-names', fetchSubjectNames);
router.get('/subjects', fetchSubjectsByClass);
router.post('/save-subjects', saveSubjectsHandler);
router.delete('/delete-subject/:subjectCode', deleteSubjectHandler);
router.put('/update-subject/:subjectCode', updateSubjectHandler);

module.exports = router;