const express = require('express');
const router = express.Router();
const EnrollmentController = require('../../controllers/academic/enrollment');

router.get('/enrollment/applications', EnrollmentController.getApplications);
router.post('/enrollment/approve', EnrollmentController.validateApproveApplications(), EnrollmentController.approveApplications);

module.exports = router;