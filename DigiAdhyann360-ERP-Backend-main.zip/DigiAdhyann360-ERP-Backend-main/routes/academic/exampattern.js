// backend/routes/academic/exampattern.js
const express = require('express');
const router = express.Router();
const exampatternController = require('../../controllers/academic/exampattern');

router.get('/getExamType', exampatternController.getExamTypes);
router.get('/exams', exampatternController.getAllExams);
router.post('/exams', exampatternController.createExam);
router.delete('/exams/:id', exampatternController.deleteExam);
router.put('/exams/:id', exampatternController.updateExam);

module.exports = router;