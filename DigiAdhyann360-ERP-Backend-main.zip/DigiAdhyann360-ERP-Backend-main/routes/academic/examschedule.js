const express = require('express');
const router = express.Router();
const {
  getClasses,
  getSubjects,
  getExam,
  saveExamScheduleController,
} = require('../../controllers/academic/examschedule');

router.get('/getClasses', getClasses);
router.get('/getSubjects', getSubjects);
router.get('/getExam', getExam);
router.post('/saveExamSchedule', saveExamScheduleController);

module.exports = router;