const express = require('express');
const router = express.Router();
const { getStudentCertificate, getCharacterCertificate, getAlumniStudentsList } = require('../../controllers/academic/generatecertificate');

// Route to fetch student data for certificate generation
router.get('/generatestudent/:studentId', getStudentCertificate);

// Route to fetch student data for character certificate
router.get('/CharacterCertificate/:studentId', getCharacterCertificate);

// Route to fetch alumni students
router.get('/get-alumniStudents', getAlumniStudentsList);

module.exports = router;