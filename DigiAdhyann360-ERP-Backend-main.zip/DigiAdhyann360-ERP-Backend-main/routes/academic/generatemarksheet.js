const express = require('express');
const router = express.Router();
const { getGenerateMarksController } = require('../../controllers/academic/generatemarksheet');
const { globalMiddleware } = require('../../middleware/authmiddleware');
 
router.get('/getGenerateMarks', globalMiddleware, getGenerateMarksController);
 
module.exports = router;