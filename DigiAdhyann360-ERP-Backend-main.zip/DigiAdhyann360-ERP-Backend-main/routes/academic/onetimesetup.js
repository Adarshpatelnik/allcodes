
const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../../middleware/authmiddleware');
const {
  saveConfigCodeController,
  saveConfigValuesController,
  getConfigCodeController,
  getConfigValuesController,
  deleteConfigCodeController,
  deleteConfigValuesController,
} = require('../../controllers/academic/onetimesetup');

router.use((req, res, next) => {
  console.log(`Route hit: ${req.method} ${req.originalUrl}`);
  next();
});

router.post('/saveConfigCode', authMiddleware, saveConfigCodeController);
router.post('/saveConfigValues', authMiddleware, saveConfigValuesController);
router.get('/getConfigCode', authMiddleware, getConfigCodeController);
router.get('/getConfigValues', authMiddleware, getConfigValuesController);
router.delete('/deleteConfigCode/:lovId', authMiddleware, deleteConfigCodeController);
router.delete('/deleteConfigValues/:listId', authMiddleware, deleteConfigValuesController);

module.exports = router;