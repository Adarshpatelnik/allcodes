const express = require('express');
const router = express.Router();
const ParentDetailController = require('../../controllers/academic/parentdetail');

router.get('/parent_Detail_Update/:parentId', ParentDetailController.getParentDetails);
router.get('/parentProfiles', ParentDetailController.getAllParentProfiles);
router.put('/parent_Detail_Update/:parentId', ParentDetailController.updateParentDetails);

module.exports = router;