// backend/routes/academic/parentprofile.js
const express = require('express');
const router = express.Router();
const { getParentProfile } = require('../../controllers/academic/parentprofile');

// Define GET endpoint for student profiles
router.get('/Parentprofile', getParentProfile);

module.exports = router;