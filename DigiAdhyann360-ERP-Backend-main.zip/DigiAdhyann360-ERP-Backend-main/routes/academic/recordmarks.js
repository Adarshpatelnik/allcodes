
const express = require('express');
const router = express.Router();
const gradeEntryController = require('../../controllers/academic/recordmarks');

router.get('/getClassesforgradeentry', gradeEntryController.getClassesForGradeEntry);
router.get('/getexamnameexamtype', gradeEntryController.getExamNameAndExamType);
router.get('/getSubjectsforgradeentry', gradeEntryController.getSubjectsForGradeEntry);
router.get('/getStudentsWithClass', gradeEntryController.getStudentsWithClass);
router.get('/getSavedData', gradeEntryController.getSavedData);
router.get('/getTotalMarks', gradeEntryController.getTotalMarks);
router.post('/submittotalmarks', gradeEntryController.submitTotalMarks);
router.post('/saveGradeEntry', gradeEntryController.saveGradeEntry);
router.post('/submitGradeEntry', gradeEntryController.submitGradeEntry);

module.exports = router;