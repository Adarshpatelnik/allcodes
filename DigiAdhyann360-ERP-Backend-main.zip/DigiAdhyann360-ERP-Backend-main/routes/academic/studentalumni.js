const express = require('express');
const router = express.Router();
const { getAlumniStudentsList, promoteStudentsToAlumni } = require('../../controllers/academic/studentalumni');

// Route to fetch alumni students
router.get('/get-alumniStudents', getAlumniStudentsList);

// Route to promote students to alumni
router.post('/alumniStudents', promoteStudentsToAlumni);

module.exports = router;