const express = require('express');
const router = express.Router();
const { getStudentAssignmentRecord } = require('../../controllers/academic/studentassignment');

// Define GET endpoint for student assignment records
router.get('/studentassignmentrecord', getStudentAssignmentRecord);

module.exports = router;