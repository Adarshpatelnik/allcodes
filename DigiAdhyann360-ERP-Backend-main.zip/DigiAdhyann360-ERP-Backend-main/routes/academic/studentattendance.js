const express = require('express');
const router = express.Router();
const { getClassListController, getAttendanceListController, submitAttendanceController, checkAttendanceStatusController, getAttendanceCountsController } = require('../../controllers/academic/studentattendance');

router.get('/classlist', getClassListController);
router.get('/attendancelist', getAttendanceListController);
router.post('/submit-attendance', submitAttendanceController);
router.get('/check-attendance-status', checkAttendanceStatusController);
router.get('/attendance-counts', getAttendanceCountsController);

module.exports = router;