const express = require('express');
const router = express.Router();
const { getAllStudents, getStudent, updateStudent, setStudentIdToken } = require('../../controllers/academic/studentdetail');

// Route to get all student profiles
router.get('/studentprofile', getAllStudents);

// Route to get a specific student by ID
router.get('/studentupdate/:studentId', getStudent);

// Route to update a specific student by ID
router.put('/studentupdate/:studentId', updateStudent);

// Route to set student ID in JWT token
router.get('/SetStudentId/:studentId', setStudentIdToken);

module.exports = router;