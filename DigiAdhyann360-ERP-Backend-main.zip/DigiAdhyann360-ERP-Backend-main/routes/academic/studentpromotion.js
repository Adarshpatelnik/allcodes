const express =  require('express');
const router = express.Router();
const {
  getPromotableStudentsController,
  promoteStudentsController,
} = require('../../controllers/academic/studentpromotion');

router.get('/promotestudent', getPromotableStudentsController);
router.post('/promoteStudents', promoteStudentsController);

module.exports = router;