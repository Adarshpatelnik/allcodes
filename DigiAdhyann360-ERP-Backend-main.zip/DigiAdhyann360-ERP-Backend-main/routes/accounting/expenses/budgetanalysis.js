// backend/routes/accounting/expense/budgetanalysis.js
const express = require('express');
const router = express.Router();
const {
  getTotalBudgetController,
  getCategoryWiseTotalBudgetController,
} = require('../../../controllers/accounting/expenses/budgetanalysis');

router.get('/gettotalbudget', getTotalBudgetController);
router.get('/getcategorywisetotalbudget', getCategoryWiseTotalBudgetController);

module.exports = router;