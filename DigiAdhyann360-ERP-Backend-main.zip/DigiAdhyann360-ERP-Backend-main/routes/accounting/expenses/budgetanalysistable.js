// backend/routes/accounting/expense/budgetanalysistable.js
const express = require('express');
const router = express.Router();
const { getTotalBudgetTotalExpenseController } = require('../../../controllers/accounting/expenses/budgetanalysistable');

router.get('/gettotalbudgettotalexpense', getTotalBudgetTotalExpenseController);

module.exports = router;