const express = require('express');
const router = express.Router();
const {
  submitAcctExpenseCategoryController,
  getAcctExpenseCategoryController,
  deleteAcctExpenseCategoryController,
} = require('../../../controllers/accounting/expenses/expensecategories');

// POST Submit Expense Category (Insert or Update)
router.post('/submit-acctexpensecategory', submitAcctExpenseCategoryController);

// GET Fetch All Expense Categories
router.get('/get-acctexpensecategory', getAcctExpenseCategoryController);

// DELETE Delete an Expense Category by ID
router.delete('/delete-acctexpensecategory/:id', deleteAcctExpenseCategoryController);

module.exports = router;