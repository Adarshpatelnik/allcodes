
const express = require('express');
const router = express.Router();
const {
  getExpenseCategoryController,
  deleteExpenseCategoryController,
  submitExpenseCategoryController,
  getExpenseCategoriesController,
} = require('../../../controllers/accounting/expenses/expensedetail');

router.get('/getacctexpensecategory', getExpenseCategoryController);
router.delete('/deleteacctexpensecategory/:categoryId', deleteExpenseCategoryController);
router.post('/submitacctexpensecategory', submitExpenseCategoryController);
router.get('/getexpensecategories', getExpenseCategoriesController); // Corrected route

module.exports = router;
