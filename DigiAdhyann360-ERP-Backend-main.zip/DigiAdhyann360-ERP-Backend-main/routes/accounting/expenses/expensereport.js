// backend/routes/account/expense/expensereport.js
const express = require('express');
const router = express.Router();
const {
  getAcctTotalExpenseController,
  getAcctTotalBudgetThisMonthController,
  getExpenseFromBudgetController,
  getAcctExpenseByCategoryController,
} = require('../../../controllers/accounting/expenses/expensereport');

router.get('/getaccttotalexpense', getAcctTotalExpenseController);
router.get('/getaccttotalbudgetthismonth', getAcctTotalBudgetThisMonthController);
router.get('/getexpensefrombudget', getExpenseFromBudgetController);
router.get('/getacctexpensebycategory', getAcctExpenseByCategoryController);

module.exports = router;