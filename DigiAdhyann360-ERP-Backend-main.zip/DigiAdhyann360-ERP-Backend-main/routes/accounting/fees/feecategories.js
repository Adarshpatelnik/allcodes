const express = require('express');
const router = express.Router();
const {
  createCategoryController,
  getCategoriesController,
  deleteCategoryController,
  updateCategoryController,
} = require('../../../controllers/accounting/fees/feecategories'); // Path is correct

// Match frontend endpoints exactly
router.get('/Categories', getCategoriesController); // Capital 'C' for GET
router.post('/categories', createCategoryController);
router.delete('/categoriesdelete/:id', deleteCategoryController);
router.put('/categoriesedit/:id', updateCategoryController);

module.exports = router;