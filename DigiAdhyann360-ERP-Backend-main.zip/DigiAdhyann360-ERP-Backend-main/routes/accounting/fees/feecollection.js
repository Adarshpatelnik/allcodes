

const express = require('express');
  const router = express.Router();
  const {
    getClassesController,
    getFrequenciesController,
    getStudentFeesByClassAndFrequencyController,
    insertFeeRecordsController,

    updateFeeRecordController,
    deleteFeeRecordController,
  } = require('../../../controllers/accounting/fees/feecollection');

  // GET Classes
  router.get('/feesclasses', getClassesController);

  // GET Frequencies
  router.get('/frequencies', getFrequenciesController);

  // GET Students Fees By Class and Frequency
  router.get('/studentfeesRecord/:class/:frequency', getStudentFeesByClassAndFrequencyController);

  // POST Insert Fee Records (Bulk)
  router.post('/submit-fee-records', insertFeeRecordsController);

  // PUT Update Fee Record
  router.put('/update-fee-record', updateFeeRecordController);

  // DELETE Fee Record
  router.delete('/fee-record/:recordId', deleteFeeRecordController);

  module.exports = router;