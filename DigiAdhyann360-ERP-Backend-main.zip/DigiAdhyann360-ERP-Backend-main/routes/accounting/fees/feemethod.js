

const express = require('express');
const router = express.Router();
const {
  getFeeCollectionController,
  updateFeeCollectionController,
  deleteFeeCollectionController,
} = require('../../../controllers/accounting/fees/feemethod');

// GET: Fetch fee collection methods
router.get('/fee-collectiontype', getFeeCollectionController);

// POST: Insert or update collection method
router.post('/fee-collection', updateFeeCollectionController);

// DELETE: Remove collection method by ID
router.delete('/fee-collection/:collectionId', deleteFeeCollectionController);

module.exports = router;