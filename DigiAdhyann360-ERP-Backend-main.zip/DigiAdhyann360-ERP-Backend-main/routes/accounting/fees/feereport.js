const express = require('express');
const router = express.Router();
const { getFeeCollectionByCategoryController } = require('../../../controllers/accounting/fees/feereport');

// GET Fee Collection by Category
router.get('/fee-collectioncategory', getFeeCollectionByCategoryController);

module.exports = router;