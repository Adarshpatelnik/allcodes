

const express = require('express');
const router = express.Router();
const {
  getClassesController,
  getCategoriesController,
  getFeeStructureController,
  getCollectionTypesController,
  getFrequenciesController,
  addFeeStructureController,
  updateFeeStructureController,
  deleteFeeStructureByClassFrequencyAndCollectionController,
} = require('../../../controllers/accounting/fees/feestructure');

// GET Classes
router.get('/feestructure-Classes', getClassesController);

// GET Categories
router.get('/feestructure-Categories', getCategoriesController);

// GET Fee Structure
router.get('/get-fee-structure', getFeeStructureController);

// GET Collection Types
router.get('/feestructure-CollectionTypes', getCollectionTypesController);

// GET Frequencies
router.get('/feestructure-Frequencies', getFrequenciesController);

// POST Fee Structure
router.post('/post-fee-structure', addFeeStructureController);

// PUT Fee Structure
router.put('/fee-structure', updateFeeStructureController);

// DELETE Fee Structure by Class, Frequency, and Collection Type
router.delete('/fee-structure/class/:class/frequency/:frequency/collection/:collection', deleteFeeStructureByClassFrequencyAndCollectionController);

module.exports = router;