const express = require('express');
const router = express.Router();
const { fetchStudentPaymentDetails, submitFeeTransaction } = require('../../../controllers/accounting/fees/studentcashpayment');

router.get('/student-payment/:studentId', fetchStudentPaymentDetails);
router.post('/payments', submitFeeTransaction);

module.exports = router;