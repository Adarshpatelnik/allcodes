const express = require('express');
const router = express.Router();
const {
  getAcctStaffDetails,
  getStaffById,
  updateAcct,
  deleteAcctStaff,
} = require('../../../controllers/accounting/payroll/payrollemployees');

router.get('/get-acctstaffdetails', getAcctStaffDetails);
router.post('/get-staff-by-id', getStaffById);
router.put('/update-acctstaffdetails/:id', updateAcct);
router.delete('/delete-acctstaffdetails/:id', deleteAcctStaff);

module.exports = router;