// const express = require('express');
// const router = express.Router();
// const PayrollRecordStaffController = require('../../../controllers/accounting/payroll/payrollrecordstaff');
// const { authMiddleware } = require('../../../middleware/authmiddleware');

// router.get('/getsalarycomponentsdynamiccolumn', authMiddleware, PayrollRecordStaffController.getDynamicSalaryComponents);
// router.get('/get-staff-list', authMiddleware, PayrollRecordStaffController.getPayrollStaffList);
// router.get('/get-payroll-records', authMiddleware, PayrollRecordStaffController.getPayrollRecords);

// module.exports = router;




const express = require('express');
const router = express.Router();
const PayrollRecordStaffController = require('../../../controllers/accounting/payroll/payrollrecordstaff');
const { authMiddleware } = require('../../../middleware/authmiddleware');

router.get('/getsalarycomponentsdynamiccolumn', authMiddleware, PayrollRecordStaffController.getDynamicSalaryComponents);
router.get('/get-staff-list', authMiddleware, PayrollRecordStaffController.getPayrollStaffList);
router.get('/get-payroll-records', authMiddleware, PayrollRecordStaffController.getPayrollRecords);
router.post('/submit-payroll-record', authMiddleware, PayrollRecordStaffController.submitPayrollRecord);

module.exports = router;