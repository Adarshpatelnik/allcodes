const express = require('express');
const router = express.Router();
const { getStaffPayrollRecordsController } = require('../../../controllers/accounting/payroll/payrollrecordstaffview');

router.get('/getstaffviewpayrollrecords', getStaffPayrollRecordsController);

module.exports = router;