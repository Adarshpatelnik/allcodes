const express = require("express");
const router = express.Router();
const { authMiddleware } = require("../../../middleware/authmiddleware");
const payrollController = require("../../../controllers/accounting/payroll/processsalary");

router.get("/get-processpayroll", authMiddleware, payrollController.getPayrollRecords);
router.get("/get-inprogress-payroll", authMiddleware, payrollController.getInProgressPayrollRecords);
router.get("/get-paid-payroll", authMiddleware, payrollController.getPaidPayrollRecords);
router.post("/update-payroll-status", authMiddleware, payrollController.updatePayrollStatus);
router.post("/submit-processsalaryrecords", authMiddleware, payrollController.submitPayrollRecords);

module.exports = router;