const express = require('express');
const router = express.Router();
const SalaryComponentController = require('../../../controllers/accounting/payroll/salarycomponents');
const { authMiddleware } = require('../../../middleware/authmiddleware');

router.get('/get-acctsalarycomponent', authMiddleware, SalaryComponentController.getSalaryComponents);
router.post('/submit-acctsalarycomponent', authMiddleware, SalaryComponentController.submitSalaryComponent);
router.delete('/delete-acctsalarycomponent/:id', authMiddleware, SalaryComponentController.deleteSalaryComponent);

module.exports = router;
