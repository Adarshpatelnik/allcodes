const express = require('express');
const router = express.Router();
const {
  getAcctGeneralLedgerController,
  getAcctLedgerController,
  getAcctExpenseCategoriesController,
} = require('../../../controllers/accounting/smartledger/generalledger');


router.get('/get-acctgeneralledger', getAcctGeneralLedgerController);
router.get('/get-acctledger', getAcctLedgerController);
router.get('/get-acctexpensecategories', getAcctExpenseCategoriesController);

module.exports = router;