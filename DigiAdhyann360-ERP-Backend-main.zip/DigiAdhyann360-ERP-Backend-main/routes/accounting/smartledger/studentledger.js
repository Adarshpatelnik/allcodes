const express = require('express');
const router = express.Router();
const {
  getAcctGeneralLedgerController,
  getAcctLedgerController,
  getAcctExpenseCategoriesController,
  getAcctStudentTrnsHistoryController,
  getAcctStudentTrnsFeeCategoryController,
  getAcctStudentProfileController,
  getAcctClassDetailController,
  getStudentClassMappingController,
} = require('../../../controllers/accounting/smartledger/studentledger');
 

router.get('/get-acctgeneralledger', getAcctGeneralLedgerController);
 router.get('/get-acctledger', getAcctLedgerController);
 router.get('/get-acctexpensecategories', getAcctExpenseCategoriesController);
router.get('/get-acctstudenttrnshistory', getAcctStudentTrnsHistoryController);
router.get('/get-acctstudenttrnsfeecategory', getAcctStudentTrnsFeeCategoryController);
 router.get('/get-acctstudentprofile', getAcctStudentProfileController);
router.get('/get-acctclassdetail', getAcctClassDetailController);
router.get('/get-student-class-mapping', getStudentClassMappingController);
 
module.exports = router;