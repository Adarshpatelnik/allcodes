
const express = require('express');
const router = express.Router();
const { uploadSchoolLogoToS3 } = require('../../middleware/awsupload'); // 👈 NOT aws.js
const { authMiddleware, globalMiddleware } = require('../../middleware/authmiddleware');
const {
  attachIdentifiers,
  uploadSchoolLogo,
} = require('../../services/adminprofile/schoolprofile');
const {
  getSchoolProfileController,
  getSchoolLogoController,
  uploadSchoolLogoController,
  updateSchoolProfileController,
} = require('../../controllers/adminprofile/schoolprofile');

// ✅ Add this GET route for fetching school profile
router.get(
  '/SchoolProfile',
  authMiddleware,
  attachIdentifiers,
  getSchoolProfileController
);

// ✅ Also add this GET route for fetching school logo (used in frontend)
router.get(
  '/get-school-logo',
  authMiddleware,
  attachIdentifiers,
  getSchoolLogoController
);

// Existing upload route
router.post(
  '/upload-school-logo',
  authMiddleware,
  attachIdentifiers,
  uploadSchoolLogoToS3,
  uploadSchoolLogoController
);

// New update route
router.put(
  '/update-school-profile',
  authMiddleware,
  attachIdentifiers,
  updateSchoolProfileController
);

module.exports = router;