const express = require('express');
const router = express.Router();
const { classScheduleOneTimeLoad } = require('../../controllers/bulkload/classscheduleonetimeload');

router.post('/BulkLoadForClassSchedule', classScheduleOneTimeLoad);

module.exports = router;