const express = require('express');
const router = express.Router();
const StaffBulkLoadController = require('../../controllers/bulkload/staffonetimeload');

router.post('/StaffBulkLoad', StaffBulkLoadController.bulkLoadStaff);

module.exports = router;