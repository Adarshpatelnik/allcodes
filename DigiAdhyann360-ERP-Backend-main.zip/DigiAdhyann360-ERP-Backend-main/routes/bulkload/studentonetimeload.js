const express = require('express');
const router = express.Router();
const { studentOneTimeLoad } = require('../../controllers/bulkload/studentonetimeload');

router.post('/StudentOnetimeload', studentOneTimeLoad);

module.exports = router;