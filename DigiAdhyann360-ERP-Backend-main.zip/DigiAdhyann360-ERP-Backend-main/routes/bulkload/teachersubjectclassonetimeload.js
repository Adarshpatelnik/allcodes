const express = require('express');
const router = express.Router();
const { teacherClassSubjectOneTimeLoad } = require('../../controllers/bulkload/teachersubjectclassonetimeload');

router.post('/BulkLoadForTeacherClassSubject', teacherClassSubjectOneTimeLoad);

module.exports = router;