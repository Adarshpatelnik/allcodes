const express = require('express');
const router = express.Router();
const { getClassesController } = require('../../controllers/common/class');


router.get('/classes', getClassesController);

module.exports = router;