const express = require('express');
const router = express.Router();
const { getSectionsController } = require('../../controllers/common/section');

router.get('/sections', getSectionsController);

module.exports = router;