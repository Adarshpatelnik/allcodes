const express = require('express');
const router = express.Router();
const { 
  getStudentCountController, 
  getSchoolProfileController, 
  getStaffCountController, 
  getWorkingStaffController 
} = require('../../../controllers/home/Academicdashoard/academicdashboard');

router.get('/studentcountdetails', getStudentCountController);
router.get('/SchoolProfile', getSchoolProfileController);
router.get('/staffcount', getStaffCountController);
router.get('/workingStaff', getWorkingStaffController);

module.exports = router;