const express = require('express');
const router = express.Router();
const { getEventsController } = require('../../../controllers/home/Academicdashoard/eventcalendar');

router.get('/events', getEventsController);

module.exports = router;