const express = require('express');
const router = express.Router();
const { getNoticeboardController } = require('../../../controllers/home/Academicdashoard/noticeboard');

router.get('/noticeboard', getNoticeboardController);

module.exports = router;