
const express = require('express');
const router = express.Router();
const { getAttendanceSummaryController } = require('../../../controllers/home/Academicdashoard/studentattendancechart');

router.get('/class-attendance-summary', getAttendanceSummaryController);

module.exports = router;