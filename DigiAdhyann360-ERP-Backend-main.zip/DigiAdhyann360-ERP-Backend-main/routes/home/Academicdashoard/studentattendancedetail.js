const express = require('express');
const router = express.Router();
const { getStudentAttendanceDetailController } = require('../../../controllers/home/Academicdashoard/studentattendancedetail');

router.get('/studentattendancedetail', getStudentAttendanceDetailController);

module.exports = router;