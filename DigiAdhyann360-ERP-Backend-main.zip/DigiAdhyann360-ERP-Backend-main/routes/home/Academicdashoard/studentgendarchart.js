const express = require('express');
const router = express.Router();
const { getStudentGenderController } = require('../../../controllers/home/Academicdashoard/studentgendarchart');

router.get('/studentgender', getStudentGenderController);

module.exports = router;