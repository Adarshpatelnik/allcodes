const express = require('express');
const router = express.Router();
const studentGenderDetailController = require('../../../controllers/home/Academicdashoard/studentgendardetail');

router.get('/CasteDistribution', studentGenderDetailController.getCasteDistribution);
router.get('/StudentDetailsByClass', studentGenderDetailController.getStudentDetailsByClass);

module.exports = router;