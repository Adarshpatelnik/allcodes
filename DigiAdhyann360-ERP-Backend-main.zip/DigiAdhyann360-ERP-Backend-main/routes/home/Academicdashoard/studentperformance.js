const express = require('express');
const router = express.Router();
const { getPerformanceSummaryController } = require('../../../controllers/home/Academicdashoard/studentperformance');

router.get('/PerformanceSummary', getPerformanceSummaryController);

module.exports = router;