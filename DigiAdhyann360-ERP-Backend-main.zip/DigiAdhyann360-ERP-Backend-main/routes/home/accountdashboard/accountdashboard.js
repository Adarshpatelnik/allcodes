// backend/routes/accounting/expense/accountdashboard.js
const express = require('express');
const router = express.Router();
const {
  getTotalExpenseForDashboardController,
  getFeeCollectionRateForDashboardController,
} = require('../../../controllers/home/accountdashboard/accountdashboard');

router.get('/get-totalexpensefordashboard', getTotalExpenseForDashboardController);
router.get('/get-feecollectionratefordashboard', getFeeCollectionRateForDashboardController);

module.exports = router;