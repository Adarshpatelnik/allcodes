const express = require('express');
const router = express.Router();
const ExpenseGrouthController = require('../../../controllers/home/accountdashboard/expensegrouthtable');
const { authMiddleware } = require('../../../middleware/authmiddleware');

router.get('/ExpenseGrouth', authMiddleware, ExpenseGrouthController.getExpenseGrouth);

module.exports = router;
