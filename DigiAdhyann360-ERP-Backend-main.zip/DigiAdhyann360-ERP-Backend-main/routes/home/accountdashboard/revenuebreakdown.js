const express = require('express');
const router = express.Router();
const TotalRevenueController = require('../../../controllers/home/accountdashboard/revenuebreakdown');
const { authMiddleware } = require('../../../middleware/authmiddleware');

router.get('/TotalRevenue', authMiddleware, TotalRevenueController.getTotalRevenue);

module.exports = router;