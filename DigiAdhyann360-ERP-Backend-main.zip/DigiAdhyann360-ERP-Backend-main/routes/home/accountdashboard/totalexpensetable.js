const express = require('express');
const router = express.Router();
const TotalExpenseController = require('../../../controllers/home/accountdashboard/totalexpensetable');
const { authMiddleware } = require('../../../middleware/authmiddleware');

router.get('/TotalExpenseTable', authMiddleware, TotalExpenseController.getTotalExpense); 

module.exports = router;
