const express = require('express');
const router = express.Router();
const { getStaffAttendance } = require('../../../controllers/home/hrdashboard/staffattendancechart');

router.get('/staffAttendance', getStaffAttendance);

module.exports = router;