const express = require('express');
const router = express.Router();
const { getTeacherReassign } = require('../../../controllers/home/hrdashboard/teacherallocation');

router.get('/TeacherReassign', getTeacherReassign);

module.exports = router;