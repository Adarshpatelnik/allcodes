const express = require('express');
const router = express.Router();
const StaffApprovalController = require('../../controllers/hr/staffapprovalstatus');
const controllerInstance = new StaffApprovalController();

router.get( '/STAFF_REGISTRATION',controllerInstance.getPendingRegistrations.bind(controllerInstance) );
router.post('/staffApproval', StaffApprovalController.validateApproval(),  controllerInstance.processApproval.bind(controllerInstance) );

module.exports = router;