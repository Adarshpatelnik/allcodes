const express = require('express');
const router = express.Router();
const StaffAttendanceDetailController = require('../../controllers/hr/staffattendancedetail');

router.get('/staffattendancebarchart', StaffAttendanceDetailController.getAttendanceData);

module.exports = router;