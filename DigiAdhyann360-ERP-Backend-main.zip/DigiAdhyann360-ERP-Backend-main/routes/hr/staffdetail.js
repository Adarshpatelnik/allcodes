const express = require('express');
const router = express.Router();
const StaffDetailController = require('../../controllers/hr/staffdetail');

router.get('/staffupdate/:staffId', StaffDetailController.getStaffDetail);
router.put('/staffupdate/:staffId', StaffDetailController.updateStaffDetail);

module.exports = router;