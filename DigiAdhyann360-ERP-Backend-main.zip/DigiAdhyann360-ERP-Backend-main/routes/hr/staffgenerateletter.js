const express = require('express');
const router = express.Router();
const { fetchStaffGenerateLetterData } = require('../../controllers/hr/staffgenerateletter');

router.get('/StaffGenerateLetter', fetchStaffGenerateLetterData);

module.exports = router;