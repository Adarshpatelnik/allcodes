const express = require('express');
const router = express.Router();
const StaffLeaveBalanceController = require('../../controllers/hr/staffleavebalance');

router.get('/get-leave-balance', StaffLeaveBalanceController.getLeaveBalances);

module.exports = router;