const express = require('express');
const router = express.Router();
const StaffLeaveTypeController = require('../../controllers/hr/staffleavetype');

router.get('/staff-roles', StaffLeaveTypeController.getStaffRoles);
router.get('/leave-data', StaffLeaveTypeController.getLeaveData);
router.post('/add-leave', StaffLeaveTypeController.addLeaveType);
router.put('/update-leave/:num', StaffLeaveTypeController.updateLeaveType);
router.delete('/delete-leave/:num', StaffLeaveTypeController.deleteLeaveType);

module.exports = router;