const express = require('express');
const router = express.Router();
const StaffProfileController = require('../../controllers/hr/staffprofile');

router.get('/Staff_Profile', StaffProfileController.getAllStaffProfiles);
router.get('/SetStaffId/:staffId', StaffProfileController.setStaffId);

module.exports = router;