const express = require('express');
const router = express.Router();
const StaffRegistrationController = require('../../controllers/hr/staffregistrationform');

router.post('/teacherhiring', StaffRegistrationController.addStaff);

module.exports = router;