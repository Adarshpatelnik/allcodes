const express = require('express');
const router = express.Router();
const StaffRegistrationController = require('../../controllers/hr/staffregistrationlist');
const controllerInstance = new StaffRegistrationController();

// GET: All staff registration data (with all statuses)
router.get('/staffregistration', controllerInstance.getAllStaffRegistrations.bind(controllerInstance));

module.exports = router;
