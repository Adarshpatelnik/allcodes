const express = require('express');
const router = express.Router();
const StaffScheduleController = require('../../controllers/hr/staffschedule');

router.delete('/scheduleclassdatadelete', StaffScheduleController.deleteSchedule);
router.put('/scheduleclassdata', StaffScheduleController.upsertSchedule);
router.get('/class_sections', StaffScheduleController.getClassSections);
router.get('/schedule_class_data', StaffScheduleController.getScheduleData);

module.exports = router;