const express = require('express');
const { loginUserController, developerLoginController } = require('../../controllers/login/login');

const router = express.Router();

router.post('/login', loginUserController);
router.post('/developer', developerLoginController);

module.exports = router;