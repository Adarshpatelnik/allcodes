const express = require('express');
const router = express.Router();
const adminNotificationController = require('../../controllers/notification/adminnotification');

router.get('/get-staff-notification', adminNotificationController.getStaffNotification);
router.get('/getleaverequests', adminNotificationController.getLeaveRequests);
router.get('/getparentraiseissuecount', adminNotificationController.getParentRaiseIssueCount);
router.get('/studenteditrequestcount', adminNotificationController.getStudentEditRequestCount);

module.exports = router;