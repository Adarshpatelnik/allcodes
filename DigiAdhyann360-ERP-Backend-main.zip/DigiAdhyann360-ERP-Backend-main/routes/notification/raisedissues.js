const express = require('express');
const router = express.Router();
const raisedIssuesController = require('../../controllers/notification/raisedissues');

router.get('/getraiseissuelist', raisedIssuesController.getRaiseIssueList);
router.post('/updateraiseissuelist', raisedIssuesController.updateRaiseIssueStatus);

module.exports = router;