const express = require('express');
const router = express.Router();
const staffAttendanceController = require('../../controllers/notification/staffattendanceapproval');

router.get('/getstaffattendanceapproval', staffAttendanceController.getStaffAttendanceApproval);
router.get('/getstaffleaveapproval', staffAttendanceController.getStaffLeaveApproval);
router.post('/updatestaffattendanceapproval', staffAttendanceController.updateStaffAttendanceApproval);
router.post('/updatestaffleaveapproval', staffAttendanceController.updateStaffLeaveApproval);

module.exports = router;