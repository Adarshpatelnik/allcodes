const express = require('express');
const router = express.Router();
const studentNotificationController = require('../../controllers/notification/studentnotification');

router.get('/student-data', studentNotificationController.getStudentData);
router.post('/update-status', studentNotificationController.updateStatus);
router.post('/update-student-profile', studentNotificationController.updateStudentProfile);

module.exports = router;