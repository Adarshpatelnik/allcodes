const express = require('express');
const router = express.Router();
const { createRazorpayOrderController, verifyRazorpaySignatureController,savePaymentController } = require('../../controllers/payment/razorpay');


router.post('/create-razorpay-order', createRazorpayOrderController);
router.post('/verify-razorpay-signature', verifyRazorpaySignatureController);
router.post('/save-payment', savePaymentController);

module.exports = router;