const express = require('express');
const router = express.Router();
const { getServicesController, addTenantServiceController,validateCouponController } = require('../../controllers/signup/erpservices');

router.get('/get-services', getServicesController);
router.post('/add-tenant-service', addTenantServiceController);
router.post('/validate-coupon', validateCouponController);

module.exports = router;