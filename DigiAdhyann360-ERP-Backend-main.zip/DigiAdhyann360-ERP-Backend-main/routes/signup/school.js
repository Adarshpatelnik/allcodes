const express = require('express');
const router = express.Router();
const { getLatestSchoolController } = require('../../controllers/signup/school');
router.get('/get-latest-school', getLatestSchoolController);
module.exports = router;
