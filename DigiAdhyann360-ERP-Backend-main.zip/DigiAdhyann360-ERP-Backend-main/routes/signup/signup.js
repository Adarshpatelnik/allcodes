const express = require('express');
const { signupUserController } = require('../../controllers/signup/signup');

const router = express.Router();

router.post('/signup', signupUserController);

module.exports = router;