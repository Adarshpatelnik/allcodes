const express = require('express');
const router = express.Router();
const { getAssignmentDataController, teacherApprovalController } = require('../../controllers/staff/staffapproveassignment');
const logger = require('../../logger/logger');

logger.info('Registering staff select assignment routes');

router.get('/get-assignment-data', (req, res, next) => {
  logger.info('GET /api/staff/get-assignment-data called');
  getAssignmentDataController(req, res, next);
});

router.post('/teacher-approval', (req, res, next) => {
  logger.info('POST /api/staff/teacher-approval called', { body: req.body });
  teacherApprovalController(req, res, next);
});

module.exports = router;