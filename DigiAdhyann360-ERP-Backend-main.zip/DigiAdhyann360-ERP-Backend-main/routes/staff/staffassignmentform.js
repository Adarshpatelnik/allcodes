const express = require('express');
const router = express.Router();
const { getAssignments, submitAssignmentData } = require('../../controllers/staff/staffassignmentform');

router.get('/assignment', getAssignments);
router.post('/assignmentdata', submitAssignmentData);

module.exports = router;