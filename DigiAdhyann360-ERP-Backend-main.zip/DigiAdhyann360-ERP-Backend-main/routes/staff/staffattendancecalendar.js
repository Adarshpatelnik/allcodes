
const express = require('express');
const router = express.Router();
const staffAttendanceCalendarController = require('../../controllers/staff/staffattendancecalendar');

router.get('/staffattendancecalendar/get-attendance', staffAttendanceCalendarController.getAttendance);
router.get('/staffattendancecalendar/get-leave', staffAttendanceCalendarController.getLeave);
router.get('/staffattendancecalendar/get-leave-type', staffAttendanceCalendarController.getLeaveType);
router.post('/staffattendancecalendar/submit-leave', staffAttendanceCalendarController.submitLeave);
router.post('/staffattendancecalendar/submitattendance', staffAttendanceCalendarController.submitAttendance);
router.get('/staffattendancecalendar/get-staff-gender', staffAttendanceCalendarController.getStaffGender);

module.exports = router;