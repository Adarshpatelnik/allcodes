const express = require('express');
const router = express.Router();
const myAttendanceController = require('../../../controllers/staff/staffdashboard/myattendance');

router.get('/STAFFDASHBOARD', myAttendanceController.getMyAttendance);

module.exports = router;