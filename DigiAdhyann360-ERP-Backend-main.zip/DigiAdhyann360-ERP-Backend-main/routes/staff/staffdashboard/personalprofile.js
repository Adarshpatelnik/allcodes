const express = require('express');
const router = express.Router();
const { getStaffPersonalProfile } = require('../../../controllers/staff/staffdashboard/personalprofile');

router.get('/StaffPersonalProfile', getStaffPersonalProfile);

module.exports = router;