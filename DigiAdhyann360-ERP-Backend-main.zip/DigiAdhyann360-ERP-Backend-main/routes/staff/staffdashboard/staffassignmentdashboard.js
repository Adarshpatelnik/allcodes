const express = require('express');
const router = express.Router();
const { getStaffAssignmentDashboard } = require('../../../controllers/staff/staffdashboard/staffassignmentdashboard');

router.get('/StaffAssignmentDashboard', getStaffAssignmentDashboard);

module.exports = router;