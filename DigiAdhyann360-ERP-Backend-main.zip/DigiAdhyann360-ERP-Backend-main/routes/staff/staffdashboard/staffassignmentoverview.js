const express = require('express');
const router = express.Router();
const staffAssignmentOverviewController = require('../../../controllers/staff/staffdashboard/staffassignmentoverview');

router.get('/StaffAssignmentDashboad', staffAssignmentOverviewController.getStaffAssignmentOverview);

module.exports = router;