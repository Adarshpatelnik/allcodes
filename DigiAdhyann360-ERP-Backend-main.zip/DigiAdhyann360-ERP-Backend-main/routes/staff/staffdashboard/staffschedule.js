const express = require('express');
const router = express.Router();
const { getClassSchedule } = require('../../../controllers/staff/staffdashboard/staffschedule')
router.get('/schedule', getClassSchedule);

module.exports = router;