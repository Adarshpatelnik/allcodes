const express = require('express');
const router = express.Router();

const staffTimetableController = require('../../../controllers/staff/staffdashboard/stafftimetable');

router.get('/stafftimetable', staffTimetableController.getStaffTimetable);



module.exports = router;