
const express = require('express');
const router = express.Router();
const studentListController = require('../../../controllers/staff/staffdashboard/studentlist');

router.get('/studentlist', studentListController.getStudentList);

module.exports = router;




