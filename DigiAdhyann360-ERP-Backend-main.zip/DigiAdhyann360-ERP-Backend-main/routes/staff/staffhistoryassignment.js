const express = require('express');
const router = express.Router();
const { getAssignmentRecord } = require('../../controllers/staff/staffhistoryassignment');
 
router.get('/get-assignmentrecord', getAssignmentRecord);
 
module.exports = router;