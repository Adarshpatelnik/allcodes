const express = require('express');
const router = express.Router();
const staffPersonalProfileController = require('../../controllers/staff/staffpersonalprofile');

router.get('/staffpersonalprofile', staffPersonalProfileController.getStaffPersonalProfile);

module.exports = router;