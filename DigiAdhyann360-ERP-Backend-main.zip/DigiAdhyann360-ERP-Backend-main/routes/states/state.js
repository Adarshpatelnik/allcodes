const express = require('express');
const { getIndianStatesController, getIndianDistrictsController, getIndianPincodesController } = require('../../controllers/states/state');

const router = express.Router();

router.get('/indian-states', getIndianStatesController);
router.get('/indian-districts/:state', getIndianDistrictsController);
router.get('/indian-pincodes/:district', getIndianPincodesController);

module.exports = router;