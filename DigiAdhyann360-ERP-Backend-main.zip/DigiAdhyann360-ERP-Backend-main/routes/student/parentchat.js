
const express = require('express');
const multer = require('multer');
const { authMiddleware } = require('../../middleware/authmiddleware');
const { getCurrentStudentDetails, raiseIssue } = require('../../controllers/student/parentchat');

const router = express.Router();
const upload = multer(); // memory storage

// GET current student details
router.get('/getCurrentStudentDetails', authMiddleware, getCurrentStudentDetails);

// FIXED: POST Raise Issue with multer middleware
router.post('/RaiseIssue', authMiddleware, upload.single('attachment'), raiseIssue);

module.exports = router;
