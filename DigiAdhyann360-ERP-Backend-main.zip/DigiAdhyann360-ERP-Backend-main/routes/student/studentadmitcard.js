const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../../middleware/authmiddleware');
const { getSchoolDetails, getStudentDetails, getExamSchedule, generateAdmitCard } = require('../../controllers/student/studentadmitcard');
 
router.get('/getSchoolDetails', authMiddleware, getSchoolDetails);
router.get('/getStudentsstude', authMiddleware, getStudentDetails);
router.get('/getExamSchedule', authMiddleware, getExamSchedule);
router.post('/generateAdmitCard', authMiddleware, generateAdmitCard);
 
module.exports = router;