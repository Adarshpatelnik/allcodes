const express = require('express');
const router = express.Router();
const { getAssignmentsController, submitAssignmentsController } = require('../../controllers/student/studentassignment');

router.get('/assignments', getAssignmentsController);
router.post('/submit-assignment', submitAssignmentsController);

module.exports = router;