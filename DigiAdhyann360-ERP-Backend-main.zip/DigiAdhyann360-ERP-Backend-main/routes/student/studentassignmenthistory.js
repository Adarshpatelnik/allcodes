const express = require('express');
const router = express.Router();
const { getAssignmentHistoryController } = require('../../controllers/student/studentassignmenthistory');

router.get('/assignmenthistory', getAssignmentHistoryController);

module.exports = router;