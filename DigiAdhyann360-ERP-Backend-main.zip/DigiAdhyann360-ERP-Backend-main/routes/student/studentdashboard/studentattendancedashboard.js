const express = require('express');
const router = express.Router();
const { getDashboardStudentAttendance } = require('../../../controllers/student/studentdashboard/studentattendancedashboard');

router.get('/dashbordstudentattendance', getDashboardStudentAttendance);

module.exports = router;