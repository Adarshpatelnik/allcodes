const express = require('express');
const router = express.Router();
const studentPerformanceChartController = require('../../../controllers/student/studentdashboard/studentperformancechart');
// 

router.get('/studentperformancechart', studentPerformanceChartController.getStudentPerformanceChart);

module.exports = router;