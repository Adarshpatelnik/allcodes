const express = require('express');
const router = express.Router();
const { getTimetable } = require('../../../controllers/student/studentdashboard/studenttimetable');

router.get('/timetable', getTimetable);

module.exports = router;