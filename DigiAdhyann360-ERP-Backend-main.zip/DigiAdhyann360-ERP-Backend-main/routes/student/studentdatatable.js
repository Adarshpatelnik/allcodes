const express = require('express');
const router = express.Router();
const { getStudentDataController, updateStatusController, updateStudentProfileController } = require('../../controllers/student/studentdatatable');

router.get('/student-data', getStudentDataController);
router.post('/update-status', updateStatusController);
router.post('/update-student-profile', updateStudentProfileController);

module.exports = router;