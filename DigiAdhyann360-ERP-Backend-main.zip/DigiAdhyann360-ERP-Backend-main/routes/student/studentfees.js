const express = require('express');
const router = express.Router();
const {createOrder,verifyPayment,fetchClasses,fetchFrequencies,fetchStudentsAndFees,fetchStudentById,fetchFeeDetailsByStudentId, fetchCurrentStudent,fetchFinancialYears}
 = require('../../controllers/student/studentfees');

router.post('/payment/Create-Order', createOrder);
router.post('/Payment-Verification', verifyPayment);
router.get('/classes', fetchClasses);
router.get('/frequencies', fetchFrequencies);
router.get('/students-and-fees', fetchStudentsAndFees);
router.get('/student/:studentId', fetchStudentById);
router.get('/fee-details/:studentId', fetchFeeDetailsByStudentId);
router.get('/current-student', fetchCurrentStudent);
router.get('/financial-years', fetchFinancialYears);

module.exports = router;