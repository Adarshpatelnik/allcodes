
const express = require('express');
const { authMiddleware } = require('../../middleware/authmiddleware');
const { getStudentProfile, updateStudentProfile } = require('../../controllers/student/studentprofiledashboard');

const router = express.Router();

router.get('/student-profile', authMiddleware, getStudentProfile);
router.put('/student-profile', authMiddleware, updateStudentProfile); // New update route

module.exports = router;