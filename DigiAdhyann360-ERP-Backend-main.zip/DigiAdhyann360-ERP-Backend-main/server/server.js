const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const logger = require('../logger/logger');
const { closeAllPools } = require('../config/db');
const { globalMiddleware, payloadTooLargeMiddleware, asyncLocalStorage } = require('../middleware/authmiddleware');
 
dotenv.config({ path: './.env' });
 
const app = express();
 
// Enable CORS
app.use(cors());
 
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
 
// Log incoming requests
app.use((req, res, next) => {
  logger.info('Incoming request', { method: req.method, url: req.url, body: req.body });
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store contents', { store: store ? Array.from(store.entries()) : null });
  next();
});
 
 
// Error handling API route
app.post('/api/send-error', async (req, res) => {
  const { error, errorInfo, timestamp } = req.body;
 
  const message = {
    to: 'eng.adarshpatel@gmail.com',
    from: process.env.FROM_EMAIL,
    subject: 'React App Error Alert',
    text: `An error occurred in the React app at ${timestamp}:\n\nError: ${error}\n\nAdditional Info: ${JSON.stringify(errorInfo)}`,
  };
 
  try {
    await sendgrid.send(message);
    logger.info('Error email sent successfully', { timestamp });
    res.status(200).send('Error email sent successfully');
  } catch (err) {
    logger.error('Error sending email:', err);
    res.status(500).send('Error sending email');
  }
});
// Apply global middleware (includes tenantContextMiddleware and authMiddleware)
app.use(globalMiddleware);
 
// Import routes
logger.info('Mounting /api routes');
app.use('/api', require('../routes/login/login'));
app.use('/api', require('../routes/signup/signup'));
app.use('/api', require('../routes/signup/erpservices'));
app.use('/api', require('../routes/states/state'));

// ================================================//payment// ========================

app.use('/api', require('../routes/payment/razorpay'));
app.use('/api',require('../routes/signup/school'))


// ================================================academic dashboard========================
// =============================common api======================================
app.use('/api',require('../routes/common/class'));
app.use('/api',require('../routes/common/section'));
// =========================================academic api==========================================================
app.use('/api', require('../routes/academic/Studentprofile'));
app.use('/api', require('../routes/academic/studentalumni'));
app.use('/api', require('../routes/academic/parentdetail'));
app.use('/api', require('../routes/academic/parentprofile'));
app.use('/api', require('../routes/academic/studentattendance'));
app.use('/api', require('../routes/academic/generatecertificate'));
app.use('/api', require('../routes/academic/enrollment'));
app.use('/api', require('../routes/academic/applicationlist'));
app.use('/api', require('../routes/academic/applicationtracker'));
app.use('/api', require('../routes/academic/applicationdocform'));
app.use('/api', require('../routes/academic/applicationdoclist'));
app.use('/api', require('../routes/academic/recordmarks'));
app.use('/api', require('../routes/academic/exampattern'));
app.use('/api', require('../routes/academic/studentdetail'));
app.use('/api', require('../routes/academic/applicationform'));
app.use('/api', require('../routes/academic/assignsubjectteacher'));
app.use('/api', require('../routes/academic/studentassignment'));
app.use('/api',require('../routes/academic/changesection'));
app.use('/api', require('../routes/academic/applicationformupload'));
app.use('/api', require('../routes/academic/generatemarksheet'));
app.use('/api', require('../routes/academic/assignclassteacher'));
app.use('/api', require('../routes/academic/studentpromotion'));
app.use('/api', require('../routes/academic/onetimesetup'));
 
app.use('/api', require('../routes/academic/classmappingsubject'));
app.use('/api', require('../routes/academic/examschedule'));
// ===================================================admin  api ===============================================
 app.use('/api', require('../routes/adminprofile/schoolprofile'));
// ===================================================adminnotification api ===============================================
app.use('/api', require('../routes/notification/raisedissues'));
app.use('/api', require('../routes/notification/staffattendanceapproval'));
app.use('/api', require('../routes/notification/studentnotification'));
app.use('/api', require('../routes/notification/adminnotification'));
 
 
// ===================================================Academicdashoard api ===============================================
app.use('/api', require('../routes/home/Academicdashoard/studentattendancechart'));
app.use('/api', require('../routes/home/Academicdashoard/academicdashboard'));
app.use('/api', require('../routes/home/Academicdashoard/studentattendancechart'));
app.use('/api', require('../routes/home/Academicdashoard/studentgendardetail'));
app.use('/api', require('../routes/home/Academicdashoard/eventcalendar'));
app.use('/api', require('../routes/home/Academicdashoard/studentperformance'));
app.use('/api', require('../routes/home/Academicdashoard/noticeboard'));
app.use('/api', require('../routes/home/Academicdashoard/studentgendarchart'));
app.use('/api', require('../routes/home/Academicdashoard/studentattendancedetail'));
// =========================================hr api=============================================================
app.use('/api', require('../routes/hr/staffprofile'));
app.use('/api', require('../routes/hr/staffdetail'));
app.use('/api', require('../routes/hr/staffattendancedetail'));
app.use('/api', require('../routes/hr/staffleavebalance'));
app.use('/api', require('../routes/hr/staffschedule'));
app.use('/api', require('../routes/hr/staffleavetype'));
app.use('/api', require('../routes/hr/staffregistrationform'));
app.use('/api', require('../routes/hr/staffapprovalstatus'));
app.use('/api', require('../routes/hr/staffgenerateletter'));
app.use('/api', require('../routes/hr/staffregistrationlist'));

 
// ===================================================Account /payroll api====================================
app.use('/api', require('../routes/accounting/payroll/salarycomponents'));
app.use('/api', require('../routes/accounting/payroll/payrollemployees'));
app.use('/api', require('../routes/accounting/payroll/payrollrecordstaff'));
app.use('/api', require('../routes/accounting/payroll/processsalary'));
app.use('/api', require('../routes/accounting/payroll/payrollrecordstaffview'));
 
// ===================================================Account /fees api====================================
app.use('/api', require('../routes/accounting/fees/feecategories'));
app.use('/api', require('../routes/accounting/fees/feemethod'));
app.use('/api', require('../routes/accounting/fees/feestructure'));
app.use('/api', require('../routes/accounting/fees/feecollection'));
app.use('/api', require('../routes/accounting/fees/feereport'));
app.use('/api', require('../routes/accounting/fees/studentcashpayment'));
app.use('/api', require('../routes/accounting/fees/studentonlinepayment'));

// ===================================================Account /smartledger api====================================
app.use('/api', require('../routes/accounting/smartledger/studentledger'));
app.use('/api', require('../routes/accounting/smartledger/generalledger'));
 
// ==============================================account/expenses/api===========================
app.use('/api', require('../routes/accounting/expenses/budgetanalysis'));
app.use('/api', require('../routes/accounting/expenses/expensereport'));
app.use('/api', require('../routes/accounting/expenses/expensecategories'));
app.use('/api', require('../routes/accounting/expenses/budgetanalysistable'));
app.use('/api', require('../routes/accounting/expenses/expensedetail'));
 
// =========================================accountdashboard  api ==================================================
app.use('/api', require('../routes/home/accountdashboard/accountdashboard'));
app.use('/api', require('../routes/home/accountdashboard/revenuebreakdown'));
app.use('/api', require('../routes/home/accountdashboard/totalexpensetable'));
app.use('/api', require('../routes/home/accountdashboard/expensegrouthtable'));
 
// ========================================hr dashboard api====================================================
app.use('/api', require('../routes/home/hrdashboard/staffattendancechart'));
app.use('/api', require('../routes/home/hrdashboard/teacherallocation'));
 
 
 
// ==============================================stafff dashboard api =================================================
app.use('/api', require('../routes/staff/staffdashboard/myattendance'));
app.use('/api', require('../routes/staff/staffdashboard/stafftimetable'));
app.use('/api', require('../routes/staff/staffdashboard/staffassignmentoverview'));
app.use('/api', require('../routes/staff/staffdashboard/studentlist'));
// ======================staff api =====================================================
app.use('/api', require('../routes/staff/staffattendancecalendar'));
app.use('/api', require('../routes/staff/staffpersonalprofile'));
app.use('/api', require('../routes/staff/staffassignmentform'));
 app.use('/api', require('../routes/staff/staffhistoryassignment'));
app.use('/api',require('../routes/staff/staffapproveassignment'));
// ===========================================bulkupload ==================================
app.use('/api', require('../routes/bulkload/staffonetimeload'));
app.use('/api', require('../routes/bulkload/studentonetimeload'));
app.use('/api', require('../routes/bulkload/teachersubjectclassonetimeload'));
app.use('/api', require('../routes/bulkload/classscheduleonetimeload'));
 
// ==============================================student dashboard api =================================================
app.use('/api', require('../routes/student/studentdashboard/studenttimetable'));
app.use('/api', require('../routes/student/studentprofiledashboard'));
app.use('/api', require('../routes/student/studentdashboard/studentattendancedashboard'));
app.use('/api', require('../routes/student/studentdashboard/studentperformancechart'));
app.use('/api', require('../routes/student/studentassignmenthistory'));
app.use('/api', require('../routes/student/studentassignment'));
app.use('/api', require('../routes/student/parentchat'));
app.use('/api', require('../routes/student/studentadmitcard'));
app.use('/api', require('../routes/student/studentfees'));
 
// Error handling middleware
app.use(payloadTooLargeMiddleware);
app.use((err, req, res, next) => {
  logger.error('Unhandled error', { error: err.message, stack: err.stack });
  res.status(500).json({ error: 'Something went wrong', details: err.message });
});
 
const port = process.env.PORT || 2081;
const server = app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  logger.info(`Server started on port ${port}`);
});
 
// Handle server shutdown
process.on('SIGINT', async () => {
  await closeAllPools();
  logger.info('All database pools closed');
  server.close(() => {
    logger.info('Server shut down');
    process.exit(0);
  });
});
 
