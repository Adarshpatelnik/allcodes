const { asyncLocalStorage } = require('../../middleware/authmiddleware');


const getStudentProfiles = async () => {

  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }

  
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('School database connection not established');
  }


  const studentsSql = `
    SELECT
      sp.STUDENT_ID,
      sp.FIRST_NAME,
      sp.MIDDLE_NAME,
      sp.LAST_NAME,
      sp.GENDER,
      sp.CONTACT_NUMBER,
      sp.HOUSE_NUMBER,
      sp.HOUSE_BUILDING_NAME,
      sp.STREET_NAME,
      sp.LANDMARK,
      sp.CITY,
      sp.STATE,
      sp.POSTAL_CODE,
      sp.NATIONALITY,
      sp.DATE_OF_BIRTH,
      sp.EMAIL,
      sp.ENROLLMENT_DATE,
      sp.BIRTH_CERTIFICATE_NUMBER,
      sp.CASTE,
      sp.RELIGION,
      sp.BLOOD_GROUP,
      sp.IDENTIFICATION_MARK,
      sp.PREVIOUS_SCHOOL,
      sp.EMERGENCY_CONTACT_NAME,
      sp.EMERGENCY_CONTACT_NUMBER,
      sp.AADHAR_NUMBER,
      sp.DISEASE_IF_ANY,
      sp.ADDITIONAL_NOTE,
      cd.CLASS,
      cd.SECTION,
      cd.CLASS_ID
    FROM
      ACD_STUDENT_PROFILE sp
    JOIN
      ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
  `;

  try {
    const [studentsResult] = await schoolDbConnection.query(studentsSql);
    return studentsResult; 
  } catch (err) {
    throw new Error(`Error fetching student profiles: ${err.message}`);
  }
};

module.exports = { getStudentProfiles };