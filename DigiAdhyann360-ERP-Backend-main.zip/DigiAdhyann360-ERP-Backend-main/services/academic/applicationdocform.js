const { s3Client } = require('../../config/aws');
const multer = require('multer');
const multerS3 = require('multer-s3');
const mime = require('mime-types');
const path = require('path');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

// Middleware to attach udiseCode to the request
const attachIdentifiers = async (req, res, next) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const current_staff = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    // Fetch udiseCode
    console.time('udiseCodeQuery');
    const [udiseCodeResults] = await schoolDbConnection.query('SELECT UDISE_CODE FROM ACD_SCHOOL_PROFILE sp');
    console.timeEnd('udiseCodeQuery');
    if (udiseCodeResults.length === 0) {
      throw new Error('Udise code not found.');
    }
    const udiseCode = udiseCodeResults[0].UDISE_CODE;

    req.udiseCode = udiseCode;
    console.log('/GET udiseCode:', udiseCode);

    next();
  } catch (error) {
    console.error('Error fetching identifiers:', error.message);
    res.status(500).json({
      error: 'Failed to fetch udiseCode or applicationId.',
      details: error.message,
    });
  }
};

// Function to generate custom file names
const getCustomFileName = (fieldName, originalName) => {
  const fileMappings = {
    STUDENT_AADHAAR: 'STUDENT_AADHAAR',
    STUDENT_PHOTO: 'STUDENT_PHOTO',
    PREVIOUS_MARKSHEET: 'PREVIOUS_MARKSHEET',
    TRANSFER_CERTIFICATE: 'TRANSFER_CERTIFICATE',
    MIGRATION_CERTIFICATE: 'MIGRATION_CERTIFICATE',
    BIRTH_CERTIFICATE: 'BIRTH_CERTIFICATE',
    CHARACTER_CERTIFICATE: 'CHARACTER_CERTIFICATE',
    SAMAGRA_ID: 'SAMAGRA_ID',
  };

  const fileExtension = path.extname(originalName);
  return fileMappings[fieldName] ? `${fileMappings[fieldName]}${fileExtension}` : originalName;
};

// Function to determine Content-Type based on file extension
const getContentType = (file) => {
  return mime.lookup(file.originalname) || 'application/octet-stream';
};

// Function to determine Content-Disposition
const getContentDisposition = (file) => {
  const fileType = mime.lookup(file.originalname);
  return ['image/png', 'image/jpeg', 'application/pdf'].includes(fileType) ? 'inline' : 'attachment';
};

// Multer S3 Configuration
const uploadFileToS3 = multer({
  storage: multerS3({
    s3: s3Client,
    bucket: process.env.AWS_BUCKET_NAME,
    metadata: (req, file, cb) => {
      cb(null, { fieldName: file.fieldname });
    },
    key: (req, file, cb) => {
      console.time(`s3Upload_${file.fieldname}`);
      const { applicantId } = req.body;
      if (!req.udiseCode || !applicantId) {
        console.error('Missing required fields:', { udiseCode: req.udiseCode, applicantId });
        cb(new Error('Missing required fields: udiseCode or applicantId.'));
      } else {
        const customFileName = getCustomFileName(file.fieldname, file.originalname);
        const filePath = `${req.udiseCode}/Students/Applicants/${applicantId}/${customFileName}`;
        console.log(`Uploading to S3 with key: ${filePath}`);
        cb(null, filePath);
      }
    },
    acl: 'private',
    contentType: (req, file, cb) => {
      cb(null, getContentType(file));
    },
    contentDisposition: (req, file, cb) => {
      cb(null, getContentDisposition(file));
    },
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!allowedTypes.includes(file.mimetype)) {
      return cb(new Error(`Invalid file type for ${file.fieldname}. Allowed: JPEG, PNG, PDF.`));
    }
    cb(null, true);
  },
}).fields([
  { name: 'STUDENT_AADHAAR', maxCount: 1 },
  { name: 'STUDENT_PHOTO', maxCount: 1 },
  { name: 'PREVIOUS_MARKSHEET', maxCount: 1 },
  { name: 'TRANSFER_CERTIFICATE', maxCount: 1 },
  { name: 'MIGRATION_CERTIFICATE', maxCount: 1 },
  { name: 'BIRTH_CERTIFICATE', maxCount: 1 },
  { name: 'CHARACTER_CERTIFICATE', maxCount: 1 },
  { name: 'SAMAGRA_ID', maxCount: 1 },
  { name: 'applicantId', maxCount: 1 }, // Handle applicantId as a non-file field
]);

// Function to upload documents to database
const uploadDocuments = async (files, applicantId, schoolDbConnection) => {
  if (!files || Object.keys(files).length === 0) {
    throw new Error('No files were uploaded.');
  }

  const documentKeys = {};
  for (const fieldName in files) {
    const file = files[fieldName][0];
    documentKeys[fieldName] = file.key;
  }

  const query = `
    INSERT INTO ACD_STUDENT_APPLICATION_DOCS (
      APPLICATION_ID, STUDENT_AADHAAR, STUDENT_PHOTO, PREVIOUS_MARKSHEET,
      TRANSFER_CERTIFICATE, MIGRATION_CERTIFICATE, BIRTH_CERTIFICATE, CHARACTER_CERTIFICATE, SAMAGRA_ID
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      STUDENT_AADHAAR = VALUES(STUDENT_AADHAAR),
      STUDENT_PHOTO = VALUES(STUDENT_PHOTO),
      PREVIOUS_MARKSHEET = VALUES(PREVIOUS_MARKSHEET),
      TRANSFER_CERTIFICATE = VALUES(TRANSFER_CERTIFICATE),
      MIGRATION_CERTIFICATE = VALUES(MIGRATION_CERTIFICATE),
      BIRTH_CERTIFICATE = VALUES(BIRTH_CERTIFICATE),
      CHARACTER_CERTIFICATE = VALUES(CHARACTER_CERTIFICATE),
      SAMAGRA_ID = VALUES(SAMAGRA_ID)
  `;

  console.time('insertQuery');
  await schoolDbConnection.query(query, [
    applicantId,
    documentKeys['STUDENT_AADHAAR'] || null,
    documentKeys['STUDENT_PHOTO'] || null,
    documentKeys['PREVIOUS_MARKSHEET'] || null,
    documentKeys['TRANSFER_CERTIFICATE'] || null,
    documentKeys['MIGRATION_CERTIFICATE'] || null,
    documentKeys['BIRTH_CERTIFICATE'] || null,
    documentKeys['CHARACTER_CERTIFICATE'] || null,
    documentKeys['SAMAGRA_ID'] || null,
  ]);
  console.timeEnd('insertQuery');

  // Update DOCUMENTS_UPLOADED status in ACD_STUDENT_APPLICATION
  const updateQuery = `
    UPDATE ACD_STUDENT_APPLICATION
    SET DOCUMENTS_UPLOADED = 'TRUE'
    WHERE APPLICATION_ID = ?;
  `;
  await schoolDbConnection.query(updateQuery, [applicantId]);

  return { message: 'Documents uploaded successfully.', applicationId: applicantId };
};

module.exports = { attachIdentifiers, getCustomFileName, getContentType, getContentDisposition, uploadFileToS3, uploadDocuments };