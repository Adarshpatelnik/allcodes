const { GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { s3Client } = require('../../config/aws');
const mime = require('mime-types');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

const documentKeyNames = {
  STUDENT_AADHAAR: 'Student Aadhaar',
  STUDENT_PHOTO: 'Student Photo',
  PREVIOUS_MARKSHEET: 'Previous Marksheet',
  TRANSFER_CERTIFICATE: 'Transfer Certificate',
  MIGRATION_CERTIFICATE: 'Migration Certificate',
  BIRTH_CERTIFICATE: 'Birth Certificate',
  CHARACTER_CERTIFICATE: 'Character Certificate',
  SAMAGRA_ID: 'Samagra ID',
};

const getDocuments = async (udiseCode, applicationId, schoolDbConnection) => {
  if (!udiseCode || !applicationId) {
    throw new Error('Missing required parameters: udiseCode or applicationId.');
  }

  console.log('Starting getDocuments with udiseCode:', udiseCode, 'applicationId:', applicationId);
  if (!schoolDbConnection) {
    throw new Error('School database connection not established.');
  }

  console.log('Executing query for applicationId:', applicationId);
  console.time('fetchDocumentsQuery');
  const query = `
    SELECT
      STUDENT_AADHAAR, STUDENT_PHOTO, PREVIOUS_MARKSHEET, TRANSFER_CERTIFICATE,
      MIGRATION_CERTIFICATE, BIRTH_CERTIFICATE, CHARACTER_CERTIFICATE, SAMAGRA_ID
    FROM SCHOOL_ERP_DATABASE.ACD_STUDENT_APPLICATION_DOCS
    WHERE APPLICATION_ID = ?;
  `;
  let rows;
  try {
    [rows] = await schoolDbConnection.query(query, [applicationId]);
  } catch (dbError) {
    console.error('Database query failed:', dbError.message, dbError.stack);
    throw new Error(`Database error: ${dbError.message}`);
  }
  console.timeEnd('fetchDocumentsQuery');

  if (!rows || rows.length === 0) {
    console.log('No documents found for applicationId:', applicationId);
    return { message: 'No documents found for the specified UDISE Code and Application ID.', documents: {} };
  }

  const documentKeys = rows[0];
  const signedUrls = {};

  for (const key in documentKeys) {
    if (documentKeys[key]) {
      const documentName = documentKeyNames[key] || key;
      const fileKey = documentKeys[key];

      try {
        console.time(`signedUrl_${documentName}`);
        const fileMimeType = mime.lookup(fileKey) || 'application/octet-stream';
        const command = new GetObjectCommand({
          Bucket: process.env.AWS_BUCKET_NAME || 'adhyayan-360',
          Key: fileKey,
          ResponseContentDisposition: 'inline',
          ResponseContentType: fileMimeType,
        });

        const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
        signedUrls[documentName] = signedUrl;
        console.timeEnd(`signedUrl_${documentName}`);
      } catch (s3Error) {
        console.error(`Error generating signed URL for ${documentName}:`, s3Error.message, s3Error.stack);
        signedUrls[documentName] = null;
      }
    }
  }

  return { message: 'Document URLs retrieved successfully.', documents: signedUrls };
};

module.exports = { getDocuments };