

const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const cleanPhoneNumber = (phone) => {
  if (!phone) return null;
  return phone.replace(/\D/g, '').slice(-10);
};

// Helper function to validate Aadhaar number uniqueness
const validateUniqueAadhaarNumbers = (studentAadhaar, fatherAadhaar, motherAadhaar) => {
  const aadhaarSet = new Set([studentAadhaar, fatherAadhaar, motherAadhaar].filter(num => num)); // Filter out null/undefined
  if (aadhaarSet.size < [studentAadhaar, fatherAadhaar, motherAadhaar].filter(num => num).length) {
    return {
      isValid: false,
      error: 'Aadhaar numbers for student, father, and mother must be unique.'
    };
  }
  return { isValid: true };
};

const getApplicationFormStatus = async (id) => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getApplicationFormStatus', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  const query = `
    SELECT 
      FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, PHONE_NUMBER, CLASS, STREAM, OPTIONAL,
      DATE_OF_BIRTH, EMAIL, APPLICATION_DATE, BIRTH_CERTIFICATE_NUMBER, CASTE, RELIGION,
      PREVIOUS_SCHOOL, PREVIOUS_BOARD, MARKING_SYSTEM, PREVIOUS_RESULT,
      EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_RELATION, EMERGENCY_CONTACT_NUMBER,
      AADHAR_NUMBER, SAMAGRA_ID, BLOOD_GROUP, DISEASE_IF_ANY, ADDITIONAL_NOTE,
      IDENTIFICATION_MARK, HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK,
      CITY, STATE, POSTAL_CODE, FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION,
      FATHER_EDUCATION, FATHER_MOBILE_NUMBER, FATHER_INCOME, MOTHER_NAME, MOTHER_ADHAR_ID,
      MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME,
      IS_ENROLLED, APPROVAL_STATUS, REMARKS
    FROM ACD_STUDENT_APPLICATION
    WHERE APPLICATION_ID = ?
  `;

  try {
    logger.info('Executing SQL query to fetch application status', { applicationId: id });
    const [rows] = await schoolDbConnection.query(query, [id]);
    if (rows.length === 0) {
      logger.warn('Application not found', { applicationId: id });
      throw new Error('Application not found');
    }
    logger.info('Application data fetched successfully', { applicationId: id });
    return rows[0];
  } catch (err) {
    logger.error('Error fetching application data', { error: err.message, applicationId: id });
    throw new Error(`Error fetching application: ${err.message}`);
  }
};

const getApplicationClassFilter = async () => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getApplicationClassFilter', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  const classfilterSql = `
    SELECT DISTINCT class
    FROM ACD_STUDENT_CLASS_MAPPING
    WHERE class != 'Alumni'
    ORDER BY
      CASE
        WHEN class = 'LKG' THEN 0
        WHEN class = 'UKG' THEN 1
        WHEN class REGEXP '^[0-9]+$' THEN CAST(class AS UNSIGNED) + 1
        ELSE 999
      END;
  `;

  try {
    logger.info('Executing SQL query to fetch class filter');
    const [rows] = await schoolDbConnection.query(classfilterSql);
    logger.info('Class filter fetched successfully', { count: rows.length });
    return rows;
  } catch (err) {
    logger.error('Error fetching class filter', { error: err.message });
    throw new Error(`Error fetching class filter: ${err.message}`);
  }
};

const createApplication = async (applicationData) => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in createApplication', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  const cleanedData = {
    ...applicationData,
    PHONE_NUMBER: cleanPhoneNumber(applicationData.PHONE_NUMBER),
    EMERGENCY_CONTACT_NUMBER: cleanPhoneNumber(applicationData.EMERGENCY_CONTACT_NUMBER),
    FATHER_MOBILE_NUMBER: cleanPhoneNumber(applicationData.FATHER_MOBILE_NUMBER),
    MOTHER_MOBILE_NUMBER: cleanPhoneNumber(applicationData.MOTHER_MOBILE_NUMBER),
    AADHAR_NUMBER: applicationData.AADHAR_NUMBER ? applicationData.AADHAR_NUMBER.toString().replace(/\D/g, '') : null,
    FATHER_ADHAR_ID: applicationData.FATHER_ADHAR_ID ? applicationData.FATHER_ADHAR_ID.toString().replace(/\D/g, '') : null,
    MOTHER_ADHAR_ID: applicationData.MOTHER_ADHAR_ID ? applicationData.MOTHER_ADHAR_ID.toString().replace(/\D/g, '') : null,
  };

  // Validate Aadhaar number uniqueness
  const { AADHAR_NUMBER, FATHER_ADHAR_ID, MOTHER_ADHAR_ID } = cleanedData;
  const aadhaarValidation = validateUniqueAadhaarNumbers(AADHAR_NUMBER, FATHER_ADHAR_ID, MOTHER_ADHAR_ID);
  if (!aadhaarValidation.isValid) {
    logger.error('Aadhaar number validation failed', { error: aadhaarValidation.error });
    throw new Error(aadhaarValidation.error);
  }

  // Validate Aadhaar number length (12 digits)
  const aadhaarFields = { AADHAR_NUMBER, FATHER_ADHAR_ID, MOTHER_ADHAR_ID };
  for (const [field, value] of Object.entries(aadhaarFields)) {
    if (value && !/^\d{12}$/.test(value)) {
      logger.error(`Invalid ${field}`, { value });
      throw new Error(`${field} must be a 12-digit number.`);
    }
  }

  const {
    FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CLASS, STREAM, OPTIONAL,
    HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK, CITY, STATE,
    POSTAL_CODE, DATE_OF_BIRTH, PHONE_NUMBER, EMAIL, NATIONALITY, CASTE,
    RELIGION, BLOOD_GROUP, BIRTH_CERTIFICATE_NUMBER, DISEASE_IF_ANY,
    ADDITIONAL_NOTE, IDENTIFICATION_MARK, PREVIOUS_SCHOOL, PREVIOUS_BOARD,
    MARKING_SYSTEM, PREVIOUS_RESULT, EMERGENCY_CONTACT_NAME,
    EMERGENCY_CONTACT_RELATION, EMERGENCY_CONTACT_NUMBER,
    AADHAR_NUMBER: studentAadhaar, // Renamed to avoid conflict
    SAMAGRA_ID, FATHER_NAME,
    FATHER_ADHAR_ID: fatherAadhaar, // Renamed to avoid conflict
    FATHER_OCCUPATION, FATHER_EDUCATION, FATHER_MOBILE_NUMBER, MOTHER_NAME,
    MOTHER_ADHAR_ID: motherAadhaar, // Renamed to avoid conflict
    MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME,
    APPLICATION_DATE,
  } = cleanedData;

  const INSERT_APPLICATION_QUERY = `
    INSERT INTO ACD_STUDENT_APPLICATION (
      FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CLASS, STREAM, OPTIONAL,
      HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK, CITY, STATE,
      POSTAL_CODE, DATE_OF_BIRTH, PHONE_NUMBER, EMAIL, NATIONALITY, CASTE,
      RELIGION, BLOOD_GROUP, BIRTH_CERTIFICATE_NUMBER, DISEASE_IF_ANY,
      ADDITIONAL_NOTE, IDENTIFICATION_MARK, PREVIOUS_SCHOOL, PREVIOUS_BOARD,
      MARKING_SYSTEM, PREVIOUS_RESULT, EMERGENCY_CONTACT_NAME,
      EMERGENCY_CONTACT_RELATION, EMERGENCY_CONTACT_NUMBER, AADHAR_NUMBER,
      SAMAGRA_ID, FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION,
      FATHER_EDUCATION, FATHER_MOBILE_NUMBER, MOTHER_NAME, MOTHER_ADHAR_ID,
      MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME,
      APPLICATION_DATE, IS_ENROLLED, APPROVAL_STATUS, REMARKS
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'FALSE', 'PENDING', NULL)
  `;

  const values = [
    FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CLASS, STREAM, OPTIONAL,
    HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK, CITY, STATE,
    POSTAL_CODE, DATE_OF_BIRTH, PHONE_NUMBER, EMAIL, NATIONALITY, CASTE,
    RELIGION, BLOOD_GROUP, BIRTH_CERTIFICATE_NUMBER, DISEASE_IF_ANY,
    ADDITIONAL_NOTE, IDENTIFICATION_MARK, PREVIOUS_SCHOOL, PREVIOUS_BOARD,
    MARKING_SYSTEM, PREVIOUS_RESULT, EMERGENCY_CONTACT_NAME,
    EMERGENCY_CONTACT_RELATION, EMERGENCY_CONTACT_NUMBER, studentAadhaar,
    SAMAGRA_ID, FATHER_NAME, fatherAadhaar, FATHER_OCCUPATION,
    FATHER_EDUCATION, FATHER_MOBILE_NUMBER, MOTHER_NAME, motherAadhaar,
    MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME,
    APPLICATION_DATE,
  ];

  try {
    logger.info('Executing SQL query to insert application data');
    const [result] = await schoolDbConnection.query(INSERT_APPLICATION_QUERY, values);
    const applicantId = result.insertId;
    logger.info('Application data inserted successfully', { applicantId });
    return { message: 'Application data inserted successfully', applicantId };
  } catch (err) {
    logger.error('Error inserting application data', { error: err.message });
    throw new Error(`Error inserting application: ${err.message}`);
  }
};

const updateApplication = async (id, updatedData) => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in updateApplication', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  const cleanedData = {
    ...updatedData,
    PHONE_NUMBER: cleanPhoneNumber(updatedData.PHONE_NUMBER),
    EMERGENCY_CONTACT_NUMBER: cleanPhoneNumber(updatedData.EMERGENCY_CONTACT_NUMBER),
    FATHER_MOBILE_NUMBER: cleanPhoneNumber(updatedData.FATHER_MOBILE_NUMBER),
    MOTHER_MOBILE_NUMBER: cleanPhoneNumber(updatedData.MOTHER_MOBILE_NUMBER),
    AADHAR_NUMBER: updatedData.AADHAR_NUMBER ? updatedData.AADHAR_NUMBER.toString().replace(/\D/g, '') : null,
    FATHER_ADHAR_ID: updatedData.FATHER_ADHAR_ID ? updatedData.FATHER_ADHAR_ID.toString().replace(/\D/g, '') : null,
    MOTHER_ADHAR_ID: updatedData.MOTHER_ADHAR_ID ? updatedData.MOTHER_ADHAR_ID.toString().replace(/\D/g, '') : null,
  };

  // Validate Aadhaar number uniqueness
  const { AADHAR_NUMBER, FATHER_ADHAR_ID, MOTHER_ADHAR_ID } = cleanedData;
  const aadhaarValidation = validateUniqueAadhaarNumbers(AADHAR_NUMBER, FATHER_ADHAR_ID, MOTHER_ADHAR_ID);
  if (!aadhaarValidation.isValid) {
    logger.error('Aadhaar number validation failed', { error: aadhaarValidation.error });
    throw new Error(aadhaarValidation.error);
  }

  // Validate Aadhaar number length (12 digits)
  const aadhaarFields = { AADHAR_NUMBER, FATHER_ADHAR_ID, MOTHER_ADHAR_ID };
  for (const [field, value] of Object.entries(aadhaarFields)) {
    if (value && !/^\d{12}$/.test(value)) {
      logger.error(`Invalid ${field}`, { value });
      throw new Error(`${field} must be a 12-digit number.`);
    }
  }

  const fixedFields = {
    IS_ENROLLED: 'FALSE',
    APPROVAL_STATUS: 'PENDING',
    REMARKS: null,
  };

  const allFields = {
    ...cleanedData,
    ...fixedFields,
    AADHAR_NUMBER: cleanedData.AADHAR_NUMBER,
    FATHER_ADHAR_ID: cleanedData.FATHER_ADHAR_ID,
    MOTHER_ADHAR_ID: cleanedData.MOTHER_ADHAR_ID,
  };

  const allFieldKeys = Object.keys(allFields);
  const allFieldValues = Object.values(allFields);

  const setClause = allFieldKeys.map((field) => `${field} = ?`).join(', ');
  const query = `
    UPDATE ACD_STUDENT_APPLICATION
    SET ${setClause}
    WHERE APPLICATION_ID = ?
  `;
  const queryParams = [...allFieldValues, id];

  try {
    logger.info('Executing SQL query to update application', { applicationId: id });
    const [result] = await schoolDbConnection.query(query, queryParams);
    if (result.affectedRows === 0) {
      logger.warn('Application not found for update', { applicationId: id });
      throw new Error('Application not found');
    }
    logger.info('Application updated successfully', { applicationId: id });
    return { message: 'Application updated successfully', affectedRows: result.affectedRows };
  } catch (err) {
    logger.error('Error updating application', { error: err.message, applicationId: id });
    throw new Error(`Error updating application: ${err.message}`);
  }
};

module.exports = {
  getApplicationFormStatus,
  getApplicationClassFilter,
  updateApplication,
  createApplication,
};