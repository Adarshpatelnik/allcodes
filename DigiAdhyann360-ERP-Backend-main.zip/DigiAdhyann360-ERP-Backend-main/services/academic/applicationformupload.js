const bulkLoadData = async (schoolDbConnection, data) => {
  console.log("Service: Starting bulk load process");

  if (!data || !Array.isArray(data) || data.length === 0) {
    console.log("Service: Invalid or empty data provided.");
    throw new Error("Invalid or empty data provided");
  }

  // Define required fields based on DDL NOT NULL constraints
  const requiredFields = [
    'FIRST_NAME', 'LAST_NAME', 'GENDER', 'CLASS', 'DATE_OF_BIRTH', 'CITY', 'STATE', 'POSTAL_CODE',
    'NATIONALITY', 'BIRTH_CERTIFICATE_NUMBER', 'PREVIOUS_SCHOOL', 'PREVIOUS_BOARD', 'MARKING_SYSTEM',
    'PREVIOUS_RESULT', 'EMERGENCY_CONTACT_NAME', 'EMERGENCY_CONTACT_RELATION', 'EMERGENCY_CONTACT_NUMBER',
    'AADHAR_NUMBER', 'FATHER_NAME', 'FATHER_ADHAR_ID', 'FATHER_OCCUPATION', 'FATHER_MOBILE_NUMBER',
    'MOTHER_NAME'
  ];

  // Define ENUM values
  const enumValues = {
    GENDER: ['MALE', 'FEMALE', 'OTHER'],
    NATIONALITY: ['INDIAN', 'OTHER'],
    RELIGION: ['HINDU', 'MUSLIM', 'CHRISTIAN', 'SIKH', 'BUDDHISM', 'JAIN', 'UNKNOWN'],
    BLOOD_GROUP: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'UNKNOWN'],
    IS_ENROLLED: ['FALSE', 'TRUE'],
    APPROVAL_STATUS: ['PENDING', 'APPROVED', 'REJECTED']
  };

  // Validate data
  const errors = [];
  data.forEach((row, index) => {
    const rowErrors = {};

    // Check required fields
    requiredFields.forEach(field => {
      if (!row[field] || row[field].toString().trim() === '') {
        rowErrors[field] = `${field} is required.`;
      }
    });

    // Validate Stream and Optional Subject for Class 11 or 12
    const normalizedClass = row.CLASS ? row.CLASS.toString().replace(/\D/g, "") : "";
    if (["11", "12"].includes(normalizedClass)) {
      if (!row.STREAM || row.STREAM.toString().trim() === '') {
        rowErrors.STREAM = "Stream is required for class 11 or 12.";
      }
      if (!row.OPTIONAL || row.OPTIONAL.toString().trim() === '') {
        rowErrors.OPTIONAL = "Optional Subject is required for class 11 or 12.";
      }
    }

    // Validate Email format
    if (row.EMAIL && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(row.EMAIL)) {
      rowErrors.EMAIL = "Invalid email format.";
    }

    // Validate Phone Numbers (must be 10 digits)
    const phoneFields = ['PHONE_NUMBER', 'EMERGENCY_CONTACT_NUMBER', 'FATHER_MOBILE_NUMBER', 'MOTHER_MOBILE_NUMBER'];
    phoneFields.forEach(field => {
      if (row[field]) {
        const cleanedPhone = row[field].toString().replace(/\D/g, "");
        if (!/^\d{10}$/.test(cleanedPhone)) {
          rowErrors[field] = `${field} must be a 10-digit number.`;
        }
      }
    });

    // Validate Aadhaar Numbers (must be 12 digits)
    const aadhaarFields = ['AADHAR_NUMBER', 'FATHER_ADHAR_ID', 'MOTHER_ADHAR_ID'];
    aadhaarFields.forEach(field => {
      if (row[field]) {
        const cleanedAadhaar = row[field].toString().replace(/\D/g, "");
        if (!/^\d{12}$/.test(cleanedAadhaar)) {
          rowErrors[field] = `${field} must be a 12-digit number.`;
        }
      }
    });

    // Validate Postal Code (must be 6 digits)
    if (row.POSTAL_CODE) {
      const cleanedPostalCode = row.POSTAL_CODE.toString().replace(/\D/g, "");
      if (!/^\d{6}$/.test(cleanedPostalCode)) {
        rowErrors.POSTAL_CODE = "Postal code must be a 6-digit number.";
      }
    }

    // Validate Samagra ID (must be 8 digits, if provided)
    if (row.SAMAGRA_ID && !/^\d{8}$/.test(row.SAMAGRA_ID.toString())) {
      rowErrors.SAMAGRA_ID = "Samagra ID must be an 8-digit number.";
    }

    // Validate ENUM fields
    if (row.GENDER && !enumValues.GENDER.includes(row.GENDER.toUpperCase())) {
      rowErrors.GENDER = `Gender must be one of: ${enumValues.GENDER.join(', ')}.`;
    }
    if (row.NATIONALITY && !enumValues.NATIONALITY.includes(row.NATIONALITY.toUpperCase())) {
      rowErrors.NATIONALITY = `Nationality must be one of: ${enumValues.NATIONALITY.join(', ')}.`;
    }
    if (row.RELIGION && !enumValues.RELIGION.includes(row.RELIGION.toUpperCase())) {
      rowErrors.RELIGION = `Religion must be one of: ${enumValues.RELIGION.join(', ')}.`;
    }
    if (row.BLOOD_GROUP && !enumValues.BLOOD_GROUP.includes(row.BLOOD_GROUP.toUpperCase())) {
      rowErrors.BLOOD_GROUP = `Blood group must be one of: ${enumValues.BLOOD_GROUP.join(', ')}.`;
    }

    // Validate Date of Birth (must be after 1900-01-01)
    if (row.DATE_OF_BIRTH) {
      const dob = new Date(row.DATE_OF_BIRTH);
      if (isNaN(dob.getTime()) || dob <= new Date('1900-01-01')) {
        rowErrors.DATE_OF_BIRTH = "Date of Birth must be a valid date after 1900-01-01.";
      }
    }

    // Validate Application Date (must be a valid date)
    if (row.APPLICATION_DATE) {
      const appDate = new Date(row.APPLICATION_DATE);
      if (isNaN(appDate.getTime())) {
        rowErrors.APPLICATION_DATE = "Application Date must be a valid date.";
      }
    }

    // Validate Father Income (must be >= 0, if provided)
    if (row.FATHER_INCOME && (isNaN(row.FATHER_INCOME) || row.FATHER_INCOME < 0)) {
      rowErrors.FATHER_INCOME = "Father Income must be a non-negative number.";
    }

    if (Object.keys(rowErrors).length > 0) {
      errors.push({ row: index + 1, errors: rowErrors });
    }
  });

  if (errors.length > 0) {
    console.log("Service: Validation errors:", JSON.stringify(errors, null, 2));
    throw new Error(JSON.stringify({ error: "Validation failed", details: errors }));
  }

  // Define the INSERT query
  const query = `
    INSERT INTO ACD_STUDENT_APPLICATION (
      FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CLASS, STREAM, OPTIONAL, HOUSE_NUMBER, HOUSE_BUILDING_NAME,
      STREET_NAME, LANDMARK, CITY, STATE, POSTAL_CODE, DATE_OF_BIRTH, PHONE_NUMBER, EMAIL, NATIONALITY,
      CASTE, RELIGION, BLOOD_GROUP, BIRTH_CERTIFICATE_NUMBER, DISEASE_IF_ANY, ADDITIONAL_NOTE, IDENTIFICATION_MARK,
      PREVIOUS_SCHOOL, PREVIOUS_BOARD, MARKING_SYSTEM, PREVIOUS_RESULT, EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_RELATION,
      EMERGENCY_CONTACT_NUMBER, AADHAR_NUMBER, SAMAGRA_ID, FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION,
      FATHER_EDUCATION, FATHER_MOBILE_NUMBER, FATHER_INCOME, MOTHER_NAME, MOTHER_ADHAR_ID, MOTHER_OCCUPATION,
      MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME, APPLICATION_DATE, IS_ENROLLED, APPROVAL_STATUS, REMARKS
    ) VALUES ?
  `;

  // Map the data into arrays for the bulk INSERT query
  const values = data.map(row => {
    const dob = row.DATE_OF_BIRTH ? new Date(row.DATE_OF_BIRTH).toISOString().split('T')[0] : null;
    const appDate = row.APPLICATION_DATE ? new Date(row.APPLICATION_DATE).toISOString() : null;
    return [
      row.FIRST_NAME || null,
      row.MIDDLE_NAME || null,
      row.LAST_NAME || null,
      row.GENDER ? row.GENDER.toUpperCase() : null,
      row.CLASS || null,
      row.STREAM || null,
      row.OPTIONAL || null,
      row.HOUSE_NUMBER || null,
      row.HOUSE_BUILDING_NAME || null,
      row.STREET_NAME || null,
      row.LANDMARK || null,
      row.CITY || null,
      row.STATE || null,
      row.POSTAL_CODE ? parseInt(row.POSTAL_CODE) : null,
      dob,
      row.PHONE_NUMBER ? row.PHONE_NUMBER.toString().replace(/\D/g, "") : null,
      row.EMAIL || null,
      row.NATIONALITY ? row.NATIONALITY.toUpperCase() : null,
      row.CASTE || null,
      row.RELIGION ? row.RELIGION.toUpperCase() : null,
      row.BLOOD_GROUP ? row.BLOOD_GROUP.toUpperCase() : null,
      row.BIRTH_CERTIFICATE_NUMBER || null,
      row.DISEASE_IF_ANY || null,
      row.ADDITIONAL_NOTE || null,
      row.IDENTIFICATION_MARK || null,
      row.PREVIOUS_SCHOOL || null,
      row.PREVIOUS_BOARD || null,
      row.MARKING_SYSTEM || null,
      row.PREVIOUS_RESULT || null,
      row.EMERGENCY_CONTACT_NAME || null,
      row.EMERGENCY_CONTACT_RELATION || null,
      row.EMERGENCY_CONTACT_NUMBER ? row.EMERGENCY_CONTACT_NUMBER.toString().replace(/\D/g, "") : null,
      row.AADHAR_NUMBER ? parseInt(row.AADHAR_NUMBER.toString().replace(/\D/g, "")) : null,
      row.SAMAGRA_ID ? parseInt(row.SAMAGRA_ID) : null,
      row.FATHER_NAME || null,
      row.FATHER_ADHAR_ID ? parseInt(row.FATHER_ADHAR_ID.toString().replace(/\D/g, "")) : null,
      row.FATHER_OCCUPATION || null,
      row.FATHER_EDUCATION || null,
      row.FATHER_MOBILE_NUMBER ? row.FATHER_MOBILE_NUMBER.toString().replace(/\D/g, "") : null,
      row.FATHER_INCOME ? parseInt(row.FATHER_INCOME) : null,
      row.MOTHER_NAME || null,
      row.MOTHER_ADHAR_ID ? parseInt(row.MOTHER_ADHAR_ID.toString().replace(/\D/g, "")) : null,
      row.MOTHER_OCCUPATION || null,
      row.MOTHER_EDUCATION || null,
      row.MOTHER_MOBILE_NUMBER ? row.MOTHER_MOBILE_NUMBER.toString().replace(/\D/g, "") : null,
      row.MOTHER_INCOME ? parseInt(row.MOTHER_INCOME) : null,
      appDate,
      'FALSE', // IS_ENROLLED
      'PENDING', // APPROVAL_STATUS
      null // REMARKS
    ];
  });

  console.log(`Service: Attempting to insert ${values.length} records.`);

  // Execute the query
  await schoolDbConnection.query(query, [values]);

  console.log("Service: Data uploaded successfully.");
  return { message: "Data uploaded successfully" };
};

module.exports = { bulkLoadData };