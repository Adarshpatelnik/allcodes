const { asyncLocalStorage } = require('../../middleware/authmiddleware');

class ApplicationListService {
  async getApplications() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      throw new Error('School database connection not established');
    }

    const query = `SELECT * FROM ACD_STUDENT_APPLICATION
     where APPROVAL_STATUS in ('APPROVED','REJECTED')`;
    const [results] = await schoolDbConnection.query(query);
    return results;
  }
}

module.exports = new ApplicationListService();
