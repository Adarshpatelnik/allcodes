const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StudentStatusService {
  async getApplicationStatus(appId) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
      SELECT 
        APPLICATION_ID,
        CONCAT(
          FIRST_NAME, ' ',
          COALESCE(MIDDLE_NAME, ''), ' ',
          LAST_NAME
        ) AS STUDENT_NAME,
        APPROVAL_STATUS,
        REMARKS
      FROM ACD_STUDENT_APPLICATION
      WHERE APPLICATION_ID = ?
    `;

    logger.info('Executing query for application status', { appId, query });
    const [results] = await schoolDbConnection.query(query, [appId]);

    if (results.length === 0) {
      throw new Error('Application not found');
    }

    logger.info('Application status fetched successfully', { appId });
    return results[0];
  }
}

module.exports = new StudentStatusService();