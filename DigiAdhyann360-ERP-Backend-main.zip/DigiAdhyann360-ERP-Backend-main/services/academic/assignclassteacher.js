const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const moment = require('moment');

// 📘 Get all teachers
const getTeachers = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  const query = `
    SELECT STAFF_ID, STAFF_NAME 
    FROM ACD_STAFF_PROFILE 
    WHERE STAFF_ROLE = 'TEACHER'
  `;
  const [results] = await schoolDbConnection.execute(query);
  return results;
};

// 📘 Get all teacher assignments
const getTeacherAssignments = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  const query = `
SELECT 
  scm.CLASS_ID,                            
  cstm.SUBJECT,
  sp.STAFF_NAME,
  cstm.TEACHER_ID,
  cstm.CLASS_TEACHER_FLAG
FROM (
  SELECT DISTINCT CLASS_ID
  FROM ACD_STUDENT_CLASS_MAPPING
) scm
LEFT JOIN ACD_CLASS_SUB_TEACHER_MAPPING cstm
  ON TRIM(scm.CLASS_ID) = TRIM(cstm.CLASS_ID)
LEFT JOIN ACD_STAFF_PROFILE sp
  ON cstm.TEACHER_ID = sp.STAFF_ID
ORDER BY
  CASE 
    WHEN SUBSTRING_INDEX(scm.CLASS_ID, ' ', 1) = 'LKG' THEN 0
    WHEN SUBSTRING_INDEX(scm.CLASS_ID, ' ', 1) = 'UKG' THEN 1
    WHEN SUBSTRING_INDEX(scm.CLASS_ID, ' ', 1) REGEXP '^[0-9]+$' 
         THEN CAST(SUBSTRING_INDEX(scm.CLASS_ID, ' ', 1) AS UNSIGNED) + 2
    ELSE 999
  END,
  SUBSTRING_INDEX(scm.CLASS_ID, ' ', -1); 
  `;
  const [results] = await schoolDbConnection.query(query);
  return results;
};

// 📘 Assign only Class Teacher
const assignClassTeacher = async (staffId, className, section) => {
  if (!staffId || !className || !section) throw new Error("Missing required fields");

  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error("Unauthorized or missing context");
  const schoolDbConnection = store.get("schoolDbConnection");
  if (!schoolDbConnection) throw new Error("Database connection not established");

  const connection = await schoolDbConnection.getConnection();
  const currentDateTime = moment().format("YYYY-MM-DD HH:mm:ss");

  try {
    await connection.beginTransaction();

    // ✅ Step 1: Get teacher name by ID
    const [teacherRow] = await connection.query(
      `SELECT STAFF_NAME FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?`,
      [staffId]
    );
    if (!teacherRow || teacherRow.length === 0) throw new Error(`No staff found for ID ${staffId}`);
    const teacherName = teacherRow[0].STAFF_NAME;

    // ✅ Step 2: Remove existing class teacher for that class+section
    await connection.query(
      `UPDATE ACD_CLASS_SUB_TEACHER_MAPPING
       SET CLASS_TEACHER_FLAG = 0
       WHERE CLASS = ? AND SECTION = ? AND CLASS_TEACHER_FLAG = 1`,
      [className, section]
    );

   
    const [insertResult] = await connection.query(
  `INSERT INTO ACD_CLASS_SUB_TEACHER_MAPPING (
    CLASS, SECTION, SUBJECT, TEACHER_ID, TEACHER_NAME,
    CLASS_TEACHER_FLAG, IS_ACTIVE, ACADEMIC_YEAR,
    CREATE_DATE, CREATED_BY
  )
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON DUPLICATE KEY UPDATE
    TEACHER_ID = VALUES(TEACHER_ID),
    TEACHER_NAME = VALUES(TEACHER_NAME),
    CLASS_TEACHER_FLAG = 1,
    IS_ACTIVE = 1,
    UPDATE_DATE = ?,
    UPDATED_BY = ?`,
  [
    className,
    section,
    'GENERAL',
    staffId,
    teacherName,
    1,
    1,
    '2025-2026',
    currentDateTime,
    'SYSTEM',
    currentDateTime,  // for UPDATE_DATE
    'SYSTEM'          // for UPDATED_BY
  ]
);

    if (insertResult.affectedRows === 0) throw new Error('Insert failed');

    await connection.commit();
    return { success: true, message: 'Class teacher assigned successfully' };
  } catch (err) {
    await connection.rollback();
    console.error('AssignClassTeacher error:', err.message);
    throw new Error(`Transaction failed: ${err.message}`);
  } finally {
    connection.release();
  }
};

// 📘 Delete all assignments for a class
const deleteTeacherAssignment = async (classId) => {
  if (!classId) throw new Error('CLASS_ID is required');

  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();
    await connection.query('SET FOREIGN_KEY_CHECKS = 0');

    const [result] = await connection.query(
      `DELETE FROM ACD_CLASS_SUB_TEACHER_MAPPING WHERE CLASS_ID = ?`,
      [classId]
    );
    if (result.affectedRows === 0) throw new Error('No records found to delete');

    await connection.query('SET FOREIGN_KEY_CHECKS = 1');
    await connection.commit();
    return { success: true, message: 'All teacher assignments deleted for this class' };
  } catch (err) {
    await connection.rollback();
    throw new Error(`Delete failed: ${err.message}`);
  } finally {
    connection.release();
  }
};

module.exports = {
  getTeachers,
  getTeacherAssignments,
  assignClassTeacher,
  deleteTeacherAssignment
};


