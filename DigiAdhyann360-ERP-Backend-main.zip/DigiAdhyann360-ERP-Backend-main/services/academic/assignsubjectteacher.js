
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');
 
const getTeachers = async () => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getTeachers', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const query = "SELECT STAFF_ID, STAFF_NAME FROM ACD_STAFF_PROFILE WHERE STAFF_ROLE = 'TEACHER'";
  try {
    logger.info('Executing SQL query to fetch teachers');
    const [results] = await schoolDbConnection.query(query);
    logger.info('Teachers fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching teachers', { error: err.message });
    throw new Error(`Error fetching teachers: ${err.message}`);
  }
};
 
const getClasses = async () => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getClasses', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const query = "SELECT DISTINCT CLASS FROM ACD_STUDENT_CLASS_MAPPING";
  try {
    logger.info('Executing SQL query to fetch classes');
    const [results] = await schoolDbConnection.query(query);
    logger.info('Classes fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching classes', { error: err.message });
    throw new Error(`Error fetching classes: ${err.message}`);
  }
};
 
const getSections = async () => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getSections', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const query = "SELECT DISTINCT SECTION FROM ACD_STUDENT_CLASS_MAPPING";
  try {
    logger.info('Executing SQL query to fetch sections');
    const [results] = await schoolDbConnection.query(query);
    logger.info('Sections fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching sections', { error: err.message });
    throw new Error(`Error fetching sections: ${err.message}`);
  }
};
 
const getSubjectsByClass = async (selectedClass) => {
  if (!selectedClass) {
    logger.error('Class parameter is required');
    throw new Error('Class parameter is required');
  }
 
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getSubjectsByClass', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const query = "SELECT distinct SUBJECT_NAME FROM ACD_SUBJECT WHERE CLASS = ?";
  try {
    logger.info('Executing SQL query to fetch subjects', { class: selectedClass });
    const [results] = await schoolDbConnection.query(query, [selectedClass]);
    if (results.length === 0) {
      logger.warn(`No subjects found for class ${selectedClass}`);
      throw new Error(`No subjects found for class ${selectedClass}`);
    }
    logger.info('Subjects fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching subjects', { error: err.message });
    throw err;
  }
};
 
const checkTeacherAssignmentExists = async (teacherId, className, section, subject) => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in checkTeacherAssignmentExists', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const query = `
    SELECT COUNT(*) as count
    FROM ACD_CLASS_SUB_TEACHER_MAPPING
    WHERE TEACHER_ID = ? AND CLASS = ? AND SECTION = ? AND SUBJECT = ?
  `;
  try {
    logger.info('Checking if teacher assignment exists', { teacherId, className, section, subject });
    const [results] = await schoolDbConnection.query(query, [teacherId, className, section, subject]);
    const exists = results[0].count > 0;
    logger.info('Teacher assignment check complete', { exists });
    return exists;
  } catch (err) {
    logger.error('Error checking teacher assignment', { error: err.message });
    throw new Error(`Error checking teacher assignment: ${err.message}`);
  }
};
 
const insertOrUpdateTeacherDetail = async (teacherData) => {
  const { TEACHER_ID, TEACHER_NAME, CLASS, SECTION, SUBJECT_NAME } = teacherData;
  if (!TEACHER_ID || !TEACHER_NAME || !CLASS || !SECTION || !SUBJECT_NAME) {
    logger.error('Missing required fields in teacherData', { teacherData });
    throw new Error('Missing required fields: TEACHER_ID, TEACHER_NAME, CLASS, SECTION, or SUBJECT_NAME');
  }
 
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in insertOrUpdateTeacherDetail', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const connection = await schoolDbConnection.getConnection();
 
  try {
    await connection.beginTransaction();
 
    const exists = await checkTeacherAssignmentExists(TEACHER_ID, CLASS, SECTION, SUBJECT_NAME);
 
    if (exists) {
      const updateQuery = `
        UPDATE ACD_CLASS_SUB_TEACHER_MAPPING
        SET TEACHER_NAME = ?, IS_ACTIVE = ?
        WHERE TEACHER_ID = ? AND CLASS = ? AND SECTION = ? AND SUBJECT = ?
      `;
      const [result] = await connection.query(updateQuery, [TEACHER_NAME, 1, TEACHER_ID, CLASS, SECTION, SUBJECT_NAME]);
      await connection.commit();
      logger.info('Teacher detail updated successfully', { teacherId: TEACHER_ID });
      return { success: true, message: 'Teacher detail updated successfully!', affectedRows: result.affectedRows };
    } else {
      const insertQuery = `
        INSERT INTO ACD_CLASS_SUB_TEACHER_MAPPING (TEACHER_ID, CLASS, SECTION, SUBJECT, TEACHER_NAME, IS_ACTIVE)
        VALUES (?, ?, ?, ?, ?, ?)
      `;
      const [result] = await connection.query(insertQuery, [TEACHER_ID, CLASS, SECTION, SUBJECT_NAME, TEACHER_NAME, 1]);
      await connection.commit();
      logger.info('Teacher detail inserted successfully', { teacherId: TEACHER_ID });
      return { success: true, message: 'Teacher detail inserted successfully!', insertId: result.insertId };
    }
  } catch (error) {
    await connection.rollback();
    logger.error('Error in insertOrUpdateTeacherDetail', { error: error.message });
    throw error;
  } finally {
    connection.release();
  }
};
 
const deleteTeacherDetail = async (teacherData) => {
  const { TEACHER_ID, CLASS, SECTION, SUBJECT_NAME } = teacherData;
  if (!TEACHER_ID || !CLASS || !SECTION || !SUBJECT_NAME) {
    logger.error('Missing required fields in teacherData for deletion', { teacherData });
    throw new Error('Missing required fields: TEACHER_ID, CLASS, SECTION, or SUBJECT_NAME');
  }
 
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in deleteTeacherDetail', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const connection = await schoolDbConnection.getConnection();
 
  try {
    await connection.beginTransaction();
 
    const deleteQuery = `
      DELETE FROM ACD_CLASS_SUB_TEACHER_MAPPING
      WHERE TEACHER_ID = ? AND CLASS = ? AND SECTION = ? AND SUBJECT = ?
    `;
    const [result] = await connection.query(deleteQuery, [TEACHER_ID, CLASS, SECTION, SUBJECT_NAME]);
 
    if (result.affectedRows === 0) {
      throw new Error('No matching teacher assignment found to delete');
    }
 
    await connection.commit();
    logger.info('Teacher detail deleted successfully', { teacherId: TEACHER_ID });
    return { success: true, message: 'Teacher detail deleted successfully!', affectedRows: result.affectedRows };
  } catch (error) {
    await connection.rollback();
    logger.error('Error in deleteTeacherDetail', { error: error.message });
    throw error;
  } finally {
    connection.release();
  }
};
 
const getTeacherDetails = async () => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getTeacherDetails', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
 
  const query = "SELECT TEACHER_ID, CLASS, SECTION, SUBJECT, TEACHER_NAME FROM ACD_CLASS_SUB_TEACHER_MAPPING";
  try {
    logger.info('Executing SQL query to fetch teacher details');
    const [results] = await schoolDbConnection.query(query);
    logger.info('Teacher details fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching teacher details', { error: err.message });
    throw new Error(`Error fetching teacher details: ${err.message}`);
  }
};
 
module.exports = {
  getTeachers,
  getClasses,
  getSections,
  getSubjectsByClass,
  insertOrUpdateTeacherDetail,
  deleteTeacherDetail,
  getTeacherDetails,
};  
 