const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');
 
// Fetch all students with class details and academic marks
const getAllStudents = async () => {
  // Check if context exists
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  // Get school database connection
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }
 
  // SQL query to fetch students
  const studentsSql = `
SELECT 
  s.STUDENT_ID,
  CONCAT(asp.FIRST_NAME, ' ', COALESCE(asp.MIDDLE_NAME, ''), ' ', asp.LAST_NAME) AS STUDENT_NAME,
  s.CLASS,
  asm.SECTION,
  asm.CLASS_ID,
  s.ACADEMIC_YEAR,
  ROUND(SUM(s.MARKS) / COUNT(s.SUBJECT_NAME), 2) AS PERCENT,
  s.EXAM_TYPE 
FROM ACD_MARKS_DETAIL s
LEFT JOIN ACD_STUDENT_PROFILE asp ON s.STUDENT_ID = asp.STUDENT_ID
LEFT JOIN ACD_STUDENT_CLASS_MAPPING asm ON asm.STUDENT_ID = asp.STUDENT_ID
WHERE s.EXAM_TYPE = 'Annual'
GROUP BY s.STUDENT_ID, s.EXAM_TYPE, s.CLASS, s.ACADEMIC_YEAR, asm.CLASS_ID, asm.SECTION
ORDER BY 
  CASE 
    WHEN s.CLASS = 'LKG' THEN 0
    WHEN s.CLASS = 'UKG' THEN 1
    WHEN s.CLASS REGEXP '^[0-9]+$' THEN CAST(s.CLASS AS UNSIGNED) + 1
    ELSE 999
  END,
  asm.SECTION;

 `;
 
  try {
    logger.info('Executing SQL query for fetching students');
    const [rows] = await schoolDbConnection.query(studentsSql);
    logger.info('Students fetched successfully', { count: rows.length });
    return rows;
  } catch (err) {
    logger.error('Error fetching students', { error: err.message });
    throw new Error(`Error fetching students: ${err.message}`);
  }
};
 
// Update the section of a student
const updateStudentSection = async (studentId, newSection) => {
  // Check if context exists
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }
 
  // Get school database connection
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }
 
  // Ensure section is uppercase
  newSection = newSection.toUpperCase();
 
  try {
    logger.info('Executing SQL query to update student section', { studentId, newSection });
    const [result] = await schoolDbConnection.query(
      'UPDATE ACD_STUDENT_CLASS_MAPPING SET section = ? WHERE STUDENT_ID = ?',
      [newSection, studentId]
    );
 
    if (result.affectedRows === 0) {
      logger.warn('Student not found for section update', { studentId });
      throw new Error('Student not found');
    }
 
    logger.info('Student section updated successfully', { studentId, newSection });
    return { message: 'Section updated successfully' };
  } catch (err) {
    logger.error('Error updating student section', { error: err.message, studentId });
    throw new Error(`Error updating student section: ${err.message}`);
  }
};
 
module.exports = {
  getAllStudents,
  updateStudentSection,
};
 
 