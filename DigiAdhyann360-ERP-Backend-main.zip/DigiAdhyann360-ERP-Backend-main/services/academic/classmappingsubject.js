 const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const moment = require('moment');

// Helper function to fetch LOV_ID dynamically based on CODE
const getLovIdByCode = async (code) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!code) throw new Error('Code parameter is required');

  const query = `
    SELECT LOV_ID
    FROM ACD_L_MASTER_LOV_CODE
    WHERE CODE = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [code]);

  if (results.length === 0) {
    throw new Error(`No LOV_ID found for CODE: ${code}`);
  }

  return results[0].LOV_ID;
};

// Get all classes
const getClasses = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  try {
    const lovId = await getLovIdByCode('CLASS'); // Fetch LOV_ID dynamically for CLASS
    const query = "SELECT DISTINCT SUBSTRING_INDEX(`VALUES`, '-', 1) AS CLASS FROM ACD_L_MASTER_LIST_OF_VALUES WHERE LOV_ID = ?";
    const [results] = await schoolDbConnection.query(query, [lovId]);
    console.log('Classes retrieved from ACD_L_MASTER_LIST_OF_VALUES:', results);
    if (!results.length) {
      console.warn('No classes found in ACD_L_MASTER_LIST_OF_VALUES for LOV_ID =', lovId);
    }
    return results;
  } catch (error) {
    console.error('Error fetching classes:', error.message);
    throw new Error('An unexpected error occurred while fetching class data');
  }
};

// Get subjects for a specific class
const getSubjectsByClass = async (selectedClass) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');
  if (!selectedClass) throw new Error('Class parameter is required');

  try {
    const query = `
      SELECT
        CLASS,
        SUBJECT_CODE,
        SUBJECT_NAME,
        SUBJECT_TYPE,
        CREATE_DATE AS REC_CREATE_DATE,
        UPDATE_DATE AS REC_UPDATE_DATE,
        CREATED_BY AS REC_CREATED_BY,
        UPDATED_BY AS REC_UPDATED_BY
      FROM ACD_SUBJECT
      WHERE CLASS = ?
    `;
    console.log('Executing getSubjectsByClass query:', query, 'with class:', selectedClass);
    const [results] = await schoolDbConnection.query(query, [selectedClass]);
    console.log('Subjects retrieved from ACD_SUBJECT table:', results);
    if (!results.length) {
      console.warn(`No subjects found in ACD_SUBJECT table for class: ${selectedClass}`);
    }
    return results;
  } catch (error) {
    console.error('Error fetching subjects:', error.message, error.stack);
    throw new Error(`An unexpected error occurred while fetching subject data: ${error.message}`);
  }
};

// Get subject names for a specific class or all classes
const getSubjectNames = async (selectedClass = null) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  try {
    const lovId = await getLovIdByCode('SUBJECT'); // Fetch LOV_ID dynamically for SUBJECT
    let query = `
      SELECT DISTINCT SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1) AS SUBJECT_NAME
      FROM ACD_L_MASTER_LIST_OF_VALUES
      WHERE LOV_ID = ?
    `;
    const params = [lovId];
    if (selectedClass) {
      query += ` AND SUBSTRING_INDEX(\`VALUES\`, '-', 1) = ?`;
      params.push(selectedClass);
    }
    console.log('Executing getSubjectNames query:', query, 'with params:', params);
    const [results] = await schoolDbConnection.query(query, params);
    console.log('Subject names retrieved from ACD_L_MASTER_LIST_OF_VALUES:', results);
    if (!results.length) {
      console.warn(`No subject names found in ACD_L_MASTER_LIST_OF_VALUES for LOV_ID = ${lovId}${selectedClass ? ` and class = ${selectedClass}` : ''}`);
    }
    return results;
  } catch (error) {
    console.error('Error fetching subject names:', error.message, error.stack);
    throw new Error(`An unexpected error occurred while fetching subject names: ${error.message}`);
  }
};

// Save or update subjects
const saveSubjects = async (className, addedSubjects, deletedSubjects) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');
  if (!className || typeof className !== 'string') throw new Error('Invalid or missing className');

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    if (Array.isArray(deletedSubjects) && deletedSubjects.length > 0) {
      const subjectCodesToDelete = deletedSubjects.map(subject => subject.subjectCode);
      const deleteQuery = `DELETE FROM ACD_SUBJECT WHERE CLASS = ? AND SUBJECT_CODE IN (?)`;
      console.log('Executing delete query:', deleteQuery, 'with values:', [className, subjectCodesToDelete]);
      const [deleteResult] = await connection.query(deleteQuery, [className, subjectCodesToDelete]);
      console.log('Delete result:', deleteResult);
    }

    if (Array.isArray(addedSubjects) && addedSubjects.length > 0) {
      const values = addedSubjects.map(subject => {
        if (!subject.subjectCode || !subject.subjectName) {
          throw new Error('Each subject must have a subjectCode and subjectName');
        }
        return [
          className,
          subject.subjectCode,
          subject.subjectName,
          subject.subjectType
        ];
      });

      const insertQuery = `INSERT INTO ACD_SUBJECT (CLASS, SUBJECT_CODE, SUBJECT_NAME, SUBJECT_TYPE) VALUES ?`;
      console.log('Executing insert query:', insertQuery, 'with values:', values);
      const [insertResult] = await connection.query(insertQuery, [values]);
      console.log('Insert result:', insertResult);
    }

    await connection.commit();
    return { success: true, message: `Subjects successfully updated for class ${className}` };
  } catch (error) {
    await connection.rollback();
    console.error('Error while saving subjects:', error.message, error.stack);
    throw new Error(`An unexpected error occurred while saving subjects: ${error.message}`);
  } finally {
    connection.release();
  }
};

// Delete subject
const deleteSubject = async (subjectCode) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');
  if (!subjectCode || typeof subjectCode !== 'string') throw new Error('Invalid or missing subjectCode');

  try {
    const query = `DELETE FROM ACD_SUBJECT WHERE SUBJECT_CODE = ?`;
    console.log('Executing delete query:', query, 'with subjectCode:', subjectCode);
    const [result] = await schoolDbConnection.query(query, [subjectCode]);

    if (result.affectedRows === 0) {
      throw new Error('Subject not found');
    }
    console.log('Query result:', result);
    return { success: true, message: `Subject with code ${subjectCode} successfully deleted` };
  } catch (error) {
    console.error('Error deleting subject:', error.message, error.stack);
    throw new Error(`An unexpected error occurred while deleting the subject: ${error.message}`);
  }
};

// Update subject
const updateSubject = async (subjectCode, payload) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');
  if (!subjectCode || typeof subjectCode !== 'string') throw new Error('Invalid or missing subjectCode');
  if (!payload.className || !payload.subjectType || !payload.subjectName) {
    throw new Error('className, subjectType, and subjectName are required');
  }

  try {
    // Strip "- T/P" from subjectName if present
    const cleanSubjectName = payload.subjectName.replace(/ - [T|P]$/, '');
    // Generate new SUBJECT_CODE based on updated className, subjectName, and subjectType
    const newSubjectCode = `${payload.className.toUpperCase()}-${cleanSubjectName.toUpperCase().slice(0, 3)}-${payload.subjectType === 'THEORY' ? 'T' : 'P'}`;
    const currentDateTime = moment().format('YYYY-MM-DD HH:mm:ss');

    // Check if the new SUBJECT_CODE already exists (excluding the current subject)
    const checkQuery = `SELECT * FROM ACD_SUBJECT WHERE SUBJECT_CODE = ? AND SUBJECT_CODE != ?`;
    const [existingRows] = await schoolDbConnection.query(checkQuery, [newSubjectCode, subjectCode]);
    if (existingRows.length > 0) {
      throw new Error(`Subject with code ${newSubjectCode} already exists`);
    }

    const query = `
      UPDATE ACD_SUBJECT
      SET CLASS = ?, SUBJECT_CODE = ?, SUBJECT_NAME = ?, SUBJECT_TYPE = ?, UPDATE_DATE = ?, UPDATED_BY = ?
      WHERE SUBJECT_CODE = ?
    `;
    const values = [
      payload.className,
      newSubjectCode,
      cleanSubjectName,
      payload.subjectType,
      currentDateTime,
      'N/A',
      subjectCode
    ];
    console.log('Executing update query:', query, 'with values:', values);
    const [result] = await schoolDbConnection.query(query, values);

    if (result.affectedRows === 0) {
      throw new Error(`Subject with code ${subjectCode} not found`);
    }

    return {
      success: true,
      message: 'Subject updated successfully',
      subject: {
        CLASS: payload.className,
        SUBJECT_CODE: newSubjectCode,
        SUBJECT_NAME: cleanSubjectName,
        SUBJECT_TYPE: payload.subjectType,
        REC_UPDATE_DATE: currentDateTime,
        REC_UPDATED_BY: 'N/A'
      }
    };
  } catch (error) {
    console.error('Error updating subject:', error.message, error.stack);
    throw new Error(`Failed to update subject: ${error.message}`);
  }
};

module.exports = {
  getClasses,
  getSubjectsByClass,
  getSubjectNames,
  saveSubjects,
  deleteSubject,
  updateSubject,
};
 