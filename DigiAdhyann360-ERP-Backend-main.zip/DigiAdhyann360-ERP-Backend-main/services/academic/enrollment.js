const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const bcrypt = require('bcrypt');
const { pool } = require('../../config/db');

class EnrollmentService {
  async getApplications() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      throw new Error('School database connection not established');
    }

    const query = `SELECT * FROM ACD_STUDENT_APPLICATION WHERE IS_ENROLLED = 'FALSE' AND APPROVAL_STATUS = 'PENDING';`;
    const [results] = await schoolDbConnection.query(query);
    return results;
  }

  async approveApplications({ applicationId, approval_status, remarks }) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      throw new Error('School database connection not established');
    }

    const tenantId = store.get('tenantId'); // Fetch tenantId from store
    if (!tenantId) {
      throw new Error('Tenant ID not found in context');
    }

    const isEnrolled = approval_status === 'APPROVED' ? 'TRUE' : 'FALSE';
    const connection = await schoolDbConnection.getConnection();
    await connection.beginTransaction();

    try {
      for (const appId of applicationId) {
        if (approval_status === 'PENDING') {
          const updateQuery = `
            UPDATE ACD_STUDENT_APPLICATION
            SET APPROVAL_STATUS = 'PENDING', IS_ENROLLED = 'FALSE'
            WHERE APPLICATION_ID = ?;
          `;
          await connection.query(updateQuery, [appId]);
        } else if (approval_status === 'REJECTED') {
          const updateQuery = `
            UPDATE ACD_STUDENT_APPLICATION
            SET APPROVAL_STATUS = 'REJECTED', IS_ENROLLED = 'FALSE', REMARKS = ?
            WHERE APPLICATION_ID = ?;
          `;
          await connection.query(updateQuery, [remarks, appId]);
        } else if (approval_status === 'APPROVED') {
          const fetchQuery = `SELECT * FROM ACD_STUDENT_APPLICATION WHERE APPLICATION_ID = ? AND APPROVAL_STATUS = 'PENDING';`;
          const [results] = await connection.query(fetchQuery, [appId]);
          if (results.length === 0) {
            console.log(`Student with APPLICATION_ID ${appId} not found or already processed.`);
            continue;
          }
          const students = results[0];
          const studentClass = students.CLASS;

          const updateApplicationQuery = `
            UPDATE ACD_STUDENT_APPLICATION
            SET APPROVAL_STATUS = 'APPROVED', IS_ENROLLED = 'TRUE'
            WHERE APPLICATION_ID = ?;
          `;
          await connection.query(updateApplicationQuery, [appId]);

          const insertEnrollmentQuery = `
            INSERT INTO ACD_STUDENT_ENROLLMENT (
              APPLICATION_ID, FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CLASS, STREAM, OPTIONAL,
              HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK, CITY, STATE, POSTAL_CODE,
              DATE_OF_BIRTH, PHONE_NUMBER, EMAIL, NATIONALITY, CASTE, RELIGION, BLOOD_GROUP,
              BIRTH_CERTIFICATE_NUMBER, DISEASE_IF_ANY, ADDITIONAL_NOTE, IDENTIFICATION_MARK,
              PREVIOUS_SCHOOL, PREVIOUS_BOARD, MARKING_SYSTEM, PREVIOUS_RESULT, EMERGENCY_CONTACT_NAME,
              EMERGENCY_CONTACT_RELATION, EMERGENCY_CONTACT_NUMBER, AADHAR_NUMBER, SAMAGRA_ID,
              FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION, FATHER_EDUCATION, FATHER_MOBILE_NUMBER,
              FATHER_INCOME, MOTHER_NAME, MOTHER_ADHAR_ID, MOTHER_OCCUPATION, MOTHER_EDUCATION,
              MOTHER_MOBILE_NUMBER, MOTHER_INCOME, APPLICATION_DATE, APPROVAL_STATUS
            ) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
          `;
          const enrollmentValues = [
            students.APPLICATION_ID, students.FIRST_NAME, students.MIDDLE_NAME, students.LAST_NAME, students.GENDER, students.CLASS,
            students.STREAM, students.OPTIONAL, students.HOUSE_NUMBER, students.HOUSE_BUILDING_NAME, students.STREET_NAME,
            students.LANDMARK, students.CITY, students.STATE, students.POSTAL_CODE, students.DATE_OF_BIRTH, students.PHONE_NUMBER,
            students.EMAIL, students.NATIONALITY, students.CASTE, students.RELIGION, students.BLOOD_GROUP, students.BIRTH_CERTIFICATE_NUMBER,
            students.DISEASE_IF_ANY, students.ADDITIONAL_NOTE, students.IDENTIFICATION_MARK, students.PREVIOUS_SCHOOL,
            students.PREVIOUS_BOARD, students.MARKING_SYSTEM, students.PREVIOUS_RESULT, students.EMERGENCY_CONTACT_NAME,
            students.EMERGENCY_CONTACT_RELATION, students.EMERGENCY_CONTACT_NUMBER, students.AADHAR_NUMBER, students.SAMAGRA_ID,
            students.FATHER_NAME, students.FATHER_ADHAR_ID, students.FATHER_OCCUPATION, students.FATHER_EDUCATION, students.FATHER_MOBILE_NUMBER,
            students.FATHER_INCOME, students.MOTHER_NAME, students.MOTHER_ADHAR_ID, students.MOTHER_OCCUPATION, students.MOTHER_EDUCATION,
            students.MOTHER_MOBILE_NUMBER, students.MOTHER_INCOME, students.APPLICATION_DATE, 'APPROVED'
          ];
          await connection.query(insertEnrollmentQuery, enrollmentValues);

          const [seqResults] = await connection.query(`
            SELECT MAX(CAST(SUBSTRING(STUDENT_ID, 5) AS UNSIGNED)) AS MAX_SEQ,
                   MAX(CAST(SUBSTRING_INDEX(STUDENT_USER_ID, "_", -1) AS UNSIGNED)) AS MAX_STUDENT_USER_SEQ
            FROM ACD_STUDENT_PROFILE
          `);
          const newSeq = (seqResults[0].MAX_SEQ || 0) + 1;
          const newStudentUserSeq = (seqResults[0].MAX_STUDENT_USER_SEQ || 0) + 1;

          const newStudentId = `SID-${String(newSeq).padStart(5, '0')}`;
          const newStudentUserId = `${students.FIRST_NAME}_${String(newStudentUserSeq).padStart(5, '0')}`;

          const studentsProfileSql = `
            INSERT INTO ACD_STUDENT_PROFILE (
              STUDENT_ID, STUDENT_USER_ID, FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER, CONTACT_NUMBER,
              HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK, CITY, STATE, POSTAL_CODE, DATE_OF_BIRTH, EMAIL,
              ENROLLMENT_DATE, NATIONALITY, BIRTH_CERTIFICATE_NUMBER, CASTE, RELIGION, BLOOD_GROUP, DISEASE_IF_ANY, ADDITIONAL_NOTE,
              IDENTIFICATION_MARK, AADHAR_NUMBER, EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_NUMBER, PREVIOUS_SCHOOL, SCHOOL_INFO
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;
          const studentsProfileValues = [
            newStudentId, newStudentUserId, students.FIRST_NAME, students.MIDDLE_NAME, students.LAST_NAME,
            students.GENDER, students.PHONE_NUMBER, students.HOUSE_NUMBER, students.HOUSE_BUILDING_NAME, students.STREET_NAME,
            students.LANDMARK, students.CITY, students.STATE, students.POSTAL_CODE, students.DATE_OF_BIRTH, students.EMAIL,
            students.APPLICATION_DATE, students.NATIONALITY, students.BIRTH_CERTIFICATE_NUMBER, students.CASTE, students.RELIGION,
            students.BLOOD_GROUP, students.DISEASE_IF_ANY, students.ADDITIONAL_NOTE, students.IDENTIFICATION_MARK, students.AADHAR_NUMBER,
            students.EMERGENCY_CONTACT_NAME, students.EMERGENCY_CONTACT_NUMBER, students.PREVIOUS_SCHOOL, tenantId // Replace '1' with tenantId
          ];
          await connection.query(studentsProfileSql, studentsProfileValues);

          const maxParentSeqQuery = 'SELECT MAX(CAST(SUBSTRING(PARENT_ID, 5) AS UNSIGNED)) AS MAX_SEQ FROM ACD_PARENT_PROFILE';
          const [parentSeqResults] = await connection.query(maxParentSeqQuery);
          const newParentSeq = (parentSeqResults[0].MAX_SEQ || 0) + 1;
          const newParentId = `PID-${String(newParentSeq).padStart(5, '0')}`;

          const parentProfileSql = `
            INSERT INTO ACD_PARENT_PROFILE (
              PARENT_ID, STUDENT_ID, FATHER_NAME, FATHER_OCCUPATION, FATHER_EDUCATION, FATHER_MOBILE_NUMBER, FATHER_INCOME,
              MOTHER_NAME, MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;
          const parentProfileValues = [
            newParentId, newStudentId, students.FATHER_NAME, students.FATHER_OCCUPATION, students.FATHER_EDUCATION,
            students.FATHER_MOBILE_NUMBER, students.FATHER_INCOME, students.MOTHER_NAME, students.MOTHER_OCCUPATION,
            students.MOTHER_EDUCATION, students.MOTHER_MOBILE_NUMBER, students.MOTHER_INCOME
          ];
          await connection.query(parentProfileSql, parentProfileValues);

          const totalStudentQuery = 'SELECT COUNT(*) AS TOTAL_STUDENTS FROM ACD_STUDENT_CLASS_MAPPING WHERE CLASS = ?';
          const [totalStudentsInClassResults] = await connection.query(totalStudentQuery, [studentClass]);
          const totalStudentsInClass = totalStudentsInClassResults[0].TOTAL_STUDENTS || 0;
          let sectionName = totalStudentsInClass <= 60 ? 'A' : totalStudentsInClass <= 120 ? 'B' : 'C';

          const classDetailSql = 'INSERT INTO ACD_STUDENT_CLASS_MAPPING (STUDENT_ID, CLASS, SECTION) VALUES (?, ?, ?)';
          await connection.query(classDetailSql, [newStudentId, studentClass, sectionName]);

          console.log(`Student with ID ${newStudentId} is assigned to class ${studentClass} section ${sectionName}`);

          const studentdataSql = `SELECT * FROM ACD_STUDENT_PROFILE WHERE STUDENT_USER_ID = ?`;
          const [student] = await connection.query(studentdataSql, [newStudentUserId]);
          const studentdata = student[0];

          function generateRandomPassword(length = 8) {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+[]{}|;:,.<>?';
            let password = '';
            for (let i = 0; i < length; i++) {
              const randomIndex = Math.floor(Math.random() * characters.length);
              password += characters[randomIndex];
            }
            return password;
          }
          const Random_Genrated_pass = generateRandomPassword();
          const hashedRandom_Genrated_pass = await bcrypt.hash(Random_Genrated_pass, 10);

          const RoleQuery = "SELECT ROLE_ID FROM ROLES WHERE ROLE_NAME = 'STUDENT'";
          const [roleResult] = await pool.query(RoleQuery);
          if (!roleResult.length) throw new Error("ROLE_ID for 'STUDENT' not found.");
          const ROLE_ID = roleResult[0].ROLE_ID;

          const STUDENT_USER_ID_Details = `
            INSERT INTO USERS (
              TENANT_ID, FULL_NAME, USER_ID, USERNAME, PASSWORD, ROLE_ID, CONTACT_NUMBER, EMAIL
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `;
          const Details_values = [
            tenantId, // Use tenantId instead of studentdata.SCHOOL_INFO
            `${studentdata.FIRST_NAME} ${studentdata.MIDDLE_NAME} ${studentdata.LAST_NAME}`,
            studentdata.STUDENT_ID,
            studentdata.STUDENT_USER_ID,
            hashedRandom_Genrated_pass,
            ROLE_ID,
            studentdata.CONTACT_NUMBER,
            studentdata.EMAIL,
          ];
          await pool.query(STUDENT_USER_ID_Details, Details_values);
          console.log('Student user created with password:', Random_Genrated_pass);
        }
      }

      await connection.commit();
      return { success: true, message: `${applicationId.length} application(s) processed successfully.` };
    } catch (err) {
      await connection.rollback();
      throw err;
    } finally {
      connection.release();
    }
  }
}

module.exports = new EnrollmentService();