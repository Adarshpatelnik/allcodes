const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getExamTypes = async (lovId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('School database connection not established');
  }

  const query = `
    SELECT v.VALUES AS EXAM_TYPE
    FROM ACD_L_MASTER_LIST_OF_VALUES v
    INNER JOIN ACD_L_MASTER_LOV_CODE c ON v.LOV_ID = c.LOV_ID
    WHERE v.LOV_ID = ?
      AND c.CODE = 'EXAM'
  `;
  const [results] = await schoolDbConnection.query(query, [lovId]);
  if (!results.length) {
    throw new Error(`No active exam types found for LOV_ID: ${lovId}`);
  }
  return results;
};

const getAllExams = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('School database connection not established');
  }

  const query = `
    SELECT ID AS id,
           EXAM_NAME AS name,
           EXAM_TYPE AS type,
           EXAM_START_DATE AS startDate,
           EXAM_END_DATE AS endDate,
           CREATE_DATE AS REC_CREATE_DATE,
           UPDATE_DATE AS REC_UPDATE_DATE,
           CREATED_BY AS REC_CREATED_BY,
           UPDATED_BY AS REC_UPDATED_BY
    FROM ACD_ADD_EXAM;
  `;
  const [examsResult] = await schoolDbConnection.query(query);
  return examsResult;
};

const createExam = async ({ name, type, startDate, endDate }) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('School database connection not established');
  }

  const createdBy = store.get('user')?.username || 'admin';
  // Get the next available ID
  const [maxIdResult] = await schoolDbConnection.query(
    'SELECT COALESCE(MAX(ID), 0) + 1 AS nextId FROM ACD_ADD_EXAM'
  );
  const newId = maxIdResult[0].nextId;

  const query = `
    INSERT INTO ACD_ADD_EXAM
    (ID, EXAM_NAME, EXAM_TYPE, EXAM_START_DATE, EXAM_END_DATE, CREATED_BY)
    VALUES (?, ?, ?, ?, ?, ?);
  `;
  const [result] = await schoolDbConnection.query(query, [newId, name, type, startDate, endDate, createdBy]);
  return { id: newId, name, type, startDate, endDate };
};

const updateExam = async (id, { name, type, startDate, endDate }) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('School database connection not established');
  }

  const updatedBy = store.get('user')?.username || 'admin';
  const query = `
    UPDATE ACD_ADD_EXAM
    SET EXAM_NAME = ?,
        EXAM_TYPE = ?,
        EXAM_START_DATE = ?,
        EXAM_END_DATE = ?,
        UPDATE_DATE = NOW(),
        UPDATED_BY = ?
    WHERE ID = ?;
  `;
  const [result] = await schoolDbConnection.query(query, [name, type, startDate, endDate, updatedBy, id]);
  if (result.affectedRows === 0) {
    throw new Error('Exam not found');
  }
  return { id, name, type, startDate, endDate };
};

const deleteExam = async (id) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('School database connection not established');
  }

  const query = `
    DELETE FROM ACD_ADD_EXAM
    WHERE ID = ?;
  `;
  const [result] = await schoolDbConnection.query(query, [id]);
  if (result.affectedRows === 0) {
    throw new Error('Exam not found');
  }
  return { message: 'Exam deleted successfully' };
};

module.exports = {
  getExamTypes,
  getAllExams,
  createExam,
  updateExam,
  deleteExam,
};