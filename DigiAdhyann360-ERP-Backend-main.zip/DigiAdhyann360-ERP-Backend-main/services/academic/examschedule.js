const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const moment = require('moment');

const getLovIdByCode = async (code) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');
  if (!code) throw new Error('Code parameter is required');

  const query = `
    SELECT LOV_ID
    FROM ACD_L_MASTER_LOV_CODE
    WHERE CODE = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [code]);
  if (results.length === 0) {
    throw new Error(`No LOV_ID found for CODE: ${code}`);
  }
  return results[0].LOV_ID;
};

const getClassesForExamSchedule = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const lovId = await getLovIdByCode('CLASS');

  const query = `
    SELECT DISTINCT SUBSTRING_INDEX(\`VALUES\`, '-', 1) AS CLASS
    FROM ACD_L_MASTER_LIST_OF_VALUES
    WHERE LOV_ID = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [lovId]);
  return results;
};

const getSubjectsWithSchedule = async (selectedClass, examType, examName) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');
  if (!selectedClass) throw new Error('Class parameter is required');

  const lovId = await getLovIdByCode('SUBJECT');

  const subjectsQuery = `
    SELECT 
      CASE 
        WHEN (LENGTH(\`VALUES\`) - LENGTH(REPLACE(\`VALUES\`, '-', ''))) / LENGTH('-') = 2 THEN
          CONCAT(
            SUBSTRING_INDEX(\`VALUES\`, '-', 1), 
            '-', 
            LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1), 3)
          )
        ELSE
          CONCAT(
            SUBSTRING_INDEX(\`VALUES\`, '-', 1), 
            '-', 
            LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1), 3)
          )
      END AS SUBJECT_CODE,
      SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1) AS SUBJECT
    FROM ACD_L_MASTER_LIST_OF_VALUES
    WHERE LOV_ID = ?
      AND SUBSTRING_INDEX(\`VALUES\`, '-', 1) = ?;
  `;
  const [subjects] = await schoolDbConnection.query(subjectsQuery, [lovId, selectedClass]);

  const scheduleQuery = `
    SELECT 
      SUBJECT_CODE,
      EXAM_DATE AS examDate,
      START_TIME AS startTime,
      END_TIME AS endTime,
      EXAM_TYPE AS examType,
      EXAM_NAME AS examName,
      CREATE_DATE AS creationDate,
      CREATED_BY AS createdBy,
      UPDATE_DATE AS lastUpdateDate,
      UPDATED_BY AS lastUpdatedBy
    FROM ACD_EXAM_SCHEDULE
    WHERE CLASS = ? AND EXAM_TYPE = ? AND EXAM_NAME = ?;
  `;
  const [scheduleData] = await schoolDbConnection.query(scheduleQuery, [selectedClass, examType, examName]);

  const scheduleMap = scheduleData.reduce((acc, row) => {
    acc[row.SUBJECT_CODE] = row;
    return acc;
  }, {});

  return subjects.map((sub, index) => {
    const scheduled = scheduleMap[sub.SUBJECT_CODE];
    return {
      id: sub.SUBJECT_CODE || `sub-${index}`,
      SUBJECT_CODE: sub.SUBJECT_CODE || 'N/A',
      SUBJECT_NAME: sub.SUBJECT || 'N/A',
      examType: scheduled?.examType || examType || '',
      examName: scheduled?.examName || examName || '',
      examDate: scheduled?.examDate || '',
      startTime: scheduled?.startTime || '',
      endTime: scheduled?.endTime || '',
      creationDate: scheduled?.creationDate ? moment(scheduled.creationDate).format('YYYY-MM-DD') : 'N/A',
      createdBy: scheduled?.createdBy || 'N/A',
      lastUpdateDate: scheduled?.lastUpdateDate ? moment(scheduled.lastUpdateDate).format('YYYY-MM-DD') : 'N/A',
      lastUpdatedBy: scheduled?.lastUpdatedBy || 'N/A',
    };
  });
};

const getExamDetails = async (examType, examName) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (examType && examName) {
    const [dateResults] = await schoolDbConnection.query(
      `SELECT EXAM_START_DATE AS examStartDate, EXAM_END_DATE AS examEndDate 
       FROM ACD_ADD_EXAM 
       WHERE EXAM_TYPE = ? AND EXAM_NAME = ? LIMIT 1`,
      [examType, examName]
    );
    return dateResults.length > 0
      ? {
          examStartDate: dateResults[0].examStartDate,
          examEndDate: dateResults[0].examEndDate,
        }
      : { examStartDate: null, examEndDate: null };
  }

  const query = `
    SELECT DISTINCT EXAM_TYPE, EXAM_NAME
    FROM ACD_ADD_EXAM
    WHERE EXAM_TYPE IS NOT NULL AND EXAM_NAME IS NOT NULL;
  `;
  const [results] = await schoolDbConnection.query(query);
  const examTypes = [...new Set(results.map(r => r.EXAM_TYPE))];
  const examNameMap = {};
  results.forEach(({ EXAM_TYPE, EXAM_NAME }) => {
    if (!examNameMap[EXAM_TYPE]) examNameMap[EXAM_TYPE] = [];
    if (!examNameMap[EXAM_TYPE].includes(EXAM_NAME)) examNameMap[EXAM_TYPE].push(EXAM_NAME);
  });
  return { examTypes, examNameMap };
};

const saveExamSchedule = async ({ studentClass, subjects, submit }) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!studentClass || !subjects || !Array.isArray(subjects)) {
    throw new Error('Class and subjects array are required');
  }
  if (subjects.length === 0) {
    throw new Error('Subjects array cannot be empty');
  }

  let insertedCount = 0;
  let updatedCount = 0;
  const updatedRecords = [];
  const currentDateTime = moment().format('YYYY-MM-DD HH:mm:ss');

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    for (const subject of subjects) {
      const { SUBJECT_CODE, SUBJECT_NAME, examDate, startTime, endTime, examType, examName } = subject;
      const formattedExamType = examType ? examType.toUpperCase() : null;
      const formattedExamName = examName || null;
      const formattedExamDate = examDate || null;

      const formattedStartTime = startTime
        ? moment(startTime, ['HH:mm', 'hh:mm A'], true).isValid()
          ? moment(startTime, ['HH:mm', 'hh:mm A']).format('hh:mm A')
          : null
        : null;

      const formattedEndTime = endTime
        ? moment(endTime, ['HH:mm', 'hh:mm A'], true).isValid()
          ? moment(endTime, ['HH:mm', 'hh:mm A']).format('hh:mm A')
          : null
        : null;

      const checkQuery = `
        SELECT * FROM ACD_EXAM_SCHEDULE 
        WHERE CLASS = ? AND SUBJECT_CODE = ? AND EXAM_TYPE = ?;
      `;
      const [existingRows] = await connection.query(checkQuery, [
        studentClass,
        SUBJECT_CODE,
        formattedExamType,
      ]);

      if (existingRows.length > 0) {
        const updateQuery = `
          UPDATE ACD_EXAM_SCHEDULE 
          SET SUBJECT_NAME = ?, 
              EXAM_DATE = ?, 
              START_TIME = ?, 
              END_TIME = ?, 
              EXAM_NAME = ?,
              UPDATE_DATE = ?,
              UPDATED_BY = ?
          WHERE CLASS = ? AND SUBJECT_CODE = ? AND EXAM_TYPE = ?;
        `;
        await connection.query(updateQuery, [
          SUBJECT_NAME || 'N/A',
          formattedExamDate,
          formattedStartTime,
          formattedEndTime,
          formattedExamName,
          currentDateTime,
          'N/A',
          studentClass,
          SUBJECT_CODE,
          formattedExamType,
        ]);
        updatedCount++;
        updatedRecords.push({
          SUBJECT_CODE,
          SUBJECT_NAME: SUBJECT_NAME || 'N/A',
          examDate: formattedExamDate,
          startTime: formattedStartTime,
          endTime: formattedEndTime,
          examType: formattedExamType,
          examName: formattedExamName,
          creationDate: existingRows[0].CREATE_DATE,
          createdBy: existingRows[0].CREATED_BY,
          lastUpdateDate: currentDateTime,
          lastUpdatedBy: 'N/A',
        });
      } else {
        const insertQuery = `
          INSERT INTO ACD_EXAM_SCHEDULE 
          (CLASS, SUBJECT_CODE, SUBJECT_NAME, EXAM_DATE, START_TIME, END_TIME, EXAM_TYPE, EXAM_NAME, ACADEMIC_YEAR, CREATE_DATE, CREATED_BY, UPDATE_DATE, UPDATED_BY)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        `;
        await connection.query(insertQuery, [
          studentClass,
          SUBJECT_CODE,
          SUBJECT_NAME || 'N/A',
          formattedExamDate,
          formattedStartTime,
          formattedEndTime,
          formattedExamType,
          formattedExamName,
          '2025-2026',
          currentDateTime,
          'N/A',
          currentDateTime,
          'N/A',
        ]);
        insertedCount++;
        updatedRecords.push({
          SUBJECT_CODE,
          SUBJECT_NAME: SUBJECT_NAME || 'N/A',
          examDate: formattedExamDate,
          startTime: formattedStartTime,
          endTime: formattedEndTime,
          examType: formattedExamType,
          examName: formattedExamName,
          creationDate: currentDateTime,
          createdBy: 'N/A',
          lastUpdateDate: currentDateTime,
          lastUpdatedBy: 'N/A',
        });
      }
    }

    await connection.commit();
    return {
      success: true,
      message: `Exam schedule ${submit ? 'submitted' : 'saved'} successfully`,
      insertedRows: insertedCount,
      updatedRows: updatedCount,
      updatedRecords,
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};
module.exports = {
  getClassesForExamSchedule,
  getSubjectsWithSchedule,
  getExamDetails,
  saveExamSchedule,
};
