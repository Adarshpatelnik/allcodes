const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getStudentForCertificate = async (studentId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const studentSql = `
  WITH cte AS (
  SELECT
    STUDENT_ID,
    CLASS,
    ROUND(
      SUM(CASE WHEN EXAM_TYPE = 'Annual' THEN MARKS ELSE 0 END) /
      (COUNT(CASE WHEN EXAM_TYPE = 'Annual' THEN SUBJECT_NAME ELSE NULL END) * 100) * 100, 2
    ) AS Annual_Percentage
 
  FROM
    ACD_MARKS_DETAIL
  GROUP BY
    STUDENT_ID, CLASS
)
SELECT
  sp.STUDENT_ID,
  sp.FIRST_NAME,
  sp.MIDDLE_NAME,
  sp.LAST_NAME,
  pp.FATHER_NAME,
  sp.GENDER,
  cd.CLASS,
  cd.SECTION,
  sp.CONTACT_NUMBER,
  sp.HOUSE_NUMBER,
  sp.HOUSE_BUILDING_NAME,
  sp.STREET_NAME,
  sp.LANDMARK,
  sp.CITY,
  case when Annual_Percentage >= 33 then 'PASS' else 'FAIL' end AS STATUS,
  cte.Annual_Percentage as PERCENT,
  sp.STATE,
  sp.POSTAL_CODE,
  sp.NATIONALITY,
  sp.DATE_OF_BIRTH,
  sp.EMAIL,
  sp.ENROLLMENT_DATE,
  sp.BIRTH_CERTIFICATE_NUMBER,
  sp.CASTE,
  sp.RELIGION,
  sp.BLOOD_GROUP,
  sp.IDENTIFICATION_MARK,
  sp.PREVIOUS_SCHOOL,
  sp.EMERGENCY_CONTACT_NAME,
  sp.EMERGENCY_CONTACT_NUMBER,
  sp.AADHAR_NUMBER,
  sp.DISEASE_IF_ANY,
  sp.ADDITIONAL_NOTE
FROM
  ACD_STUDENT_PROFILE sp
JOIN ACD_PARENT_PROFILE pp ON sp.STUDENT_ID = pp.STUDENT_ID
JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
JOIN ACD_CLASS_SUB_TEACHER_MAPPING ci ON cd.CLASS_ID = ci.CLASS_ID
JOIN ACD_STAFF_PROFILE s ON ci.TEACHER_ID = s.STAFF_ID
Inner join cte on cte.STUDENT_ID=sp.STUDENT_ID;
  `;

  const [studentdataResult] = await schoolDbConnection.query(studentSql, [studentId]);
  return studentdataResult;
};

const getCharacterCertificateData = async (studentId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const studentSql = `
 WITH cte AS (
  SELECT
    STUDENT_ID,
    CLASS,
    ROUND(
      SUM(CASE WHEN EXAM_TYPE = 'Annual' THEN MARKS ELSE 0 END) /
      (COUNT(CASE WHEN EXAM_TYPE = 'Annual' THEN SUBJECT_NAME ELSE NULL END) * 100) * 100, 2
    ) AS Annual_Percentage
 
  FROM
    ACD_MARKS_DETAIL
  GROUP BY
    STUDENT_ID, CLASS
)
SELECT
  sp.STUDENT_ID,
  sp.FIRST_NAME,
  sp.MIDDLE_NAME,
  sp.LAST_NAME,
  pp.FATHER_NAME,
  sp.GENDER,
  cd.CLASS,
  cd.SECTION,
  sp.CONTACT_NUMBER,
  sp.HOUSE_NUMBER,
  sp.HOUSE_BUILDING_NAME,
  sp.STREET_NAME,
  sp.LANDMARK,
  sp.CITY,
  case when Annual_Percentage >= 33 then 'PASS' else 'FAIL' end AS STATUS,
  cte.Annual_Percentage as PERCENT,
  sp.STATE,
  sp.POSTAL_CODE,
  sp.NATIONALITY,
  sp.DATE_OF_BIRTH,
  sp.EMAIL,
  sp.ENROLLMENT_DATE,
  sp.BIRTH_CERTIFICATE_NUMBER,
  sp.CASTE,
  sp.RELIGION,
  sp.BLOOD_GROUP,
  sp.IDENTIFICATION_MARK,
  sp.PREVIOUS_SCHOOL,
  sp.EMERGENCY_CONTACT_NAME,
  sp.EMERGENCY_CONTACT_NUMBER,
  sp.AADHAR_NUMBER,
  sp.DISEASE_IF_ANY,
  sp.ADDITIONAL_NOTE
FROM
  ACD_STUDENT_PROFILE sp
JOIN ACD_PARENT_PROFILE pp ON sp.STUDENT_ID = pp.STUDENT_ID
JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
JOIN ACD_CLASS_SUB_TEACHER_MAPPING ci ON cd.CLASS_ID = ci.CLASS_ID
JOIN ACD_STAFF_PROFILE s ON ci.TEACHER_ID = s.STAFF_ID
Inner join cte on cte.STUDENT_ID=sp.STUDENT_ID
  `;

  const [studentData] = await schoolDbConnection.query(studentSql, [studentId]);
  return studentData;
};

module.exports = {
  getStudentForCertificate,
  getCharacterCertificateData,
};