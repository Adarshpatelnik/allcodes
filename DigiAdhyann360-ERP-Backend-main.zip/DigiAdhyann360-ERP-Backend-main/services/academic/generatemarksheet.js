const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');
 
const getGenerateMarks = async () => {
  logger.info('Service: GET /api/getGenerateMarks: Fetching marks data');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/getGenerateMarks' });
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/getGenerateMarks' });
      throw new Error('School database connection not established');
    }
 
    const query = `WITH cte AS (
      SELECT
        STUDENT_ID,
        CLASS,
        ROUND(
          SUM(CASE WHEN EXAM_TYPE = 'QUARTERLY' THEN MARKS ELSE 0 END) /
          (COUNT(CASE WHEN EXAM_TYPE = 'QUARTERLY' THEN SUBJECT_NAME ELSE NULL END) * 100) * 100, 2
        ) AS QUARTERLY_Percentage,
        ROUND(
          SUM(CASE WHEN EXAM_TYPE = 'Half Yearly' THEN MARKS ELSE 0 END) /
          (COUNT(CASE WHEN EXAM_TYPE = 'Half Yearly' THEN SUBJECT_NAME ELSE NULL END) * 100) * 100, 2
        ) AS Half_Yearly_Percentage,
        ROUND(
          SUM(CASE WHEN EXAM_TYPE = 'Annual' THEN MARKS ELSE 0 END) /
          (COUNT(CASE WHEN EXAM_TYPE = 'Annual' THEN SUBJECT_NAME ELSE NULL END) * 100) * 100, 2
        ) AS Annual_Percentage
      FROM
        ACD_MARKS_DETAIL
      GROUP BY
        STUDENT_ID, CLASS
    )
    SELECT
      a.STUDENT_ID,
      CONCAT_WS(' ', a.FIRST_NAME, a.MIDDLE_NAME, a.LAST_NAME) AS STUDENT_NAME,
      a.DATE_OF_BIRTH,
      b.FATHER_NAME,
      b.MOTHER_NAME,
      c.CLASS_ID,
      c.CLASS,
      c.ACADEMIC_YEAR,
      d.SUBJECT_NAME,
      cte.QUARTERLY_Percentage,
      CASE
        WHEN cte.QUARTERLY_Percentage BETWEEN 80 AND 100 THEN 'OUTDO'
        WHEN cte.QUARTERLY_Percentage BETWEEN 60 AND 79 THEN 'TRAIL'
        WHEN cte.QUARTERLY_Percentage BETWEEN 33 AND 59 THEN 'SATISFY'
        WHEN cte.QUARTERLY_Percentage <= 33 THEN 'FAIL'
        ELSE 'NA'
      END AS Quarterly_Result,
      cte.Half_Yearly_Percentage,
      CASE
        WHEN cte.Half_Yearly_Percentage BETWEEN 80 AND 100 THEN 'OUTDO'
        WHEN cte.Half_Yearly_Percentage BETWEEN 60 AND 79 THEN 'TRAIL'
        WHEN cte.Half_Yearly_Percentage BETWEEN 33 AND 59 THEN 'SATISFY'
        WHEN cte.Half_Yearly_Percentage <= 33 THEN 'FAIL'
        ELSE 'NA'
      END AS Half_Yearly_Result,
      cte.Annual_Percentage,
      CASE
        WHEN cte.Annual_Percentage BETWEEN 80 AND 100 THEN 'OUTDO'
        WHEN cte.Annual_Percentage BETWEEN 60 AND 79 THEN 'TRAIL'
        WHEN cte.Annual_Percentage BETWEEN 33 AND 59 THEN 'SATISFY'
        WHEN cte.Annual_Percentage <= 33 THEN 'FAIL'
        ELSE 'NA'
      END AS Annual_Result
    FROM
      ACD_STUDENT_PROFILE a
    LEFT JOIN
      ACD_PARENT_PROFILE b ON a.STUDENT_ID = b.STUDENT_ID
    LEFT JOIN
      ACD_STUDENT_CLASS_MAPPING c ON a.STUDENT_ID = c.STUDENT_ID
    INNER JOIN
      ACD_SUBJECT d ON c.CLASS = d.CLASS
    INNER JOIN
      cte ON cte.STUDENT_ID = a.STUDENT_ID AND cte.CLASS = c.CLASS `;
 
    logger.info('Service: Executing marks query', { query });
    const [results] = await schoolDbConnection.query(query);
    logger.info('Service: Marks data fetched successfully', { count: results.length });
 
    if (!results || !Array.isArray(results)) {
      logger.error('Service: No data returned from marks query', { path: '/api/getGenerateMarks' });
      throw new Error('No data returned from marks query');
    }
 
    const requiredFields = ['STUDENT_ID', 'STUDENT_NAME', 'CLASS', 'ACADEMIC_YEAR'];
    results.forEach((record, index) => {
      requiredFields.forEach(field => {
        if (!(field in record)) {
          logger.warn(`Service: Record ${index} is missing required field: ${field}`, { path: '/api/getGenerateMarks' });
        }
      });
    });
 
    return results;
  } catch (err) {
    logger.error('Service: Error fetching marks data', { error: err.message, stack: err.stack, path: '/api/getGenerateMarks' });
    throw err;
  }
};
 
module.exports = { getGenerateMarks };