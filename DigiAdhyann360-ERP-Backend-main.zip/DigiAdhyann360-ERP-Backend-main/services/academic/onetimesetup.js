
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

const saveConfigCode = async (configs) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  if (!Array.isArray(configs) || configs.length === 0) throw new Error('No configuration data provided');

  const insertedOrUpdatedLovIds = [];
  const connection = await schoolDbConnection.getConnection();

  try {
    await connection.beginTransaction();

    for (const config of configs) {
      let { lovId, code, description, enableDate, disableDate } = config;
      code = code?.trim() || '';
      description = description?.trim() || '';

      if (!code) throw new Error('CODE is required');
      if (code.length > 100) throw new Error('CODE must not exceed 100 characters');
      if (!description) throw new Error('DESCRIPTION is required');
      if (description.length > 100) throw new Error('DESCRIPTION must not exceed 100 characters');

      const [existingRows] = await connection.query('SELECT LOV_ID FROM ACD_L_MASTER_LOV_CODE WHERE CODE = ?', [code]);

      let finalLovId = lovId;
      if (existingRows.length > 0) {
        finalLovId = existingRows[0].LOV_ID;
        const updateQuery = `
          UPDATE ACD_L_MASTER_LOV_CODE 
          SET DESCRIPTION = ?, ENABLE_DATE = ?, DISABLE_DATE = ?
          WHERE LOV_ID = ?`;
        const updateParams = [description, enableDate || null, disableDate || null, finalLovId];
        await connection.query(updateQuery, updateParams);
      } else {
        const insertQuery = `
          INSERT INTO ACD_L_MASTER_LOV_CODE 
          (CODE, DESCRIPTION, ENABLE_DATE, DISABLE_DATE)
          VALUES (?, ?, ?, ?)`;
        const insertParams = [code, description, enableDate || null, disableDate || null];
        const [result] = await connection.query(insertQuery, insertParams);
        finalLovId = result.insertId;
      }
      insertedOrUpdatedLovIds.push(finalLovId);
    }

    await connection.commit();
    return { message: 'Configuration code saved', lovIds: insertedOrUpdatedLovIds };
  } catch (error) {
    await connection.rollback();
    console.error('Error in saveConfigCode:', error.message);
    throw error;
  } finally {
    connection.release();
  }
};

const saveConfigValues = async (configs) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  if (!Array.isArray(configs) || configs.length === 0) throw new Error('No configuration values provided');

  const insertedOrUpdatedListIds = [];
  const connection = await schoolDbConnection.getConnection();

  try {
    await connection.beginTransaction();

    for (const config of configs) {
      let { listId, lovId, values, enableDate, disableDate } = config;
      values = values?.trim() || '';

      if (!lovId || !values) throw new Error(`LOV_ID and VALUES required. Got: lovId=${lovId}, values=${values}`);
      if (values.length > 100) throw new Error('VALUES must not exceed 100 characters');

      const [lovIdRows] = await connection.query('SELECT LOV_ID FROM ACD_L_MASTER_LOV_CODE WHERE LOV_ID = ?', [lovId]);
      if (lovIdRows.length === 0) throw new Error(`LOV_ID ${lovId} does not exist in ACD_L_MASTER_LOV_CODE`);

      const [existingRows] = await connection.query('SELECT LIST_ID FROM ACD_L_MASTER_LIST_OF_VALUES WHERE LOV_ID = ? AND `VALUES` = ?', [lovId, values]);

      let finalListId = listId;
      if (existingRows.length > 0) {
        finalListId = existingRows[0].LIST_ID;
        const updateQuery = `
          UPDATE ACD_L_MASTER_LIST_OF_VALUES 
          SET ENABLE_DATE = ?, DISABLE_DATE = ?
          WHERE LIST_ID = ?`;
        const updateParams = [enableDate || null, disableDate || null, finalListId];
        await connection.query(updateQuery, updateParams);
      } else {
        const insertQuery = `
          INSERT INTO ACD_L_MASTER_LIST_OF_VALUES 
          (LOV_ID, \`VALUES\`, ENABLE_DATE, DISABLE_DATE)
          VALUES (?, ?, ?, ?)`;
        const insertParams = [lovId, values, enableDate || null, disableDate || null];
        const [result] = await connection.query(insertQuery, insertParams);
        finalListId = result.insertId;
      }
      insertedOrUpdatedListIds.push(finalListId);
    }

    await connection.commit();
    return { message: 'Configuration values saved', listIds: insertedOrUpdatedListIds };
  } catch (error) {
    await connection.rollback();
    console.error('Error in saveConfigValues:', error.message);
    throw error;
  } finally {
    connection.release();
  }
};

const getConfigCode = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  const [rows] = await schoolDbConnection.query(
    'SELECT LOV_ID, CODE, DESCRIPTION, ENABLE_DATE, DISABLE_DATE, CREATE_DATE, CREATED_BY, UPDATE_DATE, UPDATED_BY FROM ACD_L_MASTER_LOV_CODE'
  );
  return rows;
};

const getConfigValues = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  const [rows] = await schoolDbConnection.query(
    'SELECT v.LIST_ID, v.LOV_ID, c.CODE, v.`VALUES`, v.ENABLE_DATE, v.DISABLE_DATE, v.CREATE_DATE, v.CREATED_BY, v.UPDATE_DATE, v.UPDATED_BY ' +
    'FROM ACD_L_MASTER_LIST_OF_VALUES v JOIN ACD_L_MASTER_LOV_CODE c ON v.LOV_ID = c.LOV_ID'
  );
  return rows;
};

const deleteConfigCode = async (lovId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    const [refRows] = await connection.query('SELECT LIST_ID FROM ACD_L_MASTER_LIST_OF_VALUES WHERE LOV_ID = ?', [lovId]);
    if (refRows.length > 0) throw new Error('Cannot delete; LOV_ID is referenced in ACD_L_MASTER_LIST_OF_VALUES');

    const [result] = await connection.query('DELETE FROM ACD_L_MASTER_LOV_CODE WHERE LOV_ID = ?', [lovId]);
    if (result.affectedRows === 0) throw new Error('LOV_ID not found');

    await connection.commit();
    return { message: 'Configuration code deleted' };
  } catch (error) {
    await connection.rollback();
    console.error('Error in deleteConfigCode:', error.message);
    throw error;
  } finally {
    connection.release();
  }
};

const deleteConfigValues = async (listId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('Database connection not established');

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    const [result] = await connection.query('DELETE FROM ACD_L_MASTER_LIST_OF_VALUES WHERE LIST_ID = ?', [listId]);
    if (result.affectedRows === 0) throw new Error('LIST_ID not found');

    await connection.commit();
    return { message: 'Configuration values deleted' };
  } catch (error) {
    await connection.rollback();
    console.error('Error in deleteConfigValues:', error.message);
    throw error;
  } finally {
    connection.release();
  }
};

module.exports = {
  saveConfigCode,
  saveConfigValues,
  getConfigCode,
  getConfigValues,
  deleteConfigCode,
  deleteConfigValues,
};