const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class ParentDetailService {
  async getParentDetails(parentId) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const parentQuery = `
      SELECT 
        pp.PARENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
        pp.FATHER_NAME, pp.FATHER_OCCUPATION, pp.FATHER_EDUCATION, pp.FATHER_ADHAR_ID, 
        pp.FATHER_MOBILE_NUMBER, pp.FATHER_INCOME,
        pp.MOTHER_NAME, pp.MOTHER_OCCUPATION, pp.MOTHER_EDUCATION, pp.MOTHER_ADHAR_ID, 
        pp.MOTHER_MOBILE_NUMBER, pp.MOTHER_INCOME
      FROM ACD_PARENT_PROFILE pp
      JOIN ACD_STUDENT_PROFILE sp ON pp.STUDENT_ID = sp.STUDENT_ID
      WHERE pp.PARENT_ID = ?
    `;

    logger.info('Fetching parent details', { parentId });
    const [results] = await schoolDbConnection.query(parentQuery, [parentId]);

    if (results.length === 0) {
      throw new Error('Parent not found');
    }

    return results[0];
  }

  async getAllParentProfiles() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
      SELECT 
        pp.PARENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
        pp.FATHER_NAME, pp.FATHER_OCCUPATION, pp.FATHER_EDUCATION, pp.FATHER_ADHAR_ID, 
        pp.FATHER_MOBILE_NUMBER, pp.FATHER_INCOME,
        pp.MOTHER_NAME, pp.MOTHER_OCCUPATION, pp.MOTHER_EDUCATION, pp.MOTHER_ADHAR_ID, 
        pp.MOTHER_MOBILE_NUMBER, pp.MOTHER_INCOME
      FROM ACD_PARENT_PROFILE pp
      LEFT JOIN ACD_STUDENT_PROFILE sp ON pp.STUDENT_ID = sp.STUDENT_ID
    `;

    logger.info('Fetching all parent profiles');
    const [results] = await schoolDbConnection.query(query);
    return results;
  }

  async updateParentDetails(parentId, updatedData) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const parentProfileFields = [
      'FATHER_NAME', 'FATHER_OCCUPATION', 'FATHER_EDUCATION', 'FATHER_ADHAR_ID', 
      'FATHER_MOBILE_NUMBER', 'FATHER_INCOME', 'MOTHER_NAME', 'MOTHER_OCCUPATION', 
      'MOTHER_EDUCATION', 'MOTHER_ADHAR_ID', 'MOTHER_MOBILE_NUMBER', 'MOTHER_INCOME'
    ];

    let setClause = '';
    const values = [];

    parentProfileFields.forEach(field => {
      if (field in updatedData) {
        if (setClause !== '') setClause += ', ';
        setClause += `pp.${field} = ?`;
        values.push(updatedData[field]);
      }
    });

    if (!setClause) {
      throw new Error('No valid fields provided for update');
    }

    const query = `
      UPDATE ACD_PARENT_PROFILE pp
      SET ${setClause}
      WHERE pp.PARENT_ID = ?
    `;

    values.push(parentId);

    logger.info('Updating parent details', { parentId });
    const [result] = await schoolDbConnection.query(query, values);

    if (result.affectedRows === 0) {
      throw new Error('Parent not found or no changes made');
    }

    return { message: 'Parent details updated successfully' };
  }
}

module.exports = new ParentDetailService();