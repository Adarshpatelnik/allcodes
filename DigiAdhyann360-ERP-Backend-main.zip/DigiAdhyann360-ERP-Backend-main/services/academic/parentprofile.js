const { asyncLocalStorage } = require('../../middleware/authmiddleware');

// Fetch all parent profiles from the database
const getParentProfiles = async () => {
  // Check if context exists
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }

  // Get school database connection
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('School database connection not established');
  }

  // SQL query to fetch parent profiles with class details
  const parentSql = `
   SELECT
        pp.PARENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
        pp.FATHER_NAME,
        pp.FATHER_OCCUPATION,
        pp.FATHER_EDUCATION,
        pp.FATHER_ADHAR_ID,
        pp.FATHER_MOBILE_NUMBER,
        pp.FATHER_INCOME,
        pp.MOTHER_NAME,
        pp.MOTHER_OCCUPATION,
        pp.MOTHER_EDUCATION,
        pp.MOTHER_ADHAR_ID,
        pp.MOTHER_MOBILE_NUMBER,
        pp.MOTHER_INCOME
      FROM
        ACD_PARENT_PROFILE pp, ACD_STUDENT_PROFILE sp
      WHERE
        pp.STUDENT_ID = sp.STUDENT_ID
  `;

  try {
    const [parentResult] = await schoolDbConnection.query(parentSql);
    return parentResult; // Return fetched data
  } catch (err) {
    throw new Error(`Error fetching parent profiles: ${err.message}`);
  }
};

module.exports = { getParentProfiles };