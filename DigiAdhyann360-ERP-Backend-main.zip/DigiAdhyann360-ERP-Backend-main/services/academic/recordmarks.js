const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getLovIdByCode = async (code) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!code) throw new Error('Code parameter is required');

  const query = `
    SELECT LOV_ID
    FROM ACD_L_MASTER_LOV_CODE
    WHERE CODE = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [code]);

  if (results.length === 0) {
    throw new Error(`No LOV_ID found for CODE: ${code}`);
  }

  return results[0].LOV_ID;
};

const getClassesForGradeEntry = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const lovId = await getLovIdByCode('CLASS');

  const query = `
    SELECT DISTINCT SUBSTRING_INDEX(\`VALUES\`, '-', 1) AS CLASS
    FROM ACD_L_MASTER_LIST_OF_VALUES
    WHERE LOV_ID = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [lovId]);
  return results;
};

const getExamNameAndExamType = async (className) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!className) throw new Error('Class parameter is required');

  const query = `
    SELECT DISTINCT EXAM_NAME, EXAM_TYPE
    FROM ACD_EXAM_SCHEDULE
    WHERE CLASS = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [className]);
  return results;
};

const getSubjectsForGradeEntry = async (selectedClass) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!selectedClass) throw new Error('Class parameter is required');

  const lovId = await getLovIdByCode('SUBJECT');

  const query = `
    SELECT DISTINCT 
      CASE
        WHEN (LENGTH(\`VALUES\`) - LENGTH(REPLACE(\`VALUES\`, '-', ''))) / LENGTH('-') = 2 THEN
          CONCAT(
            SUBSTRING_INDEX(\`VALUES\`, '-', 1),
            '-',
            LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1), 3)
          )
        ELSE
          CONCAT(
            SUBSTRING_INDEX(\`VALUES\`, '-', 1),
            '-',
            LEFT(SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1), 3)
          )
      END AS SUBJECT_CODE,
      CASE 
        WHEN SUBSTRING_INDEX(\`VALUES\`, '-', -1) = 'THEORY' THEN 
          CONCAT(SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1), '-T')
        ELSE 
          SUBSTRING_INDEX(SUBSTRING_INDEX(\`VALUES\`, '-', 2), '-', -1)
      END AS SUBJECT_NAME
    FROM ACD_L_MASTER_LIST_OF_VALUES
    WHERE LOV_ID = ?
    AND SUBSTRING_INDEX(\`VALUES\`, '-', 1) = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [lovId, selectedClass]);
  return results;
};

const getStudentsWithClass = async (selectedClass) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!selectedClass) throw new Error('Class parameter is required');

  const query = `
    SELECT sp.STUDENT_ID
    FROM ACD_STUDENT_PROFILE sp
    INNER JOIN ACD_STUDENT_CLASS_MAPPING cd ON cd.STUDENT_ID = sp.STUDENT_ID
    WHERE cd.CLASS = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [selectedClass]);
  return results;
};

const getSavedData = async (className, examName, examType) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!className || !examName || !examType) {
    throw new Error('Class, examName, and examType parameters are required');
  }

  const totalMarksQuery = `
    SELECT Subject, TOTAL_MARKS
    FROM ACD_SUBJECT_EXAM_MAPPING
    WHERE CLASS = ? AND EXAM_NAME = ? AND EXAM_TYPE = ?;
  `;
  const gradesQuery = `
    SELECT STUDENT_ID, SUBJECT_NAME, MARKS
    FROM ACD_MARKS_DETAIL
    WHERE CLASS = ? AND EXAM_NAME = ? AND EXAM_TYPE = ?;
  `;
  const [totalMarks] = await schoolDbConnection.query(totalMarksQuery, [className, examName, examType]);
  const [grades] = await schoolDbConnection.query(gradesQuery, [className, examName, examType]);

  return { totalMarks, grades };
};

const submitTotalMarks = async ({ CLASS, Subject, EXAM_NAME, EXAM_TYPE, TOTAL_MARKS }) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!CLASS || !Subject || !EXAM_NAME || !EXAM_TYPE || !TOTAL_MARKS) {
    throw new Error('All fields are required');
  }

  const query = `
    INSERT INTO ACD_SUBJECT_EXAM_MAPPING (CLASS, Subject, EXAM_NAME, EXAM_TYPE, TOTAL_MARKS)
    VALUES (?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE TOTAL_MARKS = ?;
  `;
  await schoolDbConnection.query(query, [CLASS, Subject.toUpperCase(), EXAM_NAME, EXAM_TYPE, TOTAL_MARKS, TOTAL_MARKS]);
  return { message: 'Total marks saved successfully' };
};

const getTotalMarks = async (className, examName, examType) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!className || !examName || !examType) {
    throw new Error('Class, examName, and examType parameters are required');
  }

  const query = `
    SELECT CLASS, EXAM_NAME, EXAM_TYPE, Subject, TOTAL_MARKS
    FROM ACD_SUBJECT_EXAM_MAPPING
    WHERE CLASS = ? AND EXAM_NAME = ? AND EXAM_TYPE = ?;
  `;
  const [results] = await schoolDbConnection.query(query, [className, examName, examType]);
  return results;
};

const saveGradeEntry = async (grades) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!Array.isArray(grades) || grades.length === 0) {
    throw new Error('No grades provided');
  }

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    for (const grade of grades) {
      const { studentId, studentName, studentClass, subjectName, marks, examName, examType, academicYear } = grade;
      const createdBy = store.get('user') || 'N/A';

      if (!studentId || !studentClass || !examName || !examType) {
        throw new Error('Required fields (studentId, studentClass, examName, examType) are missing');
      }

      const checkQuery = `
        SELECT * FROM ACD_MARKS_DETAIL 
        WHERE STUDENT_ID = ? AND SUBJECT_NAME = ? AND EXAM_NAME = ? AND EXAM_TYPE = ? AND ACADEMIC_YEAR = ?;
      `;
      const checkParams = [studentId, subjectName, examName, examType, academicYear || '2024-2025'];
      const [rows] = await connection.query(checkQuery, checkParams);
      console.log('Check Query Result:', rows); // Debug log

      if (rows.length > 0) {
        const updateQuery = `
          UPDATE ACD_MARKS_DETAIL 
          SET  CLASS = ?, SUBJECT_NAME = ?, MARKS = ?, EXAM_TYPE = ?, ACADEMIC_YEAR = ?, UPDATE_DATE = NOW(), UPDATED_BY = ?
          WHERE STUDENT_ID = ? AND EXAM_NAME = ? AND EXAM_TYPE = ? AND ACADEMIC_YEAR = ?;
        `;
        const updateParams = [
          // studentName || 'Unknown',
          studentClass,
          subjectName || null,
          marks || null,
          examType,
          academicYear || '2024-2025',
          createdBy,
          studentId,
          examName,
          examType,
          academicYear || '2024-2025',
        ];
        await connection.query(updateQuery, updateParams);
        console.log('Update executed for:', { studentId, examName, examType });
      } else {
        const insertQuery = `
          INSERT INTO ACD_MARKS_DETAIL 
          (STUDENT_ID, CLASS, SUBJECT_NAME, MARKS, EXAM_NAME, EXAM_TYPE, ACADEMIC_YEAR, CREATED_BY)
          VALUES (?,  ?, ?, ?, ?, ?, ?, ?);
        `;
        const insertParams = [
          studentId,
          // studentName || 'Unknown',
          studentClass,
          subjectName || null,
          marks || null,
          examName,
          examType,
          academicYear || '2024-2025',
          createdBy,
        ];
        await connection.query(insertQuery, insertParams);
        console.log('Insert executed for:', { studentId, examName, examType });
      }
    }

    await connection.commit();
    return { message: 'Grade entries processed successfully (Insert/Update)' };
  } catch (error) {
    await connection.rollback();
    console.error('Error saving grade entry:', error);
    throw error;
  } finally {
    connection.release();
  }
};

const submitGradeEntry = async (grades) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!Array.isArray(grades) || grades.length === 0) {
    throw new Error('No grades provided');
  }

  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    for (const grade of grades) {
      const { studentId, studentName, studentClass, subjectName, marks, examName, examType, academicYear } = grade;
      const createdBy = store.get('user') || 'N/A';

      if (!studentId || !studentClass || !examName || !examType) {
        throw new Error('Required fields (studentId, studentClass, examName, examType) are missing');
      }

      const checkQuery = `
        SELECT * FROM ACD_MARKS_DETAIL 
        WHERE STUDENT_ID = ? AND SUBJECT_NAME = ? AND EXAM_NAME = ? AND EXAM_TYPE = ? AND ACADEMIC_YEAR = ?;
      `;
      const checkParams = [studentId, subjectName, examName, examType, academicYear || '2024-2025'];
      const [rows] = await connection.query(checkQuery, checkParams);
      console.log('Check Query Result:', rows); // Debug log

      if (rows.length > 0) {
        const updateQuery = `
          UPDATE ACD_MARKS_DETAIL 
          SET CLASS = ?, SUBJECT_NAME = ?, MARKS = ?, EXAM_TYPE = ?, ACADEMIC_YEAR = ?, UPDATE_DATE = NOW(), UPDATED_BY = ?
          WHERE STUDENT_ID = ? AND EXAM_NAME = ? AND EXAM_TYPE = ? AND ACADEMIC_YEAR = ?;
        `;
        const updateParams = [
          studentName || 'Unknown',
          studentClass,
          subjectName || null,
          marks || null,
          examType,
          academicYear || '2024-2025',
          createdBy,
          studentId,
          examName,
          examType,
          academicYear || '2024-2025',
        ];
        await connection.query(updateQuery, updateParams);
        console.log('Update executed for:', { studentId, examName, examType });
      } else {
        const insertQuery = `
          INSERT INTO ACD_MARKS_DETAIL 
          (STUDENT_ID, CLASS, SUBJECT_NAME, MARKS, EXAM_NAME, EXAM_TYPE, ACADEMIC_YEAR, CREATED_BY)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        `;
        const insertParams = [
          studentId,
          studentName || 'Unknown',
          studentClass,
          subjectName || null,
          marks || null,
          examName,
          examType,
          academicYear || '2024-2025',
          createdBy,
        ];
        await connection.query(insertQuery, insertParams);
        console.log('Insert executed for:', { studentId, examName, examType });
      }
    }

    await connection.commit();
    return { message: 'Grade entries submitted successfully' };
  } catch (error) {
    await connection.rollback();
    console.error('Error submitting grade entry:', error);
    throw error;
  } finally {
    connection.release();
  }
};

module.exports = {
  getClassesForGradeEntry,
  getExamNameAndExamType,
  getSubjectsForGradeEntry,
  getStudentsWithClass,
  getSavedData,
  submitTotalMarks,
  getTotalMarks,
  saveGradeEntry,
  submitGradeEntry,
};