const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getAlumniStudents = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const query = `
    SELECT 
      STUDENT_ID, 
      STUDENT_NAME, 
      GENDER, 
      CONTACT_NUMBER, 
      DATE_OF_BIRTH, 
      EMAIL, 
      ACADEMIC_YEAR, 
      CLASS, 
      PERCENT, 
      STATUS 
    FROM ACD_ALUMNI_STUDENT
  `;

  const [getalumniResult] = await schoolDbConnection.query(query);
  return getalumniResult;
};

const promoteToAlumni = async (selectedStudents) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  let promotedCount = 0;
  let errorCount = 0;
  const errors = [];

  for (const studentId of selectedStudents) {
    try {
      console.log(`Processing student: ${studentId}`);

      // Check if the student already exists in ACD_ALUMNI_STUDENT
      const [alumniCheckResult] = await schoolDbConnection.query(
        "SELECT COUNT(*) as count FROM ACD_ALUMNI_STUDENT WHERE STUDENT_ID = ?",
        [studentId],
      );
      console.log(`Alumni check result for ${studentId}:`, alumniCheckResult);

      if (alumniCheckResult[0].count > 0) {
        console.log(`Student ${studentId} already exists in ALUMNI_STUDENT, skipping promotion.`);
        continue; // Skip to the next student
      }

      // Get student details using studentId before deleting
     const [studentDetails] = await schoolDbConnection.query(
  `WITH cte AS (
    SELECT
      STUDENT_ID,
      CLASS,
      ROUND(
        SUM(CASE WHEN EXAM_TYPE = 'Annual' THEN MARKS ELSE 0 END) /
        (COUNT(CASE WHEN EXAM_TYPE = 'Annual' THEN SUBJECT_NAME ELSE NULL END) * 100) * 100, 2
      ) AS PERCENT
    FROM
      ACD_MARKS_DETAIL
    GROUP BY
      STUDENT_ID, CLASS
  )
  SELECT
    stu.*,
    cls.ACADEMIC_YEAR,
    cls.CLASS,
    cte.PERCENT,
    CASE
      WHEN cte.PERCENT >= 33 THEN 'PASS'
      ELSE 'FAIL'
    END AS STATUS
  FROM
    ACD_STUDENT_PROFILE stu
  INNER JOIN
    ACD_STUDENT_CLASS_MAPPING cls ON stu.STUDENT_ID = cls.STUDENT_ID
  LEFT JOIN
    cte ON cte.STUDENT_ID = stu.STUDENT_ID AND cte.CLASS = cls.CLASS
  WHERE stu.STUDENT_ID = ?`,
  [studentId]
      );
      console.log(`Student details for ${studentId}:`, studentDetails);

      if (studentDetails.length === 0) {
        throw new Error(`Student details not found for ID: ${studentId}`);
      }

      const student = studentDetails[0];

      // Delete dependent rows from known tables (MARKS and STUDENT_ATTENDANCE, as identified in logs)
      const dependentTables = [
        'MARKS',
        'STUDENT_ATTENDANCE',
      ];

      for (const table of dependentTables) {
        try {
          await schoolDbConnection.query(
            `DELETE FROM ${table} WHERE STUDENT_ID = ?`,
            [studentId]
          );
          console.log(`Successfully deleted records from ${table} for Student_ID: ${studentId}`);
        } catch (deleteError) {
          console.warn(`Could not delete from ${table}: ${deleteError.message}`);
          // Continue even if deletion fails
        }
      }

      // Delete from ACD_STUDENT_CLASS_MAPPING
      await schoolDbConnection.query("DELETE FROM ACD_STUDENT_CLASS_MAPPING WHERE STUDENT_ID = ?", [studentId]);
      console.log(`Deleted from ACD_STUDENT_CLASS_MAPPING for ${studentId}`);

     // Fetch the Parent ID of the student before deleting the student record
const [parent] = await schoolDbConnection.query(
  "SELECT PARENT_ID FROM ACD_PARENT_PROFILE WHERE STUDENT_ID = ?",
  [studentId],
);

      console.log(`Parent details for ${studentId}:`, parent);

      let parentId = null;
      if (parent.length > 0) {
        parentId = parent[0].PARENT_ID;

        // Delete student from ACD_STUDENT_PROFILE
        await schoolDbConnection.query("DELETE FROM ACD_STUDENT_PROFILE WHERE STUDENT_ID = ?", [studentId]);
        console.log(`Deleted from ACD_STUDENT_PROFILE for ${studentId}`);

        // Delete parent from ACD_PARENT_PROFILE
        await schoolDbConnection.query("DELETE FROM ACD_PARENT_PROFILE WHERE PARENT_ID = ?", [parentId]);
        console.log(`Deleted from ACD_PARENT_PROFILE for Parent_ID: ${parentId}`);
      }

    const formattedDateOfBirth = student.DATE_OF_BIRTH
  ? new Date(student.DATE_OF_BIRTH).toISOString().split('T')[0]
  : null;


      // Start a transaction to disable foreign key checks
      await schoolDbConnection.query('SET FOREIGN_KEY_CHECKS = 0');
      console.log(`Foreign key checks disabled for ${studentId}`);

      try {
        // Insert into ACD_ALUMNI_STUDENT table after deletion from STUDENT_PROFILE
        const [insertResult] = await schoolDbConnection.query(
          `INSERT INTO ACD_ALUMNI_STUDENT (
            STUDENT_ID, STUDENT_NAME, GENDER, CONTACT_NUMBER, DATE_OF_BIRTH, 
            EMAIL, ACADEMIC_YEAR, CLASS, PERCENT, STATUS
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            student.STUDENT_ID,
            `${student.FIRST_NAME} ${student.MIDDLE_NAME || ''} ${student.LAST_NAME}`.trim(),
            student.GENDER || 'UNKNOWN',
            student.CONTACT_NUMBER || null,
            formattedDateOfBirth,
            student.EMAIL || null,
            student.ACADEMIC_YEAR || null,
           student.CLASS || null,
            student.PERCENT || null,
            student.STATUS || null,
          ],
        );
        console.log(`Insert result for ${studentId}:`, insertResult);

        // Verify the insertion
        const [verifyInsert] = await schoolDbConnection.query(
          "SELECT * FROM ACD_ALUMNI_STUDENT WHERE STUDENT_ID = ?",
          [studentId],
        );
        console.log(`Verification after insert for ${studentId}:`, verifyInsert);
      } finally {
        // Re-enable foreign key checks
        await schoolDbConnection.query('SET FOREIGN_KEY_CHECKS = 1');
        console.log(`Foreign key checks re-enabled for ${studentId}`);
      }

      promotedCount++;
    } catch (studentError) {
      console.error(`Error promoting student ${studentId}:`, studentError);
      errorCount++;
      errors.push({ studentId, error: studentError.message });
    }
  }

  return { promotedCount, errorCount, errors };
};

module.exports = {
  getAlumniStudents,
  promoteToAlumni,
};