const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

// Fetch all student assignment records from the database
const getStudentAssignmentRecords = async () => {
  // Check if context exists
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  // Get school database connection
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  // SQL query to fetch student assignment records
  const studentassignmentrecordSql = `
    SELECT
      sa.ASSIGNMENT_ID,
      sa.STUDENT_ID,
      CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
      CONCAT(td.CLASS, ' ', td.SECTION) AS CLASS_ID,
      sa.ASSIGNMENT_TYPE,
      sa.SUBJECT_NAME,
      sa.ASSIGNMENT_DESC,
      sa.SUBMISSION_START_DATE,
      sa.SUBMISSION_END_DATE,
      sa.SUBMISSION_DATE,
      sa.IS_SUBMITTED,
      sa.STUDENT_STATUS,
      td.TEACHER_NAME
    FROM ACD_STUDENT_ASSIGNMENT sa
    JOIN ACD_STUDENT_PROFILE sp ON sp.STUDENT_ID = sa.STUDENT_ID
    JOIN ACD_CLASS_SUB_TEACHER_MAPPING td ON td.TEACHER_ID = sa.STAFF_ID
    GROUP BY sa.ASSIGNMENT_ID
  `;

  try {
    logger.info('Executing SQL query for student assignments');
    const [result] = await schoolDbConnection.query(studentassignmentrecordSql);
    logger.info('Student assignment records fetched successfully', { count: result.length });
    return result;
  } catch (err) {
    logger.error('Error fetching student assignment records', { error: err.message });
    throw new Error(`Error fetching student assignment records: ${err.message}`);
  }
};

module.exports = {
  getStudentAssignmentRecords,
};