const { asyncLocalStorage } = require('../../middleware/authmiddleware');
 
const getClassList = async (staffId) => {
  if (!staffId || typeof staffId !== 'string') {
    throw new Error('Invalid or missing staffId');
  }
 
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('Database connection not established');
  }
 
  try {
    const classQuery = `
                SELECT DISTINCT CLASS_ID
FROM ACD_STUDENT_CLASS_MAPPING
WHERE CLASS != 'Alumni'
ORDER BY
  CASE
    WHEN SUBSTRING_INDEX(CLASS_ID, ' ', 1) = 'LKG' THEN 0
    WHEN SUBSTRING_INDEX(CLASS_ID, ' ', 1) = 'UKG' THEN 1
    WHEN SUBSTRING_INDEX(CLASS_ID, ' ', 1) REGEXP '^[0-9]+$' THEN CAST(SUBSTRING_INDEX(CLASS_ID, ' ', 1) AS UNSIGNED) + 1
    ELSE 999
  END,
  SUBSTRING_INDEX(CLASS_ID, ' ', -1)`;
    const [classes] = await schoolDbConnection.query(classQuery);
 
    let teacherClass = null;
    const teacherClassQuery = `SELECT CLASS_ID FROM ACD_CLASS_SUB_TEACHER_MAPPING WHERE TEACHER_ID = ? LIMIT 1`;
    const [teacherResult] = await schoolDbConnection.query(teacherClassQuery, [staffId]);
 
    if (teacherResult.length > 0) {
      teacherClass = teacherResult[0].CLASS_ID;
    }
 
    return {
      classes: classes.map(row => row.CLASS_ID),
      teacherClass
    };
  } catch (error) {
    throw new Error(`Failed to fetch class list: ${error.message}`);
  }
};
 
const getAttendanceList = async (className) => {
  if (!className || typeof className !== 'string') {
    throw new Error('Invalid or missing className');
  }
 
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('Database connection not established');
  }
 
  try {
    const getTeacherQuery = `SELECT TEACHER_ID FROM ACD_CLASS_SUB_TEACHER_MAPPING WHERE CLASS_ID = ? LIMIT 1`;
    const [teacherResult] = await schoolDbConnection.query(getTeacherQuery, [className]);
 
    if (teacherResult.length === 0) {
      throw new Error('No teacher found for this class');
    }
 
    const teacherId = teacherResult[0].TEACHER_ID;
 
    const studentQuery = `
      SELECT
        sp.STUDENT_ID,
         CONCAT(sp.FIRST_NAME, ' ', sp.LAST_NAME) AS FULL_NAME,
        ci.CLASS_ID,
        cd.ACADEMIC_YEAR,
        sa.STATUS
      FROM ACD_STUDENT_PROFILE sp
      JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
      JOIN ACD_CLASS_SUB_TEACHER_MAPPING ci ON cd.CLASS_ID = ci.CLASS_ID
      LEFT JOIN ACD_STUDENT_ATTENDANCE sa ON sp.STUDENT_ID = sa.STUDENT_ID
        AND sa.ACADEMIC_YEAR = cd.ACADEMIC_YEAR
        AND sa.ATTENDANCE_DATE = ?
      WHERE ci.CLASS_ID = ?
         group by  sp.STUDENT_ID
      ORDER BY sp.STUDENT_ID ASC`;
   
    const attendanceDate = new Date().toISOString().split('T')[0];
    const [students] = await schoolDbConnection.query(studentQuery, [attendanceDate, className]);
 
    if (students.length === 0) {
      throw new Error('No students found for this class');
    }
 
    return { teacherId, students };
  } catch (error) {
    throw new Error(`Failed to fetch attendance list: ${error.message}`);
  }
};
 
const getAttendanceCounts = async (className) => {
  if (!className || typeof className !== 'string') {
    throw new Error('Invalid or missing className');
  }
 
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('Database connection not established');
  }
 
  try {
    const getAcademicYearQuery = `SELECT ACADEMIC_YEAR FROM ACD_STUDENT_CLASS_MAPPING WHERE CLASS_ID = ? LIMIT 1`;
    const [result] = await schoolDbConnection.query(getAcademicYearQuery, [className]);
 
    if (result.length === 0) {
      throw new Error('Class not found');
    }
 
    const academicYear = result[0].ACADEMIC_YEAR;
    const attendanceDate = new Date().toISOString().split('T')[0];
 
    const countQuery = `
      SELECT
        SUM(CASE WHEN sa.STATUS = 'present' THEN 1 ELSE 0 END) AS presentCount,
        SUM(CASE WHEN sa.STATUS = 'absent' THEN 1 ELSE 0 END) AS absentCount
      FROM ACD_STUDENT_ATTENDANCE sa
      JOIN ACD_STUDENT_CLASS_MAPPING cd ON sa.STUDENT_ID = cd.STUDENT_ID
      WHERE cd.CLASS_ID = ? AND sa.ACADEMIC_YEAR = ? AND sa.ATTENDANCE_DATE = ?`;
    const [counts] = await schoolDbConnection.query(countQuery, [className, academicYear, attendanceDate]);
 
    return {
      presentCount: counts[0].presentCount || 0,
      absentCount: counts[0].absentCount || 0
    };
  } catch (error) {
    throw new Error(`Failed to fetch attendance counts: ${error.message}`);
  }
};
 
const submitAttendance = async (className, attendanceData) => {
  if (!className || typeof className !== 'string') {
    throw new Error('Invalid or missing className');
  }
 
  if (!Array.isArray(attendanceData) || attendanceData.length === 0) {
    throw new Error('Invalid or missing attendanceData');
  }
 
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('Database connection not established');
  }
 
  const connection = await schoolDbConnection.getConnection();
 
  try {
    await connection.beginTransaction();
 
    const getAcademicYearQuery = `SELECT ACADEMIC_YEAR FROM ACD_STUDENT_CLASS_MAPPING WHERE CLASS_ID = ? LIMIT 1`;
    const [result] = await connection.query(getAcademicYearQuery, [className]);
 
    if (result.length === 0) {
      throw new Error('Class not found');
    }
 
    const academicYear = result[0].ACADEMIC_YEAR;
    const attendanceDate = new Date().toISOString().split('T')[0];
 
    const checkAttendanceQuery = `
      SELECT COUNT(*) AS count
      FROM ACD_STUDENT_ATTENDANCE sa
      JOIN ACD_STUDENT_CLASS_MAPPING cd ON sa.STUDENT_ID = cd.STUDENT_ID
      WHERE cd.CLASS_ID = ? AND sa.ACADEMIC_YEAR = ? AND sa.ATTENDANCE_DATE = ?`;
    const [checkResult] = await connection.query(checkAttendanceQuery, [className, academicYear, attendanceDate]);
 
    if (checkResult[0].count > 0) {
      throw new Error('Attendance for this class on this date has already been submitted');
    }
 
    const insertQuery = `
      INSERT INTO ACD_STUDENT_ATTENDANCE (STUDENT_ID, ACADEMIC_YEAR, ATTENDANCE_DATE, STATUS)
      VALUES (?, ?, ?, ?)`;
    const statusValues = ['present', 'absent'];
 
    for (const student of attendanceData) {
      const { studentId, status } = student;
      if (!studentId || !status) {
        throw new Error('Each attendance record must have studentId and status');
      }
      if (!statusValues.includes(status.toLowerCase())) {
        throw new Error(`Invalid status value: ${status}. Must be 'present' or 'absent'`);
      }
 
      await connection.query(insertQuery, [studentId, academicYear, attendanceDate, status.toLowerCase()]);
    }
 
    await connection.commit();
    return { success: true, message: 'Attendance submitted successfully' };
  } catch (error) {
    await connection.rollback();
    throw new Error(`Failed to submit attendance: ${error.message}`);
  } finally {
    connection.release();
  }
};
 
const checkAttendanceStatus = async (className, date) => {
  if (!className || typeof className !== 'string') {
    throw new Error('Invalid or missing className');
  }
 
  if (!date || typeof date !== 'string') {
    throw new Error('Invalid or missing date');
  }
 
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }
 
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    throw new Error('Database connection not established');
  }
 
  try {
    const getAcademicYearQuery = `SELECT ACADEMIC_YEAR FROM ACD_STUDENT_CLASS_MAPPING WHERE CLASS_ID = ? LIMIT 1`;
    const [result] = await schoolDbConnection.query(getAcademicYearQuery, [className]);
 
    if (result.length === 0) {
      throw new Error('Class not found');
    }
 
    const academicYear = result[0].ACADEMIC_YEAR;
 
    const checkAttendanceQuery = `
      SELECT COUNT(*) AS count
      FROM ACD_STUDENT_ATTENDANCE sa
      JOIN ACD_STUDENT_CLASS_MAPPING cd ON sa.STUDENT_ID = cd.STUDENT_ID
      WHERE cd.CLASS_ID = ? AND sa.ACADEMIC_YEAR = ? AND sa.ATTENDANCE_DATE = ?`;
    const [checkResult] = await schoolDbConnection.query(checkAttendanceQuery, [className, academicYear, date]);
 
    return {
      success: true,
      isSubmitted: checkResult[0].count > 0
    };
  } catch (error) {
    throw new Error(`Failed to check attendance status: ${error.message}`);
  }
};
 
module.exports = { getClassList, getAttendanceList, submitAttendance, checkAttendanceStatus, getAttendanceCounts };