const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;
const jwt = require('jsonwebtoken');

const getStudentProfiles = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const query = `
    SELECT 
      sp.STUDENT_ID, sp.FIRST_NAME, sp.MIDDLE_NAME, sp.LAST_NAME, sp.GENDER, 
      cd.CLASS, cd.SECTION, 
        s.STAFF_NAME AS CLASS_TEACHER,
      sp.CONTACT_NUMBER, sp.HOUSE_NUMBER, sp.HOUSE_BUILDING_NAME, sp.STREET_NAME, sp.LANDMARK,
      sp.CITY, sp.STATE, sp.POSTAL_CODE, sp.NATIONALITY, sp.DATE_OF_BIRTH, 
      sp.EMAIL, sp.ENROLLMENT_DATE, sp.BIRTH_CERTIFICATE_NUMBER, sp.CASTE, 
      sp.RELIGION, sp.BLOOD_GROUP, sp.IDENTIFICATION_MARK, sp.PREVIOUS_SCHOOL,
      sp.EMERGENCY_CONTACT_NAME, sp.EMERGENCY_CONTACT_NUMBER, sp.AADHAR_NUMBER, 
      sp.DISEASE_IF_ANY, sp.ADDITIONAL_NOTE
    FROM ACD_STUDENT_PROFILE sp
  LEFT  JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
  LEFT JOIN ACD_CLASS_SUB_TEACHER_MAPPING ci ON cd.CLASS_ID = ci.CLASS_ID
  LEFT  JOIN ACD_STAFF_PROFILE s ON ci.TEACHER_ID = s.TEACHER_ID
  `;

  const [results] = await schoolDbConnection.query(query);
  return results;
};

const getStudentById = async (studentId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const studentSql = `
    SELECT
    sp.STUDENT_ID, sp.FIRST_NAME, sp.MIDDLE_NAME, sp.LAST_NAME, sp.GENDER,
    cd.CLASS, cd.SECTION,
    sp.CONTACT_NUMBER, sp.HOUSE_NUMBER, sp.HOUSE_BUILDING_NAME, sp.STREET_NAME, sp.LANDMARK,
    sp.CITY, sp.STATE, sp.POSTAL_CODE, sp.NATIONALITY, sp.DATE_OF_BIRTH,
    sp.EMAIL, sp.ENROLLMENT_DATE, sp.BIRTH_CERTIFICATE_NUMBER, sp.CASTE,
    sp.RELIGION, sp.BLOOD_GROUP, sp.IDENTIFICATION_MARK, sp.PREVIOUS_SCHOOL,
    sp.EMERGENCY_CONTACT_NAME, sp.EMERGENCY_CONTACT_NUMBER, sp.AADHAR_NUMBER,
    sp.DISEASE_IF_ANY, sp.ADDITIONAL_NOTE  
FROM ACD_STUDENT_PROFILE sp
LEFT JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
LEFT JOIN ACD_CLASS_SUB_TEACHER_MAPPING ci ON cd.CLASS_ID = ci.CLASS_ID
LEFT JOIN ACD_STAFF_PROFILE s ON ci.TEACHER_ID = s.STAFF_ID
WHERE sp.STUDENT_ID = ?;
  `;

  const [studentdataResult] = await schoolDbConnection.query(studentSql, [studentId]);
  return studentdataResult;
};

const updateStudentById = async (studentId, updatedData) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const studentProfileFields = [
    'FIRST_NAME', 'MIDDLE_NAME', 'LAST_NAME', 'GENDER', 'CONTACT_NUMBER', 'ADDRESS', 'CITY', 'STATE', 'POSTAL_CODE',
    'NATIONALITY', 'DATE_OF_BIRTH', 'EMAIL', 'ENROLLMENT_DATE', 
    'BIRTH_CERTIFICATE_NUMBER', 'CASTE', 'RELIGION', 'BLOOD_GROUP', 'IDENTIFICATION_MARK',
    'PREVIOUS_SCHOOL', 'EMERGENCY_CONTACT_NAME', 'EMERGENCY_CONTACT_NUMBER', 'AADHAR_NUMBER',
    'DISEASE_IF_ANY', 'ADDITIONAL_NOTE', 'ACADEMIC_YEAR' 
  ];

  let setClauseStudentProfile = '';
  let values = [];

  studentProfileFields.forEach(field => {
    if (field in updatedData) {
      if (setClauseStudentProfile !== '') setClauseStudentProfile += ', ';
      setClauseStudentProfile += `sp.${field} = ?`;
      values.push(updatedData[field]);
    }
  });

  if (!setClauseStudentProfile) {
    throw new Error('No valid fields provided for update');
  }

  const query = `
    UPDATE 
      ACD_STUDENT_PROFILE sp
    JOIN 
      ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
    SET 
      ${setClauseStudentProfile}
    WHERE 
      sp.STUDENT_ID = ?
  `;

  values.push(studentId);
  const [result] = await schoolDbConnection.query(query, values);
  return result;
};

const setStudentId = async (studentId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  // Verify the student exists
  const [student] = await schoolDbConnection.query(
    'SELECT STUDENT_ID FROM ACD_STUDENT_PROFILE WHERE STUDENT_ID = ?',
    [studentId]
  );
  if (student.length === 0) {
    throw new Error('Student not found');
  }

  // Generate JWT token with studentId
  const token = jwt.sign({ studentId }, process.env.JWT_SECRET || 'your_jwt_secret', { expiresIn: '1h' });
  return { token };
};

module.exports = {
  getStudentProfiles,
  getStudentById,
  updateStudentById,
  setStudentId,
};