
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');
const schedule = require('node-schedule');

const getPromotableStudents = async () => {
  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in getPromotableStudents', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }

  const query = `
    SELECT
      stu.STUDENT_ID,
      CONCAT(stu.FIRST_NAME, ' ', COALESCE(stu.MIDDLE_NAME, ''), ' ', stu.LAST_NAME) AS STUDENT_NAME,
      cls.ACADEMIC_YEAR,
      cls.CLASS,
      cls.SECTION,
      ROUND(
        SUM(CASE WHEN md.EXAM_TYPE = 'Annual' THEN md.MARKS ELSE 0 END) /
        (COUNT(CASE WHEN md.EXAM_TYPE = 'Annual' THEN md.SUBJECT_NAME ELSE NULL END) * 100) * 100,
        2
      ) AS PERCENT,
      CASE
        WHEN
          ROUND(
            SUM(CASE WHEN md.EXAM_TYPE = 'Annual' THEN md.MARKS ELSE 0 END) /
            (COUNT(CASE WHEN md.EXAM_TYPE = 'Annual' THEN md.SUBJECT_NAME ELSE NULL END) * 100) * 100,
            2
          ) > 33 THEN 'PASS'
        ELSE 'FAIL'
      END AS STATUS
    FROM
      ACD_STUDENT_PROFILE stu
    INNER JOIN
      ACD_STUDENT_CLASS_MAPPING cls ON cls.STUDENT_ID = stu.STUDENT_ID
    INNER JOIN
      ACD_MARKS_DETAIL md ON md.STUDENT_ID = stu.STUDENT_ID
    GROUP BY
      stu.STUDENT_ID,
      stu.FIRST_NAME,
      stu.MIDDLE_NAME,
      stu.LAST_NAME,
      cls.ACADEMIC_YEAR,
      cls.CLASS,
      cls.SECTION`;

  try {
    logger.info('Executing SQL query to fetch promotable students');
    const [results] = await schoolDbConnection.query(query);
    logger.info('Promotable students fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching promotable students', { error: err.message });
    throw new Error(`Error fetching promotable students: ${err.message}`);
  }
};

const promoteStudents = async (selectedStudents) => {
  if (!selectedStudents || !Array.isArray(selectedStudents) || selectedStudents.length === 0) {
    logger.error('Invalid request data: selectedStudents must be a non-empty array');
    throw new Error('Invalid request data');
  }

  const store = asyncLocalStorage.getStore();
  logger.info('AsyncLocalStorage store in promoteStudents', { store: store ? Array.from(store.keys()) : null });
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }

  try {
    // Fetch marks for selected students
    const marksQuery = `
      SELECT
        s.STUDENT_ID,
        ROUND(
          SUM(CASE WHEN s.EXAM_TYPE = 'Annual' THEN s.MARKS ELSE 0 END) /
          (COUNT(CASE WHEN s.EXAM_TYPE = 'Annual' THEN s.SUBJECT_NAME ELSE NULL END) * 100) * 100,
          2
        ) AS PERCENT
      FROM
        ACD_MARKS_DETAIL s
      WHERE
        s.STUDENT_ID IN (?)
      GROUP BY
        s.STUDENT_ID
      ORDER BY
        s.STUDENT_ID`;
    const [marksResults] = await schoolDbConnection.query(marksQuery, [selectedStudents]);
    logger.info('Fetched marks for students', { studentIds: selectedStudents, marksCount: marksResults.length });

    // Fetch class details for selected students
    const detailsQuery = `
      SELECT STUDENT_ID, CLASS, SECTION, ACADEMIC_YEAR
      FROM ACD_STUDENT_CLASS_MAPPING
      WHERE STUDENT_ID IN (?)`;
    const [detailsResults] = await schoolDbConnection.query(detailsQuery, [selectedStudents]);
    logger.info('Fetched class details for students', { studentIds: selectedStudents, detailsCount: detailsResults.length });

    const studentDetailsMap = new Map(detailsResults.map(detail => [detail.STUDENT_ID, detail]));

    // Filter and prepare promotion data
    const studentsToPromote = marksResults
      .filter(student => {
        const details = studentDetailsMap.get(student.STUDENT_ID);
        if (!details) {
          logger.warn('No class details found for student', { studentId: student.STUDENT_ID });
          return false;
        }
        return student.PERCENT > 40;
      })
      .map(student => {
        const details = studentDetailsMap.get(student.STUDENT_ID);
        const currentClass = details.CLASS || 'Unknown';
        const currentAcademicYear = details.ACADEMIC_YEAR || 'Unknown';

        // Determine the next class
        let nextClass;
        if (currentClass === '12') {
          nextClass = 'Alumni';
        } else if (['LKG', 'UKG'].includes(currentClass)) {
          nextClass = currentClass === 'LKG' ? 'UKG' : '1';
        } else if (!isNaN(currentClass)) {
          nextClass = (parseInt(currentClass, 10) + 1).toString();
        } else {
          nextClass = currentClass;
        }

        // Determine the next academic year
        const [startYear, endYear] = currentAcademicYear.split('-').map(Number);
        const nextAcademicYear = `${endYear}-${endYear + 1}`;

        return {
          STUDENT_ID: student.STUDENT_ID,
          nextClass,
          section: details.SECTION || 'Unknown',
          nextAcademicYear,
          currentClass: details.CLASS,
          currentAcademicYear: details.ACADEMIC_YEAR,
        };
      });

    if (studentsToPromote.length === 0) {
      logger.warn('No students meet the promotion criteria');
      throw new Error('No students meet the promotion criteria');
    }

    logger.info('Students to promote', { studentsToPromote });

    // Insert promotions and update IS_PROMOTED flag
    const connection = await schoolDbConnection.getConnection();
    try {
      await connection.beginTransaction();

      for (const student of studentsToPromote) {
        const insertQuery = `
          INSERT INTO ACD_STUDENT_CLASS_MAPPING (STUDENT_ID, CLASS, SECTION, ACADEMIC_YEAR)
          VALUES (?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE CLASS = VALUES(CLASS), SECTION = VALUES(SECTION), ACADEMIC_YEAR = VALUES(ACADEMIC_YEAR)`;
        await connection.query(insertQuery, [
          student.STUDENT_ID,
          student.nextClass,
          student.section,
          student.nextAcademicYear,
        ]);

        const updateQuery = `
          UPDATE ACD_STUDENT_CLASS_MAPPING 
          SET IS_PROMOTED = 'TRUE' 
          WHERE STUDENT_ID = ? AND CLASS = ? AND ACADEMIC_YEAR = ?`;
        await connection.query(updateQuery, [
          student.STUDENT_ID,
          student.currentClass,
          student.currentAcademicYear,
        ]);
      }

      await connection.commit();
      logger.info('Students promoted successfully', { count: studentsToPromote.length });
      return { success: true, message: 'Students promoted successfully', count: studentsToPromote.length };
    } catch (error) {
      await connection.rollback();
      logger.error('Error in promoteStudents transaction', { error: error.message });
      throw error;
    } finally {
      connection.release();
    }
  } catch (err) {
    logger.error('Error promoting students', { error: err.message });
    throw err;
  }
};

// Schedule job to reset IS_PROMOTED flag annually on April 1st
schedule.scheduleJob('0 0 1 4 *', async () => {
  try {
    const store = asyncLocalStorage.getStore();
    logger.info('AsyncLocalStorage store in resetPromotionStatus', { store: store ? Array.from(store.keys()) : null });
    if (!store) {
      logger.error('Missing AsyncLocalStorage context in scheduled job');
      return;
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Database connection not established in scheduled job');
      return;
    }

    const currYear = new Date().getFullYear();
    const prevYear = currYear - 1;
    const academicYear = `${prevYear}-${currYear}`;

    const resetQuery = `
      UPDATE ACD_STUDENT_CLASS_MAPPING 
      SET IS_PROMOTED = 'FALSE' 
      WHERE IS_PROMOTED = 'TRUE' 
      AND ACADEMIC_YEAR = ?`;
    await schoolDbConnection.query(resetQuery, [academicYear]);
    logger.info(`IS_PROMOTED flag reset for academic year ${academicYear}`);
  } catch (err) {
    logger.error('Error resetting IS_PROMOTED flag', { error: err.message });
  }
});

module.exports = {
  getPromotableStudents,
  promoteStudents,
};