// Fetch total budget and expenses by month
const getTotalBudget = async (schoolDbConnection) => {
  try {
    const query = `
     SELECT
  ROUND(BUDGET / 12, 2) AS MONTHLY_BUDGET,
  MONTH_NAME,
  MONTHLY_EXPENSE,
  ROUND((BUDGET / 12) - MONTHLY_EXPENSE, 2) AS DIFFERENCE,
  CASE
    WHEN MONTHLY_EXPENSE > BUDGET / 12 THEN 'OVERBUDGET'
    WHEN MONTHLY_EXPENSE < BUDGET / 12 THEN 'UNDERBUDGET'
    ELSE 'ON BUDGET'
  END AS BUDGET_STATUS
FROM (
  SELECT
    A.BUDGET,
    MONTHNAME(B.EXPENSE_DATE) AS MONTH_NAME,
    SUM(B.AMOUNT) AS MONTHLY_EXPENSE
  FROM ACC_EXPENSE_CATEGORIES A
  LEFT JOIN ACC_EXPENSES B
    ON A.CATEGORY_ID = B.CATEGORY_ID
  GROUP BY  A.BUDGET, MONTHNAME(B.EXPENSE_DATE)
) AS SUB
    `;
    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    throw error; // Let the controller handle the error
  }
};

// Fetch total budget by category
const getCategoryWiseTotalBudget = async (schoolDbConnection) => {
  try {
    const query = `
SELECT CATEGORY_NAME,BUDGET FROM   ACC_EXPENSE_CATEGORIES
    `;
    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    throw error;
  }
};

module.exports = {
  getTotalBudget,
  getCategoryWiseTotalBudget,
};