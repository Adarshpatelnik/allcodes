// backend/services/accounting/expense/budgetanalysistable.js
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getTotalBudgetTotalExpense = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  try {
    const query = `
         SELECT
         FINANCIAL_YEAR,
  ROUND(BUDGET / 12, 2) AS MONTHLY_BUDGET,
  MONTH_NAME,
  MONTHLY_EXPENSE,
  ROUND((BUDGET / 12) - MONTHLY_EXPENSE, 2) AS DIFFERENCE,
  CASE
    WHEN MONTHLY_EXPENSE > BUDGET / 12 THEN 'OVERBUDGET'
    WHEN MONTHLY_EXPENSE < BUDGET / 12 THEN 'UNDERBUDGET'
    ELSE 'ON BUDGET'
  END AS BUDGET_STATUS
FROM (
  SELECT
    B.FINANCIAL_YEAR,
    A.BUDGET,
    MONTHNAME(B.EXPENSE_DATE) AS MONTH_NAME,
    SUM(B.AMOUNT) AS MONTHLY_EXPENSE
  FROM ACC_EXPENSE_CATEGORIES A
  LEFT JOIN ACC_EXPENSES B
    ON A.CATEGORY_ID = B.CATEGORY_ID
  GROUP BY  A.BUDGET, MONTHNAME(B.EXPENSE_DATE)
) AS SUB
    `;
    console.log('Executing budget query:', query);
    const [rows] = await schoolDbConnection.query(query);
    console.log('Budget data retrieved:', rows);
    return rows;
  } catch (error) {
    console.error('Error fetching budget records:', error.message);
    throw new Error('Error fetching budget records: ' + error.message);
  }
};

module.exports = {
  getTotalBudgetTotalExpense,
};