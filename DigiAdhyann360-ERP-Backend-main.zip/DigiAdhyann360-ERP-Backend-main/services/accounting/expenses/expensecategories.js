const submitAcctExpenseCategory = async (schoolDbConnection, { CATEGORY_ID, CATEGORY_NAME, BUDGET, DESCRIPTION }) => {
  try {
    // Convert values to uppercase
    const upperCategoryName = CATEGORY_NAME.toUpperCase();
    const upperDescription = DESCRIPTION.toUpperCase();

    let query;
    if (CATEGORY_ID) {
      // Update query
      query = `
        UPDATE ACC_EXPENSE_CATEGORIES 
        SET CATEGORY_NAME = ?, DESCRIPTION = ?, BUDGET = ?
        WHERE CATEGORY_ID = ?
      `;
      console.log("Executing UPDATE query with CATEGORY_ID:", CATEGORY_ID);
      const [updateResult] = await schoolDbConnection.query(query, [upperCategoryName, upperDescription, BUDGET, CATEGORY_ID]);
      console.log("Update result:", updateResult);
      return updateResult;
    } else {
      // Insert query
      query = `
        INSERT INTO ACC_EXPENSE_CATEGORIES (CATEGORY_NAME, DESCRIPTION, BUDGET)
        VALUES (?, ?, ?)
      `;
      console.log("Executing INSERT query");
      const [insertResult] = await schoolDbConnection.query(query, [upperCategoryName, upperDescription, BUDGET]);
      console.log("Insert result:", insertResult);
      return insertResult;
    }
  } catch (error) {
    console.error("Error in submitAcctExpenseCategory service:", error.message);
    throw error;
  }
};

const getAcctExpenseCategory = async (schoolDbConnection) => {
  try {
    const query = `
   SELECT CATEGORY_ID, CATEGORY_NAME, DESCRIPTION, BUDGET, CREATE_DATE 
      FROM ACC_EXPENSE_CATEGORIES
    `;
    console.log("Executing query:", query);
    const [result] = await schoolDbConnection.query(query);
    console.log("Fetched categories:", result);
    return result;
  } catch (error) {
    console.error("Error in getAcctExpenseCategory service:", error.message);
    throw error;
  }
};

const deleteAcctExpenseCategory = async (schoolDbConnection, id) => {
  try {
    const query = `
      DELETE FROM ACC_EXPENSE_CATEGORIES
      WHERE CATEGORY_ID = ?
    `;
    console.log("Executing delete query:", query);
    const [result] = await schoolDbConnection.query(query, [id]);
    console.log("Delete result:", result);
    return result;
  } catch (error) {
    console.error("Error in deleteAcctExpenseCategory service:", error.message);
    throw error;
  }
};

module.exports = {
  submitAcctExpenseCategory,
  getAcctExpenseCategory,
  deleteAcctExpenseCategory,
};