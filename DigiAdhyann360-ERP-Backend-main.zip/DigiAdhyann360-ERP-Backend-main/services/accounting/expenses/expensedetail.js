
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getExpenseCategory = async (month, year) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  if (!month || !year) throw new Error('Month and year are required');

  try {
    const query = `
      SELECT A.CATEGORY_ID, B.EXPENSE_ID, A.CATEGORY_NAME, B.AMOUNT, B.EXPENSE_DATE, B.PAID_BY, B.DEPARTMENT, B.STATUS 
      FROM ACC_EXPENSE_CATEGORIES A
      LEFT JOIN ACC_EXPENSES B ON A.CATEGORY_ID = B.CATEGORY_ID
      WHERE UPPER(MONTHNAME(B.EXPENSE_DATE)) = UPPER(?) AND YEAR(B.EXPENSE_DATE) = ?
    `;
    console.log('Executing getExpenseCategory query:', query, [month, year]);
    const [rows] = await schoolDbConnection.query(query, [month, year]);
    console.log('Expense records retrieved:', rows);
    return rows;
  } catch (error) {
    console.error('Error fetching expense records:', error.message);
    throw new Error('Error fetching expense records: ' + error.message);
  }
};

const deleteExpenseCategory = async (categoryId) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  try {
    const query = `
      DELETE FROM ACC_EXPENSES
      WHERE CATEGORY_ID = ?
    `;
    console.log('Executing deleteExpenseCategory query:', query, [categoryId]);
    const [deleteResult] = await schoolDbConnection.query(query, [categoryId]);

    if (deleteResult.affectedRows === 0) {
      throw new Error('Expense record not found');
    }
    console.log('Delete result:', deleteResult);
    return { message: 'Expense record deleted successfully' };
  } catch (error) {
    console.error('Error deleting expense record:', error.message);
    throw new Error('Error deleting expense record: ' + error.message);
  }
};

const submitExpenseCategory = async (expenseData) => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  const {
    CATEGORY_NAME,
    AMOUNT,
    EXPENSE_DATE,
    PAID_BY,
    DEPARTMENT,
    STATUS,
  } = expenseData;

  if (!CATEGORY_NAME || !AMOUNT || !EXPENSE_DATE || !PAID_BY || !DEPARTMENT || !STATUS) {
    throw new Error('Missing required fields');
  }

  try {
    const [categoryRows] = await schoolDbConnection.query(
      'SELECT CATEGORY_ID FROM ACC_EXPENSE_CATEGORIES WHERE CATEGORY_NAME = ?',
      [CATEGORY_NAME.toUpperCase()]
    );
    if (categoryRows.length === 0) {
      throw new Error('Invalid CATEGORY_NAME');
    }
    const CATEGORY_ID = categoryRows[0].CATEGORY_ID;

    const financialYear = '2025-2026';
    const createdBy = 'SYSTEM';

    const [rows] = await schoolDbConnection.query(`
      SELECT EXPENSE_ID FROM ACC_EXPENSES ORDER BY EXPENSE_ID DESC LIMIT 1
    `);

    let newExpenseId = 'EXP-1001';
    if (rows.length > 0 && rows[0].EXPENSE_ID) {
      const lastId = rows[0].EXPENSE_ID;
      const lastNumber = parseInt(lastId.split('-')[1]) || 1000;
      newExpenseId = `EXP-${lastNumber + 1}`;
    }

    console.log('Generated new EXPENSE_ID:', newExpenseId);

    const query = `
      INSERT INTO ACC_EXPENSES 
      (EXPENSE_ID, CATEGORY_ID, AMOUNT, EXPENSE_DATE, PAID_BY, DEPARTMENT, STATUS, FINANCIAL_YEAR, CREATED_BY)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    console.log('Executing insert query:', query, [
      newExpenseId,
      CATEGORY_ID,
      AMOUNT,
      EXPENSE_DATE,
      PAID_BY.toUpperCase(),
      DEPARTMENT.toUpperCase(),
      STATUS.toUpperCase(),
      financialYear,
      createdBy,
    ]);
    const [insertResult] = await schoolDbConnection.query(query, [
      newExpenseId,
      CATEGORY_ID,
      AMOUNT,
      EXPENSE_DATE,
      PAID_BY.toUpperCase(),
      DEPARTMENT.toUpperCase(),
      STATUS.toUpperCase(),
      financialYear,
      createdBy,
    ]);

    return {
      message: 'Expense inserted successfully',
      id: insertResult.insertId,
      expenseId: newExpenseId,
    };
  } catch (error) {
    console.error('Error processing acctexpensecategory:', error);
    throw new Error('Error processing acctexpensecategory: ' + (error.message || error));
  }
};

const getExpenseCategories = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  try {
    const query = 'SELECT CATEGORY_NAME FROM ACC_EXPENSE_CATEGORIES';
    console.log('Executing getExpenseCategories query:', query);
    const [rows] = await schoolDbConnection.query(query);
    console.log('Categories retrieved:', rows);
    return rows.map(row => row.CATEGORY_NAME);
  } catch (error) {
    console.error('Error fetching expense categories:', error.message);
    throw new Error('Error fetching expense categories: ' + error.message);
  }
};

module.exports = {
  getExpenseCategory,
  deleteExpenseCategory,
  submitExpenseCategory,
  getExpenseCategories,
};