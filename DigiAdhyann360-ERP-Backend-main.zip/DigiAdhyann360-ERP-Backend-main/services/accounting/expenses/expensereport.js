
const getAcctTotalExpense = async (schoolDbConnection) => {
  try {
    const query = `
     SELECT SUM(AMOUNT) AS TOTAL_EXPENCE FROM  ACC_EXPENSES
    `;
    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    throw error;
  }
};

// Fetch total expenses for the current month
const getAcctTotalBudgetThisMonth = async (schoolDbConnection) => {
  try {
    const query = `
   WITH CTE AS(
SELECT
  SUM(AMOUNT) AS TOTAL_EXPENSE,
  MONTHNAME(EXPENSE_DATE) AS MONTH_NAME
FROM ACC_EXPENSES
GROUP BY  MONTHNAME(EXPENSE_DATE))
SELECT * FROM CTE
    `;
    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    throw error;
  }
};

// Fetch expense percentage relative to budget for the current month
const getExpenseFromBudget = async (schoolDbConnection) => {
  try {
    const query = `
SELECT
  ROUND((expense_total.total_amount * 100) / budget_total.total_budget, 2) AS EXPENSE_PERCENTAGE
FROM
  (SELECT SUM(AMOUNT) AS total_amount FROM SCHOOL_ERP_DATABASE.ACC_EXPENSES) AS expense_total,
  (SELECT SUM(BUDGET) AS total_budget FROM SCHOOL_ERP_DATABASE.ACC_EXPENSE_CATEGORIES) AS budget_total;
    `;
    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    throw error;
  }
};

// Fetch expenses by category and month
const getAcctExpenseByCategory = async (schoolDbConnection) => {
  try {
    const query = `
SELECT
  A.CATEGORY_NAME,
  EXTRACT(MONTH FROM B.EXPENSE_DATE) AS MONTH_NO,
  MONTHNAME(B.EXPENSE_DATE) AS MONTH_NAME,
  SUM(B.AMOUNT) AS TOTAL_EXPENSE
FROM ACC_EXPENSE_CATEGORIES A
LEFT JOIN ACC_EXPENSES B
  ON A.CATEGORY_ID = B.CATEGORY_ID
GROUP BY A.CATEGORY_NAME, MONTH_NO, MONTH_NAME
ORDER BY MONTH_NO

    `;
    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    throw error;
  }
};

module.exports = {
  getAcctTotalExpense,
  getAcctTotalBudgetThisMonth,
  getExpenseFromBudget,
  getAcctExpenseByCategory,
};