const createCategory = async (schoolDbConnection, { CATEGORY_NAME, DESCRIPTION, FREQUENCY }) => {
  try {
    if (!CATEGORY_NAME || !FREQUENCY) {
      throw new Error("Missing required fields");
    }
    const query = `
      INSERT INTO ACC_FEE_CATEGORY (CATEGORY_NAME, DESCRIPTION, FREQUENCY)
      VALUES (?, ?, ?)
    `;
    const [result] = await schoolDbConnection.query(query, [CATEGORY_NAME, DESCRIPTION, FREQUENCY]);
    return { CATEGORY_ID: result.insertId, CATEGORY_NAME, DESCRIPTION, FREQUENCY };
  } catch (error) {
    console.error("Error creating category:", error.message);
    throw error;
  }
};

const getCategories = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT CATEGORY_ID, CATEGORY_NAME, DESCRIPTION, FREQUENCY
      FROM ACC_FEE_CATEGORY
    `;
    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    console.error("Error fetching categories:", error.message);
    throw error;
  }
};

const deleteCategory = async (schoolDbConnection, categoryId) => {
  try {
    const query = `DELETE FROM ACC_FEE_CATEGORY WHERE CATEGORY_ID = ?`;
    const [result] = await schoolDbConnection.query(query, [categoryId]);
    if (result.affectedRows === 0) {
      throw new Error("Category not found");
    }
    return { message: "Category deleted successfully", id: categoryId };
  } catch (error) {
    console.error("Error deleting category:", error.message);
    throw error;
  }
};

const updateCategory = async (schoolDbConnection, categoryId, { CATEGORY_NAME, DESCRIPTION, FREQUENCY }) => {
  try {
    const query = `
      UPDATE ACC_FEE_CATEGORY
      SET CATEGORY_NAME = ?, DESCRIPTION = ?, FREQUENCY = ?
      WHERE CATEGORY_ID = ?
    `;
    const [result] = await schoolDbConnection.query(query, [CATEGORY_NAME, DESCRIPTION, FREQUENCY, categoryId]);
    if (result.affectedRows === 0) {
      throw new Error("Category not found");
    }
    return { CATEGORY_ID: categoryId, CATEGORY_NAME, DESCRIPTION, FREQUENCY };
  } catch (error) {
    console.error("Error updating category:", error.message);
    throw error;
  }
};

module.exports = {
  createCategory,
  getCategories,
  deleteCategory,
  updateCategory,
};