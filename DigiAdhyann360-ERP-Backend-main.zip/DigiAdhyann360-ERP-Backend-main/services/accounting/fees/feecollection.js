const logger = require('../../../logger/logger');

const getClasses = async (connection) => {
  const [rows] = await connection.execute(
    'SELECT DISTINCT CLASS FROM ACD_STUDENT_CLASS_MAPPING'
  );
  return rows.map(row => row.CLASS);
};

const getFrequencies = async (connection) => {
  const [rows] = await connection.execute(
    'SELECT DISTINCT COLLECTION_SUB_METHOD AS FREQUENCY FROM ACC_FEE_COLLECTION_METHOD'
  );
  return rows.map(row => row.FREQUENCY);
};

const getStudentFeesByClassAndFrequency = async (connection, className, frequency) => {
  try {
    const query = `
      SELECT 
        RECORD_ID,
        FREQUENCY,
        CLASS,
        STUDENT_ID,
        STUDENT_NAME,
        TOTAL_FEES,
        TOTAL_FEES_DISCOUNT,
        NET_FEES,
        STATUS,
        DATE_FORMAT(DUE_START_DATE, '%Y-%m-%d') AS DUE_START_DATE,
        DATE_FORMAT(DUE_END_DATE, '%Y-%m-%d') AS DUE_END_DATE
      FROM ACC_FEE_COLLECTION_STATUS
      WHERE TRIM(UPPER(CLASS)) = ? AND TRIM(UPPER(FREQUENCY)) = ?
    `;
    const [rows] = await connection.execute(query, [className.trim().toUpperCase(), frequency.trim().toUpperCase()]);
    logger.info('Fetched student fees from database', { className, frequency, count: rows.length });
    return rows;
  } catch (error) {
    logger.error('Error in getStudentFeesByClassAndFrequency:', { error: error.message });
    throw error;
  }
};

const insertFeeRecords = async (connection, records) => {
  const query = `
    INSERT INTO ACC_FEE_COLLECTION_STATUS (
      FREQUENCY, CLASS, STUDENT_ID, STUDENT_NAME, TOTAL_FEES, TOTAL_FEES_DISCOUNT, 
      NET_FEES, STATUS, DUE_START_DATE, DUE_END_DATE, RECORD_CREATE_DT
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())
  `;
  for (const record of records) {
    const values = [
      record.FREQUENCY,
      record.CLASS,
      record.STUDENT_ID,
      record.STUDENT_NAME,
      record.TOTAL_FEES,
      record.TOTAL_FEES_DISCOUNT || 0,
      record.NET_FEES,
      record.STATUS || 'Due',
      record.DUE_START_DATE || null,
      record.DUE_END_DATE || null,
    ];
    await connection.execute(query, values);
  }
  return { message: 'Fee records inserted successfully' };
};

const updateFeeRecord = async (connection, record) => {
  try {
    const [existingRows] = await connection.execute(
      'SELECT TOTAL_FEES, TOTAL_FEES_DISCOUNT, NET_FEES FROM ACC_FEE_COLLECTION_STATUS WHERE RECORD_ID = ?',
      [record.RECORD_ID]
    );
    if (existingRows.length === 0) {
      throw new Error('Record not found');
    }
    const existingRecord = existingRows[0];

    const totalFeesDiscount = record.TOTAL_FEES_DISCOUNT !== undefined ? parseFloat(record.TOTAL_FEES_DISCOUNT) : existingRecord.TOTAL_FEES_DISCOUNT || 0;
    let netFees = record.NET_FEES !== undefined ? parseFloat(record.NET_FEES) : existingRecord.NET_FEES || 0;

    if (isNaN(totalFeesDiscount) || totalFeesDiscount < 0) {
      throw new Error('TOTAL_FEES_DISCOUNT must be a non-negative number');
    }
    if (isNaN(netFees) || netFees < 0) {
      netFees = existingRecord.TOTAL_FEES - totalFeesDiscount; // Auto-calculate if invalid
    }


    const dueStartDate = record.DUE_START_DATE || null;
    const dueEndDate = record.DUE_END_DATE || null;
    if (dueStartDate && !/^\d{4}-\d{2}-\d{2}$/.test(dueStartDate)) {
      throw new Error('DUE_START_DATE must be in YYYY-MM-DD format');
    }
    if (dueEndDate && !/^\d{4}-\d{2}-\d{2}$/.test(dueEndDate)) {
      throw new Error('DUE_END_DATE must be in YYYY-MM-DD format');
    }

    const query = `
      UPDATE ACC_FEE_COLLECTION_STATUS 
      SET 
        TOTAL_FEES_DISCOUNT = ?,
        NET_FEES = ?,
        STATUS = ?,
        DUE_START_DATE = ?,
        DUE_END_DATE = ?
      WHERE RECORD_ID = ?
    `;
    const values = [
      totalFeesDiscount,
      netFees,
      record.STATUS || 'Due',
      dueStartDate,
      dueEndDate,
      record.RECORD_ID,
    ];

    logger.debug('Executing updateFeeRecord with values:', { values });

    const [result] = await connection.execute(query, values);
    if (result.affectedRows === 0) {
      logger.warn('No rows updated', { recordId: record.RECORD_ID, values });
      throw new Error('No rows updated. Record may not exist or no changes were made.');
    }
    logger.info('Fee record updated successfully', { recordId: record.RECORD_ID });
    return { message: 'Fee record updated successfully' };
  } catch (error) {
    logger.error('Error in updateFeeRecord:', { error: error.message, record });
    throw error;
  }
};

const deleteFeeRecord = async (connection, recordId) => {
  const query = 'DELETE FROM ACC_FEE_COLLECTION_STATUS WHERE RECORD_ID = ?';
  const [result] = await connection.execute(query, [recordId]);
  if (result.affectedRows === 0) {
    throw new Error('Record not found');
  }
  return { message: 'Fee record deleted successfully' };
};

module.exports = {
  getClasses,
  getFrequencies,
  getStudentFeesByClassAndFrequency,
  insertFeeRecords,
  updateFeeRecord,
  deleteFeeRecord,
};