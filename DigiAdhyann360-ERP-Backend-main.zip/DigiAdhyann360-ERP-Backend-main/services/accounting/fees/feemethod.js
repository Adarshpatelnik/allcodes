
const logger = require('../../../logger/logger');

const getFeeCollectionData = async (schoolDbConnection) => {
  try {
    console.log('Executing SQL query for fee collection data');
    const [rows] = await schoolDbConnection.query(
      `SELECT 
         COLLECTION_ID,
         COLLECTION_METHOD,
         COLLECTION_SUB_METHOD,
         DUE_START_DATE,
         DUE_END_DATE
       FROM ACC_FEE_COLLECTION_METHOD`
    );
    console.log('Fetched rows:', rows);

    const collectionType = rows.length > 0 ? rows[0].COLLECTION_METHOD : null;
    return { collectionType, rows };
  } catch (error) {
    logger.error('Error fetching fee collection data in service:', error);
    throw new Error(`Failed to fetch fee collection data: ${error.message}`);
  }
};

const updateFeeCollectionData = async (schoolDbConnection, { COLLECTION_TYPE, rows }) => {
  try {
    if (!COLLECTION_TYPE || !Array.isArray(rows) || rows.length === 0) {
      throw new Error('COLLECTION_TYPE and rows array are required');
    }

    const updatedRows = [];

    for (const row of rows) {
      if (row.COLLECTION_ID) {
        // Update existing record
        console.log('Updating record with COLLECTION_ID:', row.COLLECTION_ID);
        await schoolDbConnection.query(
          `UPDATE ACC_FEE_COLLECTION_METHOD
           SET COLLECTION_METHOD = ?,
               COLLECTION_SUB_METHOD = ?,
               DUE_START_DATE = ?,
               DUE_END_DATE = ?,
               UPDATE_DATE = NOW(),
               UPDATED_BY = ?
           WHERE COLLECTION_ID = ?`,
          [
            COLLECTION_TYPE,
            row.COLLECTION_SUB_METHOD,
            row.DUE_START_DATE,
            row.DUE_END_DATE,
            'system', // Replace with actual user if available
            row.COLLECTION_ID,
          ]
        );
        updatedRows.push({
          COLLECTION_ID: row.COLLECTION_ID,
          COLLECTION_METHOD: COLLECTION_TYPE,
          COLLECTION_SUB_METHOD: row.COLLECTION_SUB_METHOD,
          DUE_START_DATE: row.DUE_START_DATE,
          DUE_END_DATE: row.DUE_END_DATE,
        });
      } else {
        // Insert new record
        console.log('Inserting new record:', row);
        const [result] = await schoolDbConnection.query(
          `INSERT INTO ACC_FEE_COLLECTION_METHOD 
           (COLLECTION_METHOD, COLLECTION_SUB_METHOD, DUE_START_DATE, DUE_END_DATE, CREATED_BY)
           VALUES (?, ?, ?, ?, ?)`,
          [
            COLLECTION_TYPE,
            row.COLLECTION_SUB_METHOD,
            row.DUE_START_DATE,
            row.DUE_END_DATE,
            'system', // Replace with actual user if available
          ]
        );
        updatedRows.push({
          COLLECTION_ID: result.insertId,
          COLLECTION_METHOD: COLLECTION_TYPE,
          COLLECTION_SUB_METHOD: row.COLLECTION_SUB_METHOD,
          DUE_START_DATE: row.DUE_START_DATE,
          DUE_END_DATE: row.DUE_END_DATE,
        });
      }
    }

    console.log('Updated rows:', updatedRows);
    return updatedRows;
  } catch (error) {
    logger.error('Error saving fee collection data in service:', error);
    throw new Error(`Failed to save fee collection data: ${error.message}`);
  }
};

const deleteFeeCollectionData = async (schoolDbConnection, { COLLECTION_ID }) => {
  try {
    if (!COLLECTION_ID) {
      throw new Error('COLLECTION_ID is required');
    }

    console.log('Deleting record with COLLECTION_ID:', COLLECTION_ID);
    const [result] = await schoolDbConnection.query(
      `DELETE FROM ACC_FEE_COLLECTION_METHOD 
       WHERE COLLECTION_ID = ?`,
      [COLLECTION_ID]
    );

    if (result.affectedRows === 0) {
      throw new Error('Record not found');
    }

    return { message: 'Fee collection record successfully deleted.' };
  } catch (error) {
    logger.error('Error deleting fee collection data in service:', error);
    throw new Error(`Failed to delete fee collection record: ${error.message}`);
  }
};

module.exports = {
  getFeeCollectionData,
  updateFeeCollectionData,
  deleteFeeCollectionData,
};