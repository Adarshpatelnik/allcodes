const getFeeCollectionByCategory = async (schoolDbConnection) => {
  try {
    const [rows] = await schoolDbConnection.query(`
     SELECT
  a.CATEGORY_NAME,
  SUM(b.AMOUNT) AS TOTAL_AMOUNT,
  ROUND(SUM(b.AMOUNT) * 100 / (SELECT SUM(AMOUNT) FROM ACC_FEE_STRUCTURE), 2) AS PERCENTAGE
FROM ACC_FEE_CATEGORY a
LEFT JOIN ACC_FEE_STRUCTURE b
  ON a.CATEGORY_ID = b.CATEGORY_ID
GROUP BY a.CATEGORY_NAME;
    `);

    const result = rows
      .filter(row => row.CATEGORY_NAME && row.AMOUNT !== null)
      .map(row => ({
        CATEGORY_NAME: row.CATEGORY_NAME.trim(),
        AMOUNT: parseFloat(row.AMOUNT),
        PERCENTAGE: parseFloat(row.PERCENTAGE)
      }));

    return result;
  } catch (error) {
    console.error('Error fetching fee collection data in service:', error);
    throw error;
  }
};

module.exports = {
  getFeeCollectionByCategory,
};