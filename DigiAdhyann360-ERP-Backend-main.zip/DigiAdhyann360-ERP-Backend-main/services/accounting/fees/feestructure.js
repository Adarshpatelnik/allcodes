const getClasses = async (schoolDbConnection) => {
  try {
    const [classes] = await schoolDbConnection.query('SELECT DISTINCT CLASS FROM ACD_STUDENT_CLASS_MAPPING');
    return classes.map(row => row.CLASS).filter(cls => cls?.trim());
  } catch (error) {
    console.error('Error fetching classes in service:', error);
    throw error;
  }
};

const getCategories = async (schoolDbConnection) => {
  try {
    const [categories] = await schoolDbConnection.query('SELECT CATEGORY_NAME FROM ACC_FEE_CATEGORY');
    return categories.map(row => row.CATEGORY_NAME.trim()).filter(cat => cat);
  } catch (error) {
    console.error('Error fetching categories in service:', error);
    throw error;
  }
};

const getFeeStructure = async (schoolDbConnection) => {
  try {
    const [fees] = await schoolDbConnection.query(
      'SELECT C.COLLECTION_ID, C.COLLECTION_METHOD AS CollectionType, C.COLLECTION_SUB_METHOD AS Frequency, A.CLASS, B.CATEGORY_NAME, A.AMOUNT, A.TOTAL_AMOUNT FROM ACC_FEE_STRUCTURE A LEFT JOIN ACC_FEE_CATEGORY B ON A.CATEGORY_ID = B.CATEGORY_ID LEFT JOIN ACC_FEE_COLLECTION_METHOD C ON A.COLLECTION_ID = C.COLLECTION_ID'
    );
    return fees;
  } catch (error) {
    console.error('Error fetching fee structure in service:', error);
    throw error;
  }
};

const getCollectionTypes = async (schoolDbConnection) => {
  try {
    const [collectionTypes] = await schoolDbConnection.query(
      'SELECT DISTINCT COLLECTION_METHOD FROM ACC_FEE_COLLECTION_METHOD'
    );
    return collectionTypes.map(row => row.COLLECTION_METHOD).filter(type => type?.trim());
  } catch (error) {
    console.error('Error fetching collection types in service:', error);
    throw error;
  }
};

const getFrequencies = async (schoolDbConnection) => {
  try {
    const [frequencies] = await schoolDbConnection.query(
      'SELECT DISTINCT COLLECTION_SUB_METHOD FROM ACC_FEE_COLLECTION_METHOD'
    );
    return frequencies.map(row => row.COLLECTION_SUB_METHOD).filter(frequency => frequency?.trim());
  } catch (error) {
    console.error('Error fetching frequencies in service:', error);
    throw error;
  }
};

const addFeeStructure = async (schoolDbConnection, feeStructures) => {
  const insertedIds = [];
  try {
    for (const {
      COLLECTION_TYPE,
      FREQUENCY,
      CLASS,
      CATEGORY_NAME,
      AMOUNT,
      TOTAL_AMOUNT,
    } of feeStructures) {
      // Validate inputs
      const [collectionTypes] = await schoolDbConnection.query(
        'SELECT DISTINCT COLLECTION_METHOD FROM ACC_FEE_COLLECTION_METHOD'
      );
      const validCollectionTypes = collectionTypes.map(row => row.COLLECTION_METHOD);
      if (!validCollectionTypes.includes(COLLECTION_TYPE)) {
        console.warn(`COLLECTION_TYPE ${COLLECTION_TYPE} not found. Inserting new collection method.`);
        const [insertResult] = await schoolDbConnection.query(
          'INSERT INTO ACC_FEE_COLLECTION_METHOD (COLLECTION_METHOD, COLLECTION_SUB_METHOD, DUE_START_DATE, DUE_END_DATE, CREATED_BY, UPDATED_BY) VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), ?, ?)',
          [COLLECTION_TYPE, FREQUENCY || 'Default', 'SYSTEM', 'SYSTEM']
        );
        if (!insertResult.insertId) throw new Error(`Failed to insert new COLLECTION_TYPE: ${COLLECTION_TYPE}`);
      }

      const [frequencies] = await schoolDbConnection.query(
        'SELECT DISTINCT COLLECTION_SUB_METHOD FROM ACC_FEE_COLLECTION_METHOD'
      );
      const validFrequencies = frequencies.map(row => row.COLLECTION_SUB_METHOD);
      if (!validFrequencies.includes(FREQUENCY)) {
        console.warn(`FREQUENCY ${FREQUENCY} not found. Inserting new frequency.`);
        const [insertResult] = await schoolDbConnection.query(
          'INSERT INTO ACC_FEE_COLLECTION_METHOD (COLLECTION_METHOD, COLLECTION_SUB_METHOD, DUE_START_DATE, DUE_END_DATE, CREATED_BY, UPDATED_BY) VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), ?, ?)',
          ['Default', FREQUENCY, 'SYSTEM', 'SYSTEM']
        );
        if (!insertResult.insertId) throw new Error(`Failed to insert new FREQUENCY: ${FREQUENCY}`);
      }

      const [classes] = await schoolDbConnection.query(
        'SELECT DISTINCT CLASS FROM ACD_STUDENT_CLASS_MAPPING'
      );
      const validClasses = classes.map(row => row.CLASS);
      if (!validClasses.includes(CLASS)) {
        throw new Error(`Invalid CLASS: ${CLASS}`);
      }

      // Insert or get COLLECTION_ID
      let [collectionRows] = await schoolDbConnection.query(
        'SELECT COLLECTION_ID FROM ACC_FEE_COLLECTION_METHOD WHERE COLLECTION_METHOD = ? AND COLLECTION_SUB_METHOD = ?',
        [COLLECTION_TYPE, FREQUENCY || 'Default']
      );
      let COLLECTION_ID;
      if (collectionRows.length === 0) {
        const [insertResult] = await schoolDbConnection.query(
          'INSERT INTO ACC_FEE_COLLECTION_METHOD (COLLECTION_METHOD, COLLECTION_SUB_METHOD, DUE_START_DATE, DUE_END_DATE, CREATED_BY, UPDATED_BY) VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), ?, ?)',
          [COLLECTION_TYPE, FREQUENCY || 'Default', 'SYSTEM', 'SYSTEM']
        );
        COLLECTION_ID = insertResult.insertId;
      } else {
        COLLECTION_ID = collectionRows[0].COLLECTION_ID;
      }

      // Insert or get CATEGORY_ID
      let [categoryRows] = await schoolDbConnection.query(
        'SELECT CATEGORY_ID FROM ACC_FEE_CATEGORY WHERE TRIM(CATEGORY_NAME) = ?',
        [CATEGORY_NAME.trim()]
      );
      let CATEGORY_ID;
      if (categoryRows.length === 0) {
        const [insertResult] = await schoolDbConnection.query(
          'INSERT INTO ACC_FEE_CATEGORY (CATEGORY_NAME, DESCRIPTION, FREQUENCY, IS_RECURRING, CREATED_BY, UPDATED_BY) VALUES (?, ?, ?, 0, ?, ?)',
          [CATEGORY_NAME.trim(), `Description for ${CATEGORY_NAME}`, FREQUENCY, 'SYSTEM', 'SYSTEM']
        );
        CATEGORY_ID = insertResult.insertId;
      } else {
        CATEGORY_ID = categoryRows[0].CATEGORY_ID;
      }

      // Check for existing entry and update or insert
      let [existingRows] = await schoolDbConnection.query(
        'SELECT * FROM ACC_FEE_STRUCTURE WHERE CATEGORY_ID = ? AND COLLECTION_ID = ? AND CLASS = ?',
        [CATEGORY_ID, COLLECTION_ID, CLASS]
      );

      if (existingRows.length > 0) {
        const [updateResult] = await schoolDbConnection.query(
          'UPDATE ACC_FEE_STRUCTURE SET AMOUNT = ?, TOTAL_AMOUNT = ?, UPDATED_BY = ?, UPDATE_DATE = CURRENT_TIMESTAMP WHERE CATEGORY_ID = ? AND COLLECTION_ID = ? AND CLASS = ?',
          [AMOUNT, TOTAL_AMOUNT || 0, 'SYSTEM', CATEGORY_ID, COLLECTION_ID, CLASS]
        );
        if (updateResult.affectedRows === 0) {
          throw new Error(`Failed to update existing fee structure for CATEGORY_ID ${CATEGORY_ID}, COLLECTION_ID ${COLLECTION_ID}, CLASS ${CLASS}`);
        }
        insertedIds.push(existingRows[0].CATEGORY_ID);
      } else {
        const [insertResult] = await schoolDbConnection.query(
          `INSERT INTO ACC_FEE_STRUCTURE 
           (CATEGORY_ID, COLLECTION_ID, CLASS, AMOUNT, TOTAL_AMOUNT, FINANCIAL_YEAR, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY) 
           VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, ?, ?)`,
          [CATEGORY_ID, COLLECTION_ID, CLASS, AMOUNT, TOTAL_AMOUNT || 0, '2025-2026', 'SYSTEM', 'SYSTEM']
        );
        insertedIds.push(insertResult.insertId);
      }
    }
    return insertedIds;
  } catch (error) {
    console.error('Error adding fee structure in service:', error);
    throw error;
  }
};

const updateFeeStructure = async (schoolDbConnection, feeStructures) => {
  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    const updatedIds = [];

    for (const { COLLECTION_TYPE, FREQUENCY, CLASS, CATEGORY_NAME, AMOUNT, TOTAL_AMOUNT } of feeStructures) {
      // Validate inputs
      const [collectionTypes] = await connection.query(
        'SELECT DISTINCT COLLECTION_METHOD FROM ACC_FEE_COLLECTION_METHOD'
      );
      const validCollectionTypes = collectionTypes.map(row => row.COLLECTION_METHOD);
      if (!validCollectionTypes.includes(COLLECTION_TYPE)) {
        throw new Error(`Invalid COLLECTION_TYPE: ${COLLECTION_TYPE}`);
      }

      const [frequencies] = await connection.query(
        'SELECT DISTINCT COLLECTION_SUB_METHOD FROM ACC_FEE_COLLECTION_METHOD'
      );
      const validFrequencies = frequencies.map(row => row.COLLECTION_SUB_METHOD);
      if (!validFrequencies.includes(FREQUENCY)) {
        throw new Error(`Invalid FREQUENCY: ${FREQUENCY}`);
      }

      const [classes] = await connection.query(
        'SELECT DISTINCT CLASS FROM ACD_STUDENT_CLASS_MAPPING'
      );
      const validClasses = classes.map(row => row.CLASS);
      if (!validClasses.includes(CLASS)) {
        throw new Error(`Invalid CLASS: ${CLASS}`);
      }

      // Get COLLECTION_ID
      const [collectionRows] = await connection.query(
        'SELECT COLLECTION_ID FROM ACC_FEE_COLLECTION_METHOD WHERE COLLECTION_METHOD = ? AND COLLECTION_SUB_METHOD = ?',
        [COLLECTION_TYPE, FREQUENCY]
      );
      if (collectionRows.length === 0) {
        throw new Error(`No matching COLLECTION_METHOD and FREQUENCY found: ${COLLECTION_TYPE}, ${FREQUENCY}`);
      }
      const COLLECTION_ID = collectionRows[0].COLLECTION_ID;

      // Get or insert CATEGORY_ID
      let [categoryRows] = await connection.query(
        'SELECT CATEGORY_ID FROM ACC_FEE_CATEGORY WHERE TRIM(CATEGORY_NAME) = ?',
        [CATEGORY_NAME.trim()]
      );
      let CATEGORY_ID;
      if (categoryRows.length === 0) {
        const [insertResult] = await connection.query(
          'INSERT INTO ACC_FEE_CATEGORY (CATEGORY_NAME, DESCRIPTION, FREQUENCY, IS_RECURRING, CREATED_BY, UPDATED_BY) VALUES (?, ?, ?, 0, ?, ?)',
          [CATEGORY_NAME.trim(), `Description for ${CATEGORY_NAME}`, FREQUENCY, 'SYSTEM', 'SYSTEM']
        );
        CATEGORY_ID = insertResult.insertId;
      } else {
        CATEGORY_ID = categoryRows[0].CATEGORY_ID;
      }

      // Check for existing entry and update
      const [existingRows] = await connection.query(
        'SELECT * FROM ACC_FEE_STRUCTURE WHERE CATEGORY_ID = ? AND COLLECTION_ID = ? AND CLASS = ?',
        [CATEGORY_ID, COLLECTION_ID, CLASS]
      );

      if (existingRows.length > 0) {
        const [updateResult] = await connection.query(
          `UPDATE ACC_FEE_STRUCTURE 
           SET AMOUNT = ?, TOTAL_AMOUNT = ?, UPDATED_BY = ?, UPDATE_DATE = CURRENT_TIMESTAMP 
           WHERE CATEGORY_ID = ? AND COLLECTION_ID = ? AND CLASS = ?`,
          [AMOUNT, TOTAL_AMOUNT || 0, 'SYSTEM', CATEGORY_ID, COLLECTION_ID, CLASS]
        );
        if (updateResult.affectedRows === 0) {
          throw new Error(`Failed to update fee structure for CATEGORY_ID ${CATEGORY_ID}, COLLECTION_ID ${COLLECTION_ID}, CLASS ${CLASS}`);
        }
        updatedIds.push(CATEGORY_ID);
      } else {
        // Insert if no existing record
        const [insertResult] = await connection.query(
          `INSERT INTO ACC_FEE_STRUCTURE 
           (CATEGORY_ID, COLLECTION_ID, CLASS, AMOUNT, TOTAL_AMOUNT, FINANCIAL_YEAR, CREATE_DATE, UPDATE_DATE, CREATED_BY, UPDATED_BY) 
           VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, ?, ?)`,
          [CATEGORY_ID, COLLECTION_ID, CLASS, AMOUNT, TOTAL_AMOUNT || 0, '2025-2026', 'SYSTEM', 'SYSTEM']
        );
        updatedIds.push(insertResult.insertId);
      }
    }

    await connection.commit();
    return { message: 'Fee structures updated successfully', updatedIds };
  } catch (error) {
    await connection.rollback();
    console.error('Error updating fee structure in service:', error);
    throw error;
  } finally {
    if (connection) connection.release();
  }
};

const deleteFeeStructureByClassFrequencyAndCollection = async (schoolDbConnection, className, frequency, collectionType) => {
  const connection = await schoolDbConnection.getConnection();
  try {
    await connection.beginTransaction();

    const [result] = await connection.query(
      'DELETE FROM ACC_FEE_STRUCTURE WHERE CLASS = ? AND (SELECT COLLECTION_ID FROM ACC_FEE_COLLECTION_METHOD WHERE COLLECTION_METHOD = ? AND COLLECTION_SUB_METHOD = ?) = COLLECTION_ID',
      [className.trim(), collectionType.trim(), frequency.trim()]
    );

    if (result.affectedRows === 0) {
      throw new Error(`No fee structures found for CLASS ${className}, FREQUENCY ${frequency}, COLLECTION_TYPE ${collectionType}`);
    }

    await connection.commit();
    return { message: `Fee structures deleted successfully`, deletedCount: result.affectedRows };
  } catch (error) {
    await connection.rollback();
    console.error('Error deleting fee structures in service:', error);
    throw error;
  } finally {
    if (connection) connection.release();
  }
};

module.exports = {
  getClasses,
  getCategories,
  getFeeStructure,
  getCollectionTypes,
  getFrequencies,
  addFeeStructure,
  updateFeeStructure,
  deleteFeeStructureByClassFrequencyAndCollection,
};