const logger = require('../../../logger/logger');

const getStudentPaymentDetailsById = async (connection, studentId) => {
  try {
    const query = `
      SELECT 
        RECORD_ID,
        FREQUENCY,
        CLASS,
        STUDENT_ID,
        STUDENT_NAME,
        TOTAL_FEES,
        TOTAL_FEES_DISCOUNT,
        NET_FEES,
        STATUS,
        DATE_FORMAT(DUE_START_DATE, '%Y-%m-%d') AS DUE_START_DATE,
        DATE_FORMAT(DUE_END_DATE, '%Y-%m-%d') AS DUE_END_DATE
      FROM ACC_FEE_COLLECTION_STATUS
      WHERE STUDENT_ID = ?
    `;
    const [rows] = await connection.execute(query, [studentId]);
    logger.info('Fetched student payment details', { studentId, count: rows.length });

    if (rows.length === 0) {
      throw new Error('No payment details found for this student');
    }

    return rows;
  } catch (error) {
    logger.error('Error in getStudentPaymentDetailsById:', { error: error.message, stack: error.stack });
    throw error;
  }
};

const getNextAutoId = async (connection, columnName, prefix) => {
  try {
    const [rows] = await connection.query(`
      SELECT MAX(CAST(SUBSTRING(${columnName}, LENGTH(?) + 1) AS UNSIGNED)) AS maxId
      FROM ACC_FEE_TRANSACTIONS
      WHERE ${columnName} LIKE CONCAT(?, '%')
    `, [prefix, prefix]);

    const nextId = (rows[0].maxId || 0) + 1;
    return `${prefix}${nextId}`;
  } catch (error) {
    logger.error('Error in getNextAutoId:', { error: error.message, columnName, prefix });
    throw error;
  }
};

const insertFeeTransaction = async (connection, transactionData) => {
  try {
    logger.info('Entering insertFeeTransaction', {
      studentId: transactionData.studentId,
      frequency: transactionData.frequency,
      amount: transactionData.amount,
    });

    if (!transactionData.studentId || !transactionData.frequency || !transactionData.amount) {
      logger.error('Missing required fields in insertFeeTransaction', {
        studentId: transactionData.studentId,
        frequency: transactionData.frequency,
        amount: transactionData.amount,
      });
      throw new Error('studentId, frequency, and amount are required');
    }

    const trimmedStudentId = transactionData.studentId.trim();
    if (!/^SID-\d+$/.test(trimmedStudentId)) {
      logger.error('Invalid studentId format', { studentId: trimmedStudentId });
      throw new Error('Invalid studentId format (e.g., SID-123)');
    }

    const [studentDetails] = await connection.query(`
      SELECT 
        FIRST_NAME AS STUDENT_NAME,
        EMAIL AS STUDENT_EMAIL,
        CONTACT_NUMBER AS STUDENT_PHONE
      FROM ACD_STUDENT_PROFILE
      WHERE STUDENT_ID = ?
      LIMIT 1
    `, [trimmedStudentId]);

    if (!studentDetails || studentDetails.length === 0) {
      logger.error('No student found in ACD_STUDENT_PROFILE', { studentId: trimmedStudentId });
      throw new Error(`No student found for STUDENT_ID: ${trimmedStudentId}`);
    }

    const [schoolDetails] = await connection.query(`
      SELECT SCHOOL_NAME, SCHOOL_CODE
      FROM ACD_SCHOOL_PROFILE
      LIMIT 1
    `);

    if (!schoolDetails || schoolDetails.length === 0) {
      logger.error('No school found in ACD_SCHOOL_PROFILE');
      throw new Error('No school found in ACD_SCHOOL_PROFILE');
    }

    const [classMapping] = await connection.query(`
      SELECT CLASS
      FROM ACD_STUDENT_CLASS_MAPPING
      WHERE STUDENT_ID = ?
    `, [trimmedStudentId]);

    if (!classMapping || classMapping.length === 0) {
      logger.error('No class found in ACD_STUDENT_CLASS_MAPPING');
      throw new Error('No class found in ACD_STUDENT_CLASS_MAPPING');
    }

    const [feeDetails] = await connection.query(`
      SELECT TOTAL_FEES, FREQUENCY, CLASS
      FROM ACC_FEE_COLLECTION_STATUS
      WHERE STUDENT_ID = ? AND FREQUENCY = ?
    `, [trimmedStudentId, transactionData.frequency]);

    if (!feeDetails || feeDetails.length === 0) {
      logger.error('No fee details found for student and frequency', {
        studentId: trimmedStudentId,
        frequency: transactionData.frequency,
      });
      throw new Error(`No fee details found for STUDENT_ID: ${trimmedStudentId}, FREQUENCY: ${transactionData.frequency}`);
    }

    const expectedAmount = parseFloat(feeDetails[0].TOTAL_FEES);
    const providedAmount = parseFloat(transactionData.amount);
    if (isNaN(expectedAmount) || isNaN(providedAmount) || expectedAmount !== providedAmount) {
      logger.error('Amount mismatch or invalid', {
        studentId: trimmedStudentId,
        frequency: transactionData.frequency,
        providedAmount,
        expectedAmount,
      });
      throw new Error(`Amount mismatch: expected ${expectedAmount}, received ${providedAmount}`);
    }

    const paymentId = await getNextAutoId(connection, 'PAYMENT_ID', 'cashpayment');
    const orderId = await getNextAutoId(connection, 'ORDER_ID', 'cashorder');

    const student = studentDetails[0];
    const school = schoolDetails[0];
    const fee = feeDetails[0];
    const studentClass = classMapping[0];

    const insertQuery = `
      INSERT INTO ACC_FEE_TRANSACTIONS (
        STUDENT_ID, 
        STUDENT_NAME, 
        CLASS,
        PAYMENT_ID, 
        ORDER_ID, 
        TRANSACTION_DATE, 
        STUDENT_EMAIL, 
        STUDENT_PHONE, 
        FREQUENCY, 
        AMOUNT, 
        STATUS, 
        METHOD,
        DESCRIPTION,
        SCHOOL_CODE,
        SCHOOL_NAME,
        CURRENCY
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const params = [
      trimmedStudentId,
      student.STUDENT_NAME || '',
      studentClass.CLASS || '',
      paymentId,
      orderId,
      transactionData.transactionDate || new Date().toISOString().slice(0, 19).replace('T', ' '),
      student.STUDENT_EMAIL || '',
      student.STUDENT_PHONE || '',
      transactionData.frequency,
      providedAmount,
      'Paid',
      'Cash',
      transactionData.description || `Cash fee payment for ${transactionData.frequency} - ${fee.CLASS || ''}`,
      school.SCHOOL_CODE || '',
      school.SCHOOL_NAME || '',
      'INR'
    ];

    const [insertResult] = await connection.execute(insertQuery, params);
    logger.info('Inserted cash fee transaction', {
      studentId: trimmedStudentId,
      insertId: insertResult.insertId,
      paymentId,
      orderId,
    });

    const updateQuery = `
      UPDATE ACC_FEE_COLLECTION_STATUS 
      SET STATUS = 'Paid'
      WHERE STUDENT_ID = ? AND FREQUENCY = ?
    `;
    const [updateResult] = await connection.execute(updateQuery, [
      trimmedStudentId,
      transactionData.frequency,
    ]);

    if (updateResult.affectedRows === 0) {
      logger.warn('No rows updated in ACC_FEE_COLLECTION_STATUS', {
        studentId: trimmedStudentId,
        frequency: transactionData.frequency,
      });
    } else {
      logger.info('Updated ACC_FEE_COLLECTION_STATUS to Paid', {
        studentId: trimmedStudentId,
        frequency: transactionData.frequency,
      });
    }

    return {
      success: true,
      message: 'Cash payment recorded successfully',
      insertId: insertResult.insertId,
      paymentId,
      orderId
    };
  } catch (error) {
    logger.error('Error in insertFeeTransaction:', {
      error: error.message,
      stack: error.stack,
      studentId: transactionData.studentId,
      frequency: transactionData.frequency,
    });
    throw error;
  }
};

module.exports = {
  getStudentPaymentDetailsById,
  insertFeeTransaction,
};
