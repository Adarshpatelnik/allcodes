const logger = require('../../../logger/logger');
const crypto = require('crypto');
const Razorpay = require('razorpay');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const { pool } = require('../../../config/db');

const razorpayInstance = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_SECRET,
});

class PaymentService {
  static async createOrder({ studentId, amount, frequency }) {
    try {
      logger.info('Entering createOrder Service', { studentId, amount, frequency });

      // Validate Razorpay credentials
      if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_SECRET) {
        logger.error('Razorpay credentials missing', {
          keyId: process.env.RAZORPAY_KEY_ID ? 'present' : 'missing',
          keySecret: process.env.RAZORPAY_SECRET ? 'present' : 'missing',
        });
        throw new Error('Razorpay credentials not configured');
      }

      const store = asyncLocalStorage.getStore();
      const schoolDbConnection = store?.get('schoolDbConnection') || pool;
      if (!schoolDbConnection) {
        logger.error('No database connection available');
        throw new Error('No database connection available');
      }

      if (!studentId || !amount || !frequency) {
        logger.error('Missing required fields in createOrder', { studentId, amount, frequency });
        throw new Error('studentId, amount, and frequency are required');
      }

      const trimmedStudentId = studentId.trim();
      if (!trimmedStudentId.match(/^SID-\d+$/)) {
        logger.error('Invalid studentId format', { studentId });
        throw new Error('Invalid studentId format (e.g., SID-123)');
      }

      // Validate student
      const [studentDetails] = await schoolDbConnection.query(
        `
        SELECT 
          sp.STUDENT_ID,
          sp.FIRST_NAME AS STUDENT_NAME
        FROM ACD_STUDENT_PROFILE sp
        WHERE sp.STUDENT_ID = ?
        LIMIT 1
        `,
        [trimmedStudentId]
      );

      if (!studentDetails || studentDetails.length === 0) {
        logger.error('No student found in ACD_STUDENT_PROFILE', { studentId: trimmedStudentId });
        throw new Error(`No student found for STUDENT_ID: ${trimmedStudentId}`);
      }

      // Validate fee details
      const [feeDetails] = await schoolDbConnection.query(
        `
        SELECT TOTAL_FEES, FREQUENCY
        FROM ACC_FEE_COLLECTION_STATUS
        WHERE STUDENT_ID = ? AND FREQUENCY = ?
        `,
        [trimmedStudentId, frequency]
      );

      if (!feeDetails || feeDetails.length === 0) {
        logger.error('No fee details found for student and frequency', { studentId: trimmedStudentId, frequency });
        throw new Error(`No fee details found for STUDENT_ID: ${trimmedStudentId}, FREQUENCY: ${frequency}`);
      }

      const expectedAmount = parseFloat(feeDetails[0].TOTAL_FEES);
      const providedAmount = parseFloat(amount);
      if (isNaN(expectedAmount) || isNaN(providedAmount) || expectedAmount !== providedAmount) {
        logger.error('Amount mismatch or invalid', {
          studentId: rndStudentId,
          frequency,
          providedAmount,
          expectedAmount,
        });
        throw new Error(`Amount mismatch: expected ${expectedAmount}, received ${providedAmount}`);
      }

      const amountInPaise = Math.round(providedAmount * 100);
      if (isNaN(amountInPaise)) {
        logger.error('Invalid amount conversion to paise', { amount });
        throw new Error('Invalid amount');
      }

      const options = {
        amount: amountInPaise,
        currency: 'INR',
        receipt: `fee_${trimmedStudentId}_${Date.now()}`,
        notes: {
          studentId: trimmedStudentId,
          frequency,
          purpose: 'fee_payment',
        },
      };

      logger.info('Creating Razorpay order with options', { options });
      const order = await razorpayInstance.orders.create(options).catch((err) => {
        logger.error('Razorpay order creation failed', {
          error: err.message,
          status: err.statusCode,
          details: err.error || err,
        });
        throw new Error(`Razorpay order creation failed: ${err.message}`);
      });

      logger.info('Created Razorpay order', { orderId: order.id, studentId: trimmedStudentId, amount, frequency });

      return {
        id: order.id,
        amount: order.amount,
        currency: order.currency,
      };
    } catch (error) {
      logger.error('Error in createOrder Service:', {
        error: error.message,
        stack: error.stack,
        studentId,
        amount,
        frequency,
      });
      throw error;
    }
  }

  static async verifyPayment({ razorpayOrderId, razorpayPaymentId, razorpaySignature, frequency, studentId }) {
    try {
      logger.info('Entering verifyPayment Service', { studentId, razorpayOrderId });

      const store = asyncLocalStorage.getStore();
      const schoolDbConnection = store?.get('schoolDbConnection') || pool;
      if (!schoolDbConnection) {
        logger.error('No database connection available');
        throw new Error('No database connection available');
      }

      if (!razorpayOrderId || !razorpayPaymentId || !razorpaySignature || !studentId || !frequency) {
        logger.error('Missing required fields in verifyPayment', { razorpayOrderId, razorpayPaymentId, studentId, frequency });
        throw new Error('Missing required fields');
      }

      const trimmedStudentId = studentId.trim();
      if (!trimmedStudentId.match(/^SID-\d+$/)) {
        logger.error('Invalid studentId format', { studentId });
        throw new Error('Invalid studentId format (e.g., SID-123)');
      }

      // Verify signature
      const hmac = crypto.createHmac('sha256', process.env.RAZORPAY_SECRET);
      hmac.update(`${razorpayOrderId}|${razorpayPaymentId}`);
      const generatedSignature = hmac.digest('hex');

      if (generatedSignature !== razorpaySignature) {
        logger.error('Invalid signature in verifyPayment', { razorpayOrderId, razorpayPaymentId });
        throw new Error('Invalid signature');
      }

      // Verify payment status
      const payment = await razorpayInstance.payments.fetch(razorpayPaymentId).catch((err) => {
        logger.error('Razorpay payment fetch failed', {
          error: err.message,
          status: err.statusCode,
          details: err.error || err,
        });
        throw new Error(`Razorpay payment fetch failed: ${err.message}`);
      });

      if (payment.status !== 'captured') {
        logger.error('Payment not captured', { razorpayPaymentId, status: payment.status });
        throw new Error(`Payment not captured: ${payment.status}`);
      }

      // Get student details
      const [studentDetails] = await schoolDbConnection.query(
        `
        SELECT 
          sp.FIRST_NAME AS STUDENT_NAME,
          sp.EMAIL AS STUDENT_EMAIL,
          sp.CONTACT_NUMBER AS STUDENT_PHONE,
          cd.CLASS
        FROM ACD_STUDENT_PROFILE sp
        LEFT JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
        WHERE sp.STUDENT_ID = ?
        LIMIT 1
        `,
        [trimmedStudentId]
      );

      if (!studentDetails || studentDetails.length === 0) {
        logger.error('No student found in ACD_STUDENT_PROFILE', { studentId: trimmedStudentId });
        throw new Error(`No student found for STUDENT_ID: ${trimmedStudentId}`);
      }

      // Get school details
      const [schoolDetails] = await schoolDbConnection.query(
        `
        SELECT SCHOOL_NAME, SCHOOL_CODE, ACCOUNT_ID
        FROM ACD_SCHOOL_PROFILE
        LIMIT 1
        `
      );

      if (!schoolDetails || schoolDetails.length === 0) {
        logger.error('No school found in ACD_SCHOOL_PROFILE');
        throw new Error('No school found in ACD_SCHOOL_PROFILE');
      }

      const student = studentDetails[0];
      const school = schoolDetails[0];

      // Insert transaction record
      const insertQuery = `
        INSERT INTO ACC_FEE_TRANSACTIONS (
          STUDENT_ID, STUDENT_NAME, CLASS, ORDER_ID, PAYMENT_ID,
          AMOUNT, FREQUENCY, STATUS, CURRENCY, METHOD,
          STUDENT_EMAIL, STUDENT_PHONE, DESCRIPTION,
          ACCOUNT_ID, SCHOOL_CODE, SCHOOL_NAME
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const insertParams = [
        trimmedStudentId,
        student.STUDENT_NAME || '',
        student.CLASS || '',
        razorpayOrderId,
        razorpayPaymentId,
        payment.amount / 100,
        frequency,
        'Paid',
        payment.currency || 'INR',
        payment.method || '',
        student.STUDENT_EMAIL || '',
        student.STUDENT_PHONE || '',
        `Fee payment for ${frequency} - ${student.CLASS || ''}`,
        school.ACCOUNT_ID || '',
        school.SCHOOL_CODE || '',
        school.SCHOOL_NAME || '',
      ];

      const [transactionResult] = await schoolDbConnection.execute(insertQuery, insertParams);
      logger.info('Inserted fee transaction', { studentId: trimmedStudentId, insertId: transactionResult.insertId });

     const updateQuery = `
        UPDATE ACC_FEE_COLLECTION_STATUS 
        SET STATUS = 'Paid'
        WHERE STUDENT_ID = ? AND FREQUENCY = ?
      `;
      const [updateResult] = await schoolDbConnection.execute(updateQuery, [trimmedStudentId, frequency]);

      if (updateResult.affectedRows === 0) {
        logger.warn('No rows updated in ACC_FEE_COLLECTION_STATUS', { studentId: trimmedStudentId, frequency });
      } else {
        logger.info('Updated ACC_FEE_COLLECTION_STATUS to Paid', { studentId: trimmedStudentId, frequency });
      }

      return {
        success: true,
        message: 'Payment verified and recorded successfully',
        insertId: transactionResult.insertId,
      };
    } catch (error) {
      logger.error('Error in verifyPayment Service:', {
        error: error.message,
        stack: error.stack,
        razorpayOrderId,
        studentId,
      });
      throw error;
    }
  }

  static async getClasses() {
    try {
      logger.info('Entering getClasses Service');
      const store = asyncLocalStorage.getStore();
      const schoolDbConnection = store?.get('schoolDbConnection') || pool;
      if (!schoolDbConnection) {
        logger.error('No database connection available');
        throw new Error('No database connection available');
      }

      const [rows] = await schoolDbConnection.query(`
        SELECT DISTINCT CLASS FROM ACD_STUDENT_CLASS_MAPPING
      `);
      const classes = rows.map((row) => row.CLASS).filter((cls) => cls);
      logger.info('Fetched classes', { count: classes.length });
      return classes;
    } catch (error) {
      logger.error('Error in getClasses Service:', { error: error.message, stack: error.stack });
      throw error;
    }
  }

  static async getFrequencies() {
    try {
      logger.info('Entering getFrequencies Service');
      const store = asyncLocalStorage.getStore();
      const schoolDbConnection = store?.get('schoolDbConnection') || pool;
      if (!schoolDbConnection) {
        logger.error('No database connection available');
        throw new Error('No database connection available');
      }

      const [rows] = await schoolDbConnection.query(`
        SELECT DISTINCT FREQUENCY FROM ACC_FEE_COLLECTION_STATUS
      `);
      const frequencies = rows.map((row) => row.FREQUENCY).filter((freq) => freq);
      logger.info('Fetched frequencies', { count: frequencies.length });
      return frequencies;
    } catch (error) {
      logger.error('Error in getFrequencies Service:', { error: error.message, stack: error.stack });
      throw error;
    }
  }

  static async getStudentsAndFees({ className, frequency }) {
    try {
      logger.info('Entering getStudentsAndFees Service', { className, frequency });
      const store = asyncLocalStorage.getStore();
      const schoolDbConnection = store?.get('schoolDbConnection') || pool;
      if (!schoolDbConnection) {
        logger.error('No database connection available');
        throw new Error('No database connection available');
      }

      if (!className || !frequency) {
        logger.error('Missing class or frequency parameters', { className, frequency });
        throw new Error('Class and frequency parameters are required');
      }

      const [rows] = await schoolDbConnection.query(
        `
        SELECT 
          sp.STUDENT_ID,
          sp.FIRST_NAME AS STUDENT_NAME,
          f.TOTAL_FEES,
          sp.CONTACT_NUMBER AS STUDENT_PHONE,
          sp.EMAIL AS STUDENT_EMAIL
       FROM ACD_STUDENT_PROFILE sp
        LEFT JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
        JOIN ACC_FEE_COLLECTION_STATUS f ON sp.STUDENT_ID = f.STUDENT_ID
        WHERE cd.CLASS = ? AND f.FREQUENCY = ?
        `,
        [className, frequency]
      );

      logger.info('Fetched students and fees', { className, frequency, count: rows.length });
      return rows;
    } catch (error) {
      logger.error('Error in getStudentsAndFees Service:', { error: error.message, stack: error.stack });
      throw error;
    }
  }

  static async getStudentById(studentId) {
    try {
      logger.info('Entering getStudentById Service', { studentId });
      const store = asyncLocalStorage.getStore();
      const schoolDbConnection = store?.get('schoolDbConnection') || pool;
      if (!schoolDbConnection) {
        logger.error('No database connection available');
        throw new Error('No database connection available');
      }

      if (!studentId) {
        logger.error('Missing studentId parameter');
        throw new Error('studentId is required');
      }

      const trimmedStudentId = studentId.trim();
      if (!trimmedStudentId.match(/^SID-\d+$/)) {
        logger.error('Invalid studentId format', { studentId: trimmedStudentId });
        throw new Error('Invalid studentId format (e.g., SID-123)');
      }

      const [studentProfile] = await schoolDbConnection.query(
        `
        SELECT STUDENT_ID, FIRST_NAME, EMAIL, CONTACT_NUMBER
        FROM ACD_STUDENT_PROFILE
        WHERE STUDENT_ID = ?
        `,
        [trimmedStudentId]
      );

      if (!studentProfile || studentProfile.length === 0) {
        logger.error('No student found in ACD_STUDENT_PROFILE', { studentId: trimmedStudentId });
        throw new Error(`No student found for STUDENT_ID: ${trimmedStudentId}`);
      }

      const [classMapping] = await schoolDbConnection.query(
        `
        SELECT CLASS
        FROM ACD_STUDENT_CLASS_MAPPING
        WHERE STUDENT_ID = ?
        `,
        [trimmedStudentId]
      );

      const [schoolProfile] = await schoolDbConnection.query(
        `
        SELECT SCHOOL_CODE, SCHOOL_NAME, ACCOUNT_ID
        FROM ACD_SCHOOL_PROFILE sp
       LIMIT 1
        `,
      );

      const [feeStatus] = await schoolDbConnection.query(
        `
        SELECT TOTAL_FEES, FREQUENCY
        FROM ACC_FEE_COLLECTION_STATUS
        WHERE STUDENT_ID = ?
        `,
        [trimmedStudentId]
      );

      const student = {
        STUDENT_ID: studentProfile[0]?.STUDENT_ID || trimmedStudentId,
        STUDENT_NAME: studentProfile[0]?.FIRST_NAME || '',
        STUDENT_EMAIL: studentProfile[0]?.EMAIL || '',
        STUDENT_PHONE: studentProfile[0]?.CONTACT_NUMBER || '',
        CLASS: classMapping[0]?.CLASS || '',
        SCHOOL_CODE: schoolProfile[0]?.SCHOOL_CODE || '',
        SCHOOL_NAME: schoolProfile[0]?.SCHOOL_NAME || '',
        ACCOUNT_ID: schoolProfile[0]?.ACCOUNT_ID || '',
        TOTAL_FEES: feeStatus[0]?.TOTAL_FEES || null,
        FREQUENCY: feeStatus[0]?.FREQUENCY || '',
      };

      logger.info('Fetched student by ID', { studentId: trimmedStudentId, data: student });
      return [student];
    } catch (error) {
      logger.error('Error in getStudentById Service:', { error: error.message, stack: error.stack, studentId });
      throw error;
    }
  }
}

module.exports = PaymentService;