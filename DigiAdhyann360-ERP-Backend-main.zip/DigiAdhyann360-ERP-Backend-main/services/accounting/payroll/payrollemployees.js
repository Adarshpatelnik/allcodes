const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getDbConnection = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context');
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }
  return schoolDbConnection;
};

const fetchAcctStaffDetails = async () => {
  const schoolDbConnection = getDbConnection();
  try {
    const [rows] = await schoolDbConnection.query(`
      SELECT 
        s.STAFF_ID,
        s.STAFF_NAME,
        s.STAFF_ROLE,
        s.DESIGNATION,
        s.DATE_OF_JOINING,
        s.STATUS,
        py.NET_SALARY AS BASIC
      FROM ACD_STAFF_PROFILE s 
      LEFT JOIN ACC_STAFF_SALARY py ON py.STAFF_ID = s.STAFF_ID
      GROUP BY s.STAFF_ID
    `);
    logger.info('Fetched all staff details', { count: rows.length });
    return rows;
  } catch (error) {
    logger.error('Error fetching staff details', { error: error.message });
    throw error;
  }
};

const fetchStaffById = async (STAFF_ID) => {
  const schoolDbConnection = getDbConnection();
  try {
    logger.info('Fetching staff by ID', { STAFF_ID });
    const [staffRows] = await schoolDbConnection.query(
      `SELECT 
        s.STAFF_ID,
        s.STAFF_NAME,
        s.STAFF_ROLE,
        s.DESIGNATION,
        s.DATE_OF_JOINING,
        s.STATUS,
        py.NET_SALARY AS BASIC
      FROM ACD_STAFF_PROFILE s 
      LEFT JOIN ACC_STAFF_SALARY py ON py.STAFF_ID = s.STAFF_ID
      WHERE s.STAFF_ID = ?
      GROUP BY s.STAFF_ID`,
      [STAFF_ID]
    );

    if (staffRows.length === 0) {
      logger.warn('Staff not found', { STAFF_ID });
      return null;
    }

    logger.info('Staff fetched successfully', { STAFF_ID });
    return staffRows[0];
  } catch (error) {
    logger.error('Error fetching staff by ID', { error: error.message, STAFF_ID });
    throw error;
  }
};

const updateAcctStaff = async (id, { STATUS }) => {
   const schoolDbConnection = getDbConnection();
  try {
    logger.info('Updating staff status', { id, STATUS });
    const updateProfileQuery = `
      UPDATE ACD_STAFF_PROFILE 
      SET STATUS = ?
      WHERE STAFF_ID = ?
    `;
    
    const [profileResult] = await schoolDbConnection.query(updateProfileQuery, [
      STATUS,
      id,
    ]);

    if (profileResult.affectedRows === 0) {
      logger.warn('Staff record not found for update', { id });
      return false;
    }

    logger.info('Staff status updated successfully', { id });
    return true;
  } catch (error) {
    logger.error('Error updating staff status', { error: error.message, id });
    throw error;
  }
};


const deleteAcctStaffDetails = async (id) => {
  const schoolDbConnection = getDbConnection();
  try {
    logger.info('Deleting staff details', { id });
    const deleteSalaryQuery = `DELETE FROM ACC_STAFF_SALARY WHERE STAFF_ID = ?`;
    const deleteProfileQuery = `DELETE FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?`;

    const [salaryResult] = await schoolDbConnection.query(deleteSalaryQuery, [id]);
    const [profileResult] = await schoolDbConnection.query(deleteProfileQuery, [id]);

    if (profileResult.affectedRows === 0 && salaryResult.affectedRows === 0) {
      logger.warn('Staff record not found for deletion', { id });
      return false;
    }

    logger.info('Staff details deleted successfully', { id });
    return true;
  } catch (error) {
    logger.error('Error deleting staff details', { error: error.message, id });
    throw error;
  }
};

module.exports = {
  fetchAcctStaffDetails,
  fetchStaffById,
  updateAcctStaff,
  deleteAcctStaffDetails,
};