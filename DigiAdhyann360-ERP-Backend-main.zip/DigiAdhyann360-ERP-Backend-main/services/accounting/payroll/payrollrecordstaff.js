// const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
// const logger = require('../../../logger/logger');

// class PayrollRecordStaffService {
//   async getDynamicSalaryComponents() {
//     const store = asyncLocalStorage.getStore();
//     if (!store) {
//       throw new Error('Unauthorized or missing context');
//     }

//     const schoolDbConnection = store.get('schoolDbConnection');
//     if (!schoolDbConnection) {
//       logger.error('School database connection not established');
//       throw new Error('School database connection not established');
//     }

//     const [components] = await schoolDbConnection.query(
//       'SELECT COMPONENT_NAME, TYPE, TAXABLE FROM ACC_SALARY_COMPONENTS'
//     );

//     const columns = components.map((row) => ({
//       name: row.COMPONENT_NAME.toUpperCase().replace(/\s+/g, '_'),
//       type: row.TYPE,
//       taxable: row.TAXABLE,
//     }));

//     logger.info('Fetched dynamic salary components', { count: columns.length });
//     return { columns };
//   }

//   async getStaffList() {
//     const store = asyncLocalStorage.getStore();
//     if (!store) {
//       throw new Error('Unauthorized or missing context');
//     }

//     const schoolDbConnection = store.get('schoolDbConnection');
//     if (!schoolDbConnection) {
//       logger.error('School database connection not established');
//       throw new Error('School database connection not established');
//     }

//     const [staffRows] = await schoolDbConnection.query(
//       'SELECT STAFF_ID, STAFF_NAME, STAFF_ROLE FROM ACD_STAFF_PROFILE ORDER BY STAFF_ID ASC'
//     );

//     if (staffRows.length === 0) {
//       throw new Error('No staff found');
//     }

//     logger.info('Fetched staff list', { count: staffRows.length });
//     return staffRows;
//   }

//   async getPayrollRecords({ month, year }) {
//     const store = asyncLocalStorage.getStore();
//     if (!store) {
//       throw new Error('Unauthorized or missing context');
//     }

//     const schoolDbConnection = store.get('schoolDbConnection');
//     if (!schoolDbConnection) {
//       logger.error('School database connection not established');
//       throw new Error('School database connection not established');
//     }

//     if (!month || !year) {
//       throw new Error('Month and year are required');
//     }

//     const [records] = await schoolDbConnection.query(
//       `SELECT SALARY_ID, STAFF_ID, STAFF_NAME, STATUS, MONTH, YEAR, GROSS_EARNING, TOTAL_DEDUCTION, NET_SALARY, TOTAL_ALLOWANCES,
//               (SELECT GROUP_CONCAT(COMPONENT_NAME) FROM ACC_SALARY_COMPONENTS) AS dynamic_columns
//        FROM ACC_STAFF_SALARY
//        WHERE MONTH = ? AND YEAR = ?`,
//       [month, year]
//     );

//     if (records.length === 0) {
//       logger.info('No payroll records found', { month, year });
//       return [];
//     }

//     const dynamicColumns =
//       records[0]?.dynamic_columns?.split(',')?.map((col) => col.toUpperCase().replace(/\s+/g, '_')) || [];

//     for (let record of records) {
//       const [row] = await schoolDbConnection.query(
//         `SELECT * FROM ACC_STAFF_SALARY WHERE SALARY_ID = ?`,
//         [record.SALARY_ID]
//       );
//       dynamicColumns.forEach((col) => {
//         record[col] = row[0][col] || 0;
//       });
//     }

//     logger.info('Fetched payroll records', { count: records.length, month, year });
//     return records;
//   }
// }

// module.exports = new PayrollRecordStaffService();





const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

class PayrollRecordStaffService {
  async getDynamicSalaryComponents() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const [components] = await schoolDbConnection.query(
      'SELECT COMPONENT_NAME, TYPE, TAXABLE FROM ACC_SALARY_COMPONENTS'
    );

    const columns = components.map((row) => ({
      name: row.COMPONENT_NAME.toUpperCase().replace(/\s+/g, '_'),
      type: row.TYPE,
      taxable: row.TAXABLE,
    }));

    logger.info('Fetched dynamic salary components', { count: columns.length });
    return { columns };
  }

  async getStaffList() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const [staffRows] = await schoolDbConnection.query(
      'SELECT STAFF_ID, STAFF_NAME, STAFF_ROLE FROM ACD_STAFF_PROFILE ORDER BY STAFF_ID ASC'
    );

    if (staffRows.length === 0) {
      throw new Error('No staff found');
    }

    logger.info('Fetched staff list', { count: staffRows.length });
    return staffRows;
  }

  async getPayrollRecords({ month, year }) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    if (!month || !year) {
      throw new Error('Month and year are required');
    }

    const [records] = await schoolDbConnection.query(
      `SELECT SALARY_ID, STAFF_ID, STAFF_NAME, STATUS, MONTH, YEAR, GROSS_EARNING, TOTAL_DEDUCTION, NET_SALARY, TOTAL_ALLOWANCES,
              (SELECT GROUP_CONCAT(COMPONENT_NAME) FROM ACC_SALARY_COMPONENTS) AS dynamic_columns
       FROM ACC_STAFF_SALARY
       WHERE MONTH = ? AND YEAR = ?`,
      [month, year]
    );

    if (records.length === 0) {
      logger.info('No payroll records found', { month, year });
      return [];
    }

    const dynamicColumns =
      records[0]?.dynamic_columns?.split(',')?.map((col) => col.toUpperCase().replace(/\s+/g, '_')) || [];

    for (let record of records) {
      const [row] = await schoolDbConnection.query(
        `SELECT * FROM ACC_STAFF_SALARY WHERE SALARY_ID = ?`,
        [record.SALARY_ID]
      );
      dynamicColumns.forEach((col) => {
        record[col] = row[0][col] || 0;
      });
    }

    logger.info('Fetched payroll records', { count: records.length, month, year });
    return records;
  }

  async submitPayrollRecord(payload) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const {
      SALARY_ID,
      STAFF_ID,
      STAFF_NAME,
      STATUS,
      MONTH,
      YEAR,
      GROSS_EARNING,
      TOTAL_DEDUCTION,
      TOTAL_ALLOWANCES,
      NET_SALARY,
      ...dynamicComponents
    } = payload;

    try {
      // Validate required fields
      if (!STAFF_ID || !STAFF_NAME || !STATUS || !MONTH || !YEAR) {
        throw new Error('All required fields (STAFF_ID, STAFF_NAME, STATUS, MONTH, YEAR) must be provided');
      }

      // Check if staff exists
      const [staff] = await schoolDbConnection.query(
        'SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ? AND STAFF_NAME = ?',
        [STAFF_ID, STAFF_NAME]
      );
      if (staff.length === 0) {
        throw new Error('Invalid staff ID or name');
      }

      // Check for duplicate record
      const [existingRecord] = await schoolDbConnection.query(
        'SELECT SALARY_ID FROM ACC_STAFF_SALARY WHERE STAFF_ID = ? AND MONTH = ? AND YEAR = ?',
        [STAFF_ID, MONTH, YEAR]
      );

      let query, queryParams;

      if (existingRecord.length > 0 && SALARY_ID) {
        // Update existing record
        const dynamicFields = Object.keys(dynamicComponents)
          .map((key) => `${key} = ?`)
          .join(', ');
        query = `UPDATE ACC_STAFF_SALARY SET STAFF_ID = ?, STAFF_NAME = ?, STATUS = ?, MONTH = ?, YEAR = ?, 
                 GROSS_EARNING = ?, TOTAL_DEDUCTION = ?, TOTAL_ALLOWANCES = ?, NET_SALARY = ?${dynamicFields ? ', ' + dynamicFields : ''} 
                 WHERE SALARY_ID = ?`;
        queryParams = [
          STAFF_ID,
          STAFF_NAME,
          STATUS,
          MONTH,
          YEAR,
          GROSS_EARNING,
          TOTAL_DEDUCTION,
          TOTAL_ALLOWANCES,
          NET_SALARY,
          ...Object.values(dynamicComponents),
          SALARY_ID,
        ];
      } else {
        // Insert new record
        const dynamicFields = Object.keys(dynamicComponents).join(', ');
        const dynamicPlaceholders = Object.keys(dynamicComponents).map(() => '?').join(', ');
        query = `INSERT INTO ACC_STAFF_SALARY (STAFF_ID, STAFF_NAME, STATUS, MONTH, YEAR, GROSS_EARNING, 
                 TOTAL_DEDUCTION, TOTAL_ALLOWANCES, NET_SALARY${dynamicFields ? ', ' + dynamicFields : ''}) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?${dynamicPlaceholders ? ', ' + dynamicPlaceholders : ''})`;
        queryParams = [
          STAFF_ID,
          STAFF_NAME,
          STATUS,
          MONTH,
          YEAR,
          GROSS_EARNING,
          TOTAL_DEDUCTION,
          TOTAL_ALLOWANCES,
          NET_SALARY,
          ...Object.values(dynamicComponents),
        ];
      }

      const [result] = await schoolDbConnection.query(query, queryParams);

      logger.info('Payroll record submitted successfully', {
        SALARY_ID: SALARY_ID || result.insertId,
        STAFF_ID,
        MONTH,
        YEAR,
      });

      return {
        success: true,
        SALARY_ID: SALARY_ID || result.insertId,
        message: SALARY_ID ? 'Payroll record updated successfully' : 'Payroll record added successfully',
      };
    } catch (error) {
      logger.error('Error submitting payroll record', { error: error.message, STAFF_ID, MONTH, YEAR });
      throw new Error(`Failed to submit payroll record: ${error.message}`);
    }
  }
}

module.exports = new PayrollRecordStaffService();