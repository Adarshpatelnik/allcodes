const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getStaffPayrollRecords = async (staff_id, month, year) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('Unauthorized or missing context in getStaffPayrollRecords');
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    let query = `
      SELECT p.*, s.STAFF_NAME, s.STAFF_ROLE
      FROM ACC_STAFF_SALARY p
      LEFT JOIN ACD_STAFF_PROFILE s ON p.STAFF_ID = s.STAFF_ID
      WHERE p.STAFF_ID = ? AND p.STATUS = 'PAID'
    `;

    const queryParams = [staff_id];

    if (month && year) {
      query += ` AND p.MONTH = ? AND p.YEAR = ?`;
      queryParams.push(month, year);
    }

    query += ` ORDER BY p.SALARY_ID DESC`;

    logger.info('Executing payroll query', { query, params: queryParams });

    const [rows] = await schoolDbConnection.query(query, queryParams);

    logger.info(`Found ${rows.length} payroll records${month && year ? ` for ${month} ${year}` : ''}`, { staff_id });

    if (rows.length === 0) {
      logger.warn(`No payroll records found for Staff ID: ${staff_id}`);
      throw new Error(`No payroll records found for Staff ID: ${staff_id}`);
    }

    const [columns] = await schoolDbConnection.query(`
      SHOW COLUMNS FROM ACC_STAFF_SALARY
    `);

    return {
      data: rows,
      columns: columns.map(col => ({
        field: col.Field,
        type: col.Type,
        nullable: col.Null === 'YES',
      })),
    };
  } catch (error) {
    logger.error('Error in getStaffPayrollRecords', { error: error.message, stack: error.stack });
    throw error;
  }
};

module.exports = {
  getStaffPayrollRecords,
};