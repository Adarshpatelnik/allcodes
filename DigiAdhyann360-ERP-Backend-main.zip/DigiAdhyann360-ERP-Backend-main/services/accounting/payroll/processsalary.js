const { asyncLocalStorage } = require("../../../middleware/authmiddleware");

const fetchPayrollRecords = async (month, year, statuses) => {
  const store = asyncLocalStorage.getStore();
  if (!store || !store.get("schoolDbConnection")) {
    throw new Error("School database connection not established");
  }
  const schoolDbConnection = store.get("schoolDbConnection");
  const [components] = await schoolDbConnection.query("SELECT COMPONENT_NAME FROM ACC_SALARY_COMPONENTS");
  const dynamicColumns = components.map((comp) => comp.COMPONENT_NAME.toUpperCase().replace(/\s+/g, "_"));
  const staticFields = [
    "SALARY_ID",
    "STAFF_ID",
    "STAFF_NAME",
    "STATUS",
    "`MONTH`",
    "`YEAR`",
    "TOTAL_ALLOWANCES",
    "GROSS_EARNING",
    "TOTAL_DEDUCTION",
    "NET_SALARY",
  ];
  const allFields = staticFields.concat(dynamicColumns.map((col) => `\`${col}\``)).join(", ");
  const statusPlaceholders = statuses.map(() => "?").join(",");
  const whereClause = `
    WHERE MONTH = ? 
    AND YEAR = ? 
    AND STATUS IN (${statusPlaceholders})
    AND STAFF_ID IN (
      SELECT STAFF_ID 
      FROM ACD_STAFF_PROFILE 
      WHERE STATUS = 'ACTIVE'
    )
  `;
  const queryParams = [month, year, ...statuses];
  const [records] = await schoolDbConnection.query(`SELECT ${allFields} FROM ACC_STAFF_SALARY ${whereClause}`, queryParams);
  return records;
};

const updatePayrollStatus = async (staffIds, month, year, status) => {
  const store = asyncLocalStorage.getStore();
  if (!store || !store.get("schoolDbConnection")) {
    throw new Error("School database connection not established");
  }
  const schoolDbConnection = store.get("schoolDbConnection");
  const placeholders = staffIds.map(() => "?").join(",");
  const query = `
    UPDATE ACC_STAFF_SALARY 
    SET STATUS = ?
    WHERE STAFF_ID IN (${placeholders}) AND MONTH = ? AND YEAR = ?
  `;
  const values = [status, ...staffIds, month, year];
  const [result] = await schoolDbConnection.query(query, values);
  return result;
};

const submitPayrollRecords = async (payloads) => {
  const store = asyncLocalStorage.getStore();
  if (!store || !store.get("schoolDbConnection")) {
    throw new Error("School database connection not established");
  }
  const schoolDbConnection = store.get("schoolDbConnection");
  let affectedRows = 0;

  try {
    await schoolDbConnection.query("START TRANSACTION");
    for (const payload of payloads) {
      const setFields = Object.keys(payload)
        .filter((key) => key !== "STAFF_ID" && key !== "MONTH" && key !== "YEAR")
        .map((key) => `\`${key}\` = ?`);
      setFields.push("`STATUS` = ?");
      const setClause = setFields.join(", ");
      const values = Object.keys(payload)
        .filter((key) => key !== "STAFF_ID" && key !== "MONTH" && key !== "YEAR")
        .map((key) => payload[key]);
      values.push("INPROGRESS");
      const whereValues = [payload.STAFF_ID, payload.MONTH, payload.YEAR];
      const query = `
        UPDATE ACC_STAFF_SALARY 
        SET ${setClause}
        WHERE STAFF_ID = ? AND MONTH = ? AND YEAR = ?
      `;
      const [result] = await schoolDbConnection.query(query, [...values, ...whereValues]);
      affectedRows += result.affectedRows;
    }
    await schoolDbConnection.query("COMMIT");
    return { affectedRows };
  } catch (err) {
    await schoolDbConnection.query("ROLLBACK");
    throw err;
  }
};

module.exports = {
  fetchPayrollRecords,
  updatePayrollStatus,
  submitPayrollRecords,
};