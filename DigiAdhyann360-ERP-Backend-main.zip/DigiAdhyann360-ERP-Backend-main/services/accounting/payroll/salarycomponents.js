// const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
// const logger = require('../../../logger/logger');

// class SalaryComponentService {
//   async getSalaryComponents() {
//     const store = asyncLocalStorage.getStore();
//     if (!store) {
//       throw new Error('Unauthorized or missing context');
//     }

//     const schoolDbConnection = store.get('schoolDbConnection'); 
//     if (!schoolDbConnection) {
//       logger.error('School database connection not established');
//       throw new Error('School database connection not established');
//     }

//     const query = `
//       SELECT ID, COMPONENT_NAME, TYPE, DESCRIPTION, TAXABLE 
//       FROM ACC_SALARY_COMPONENTS
//     `;

//     logger.info('Fetching salary components');
//     const [results] = await schoolDbConnection.query(query);
//     return results;
//   }

//   async submitSalaryComponent({ ID, COMPONENT_NAME, TYPE, DESCRIPTION, TAXABLE }) {
//     const store = asyncLocalStorage.getStore();
//     if (!store) {
//       throw new Error('Unauthorized or missing context');
//     }

//     const schoolDbConnection = store.get('schoolDbConnection');
//     if (!schoolDbConnection) {
//       logger.error('School database connection not established');
//       throw new Error('School database connection not established');
//     }

//     if (!COMPONENT_NAME || !TYPE || !DESCRIPTION || TAXABLE === undefined) {
//       throw new Error('Missing required fields');
//     }

//     const upperComponentName = COMPONENT_NAME.toUpperCase();
//     const columnName = upperComponentName.replace(/\s+/g, '_');

//     // Create ACC_STAFF_SALARY table if not exists
//     const createTableQuery = `
//       CREATE TABLE IF NOT EXISTS ACC_STAFF_SALARY (
//         SALARY_ID INT NOT NULL AUTO_INCREMENT,
//         STAFF_ID VARCHAR(50) NOT NULL,
//         STAFF_NAME VARCHAR(100) DEFAULT NULL,
//         STATUS ENUM('PAID', 'UNPAID', 'PENDING', 'INPROGRESS') DEFAULT 'PENDING',
//         MONTH VARCHAR(20) DEFAULT NULL,
//         YEAR VARCHAR(4) DEFAULT NULL,
//         TOTAL_ALLOWANCES DECIMAL(10,2) DEFAULT 0.00,
//         GROSS_EARNING DECIMAL(10,2) DEFAULT 0.00,
//         TOTAL_DEDUCTION DECIMAL(10,2) DEFAULT 0.00,
//         NET_SALARY DECIMAL(10,2) DEFAULT 0.00,
//         RECORD_CREATE_DT DATE DEFAULT (CURDATE()),
//         PRIMARY KEY (SALARY_ID),
//         KEY FK_ACC_STAFF_SALARY_STAFF_ID (STAFF_ID),
//         FOREIGN KEY (STAFF_ID) REFERENCES ACD_STAFF_PROFILE(STAFF_ID)
//       )
//     `;
//     await schoolDbConnection.query(createTableQuery);

//     // Check if column exists
//     const [columns] = await schoolDbConnection.query('SHOW COLUMNS FROM ACC_STAFF_SALARY');
//     const columnExists = columns.some((col) => col.Field === columnName);

//     // Add column if it doesn't exist
//     if (!columnExists) {
//       const alterQuery = `
//         ALTER TABLE ACC_STAFF_SALARY
//         ADD COLUMN \`${columnName}\` DECIMAL(10,2) DEFAULT 0.00 AFTER STAFF_NAME
//       `;
//       await schoolDbConnection.query(alterQuery);
//       logger.info(`Column '${columnName}' added to ACC_STAFF_SALARY`);
//     }

//     // Insert or update component
//     if (ID) {
//       const updateQuery = `
//         UPDATE ACC_STAFF_SALARY
//         SET COMPONENT_NAME = ?, TYPE = ?, DESCRIPTION = ?, TAXABLE = ?
//         WHERE ID = ?
//       `;
//       const [result] = await schoolDbConnection.query(updateQuery, [
//         upperComponentName,
//         TYPE.toUpperCase(),
//         DESCRIPTION.toUpperCase(),
//         TAXABLE,
//         ID,
//       ]);

//       if (result.affectedRows === 0) {
//         throw new Error('Component not found for update');
//       }

//       return { message: 'Component updated successfully' };
//     } else {
//       const insertQuery = `
//         INSERT INTO ACC_SALARY_COMPONENTS (COMPONENT_NAME, TYPE, DESCRIPTION, TAXABLE)
//         VALUES (?, ?, ?, ?)
//       `;
//       const [result] = await schoolDbConnection.query(insertQuery, [
//         upperComponentName,
//         TYPE.toUpperCase(),
//         DESCRIPTION.toUpperCase(),
//         TAXABLE,
//       ]);

//       return { message: 'Component inserted successfully', id: result.insertId };
//     }
//   }

//   async deleteSalaryComponent(id) {
//     const store = asyncLocalStorage.getStore();
//     if (!store) {
//       throw new Error('Unauthorized or missing context');
//     }

//     const schoolDbConnection = store.get('schoolDbConnection');
//     if (!schoolDbConnection) {
//       logger.error('School database connection not established');
//       throw new Error('School database connection not established');
//     }

//     if (!id) {
//       throw new Error('Missing component ID');
//     }

//     // Fetch COMPONENT_NAME
//     const [componentRows] = await schoolDbConnection.query(
//       'SELECT COMPONENT_NAME FROM ACC_SALARY_COMPONENTS WHERE ID = ?',
//       [id]
//     );

//     if (componentRows.length === 0) {
//       throw new Error('Component not found');
//     }

//     const componentName = componentRows[0].COMPONENT_NAME;
//     const columnName = componentName.replace(/\s+/g, '_');

//     // Check if column exists
//     const [columns] = await schoolDbConnection.query('SHOW COLUMNS FROM ACC_STAFF_SALARY');
//     const columnExists = columns.some((col) => col.Field === columnName);

//     // Drop column if exists
//     if (columnExists) {
//       const dropQuery = `ALTER TABLE ACC_STAFF_SALARY DROP COLUMN \`${columnName}\``;
//       await schoolDbConnection.query(dropQuery);
//       logger.info(`Column '${columnName}' deleted from ACC_STAFF_SALARY`);
//     }

//     // Delete component
//     const deleteQuery = `DELETE FROM ACC_SALARY_COMPONENTS WHERE ID = ?`;
//     const [result] = await schoolDbConnection.query(deleteQuery, [id]);

//     if (result.affectedRows === 0) {
//       throw new Error('Component not found for deletion');
//     }

//     return { message: 'Component and related column deleted successfully' };
//   }
// }

// module.exports = new SalaryComponentService();



const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

class SalaryComponentService {
  async getSalaryComponents() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
      SELECT ID, COMPONENT_NAME, TYPE, DESCRIPTION, 
             CASE TAXABLE 
               WHEN 1 THEN 'YES' 
               WHEN 0 THEN 'NO' 
               ELSE TAXABLE 
             END AS TAXABLE
      FROM ACC_SALARY_COMPONENTS
    `;

    logger.info('Fetching salary components');
    const [results] = await schoolDbConnection.query(query);
    return results;
  }

  async submitSalaryComponent({ ID, COMPONENT_NAME, TYPE, DESCRIPTION, TAXABLE }) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    // Validate required fields
    if (!COMPONENT_NAME || !TYPE || !DESCRIPTION || TAXABLE === undefined) {
      throw new Error('Missing required fields');
    }

    // Normalize TAXABLE input (YES/NO to 1/0)
    let taxableValue;
    if (typeof TAXABLE === 'string') {
      const taxableUpper = TAXABLE.toUpperCase();
      if (taxableUpper === 'YES') {
        taxableValue = 1;
      } else if (taxableUpper === 'NO') {
        taxableValue = 0;
      } else {
        throw new Error('Invalid TAXABLE value; must be YES, NO, 1, or 0');
      }
    } else {
      taxableValue = TAXABLE === 1 ? 1 : TAXABLE === 0 ? 0 : null;
      if (taxableValue === null) {
        throw new Error('Invalid TAXABLE value; must be YES, NO, 1, or 0');
      }
    }

    const upperComponentName = COMPONENT_NAME.toUpperCase();
    const columnName = upperComponentName.replace(/\s+/g, '_');

    // Create ACC_STAFF_SALARY table if not exists
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS ACC_STAFF_SALARY (
        SALARY_ID INT NOT NULL AUTO_INCREMENT,
        STAFF_ID VARCHAR(50) NOT NULL,
        STAFF_NAME VARCHAR(100) DEFAULT NULL,
        STATUS ENUM('PAID', 'UNPAID', 'PENDING', 'INPROGRESS') DEFAULT 'PENDING',
        MONTH VARCHAR(20) DEFAULT NULL,
        YEAR VARCHAR(4) DEFAULT NULL,
        TOTAL_ALLOWANCES DECIMAL(10,2) DEFAULT 0.00,
        GROSS_EARNING DECIMAL(10,2) DEFAULT 0.00,
        TOTAL_DEDUCTION DECIMAL(10,2) DEFAULT 0.00,
        NET_SALARY DECIMAL(10,2) DEFAULT 0.00,
        RECORD_CREATE_DT DATE DEFAULT (CURDATE()),
        PRIMARY KEY (SALARY_ID),
        KEY FK_ACC_STAFF_SALARY_STAFF_ID (STAFF_ID),
        FOREIGN KEY (STAFF_ID) REFERENCES ACD_STAFF_PROFILE(STAFF_ID)
      )
    `;
    await schoolDbConnection.query(createTableQuery);

    // Check if column exists
    const [columns] = await schoolDbConnection.query('SHOW COLUMNS FROM ACC_STAFF_SALARY');
    const columnExists = columns.some((col) => col.Field === columnName);

    // Add column if it doesn't exist
    if (!columnExists) {
      const alterQuery = `
        ALTER TABLE ACC_STAFF_SALARY
        ADD COLUMN \`${columnName}\` DECIMAL(10,2) DEFAULT 0.00 AFTER STAFF_NAME
      `;
      await schoolDbConnection.query(alterQuery);
      logger.info(`Column '${columnName}' added to ACC_STAFF_SALARY`);
    }

    // Insert or update component
    if (ID) {
      const updateQuery = `
        UPDATE ACC_SALARY_COMPONENTS
        SET COMPONENT_NAME = ?, TYPE = ?, DESCRIPTION = ?, TAXABLE = ?
        WHERE ID = ?
      `;
      const [result] = await schoolDbConnection.query(updateQuery, [
        upperComponentName,
        TYPE.toUpperCase(),
        DESCRIPTION.toUpperCase(),
        taxableValue,
        ID,
      ]);

      if (result.affectedRows === 0) {
        throw new Error('Component not found for update');
      }

      return { message: 'Component updated successfully' };
    } else {
      const insertQuery = `
        INSERT INTO ACC_SALARY_COMPONENTS (COMPONENT_NAME, TYPE, DESCRIPTION, TAXABLE)
        VALUES (?, ?, ?, ?)
      `;
      const [result] = await schoolDbConnection.query(insertQuery, [
        upperComponentName,
        TYPE.toUpperCase(),
        DESCRIPTION.toUpperCase(),
        taxableValue,
      ]);

      return { message: 'Component inserted successfully', id: result.insertId };
    }
  }

  async deleteSalaryComponent(id) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    if (!id) {
      throw new Error('Missing component ID');
    }

    // Fetch COMPONENT_NAME
    const [componentRows] = await schoolDbConnection.query(
      'SELECT COMPONENT_NAME FROM ACC_SALARY_COMPONENTS WHERE ID = ?',
      [id]
    );

    if (componentRows.length === 0) {
      throw new Error('Component not found');
    }

    const componentName = componentRows[0].COMPONENT_NAME;
    const columnName = componentName.replace(/\s+/g, '_');

    // Check if column exists
    const [columns] = await schoolDbConnection.query('SHOW COLUMNS FROM ACC_STAFF_SALARY');
    const columnExists = columns.some((col) => col.Field === columnName);

    // Drop column if exists
    if (columnExists) {
      const dropQuery = `ALTER TABLE ACC_STAFF_SALARY DROP COLUMN \`${columnName}\``;
      await schoolDbConnection.query(dropQuery);
      logger.info(`Column '${columnName}' deleted from ACC_STAFF_SALARY`);
    }

    // Delete component
    const deleteQuery = `DELETE FROM ACC_SALARY_COMPONENTS WHERE ID = ?`;
    const [result] = await schoolDbConnection.query(deleteQuery, [id]);

    if (result.affectedRows === 0) {
      throw new Error('Component not found for deletion');
    }

    return { message: 'Component and related column deleted successfully' };
  }
}

module.exports = new SalaryComponentService();