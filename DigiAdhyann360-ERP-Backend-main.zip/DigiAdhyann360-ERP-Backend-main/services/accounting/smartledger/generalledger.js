const getAcctGeneralLedger = async (schoolDbConnection) => {
  try {
    const query = `
 SELECT
      t.TRANSACTION_DATE,
  t.DEBIT,
        t.CREDIT,
        t.BALANCE,
        t.TYPE
 FROM ACC_FEE_TRANSACTIONS t
 `;
console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching general ledger in service:', error.message);
    throw error;
  }
};

const getAcctLedger = async (schoolDbConnection) => {
  try {
    const query = `
SELECT
 CONCAT(ACCOUNT_CODE, ' ', ACCOUNT_NAME) AS ACCOUNT,
        ACCOUNT_NAME
      FROM ACC_LEDGER
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching account ledger in service:', error.message);
    throw error;
  }
};

const getAcctExpenseCategories = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        CATEGORY_NAME AS Description
      FROM ACC_EXPENSE_CATEGORIES
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching expense categories in service:', error.message);
    throw error;
  }
};

module.exports = {
  getAcctGeneralLedger,
  getAcctLedger,
  getAcctExpenseCategories,
};
