const getAcctGeneralLedger = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        TRANSACTION_DATE,
        DEBIT,
        CREDIT,
        BALANCE,
        TYPE
      FROM ACC_FEE_TRANSACTIONS
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching general ledger in service:', error.message);
    throw error;
  }
};
 
const getAcctLedger = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        CONCAT(ACCOUNT_CODE, ' ', ACCOUNT_NAME) AS ACCOUNT,
        ACCOUNT_NAME
      FROM ACC_LEDGER
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching account ledger in service:', error.message);
    throw error;
  }
};
 
const getAcctExpenseCategories = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        CATEGORY_NAME AS Description
      FROM ACC_EXPENSE_CATEGORIES
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching expense categories in service:', error.message);
    throw error;
  }
};
 
const getAcctStudentTrnsHistory = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        STUDENT_ID,
        TRANSACTION_DATE,
        REFERENCE,
        STATUS,
        METHOD,
        AMOUNT
      FROM ACC_FEE_TRANSACTIONS
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching student transaction history in service:', error.message);
    throw error;
  }
};
 
const getAcctStudentTrnsFeeCategory = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        CATEGORY_NAME,
        DESCRIPTION
      FROM ACC_FEE_CATEGORY
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching student transaction fee category in service:', error.message);
    throw error;
  }
};
 
const getAcctStudentProfile = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        sp.STUDENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
        sp.CONTACT_NUMBER,
        sp.EMAIL
      FROM
        ACD_STUDENT_PROFILE sp
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching student profile in service:', error.message);
    throw error;
  }
};
 
const getAcctClassDetail = async (schoolDbConnection) => {
  try {
    const query = `
             SELECT DISTINCT CLASS
    FROM ACD_STUDENT_CLASS_MAPPING
    WHERE CLASS != 'Alumni'
    ORDER BY
      CASE
        WHEN CLASS = 'LKG' THEN 0
        WHEN CLASS = 'UKG' THEN 1
        WHEN CLASS REGEXP '^[0-9]+$' THEN CAST(CLASS AS UNSIGNED) + 1
        ELSE 999
      END
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching class details in service:', error.message);
    throw error;
  }
};
 
const getStudentClassMapping = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT
        sp.STUDENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
        cd.CLASS
      FROM
        ACD_STUDENT_PROFILE sp
        LEFT JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
        group by  sp.STUDENT_ID
 
    `;
    console.log('Executing query:', query);
    const [result] = await schoolDbConnection.query(query);
    return result;
  } catch (error) {
    console.error('Error fetching student-class mapping in service:', error.message);
    throw error;
  }
};
 
module.exports = {
  getAcctGeneralLedger,
  getAcctLedger,
  getAcctExpenseCategories,
  getAcctStudentTrnsHistory,
  getAcctStudentTrnsFeeCategory,
  getAcctStudentProfile,
  getAcctClassDetail,
  getStudentClassMapping,
};
 