
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { s3Client } = require('../../config/aws');
const { GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

// Middleware to attach schoolCode to the request
const attachIdentifiers = async (req, res, next) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      return res.status(403).json({ error: 'Unauthorized or missing context' });
    }
    const current_staff = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      return res.status(500).json({ error: 'School database connection not established' });
    }

    // Fetch UDISE_CODE from ACD_SCHOOL_PROFILE
    const [udiseCodeResults] = await schoolDbConnection.query('SELECT UDISE_CODE FROM ACD_SCHOOL_PROFILE');
    if (udiseCodeResults.length === 0) {
      throw new Error('Udise code not found.');
    }
    const udiseCode = udiseCodeResults[0].UDISE_CODE;

    req.udiseCode = udiseCode;
    // req.applicationId = applicationId;

    console.log('/GET udiseCode:', udiseCode);
    // console.log('/GET Applicant Id:', applicationId);

    next();
  } catch (error) {
    console.error('Error fetching identifiers:', error.message);
    res.status(500).json({
      error: 'Failed to fetch udiseCode or applicationId.',
      details: error.message,
    });
  }
};

// Service function to get school profile
const getSchoolProfile = async (schoolDbConnection) => {
  try {
    const query = `
      SELECT SCHOOL_NAME, SCHOOL_BRANCH, UDISE_CODE, CITY, PHONE_NUMBER, EMAIL, PRINCIPAL_NAME, SCHOOL_LOGO 
      FROM ACD_SCHOOL_PROFILE;
    `;
    const [results] = await schoolDbConnection.query(query);

    if (!results || results.length === 0) {
      throw new Error('No school profile data found');
    }

    return results;
  } catch (error) {
    console.error('Error fetching school profile:', error.message || error);
    throw error;
  }
};

// Service function to get school logo
const getSchoolLogo = async (schoolDbConnection, udiseCode) => {
  try {
    const [schoolProfile] = await schoolDbConnection.query(
      'SELECT SCHOOL_LOGO FROM ACD_SCHOOL_PROFILE WHERE UDISE_CODE = ? LIMIT 1',
      [udiseCode]
    );

    if (!schoolProfile.length || !schoolProfile[0].SCHOOL_LOGO) {
      throw new Error('School logo not found.');
    }

    const command = new GetObjectCommand({
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: schoolProfile[0].SCHOOL_LOGO,
    });

    const logoUrl = await getSignedUrl(s3Client, command, { expiresIn: 86400 });
    return { logoUrl };
  } catch (error) {
    console.error('Error retrieving school logo:', error.message || error);
    throw error;
  }
};

// Service function to upload school logo
const uploadSchoolLogo = async (req, schoolDbConnection) => {
  try {
    if (!req.file) {
      throw new Error('No file uploaded or invalid type.');
    }

    console.log('Udise Code:', req.udiseCode);
    console.log('Uploaded File:', req.file);

    const query = `UPDATE ACD_SCHOOL_PROFILE SET SCHOOL_LOGO = ? WHERE UDISE_CODE = ?`;
    const [result] = await schoolDbConnection.query(query, [req.file.key, req.udiseCode]);

    console.log('Update Result:', result);

    if (result.affectedRows === 0) {
      throw new Error('No school profile found to update.');
    }

    const command = new GetObjectCommand({
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: req.file.key,
    });

    const logoUrl = await getSignedUrl(s3Client, command, { expiresIn: 86400 });

    return {
      message: 'School logo uploaded successfully.',
      fileKey: req.file.key,
      logoUrl: logoUrl,
    };
  } catch (error) {
    console.error('Error uploading school logo:', error.message || error);
    throw error;
  }
};

// Service function to update school profile
const updateSchoolProfile = async (req) => {
  let store = asyncLocalStorage.getStore();
  let schoolDbConnection = store ? store.get('schoolDbConnection') : await getFallbackConnection();

  const { SCHOOL_NAME, SCHOOL_BRANCH, CITY, PHONE_NUMBER, EMAIL, PRINCIPAL_NAME } = req.body;
  if (!req.udiseCode) {
    throw new Error('UDISE_CODE is required');
  }

  const query = `
    UPDATE ACD_SCHOOL_PROFILE
    SET SCHOOL_NAME = ?, SCHOOL_BRANCH = ?, CITY = ?, PHONE_NUMBER = ?, EMAIL = ?, PRINCIPAL_NAME = ?
    WHERE UDISE_CODE = ?;
  `;
  console.log('Updating profile with UDISE_CODE:', req.udiseCode);
  const [result] = await schoolDbConnection.query(query, [
    SCHOOL_NAME || null,
    SCHOOL_BRANCH || null,
    CITY || null,
    PHONE_NUMBER || null,
    EMAIL || null,
    PRINCIPAL_NAME || null,
    req.udiseCode,
  ]);

  if (result.affectedRows === 0) {
    throw new Error('No school profile found to update');
  }

  return { message: 'School profile updated successfully' };
};

module.exports = {
  attachIdentifiers,
  getSchoolProfile,
  getSchoolLogo,
  uploadSchoolLogo,
  updateSchoolProfile,
};