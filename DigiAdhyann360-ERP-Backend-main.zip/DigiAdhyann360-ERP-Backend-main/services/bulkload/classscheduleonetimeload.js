const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const bcrypt = require('bcrypt');
const { pool } = require('../../config/db');
async function bulkLoadClassSchedule(req, schoolDbConnection, asyncLocalStorage) {
  try {
    const { data } = req.body;

    if (!data || !Array.isArray(data) || data.length === 0) {
      console.log("bulkLoadClassSchedule: Invalid or empty data provided.");
      throw new Error("Invalid or empty data provided");
    }

    // Define the INSERT query for class schedule
    const query = `
      INSERT INTO ACD_CLASS_SCHEDULE (
        PERIOD, TIME_SLOT, DURATION, DAY, CLASS, SECTION, SUBJECT
      ) VALUES ?
    `;

    // Map the data into arrays for the bulk INSERT query
    const values = data.map(row => [
      row.PERIOD,
      row.TIME_SLOT,
      row.DURATION,
      row.DAY,
      row.CLASS,
      row.SECTION,
      row.SUBJECT
    ]);
    console.log(`bulkLoadClassSchedule: Attempting to insert ${values.length} records.`);

    // Execute the query to insert the records
    await schoolDbConnection.query(query, [values]);

    console.log("bulkLoadClassSchedule: Data uploaded successfully.");

    // Now execute the UPDATE query to update the DAY_ID based on the DAY
    const updateQuery = `
      UPDATE ACD_CLASS_SCHEDULE
      SET DAY_ID = CASE 
        WHEN DAY = 'MONDAY' THEN 1
        WHEN DAY = 'TUESDAY' THEN 2
        WHEN DAY = 'WEDNESDAY' THEN 3
        WHEN DAY = 'THURSDAY' THEN 4
        WHEN DAY = 'FRIDAY' THEN 5
        WHEN DAY = 'SATURDAY' THEN 6
        WHEN DAY = 'SUNDAY' THEN 7
        ELSE NULL
      END;
    `;

    // Execute the update query
    await schoolDbConnection.query(updateQuery);

    console.log("bulkLoadClassSchedule: DAY_ID updated successfully.");
    return { message: "Class schedule data uploaded and DAY_ID updated successfully" };
  } catch (err) {
    console.error("bulkLoadClassSchedule: Error uploading data or updating DAY_ID:", err.message);
    throw new Error("Database query error");
  }
}

module.exports = { bulkLoadClassSchedule };