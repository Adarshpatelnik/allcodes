const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const bcrypt = require('bcrypt');
const { pool } = require('../../config/db');

class StaffBulkLoadService {
  async bulkLoadStaff(data) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      throw new Error('School database connection not established');
    }

    const connection = await schoolDbConnection.getConnection();
    await connection.beginTransaction();

    try {
      // Safely access database name with fallback
      let currentDbName;
      try {
        currentDbName = process.env.DB_NAME || schoolDbConnection.pool.config.connectionConfig.database || 'school_db';
      } catch (e) {
        console.error("Errorîne: Error accessing schoolDbConnection config:", e.message);
        currentDbName = process.env.DB_NAME || 'school_db';
      }
      console.log("Current Database Name:", currentDbName);

      const [schoolRows] = await pool.query(
        `SELECT TENANT_ID FROM SCHOOL_DB_CREDENTIALS WHERE DATABASE_NAME = ?`,
        [currentDbName]
      );
      if (!schoolRows.length) {
        throw new Error(`No TENANT_ID found for DATABASE_NAME='${currentDbName}'`);
      }
      const tenantId = schoolRows[0].TENANT_ID;
      console.log("Fetched TENANT_ID:", tenantId);

      const [existingStaffIds] = await connection.query(
        "SELECT STAFF_ID, STAFF_ROLE FROM ACD_STAFF_PROFILE"
      );
      const prefixMaxNumbers = {};

      existingStaffIds.forEach((row) => {
        const [prefix, number] = row.STAFF_ID.split("-");
        if (prefix && number) {
          const num = parseInt(number, 10) || 0;
          prefixMaxNumbers[prefix] = Math.max(prefixMaxNumbers[prefix] || 0, num);
        }
      });

      const staffValues = [];
      const rolePrefixes = {
        "ACCOUNTANT": "ACID",
        "ADMIN": "AID",
        "MANAGEMENT STAFF": "MSID",
        "PRINCIPAL": "PRID",
        "TEACHER": "TID",
        "STORE MANAGER": "SMID",
        "OTHER": "OID"
      };

      for (const row of data) {
        const role = row.STAFF_ROLE?.toUpperCase() || "";
        if (!role) {
          throw new Error("STAFF_ROLE is required for each entry");
        }

        const prefix = rolePrefixes[role];
        if (!prefix) {
          throw new Error(`Unsupported STAFF_ROLE '${role}'. Must be one of: ${Object.keys(rolePrefixes).join(", ")}`);
        }

        let currentMaxNumber = prefixMaxNumbers[prefix] || 0;
        let newNumber = currentMaxNumber + 1;
        let staffId = `${prefix}-${String(newNumber).padStart(5, "0")}`;
        let firstName = row.STAFF_NAME
          ? row.STAFF_NAME.split(" ")[0].replace(/\s/g, "").toUpperCase()
          : "USER";
        let staffUserId = `${firstName}_${String(newNumber).padStart(5, "0")}`;

        let isUnique = false;
        while (!isUnique) {
          const [existingStaff] = await connection.query(
            "SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ? OR STAFF_USER_ID = ?",
            [staffId, staffUserId]
          );

          if (existingStaff.length === 0) {
            isUnique = true;
          } else {
            newNumber++;
            staffId = `${prefix}-${String(newNumber).padStart(5, "0")}`;
            staffUserId = `${firstName}_${String(newNumber).padStart(5, "0")}`;
          }
        }

        staffValues.push([
          staffId,
          staffUserId,
          row.STAFF_NAME || "",
          row.STAFF_INITIALS || "",
          row.MARITAL_STATUS || "",
          row.CONTACT_NUMBER || "",
          row.STAFF_ROLE || "",
          row.DATE_OF_JOINING || null,
          // row.MONTHLY_SALARY ? parseInt(row.MONTHLY_SALARY, 10) : null,
          row.FATHER_HUSBAND_NAME || "",
          row.GENDER || "",
          row.EXPERIENCE ? parseInt(row.EXPERIENCE, 10) : null,
          row.ADHAR_ID ? BigInt(row.ADHAR_ID) : null,
          row.RELIGION || "",
          row.EMAIL || "",
          row.EDUCATION || "",
          row.BLOOD_GROUP || "",
          row.DATE_OF_BIRTH || null,
          row.ADDRESS || "",
          row.CITY || "",
          row.STATE || "",
          row.POSTAL_CODE ? parseInt(row.POSTAL_CODE, 10) : null,
          tenantId
        ]);

        prefixMaxNumbers[prefix] = newNumber;
      }

      const staffQuery = `
        INSERT INTO ACD_STAFF_PROFILE (
          STAFF_ID, STAFF_USER_ID, STAFF_NAME, STAFF_INITIALS, MARITAL_STATUS,
          CONTACT_NUMBER, STAFF_ROLE, DATE_OF_JOINING,
          FATHER_HUSBAND_NAME, GENDER, EXPERIENCE, ADHAR_ID, RELIGION, EMAIL,
          EDUCATION, BLOOD_GROUP, DATE_OF_BIRTH, ADDRESS, CITY, STATE, POSTAL_CODE,
          SCHOOL_INFO
        ) VALUES ?
      `;
      const [staffResult] = await connection.query(staffQuery, [staffValues]);
      console.log("STAFF insert result:", staffResult);

      for (const staff of staffValues) {
        const staffUserId = staff[1];
        const [staffData] = await connection.query(
          "SELECT * FROM ACD_STAFF_PROFILE WHERE STAFF_USER_ID = ?",
          [staffUserId]
        );

        if (staffData.length > 0) {
          const randomPassword = this.generateRandomPassword();
          const hashedPassword = await bcrypt.hash(randomPassword, 10);

          const normalizedStaffRole = staffData[0].STAFF_ROLE.toUpperCase();
          const [roleResult] = await pool.query(
            "SELECT ROLE_ID FROM ROLES WHERE ROLE_NAME = ?",
            [normalizedStaffRole]
          );

          if (roleResult.length > 0) {
            const roleId = roleResult[0].ROLE_ID;

            console.log(`Inserting into USERS for ${staffUserId}...`);
            await pool.query(
              "INSERT INTO USERS (TENANT_ID, FULL_NAME, USER_ID, USERNAME, PASSWORD, ROLE_ID, CONTACT_NUMBER, EMAIL) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
              [
                staffData[0].SCHOOL_INFO,
                staffData[0].STAFF_NAME,
                staffData[0].STAFF_ID,
                staffData[0].STAFF_USER_ID,
                hashedPassword,
                roleId,
                staffData[0].CONTACT_NUMBER,
                staffData[0].EMAIL
              ]
            );
          } else {
            throw new Error(`Role '${normalizedStaffRole}' not found in ROLES`);
          }
        }
      }

      await connection.commit();
      return { message: "Data uploaded successfully into STAFF" };
    } catch (err) {
      await connection.rollback();
      throw new Error(`Error inserting data into STAFF: ${err.message}`);
    } finally {
      connection.release();
    }
  }

  generateRandomPassword(length = 8) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+[]{}|;:,.<>?';
    let password = '';
    for (let i = 0; i < length; i++) {
      password += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return password;
  }
}

module.exports = new StaffBulkLoadService();