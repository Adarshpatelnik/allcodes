const bcrypt = require('bcrypt');
const { pool } = require('../../config/db');

const config = {
  studentPrefix: process.env.STUDENT_ID_PREFIX || 'SID-',
  parentPrefix: process.env.PARENT_ID_PREFIX || 'PID-',
  idPadding: parseInt(process.env.ID_PADDING) || 5,
  defaultStudentNumber: parseInt(process.env.DEFAULT_STUDENT_NUMBER) || 1001,
  defaultParentNumber: parseInt(process.env.DEFAULT_PARENT_NUMBER) || 1001
};

function generateRandomPassword(length = parseInt(process.env.PASSWORD_LENGTH) || 8) {
  const characters = process.env.PASSWORD_CHARS || 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+[]{}|;:,.<>?';
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  console.log('Generated random password (sample):', password.slice(0, 2) + '...'); // Debug log (obfuscated for security)
  return password;
}

function generateId(prefix, number, padding) {
  const id = `${prefix}${String(number).padStart(padding, '0')}`;
  console.log('Generated ID:', id); // Debug log
  return id;
}

async function bulkLoadStudents(data, schoolDbConnection, pool) {
  console.log('bulkLoadStudents: Starting with data length:', data.length); // Debug log
  if (!data || !Array.isArray(data) || data.length === 0) {
    console.error('bulkLoadStudents: Invalid or empty data provided');
    throw new Error('Invalid or empty data provided');
  }

  const connection = await schoolDbConnection.getConnection();
  console.log('Database connection acquired'); // Debug log
  const batchSize = 500;

  async function insertInBatches(query, values, conn) {
    for (let i = 0; i < values.length; i += batchSize) {
      const batch = values.slice(i, i + batchSize);
      console.log(`Inserting batch ${i / batchSize + 1} with ${batch.length} records`); // Debug log
      await conn.query(query, [batch]);
      console.log(`Batch ${i / batchSize + 1} inserted successfully`); // Debug log
    }
  }

  try {
    let currentDbName = process.env.DB_NAME || schoolDbConnection.pool.config.connectionConfig.database || 'school_db';
    console.log('Current Database Name:', currentDbName); // Debug log

    console.log('Querying SCHOOL_DB_CREDENTIALS for TENANT_ID'); // Debug log
    const [schoolRows] = await pool.query(
      `SELECT TENANT_ID FROM SCHOOL_DB_CREDENTIALS WHERE DATABASE_NAME = ?`,
      [currentDbName]
    );
    console.log('SCHOOL_DB_CREDENTIALS result:', schoolRows); // Debug log
    if (!schoolRows.length) {
      console.error(`No TENANT_ID found for DATABASE_NAME='${currentDbName}'`);
      throw new Error(`No TENANT_ID found for DATABASE_NAME='${currentDbName}'`);
    }
    const tenantId = schoolRows[0].TENANT_ID;
    console.log('Fetched TENANT_ID:', tenantId); // Debug log

    console.log('Querying ACD_STUDENT_PROFILE for last STUDENT_ID'); // Debug log
    const [studentRows] = await connection.query(
      `SELECT STUDENT_ID FROM ACD_STUDENT_PROFILE ORDER BY STUDENT_ID DESC LIMIT 1`
    );
    console.log('ACD_STUDENT_PROFILE result:', studentRows); // Debug log

    console.log('Querying ACD_PARENT_PROFILE for last PARENT_ID'); // Debug log
    const [parentRows] = await connection.query(
      `SELECT PARENT_ID FROM ACD_PARENT_PROFILE ORDER BY PARENT_ID DESC LIMIT 1`
    );
    console.log('ACD_PARENT_PROFILE result:', parentRows); // Debug log

    let nextStudentNumber = config.defaultStudentNumber;
    let nextParentNumber = config.defaultParentNumber;

    if (studentRows.length > 0) {
      nextStudentNumber = parseInt(studentRows[0].STUDENT_ID.split(config.studentPrefix)[1]) + 1;
    }
    if (parentRows.length > 0) {
      nextParentNumber = parseInt(parentRows[0].PARENT_ID.split(config.parentPrefix)[1]) + 1;
    }
    console.log('Next Student ID number:', nextStudentNumber, 'Next Parent ID number:', nextParentNumber); // Debug log

    // ACD_STUDENT_PROFILE (Insert first to satisfy foreign key constraint)
    await connection.beginTransaction();
    console.log('Starting transaction for ACD_STUDENT_PROFILE'); // Debug log
    const studentQuery = `
      INSERT INTO ACD_STUDENT_PROFILE (
        STUDENT_ID, STUDENT_USER_ID, FIRST_NAME, MIDDLE_NAME, LAST_NAME, GENDER,
        CONTACT_NUMBER, HOUSE_NUMBER, HOUSE_BUILDING_NAME, STREET_NAME, LANDMARK, CITY,
        STATE, POSTAL_CODE, DATE_OF_BIRTH, EMAIL, ENROLLMENT_DATE, NATIONALITY,
        BIRTH_CERTIFICATE_NUMBER, CASTE, RELIGION, BLOOD_GROUP, DISEASE_IF_ANY,
        ADDITIONAL_NOTE, IDENTIFICATION_MARK, PREVIOUS_SCHOOL, EMERGENCY_CONTACT_NAME,
        EMERGENCY_CONTACT_NUMBER, AADHAR_NUMBER, IS_ACTIVE, SCHOOL_INFO
      ) VALUES ?
    `;
    const studentValues = data.map((row, index) => {
      const studentId = generateId(config.studentPrefix, nextStudentNumber + index, config.idPadding);
      // const parentId = generateId(config.parentPrefix, nextParentNumber + index, config.idPadding);
      const userId = `${String(row.FIRST_NAME || 'USER').toUpperCase()}_${String(nextStudentNumber + index).padStart(config.idPadding, '0')}`;
      const values = [
        studentId,
        userId,
        String(row.FIRST_NAME || '').toUpperCase(),
        String(row.MIDDLE_NAME || '').toUpperCase(),
        String(row.LAST_NAME || '').toUpperCase(),
        String(row.GENDER || '').toUpperCase(),
        String(row.PHONE_NUMBER || ''),
        String(row.HOUSE_NUMBER || '').toUpperCase(),
        String(row.HOUSE_BUILDING_NAME || '').toUpperCase(),
        String(row.STREET_NAME || '').toUpperCase(),
        String(row.LANDMARK || '').toUpperCase(),
        String(row.CITY || '').toUpperCase(),
        String(row.STATE || '').toUpperCase(),
        String(row.POSTAL_CODE || ''),
        String(row.DATE_OF_BIRTH || ''),
        String(row.EMAIL || '').toUpperCase(),
        String(row.APPLICATION_DATE || ''),
        String(row.NATIONALITY || '').toUpperCase(),
        String(row.BIRTH_CERTIFICATE_NUMBER || '').toUpperCase(),
        String(row.CASTE || '').toUpperCase(),
        String(row.RELIGION || '').toUpperCase(),
        String(row.BLOOD_GROUP || '').toUpperCase(),
        String(row.DISEASE_IF_ANY || '').toUpperCase(),
        String(row.ADDITIONAL_NOTE || '').toUpperCase(),
        String(row.IDENTIFICATION_MARK || '').toUpperCase(),
        String(row.PREVIOUS_SCHOOL || '').toUpperCase(),
        String(row.EMERGENCY_CONTACT_NAME || '').toUpperCase(),
        String(row.EMERGENCY_CONTACT_NUMBER || ''),
        String(row.AADHAR_NUMBER || ''),
        '1',
        tenantId
      ];
      console.log('Student values for index', index, ':', values); // Debug log
      return values;
    });
    await insertInBatches(studentQuery, studentValues, connection);
    await connection.commit();
    console.log('ACD_STUDENT_PROFILE inserted successfully'); // Debug log

    // ACD_PARENT_PROFILE (Insert after ACD_STUDENT_PROFILE)
    await connection.beginTransaction();
    console.log('Starting transaction for ACD_PARENT_PROFILE'); // Debug log
    const parentQuery = `
      INSERT INTO ACD_PARENT_PROFILE (
        PARENT_ID, STUDENT_ID, FATHER_NAME, FATHER_ADHAR_ID, FATHER_OCCUPATION, FATHER_EDUCATION,
        FATHER_MOBILE_NUMBER, FATHER_INCOME, MOTHER_NAME, MOTHER_ADHAR_ID,
        MOTHER_OCCUPATION, MOTHER_EDUCATION, MOTHER_MOBILE_NUMBER, MOTHER_INCOME
      ) VALUES ?
    `;
    const parentValues = data.map((row, index) => {
      const parentId = generateId(config.parentPrefix, nextParentNumber + index, config.idPadding);
      const studentId = generateId(config.studentPrefix, nextStudentNumber + index, config.idPadding);
      const values = [
        parentId,
        studentId, // Added to satisfy fk_parent_student constraint
        String(row.FATHER_NAME || '').toUpperCase(),
        String(row.FATHER_ADHAR_ID || ''),
        String(row.FATHER_OCCUPATION || '').toUpperCase(),
        String(row.FATHER_EDUCATION || '').toUpperCase(),
        String(row.FATHER_MOBILE_NUMBER || ''),
        row.FATHER_INCOME || null,
        String(row.MOTHER_NAME || '').toUpperCase(),
        String(row.MOTHER_ADHAR_ID || ''),
        String(row.MOTHER_OCCUPATION || '').toUpperCase(),
        String(row.MOTHER_EDUCATION || '').toUpperCase(),
        String(row.MOTHER_MOBILE_NUMBER || ''),
        row.MOTHER_INCOME || null
      ];
      console.log('Parent values for index', index, ':', values); // Debug log
      return values;
    });
    await insertInBatches(parentQuery, parentValues, connection);
    await connection.commit();
    console.log('ACD_PARENT_PROFILE inserted successfully'); // Debug log

    // ACD_STUDENT_CLASS_MAPPING
    await connection.beginTransaction();
    console.log('Starting transaction for ACD_STUDENT_CLASS_MAPPING'); // Debug log
    const classQuery = `
      INSERT INTO ACD_STUDENT_CLASS_MAPPING (
        STUDENT_ID, CLASS, SECTION, STREAM, OPTIONAL, ACADEMIC_YEAR
      ) VALUES ?
    `;
    const classValues = data.map((row, index) => {
      const values = [
        generateId(config.studentPrefix, nextStudentNumber + index, config.idPadding),
        String(row.CLASS || ''),
        String(row.SECTION || '').toUpperCase(),
        String(row.STREAM || '').toUpperCase(),
        String(row.OPTIONAL || '').toUpperCase(),
        String(row.ACADEMIC_YEAR || '').toUpperCase()
      ];
      console.log('Class mapping values for index', index, ':', values); // Debug log
      return values;
    });
    await connection.query('SET FOREIGN_KEY_CHECKS = 0');
    await insertInBatches(classQuery, classValues, connection);
    await connection.query('SET FOREIGN_KEY_CHECKS = 1');
    await connection.commit();
    console.log('ACD_STUDENT_CLASS_MAPPING inserted successfully'); // Debug log

    // Inserting data into USERS table
    console.log('Starting USERS table insertion'); // Debug log
    let userInsertCount = 0;
    try {
      const roleName = 'STUDENT';
      console.log('Querying ROLES for ROLE_ID with roleName:', roleName); // Debug log
      const [roleResult] = await pool.query(
        `SELECT ROLE_ID FROM ROLES WHERE ROLE_NAME = ?`,
        [roleName]
      );
      console.log('ROLES query result:', roleResult); // Debug log
      if (!roleResult.length) {
        console.error(`Role '${roleName}' not found in ROLES`);
        throw new Error(`Role '${roleName}' not found in ROLES`);
      }
      const ROLE_ID = roleResult[0].ROLE_ID;
      console.log(`Fetched ROLE_ID: ${ROLE_ID} for ROLE_NAME: ${roleName}`); // Debug log

      const userValues = [];
      for (const student of studentValues) {
        const index = studentValues.indexOf(student);
        const row = data[index];
        const randomPassword = generateRandomPassword();
        const hashedPassword = await bcrypt.hash(randomPassword, 10);
        const fullName = `${student[3] || ''} ${student[4] || ''} ${student[5] || ''}`.trim().toUpperCase();
        const values = [
          tenantId,
          fullName,
          student[0], // STUDENT_ID as USER_ID
          student[1], // STUDENT_USER_ID as USERNAME
          hashedPassword,
          ROLE_ID,
          String(student[7] || ''),
          String(student[16] || '').toUpperCase() // EMAIL
        ];
        console.log('User values for index', index, ':', values); // Debug log (password obfuscated)
        userValues.push(values);
      }

      console.log('Sample userValues:', JSON.stringify(userValues.slice(0, 2), null, 2)); // Debug log

      console.log('Checking for duplicate usernames'); // Debug log
      const [existingUsers] = await pool.query(
        `SELECT USERNAME FROM USERS WHERE USERNAME IN (?)`,
        [userValues.map((row) => row[3])]
      );
      console.log('Existing users check:', existingUsers); // Debug log
      if (existingUsers.length > 0) {
        console.error(`Duplicate usernames found: ${JSON.stringify(existingUsers)}`);
        throw new Error(`Duplicate usernames found: ${JSON.stringify(existingUsers)}`);
      }

      const userQuery = `
        INSERT INTO USERS (
          TENANT_ID, FULL_NAME, USER_ID, USERNAME, PASSWORD, ROLE_ID, CONTACT_NUMBER, EMAIL
        ) VALUES ?
      `;
      await insertInBatches(userQuery, userValues, pool);
      console.log('USERS inserted successfully'); // Debug log

      console.log('Verifying USERS insert count'); // Debug log
      const [userCount] = await pool.query(`SELECT COUNT(*) AS count FROM USERS WHERE TENANT_ID = ?`, [tenantId]);
      userInsertCount = userCount[0].count || 0;
      console.log(`USERS table count for TENANT_ID ${tenantId}: ${userInsertCount}`); // Debug log
    } catch (err) {
      console.error('Error inserting into USERS:', err.message, err.stack); // Debug log
      throw new Error(`USERS insert failed: ${err.message}`);
    }

    console.log('bulkLoadStudents: Completed successfully'); // Debug log
    return {
      parents: parentValues.length,
      students: studentValues.length,
      classes: classValues.length,
      users: userInsertCount
    };
  } catch (err) {
    console.error('bulkLoadStudents: Transaction error:', err.message, err.stack); // Debug log
    await connection.rollback();
    throw err;
  } finally {
    console.log('Releasing database connection'); // Debug log
    connection.release();
  }
}

module.exports = { bulkLoadStudents };