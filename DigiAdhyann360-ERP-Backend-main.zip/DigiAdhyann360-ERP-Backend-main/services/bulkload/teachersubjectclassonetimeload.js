async function bulkLoadTeacherClassSubject(req, schoolDbConnection, asyncLocalStorage) {
  let connection;
  try {
    const { teacherMapping, subject } = req.body;

    // Input validation
    if (!teacherMapping || !Array.isArray(teacherMapping) || teacherMapping.length === 0) {
      console.error('bulkLoadTeacherClassSubject: Invalid or empty teacher mapping data');
      throw new Error('Invalid or empty teacher mapping data');
    }
    if (!subject || !Array.isArray(subject) || subject.length === 0) {
      console.error('bulkLoadTeacherClassSubject: Invalid or empty subject data');
      throw new Error('Invalid or empty subject data');
    }

    connection = await schoolDbConnection.getConnection();
    console.log('bulkLoadTeacherClassSubject: Database connection acquired'); // Debug log
    await connection.beginTransaction();

    // Step 1: Collect all TEACHER_NAMEs from teacherMapping
    const teacherNames = teacherMapping.map(row => row.TEACHER_NAME);
    const allTeacherNames = [...new Set(teacherNames)];
    console.log('bulkLoadTeacherClassSubject: All teacher names:', allTeacherNames); // Debug log

    // Step 2: Fetch STAFF_IDs from ACD_STAFF_PROFILE
    const staffValidationQuery = `
      SELECT STAFF_ID, STAFF_NAME 
      FROM ACD_STAFF_PROFILE 
      WHERE STAFF_NAME IN (?) 
      AND STAFF_ROLE = 'TEACHER'
    `;
    const [staffRecords] = await connection.query(staffValidationQuery, [allTeacherNames]);
    console.log('bulkLoadTeacherClassSubject: ACD_STAFF_PROFILE query result:', staffRecords); // Debug log
    if (!staffRecords || staffRecords.length === 0) {
      console.error('bulkLoadTeacherClassSubject: No teacher names found in ACD_STAFF_PROFILE');
      throw new Error('No teacher names found in ACD_STAFF_PROFILE');
    }

    const staffMap = new Map(staffRecords.map(row => [row.STAFF_NAME, row.STAFF_ID]));
    const invalidNames = allTeacherNames.filter(name => !staffMap.has(name) && name);
    if (invalidNames.length > 0) {
      console.error('bulkLoadTeacherClassSubject: Invalid teacher names:', invalidNames);
      throw new Error(`These teacher names were not found in ACD_STAFF_PROFILE: ${invalidNames.join(', ')}`);
    }

    // Step 3: Prepare and Insert ACD_CLASS_SUB_TEACHER_MAPPING
    const usedStaffIds = new Set(); // Track assigned staff IDs for uniqueness
    const mappingValues = teacherMapping.map(row => {
      const staffId = staffMap.get(row.TEACHER_NAME);
      if (!staffId) {
        console.error('bulkLoadTeacherClassSubject: No STAFF_ID for TEACHER_NAME:', row.TEACHER_NAME);
        throw new Error(`No STAFF_ID found for TEACHER_NAME: ${row.TEACHER_NAME}`);
      }
      const classTeacherFlag = row.CLASS_TEACHER_FLAG === "1" ? 1 : 0;
      const subject = classTeacherFlag === 1 ? '' : (row.SUBJECT || '');
      const classId = `${row.CLASS} ${row.SECTION}`;

      // Check for unique class teacher assignment
      if (classTeacherFlag === 1) {
        const classSectionKey = `${row.CLASS}-${row.SECTION}`;
        if (usedStaffIds.has(classSectionKey)) {
          console.error('bulkLoadTeacherClassSubject: Multiple class teachers for', classSectionKey);
          throw new Error(`Only one class teacher can be assigned to ${row.CLASS} ${row.SECTION}`);
        }
        usedStaffIds.add(classSectionKey);
      }

      const values = [
        row.CLASS,
        row.SECTION,
        subject,
        staffId,
        row.TEACHER_NAME,
        classTeacherFlag,
        1, // IS_ACTIVE
        '2025-2026' // ACADEMIC_YEAR
      ];
      console.log('bulkLoadTeacherClassSubject: Mapping values:', values); // Debug log
      return values;
    });

    if (mappingValues.length > 0) {
      const mappingQuery = `
        INSERT INTO ACD_CLASS_SUB_TEACHER_MAPPING (
          CLASS, SECTION, SUBJECT, TEACHER_ID, TEACHER_NAME, CLASS_TEACHER_FLAG, IS_ACTIVE, ACADEMIC_YEAR
        ) VALUES ?
        ON DUPLICATE KEY UPDATE
          TEACHER_NAME = VALUES(TEACHER_NAME),
          CLASS_TEACHER_FLAG = VALUES(CLASS_TEACHER_FLAG),
          IS_ACTIVE = VALUES(IS_ACTIVE),
          UPDATE_DATE = CURRENT_TIMESTAMP
      `;
      await connection.query(mappingQuery, [mappingValues]);
      console.log(`bulkLoadTeacherClassSubject: Inserted ${mappingValues.length} records into ACD_CLASS_SUB_TEACHER_MAPPING`); // Debug log
    } else {
      console.error('bulkLoadTeacherClassSubject: No valid ACD_CLASS_SUB_TEACHER_MAPPING data to insert');
      throw new Error('No valid ACD_CLASS_SUB_TEACHER_MAPPING data to insert');
    }

    // Step 4: Prepare and Insert ACD_SUBJECT
    const subjectClasses = new Set(subject.map(row => row.CLASS.trim()));
    console.log('bulkLoadTeacherClassSubject: Classes in subject file:', Array.from(subjectClasses)); // Debug log

    // Validate CLASS against ACD_CLASS_SUB_TEACHER_MAPPING
    const [classRecords] = await connection.query(`SELECT DISTINCT CLASS FROM ACD_CLASS_SUB_TEACHER_MAPPING`);
    const existingClasses = new Set(classRecords.map(row => row.CLASS));
    console.log('bulkLoadTeacherClassSubject: Existing Classes in ACD_CLASS_SUB_TEACHER_MAPPING:', Array.from(existingClasses)); // Debug log

    const missingClasses = Array.from(subjectClasses).filter(cls => !existingClasses.has(cls));
    if (missingClasses.length > 0) {
      console.error('bulkLoadTeacherClassSubject: Missing classes in ACD_CLASS_SUB_TEACHER_MAPPING:', missingClasses);
      throw new Error(`The following classes are not available in ACD_CLASS_SUB_TEACHER_MAPPING: ${missingClasses.join(', ')}. No data will be inserted.`);
    }

    const subjectValues = subject
      .filter(row => 
        row.CLASS && row.CLASS.trim() && 
        row.SUBJECT_CODE && row.SUBJECT_CODE.trim() && 
        row.SUBJECT_NAME && row.SUBJECT_NAME.trim()
      )
      .map(row => [
        row.CLASS.trim(),
        row.SUBJECT_CODE.trim(),
        row.SUBJECT_NAME.trim(),
        row.STREAM ? row.STREAM.trim() : null,
        row.OPTIONAL ? row.OPTIONAL.trim() : null
      ]);
    console.log('bulkLoadTeacherClassSubject: Subject Values to Insert:', subjectValues); // Debug log

    if (subjectValues.length > 0) {
      const subjectQuery = `
        INSERT INTO ACD_SUBJECT (
          CLASS, SUBJECT_CODE, SUBJECT_NAME, STREAM, OPTIONAL,
          CREATE_DATE, UPDATE_DATE
        ) VALUES ?
        ON DUPLICATE KEY UPDATE
          SUBJECT_NAME = VALUES(SUBJECT_NAME),
          STREAM = VALUES(STREAM),
          OPTIONAL = VALUES(OPTIONAL),
          UPDATE_DATE = CURRENT_TIMESTAMP
      `;
      const valuesWithTimestamps = subjectValues.map(row => [
        ...row,
        new Date().toISOString().slice(0, 19).replace('T', ' '),
        new Date().toISOString().slice(0, 19).replace('T', ' ')
      ]);
      await connection.query(subjectQuery, [valuesWithTimestamps]);
      console.log(`bulkLoadTeacherClassSubject: Inserted ${valuesWithTimestamps.length} records into ACD_SUBJECT`); // Debug log
    } else {
      console.error('bulkLoadTeacherClassSubject: No valid ACD_SUBJECT data to insert');
      throw new Error('No valid ACD_SUBJECT data to insert');
    }

    // Commit transaction
    await connection.commit();
    console.log('bulkLoadTeacherClassSubject: Transaction committed successfully'); // Debug log
    return {
      message: 'All data uploaded successfully',
      details: {
        mappingCount: mappingValues.length,
        subjectCount: subjectValues.length,
      },
    };
  } catch (error) {
    console.error('bulkLoadTeacherClassSubject: Error:', error.message, error.stack); // Debug log
    if (connection) await connection.rollback();
    throw error;
  } finally {
    if (connection) {
      console.log('bulkLoadTeacherClassSubject: Releasing database connection'); // Debug log
      connection.release();
    }
  }
}

module.exports = { bulkLoadTeacherClassSubject };