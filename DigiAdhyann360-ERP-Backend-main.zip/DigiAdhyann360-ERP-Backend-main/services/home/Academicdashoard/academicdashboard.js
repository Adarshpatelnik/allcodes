const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getStudentCount = async () => {
  try {
    console.log("Services: GET /api/studentcountdetails: Fetching student count...");
    
    const store = asyncLocalStorage.getStore();
    if (!store) {
      console.error("Services: AsyncLocalStorage store is undefined");
      throw new Error("AsyncLocalStorage store is unavailable");
    }
    console.log("Services: Store contents:", Array.from(store.entries()));

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.error("Services: School database connection not established");
      throw new Error("School database connection not established");
    }

    const studentsSql = `SELECT COUNT(*) AS TOTAL_STUDENTS FROM ACD_STUDENT_PROFILE`;
    console.log("Services: Executing SQL query:", studentsSql);

    const [studentsResult] = await schoolDbConnection.query(studentsSql);
    const totalStudents = studentsResult[0].TOTAL_STUDENTS;

    console.log("Services: Student count fetched successfully. Total students:", totalStudents);
    return { totalStudents };
  } catch (error) {
    console.error("Services: Error fetching student count:", error.message);
    throw error;
  }
};

const getSchoolProfile = async () => {
  try {
    console.log("Services: GET /api/SchoolProfile: Fetching school profile...");
    
    const store = asyncLocalStorage.getStore();
    if (!store) {
      console.error("Services: AsyncLocalStorage store is undefined");
      throw new Error("AsyncLocalStorage store is unavailable");
    }
    console.log("Services: Store contents:", Array.from(store.entries()));

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.error("Services: School database connection not established");
      throw new Error("School database connection not established");
    }

    const schoolSql = `SELECT * FROM ACD_SCHOOL_PROFILE WHERE SCHOOL_ID = 1`;
    console.log("Services: Executing SQL query:", schoolSql);

    const [schoolResult] = await schoolDbConnection.query(schoolSql);
    if (!schoolResult || schoolResult.length === 0) {
      console.error("Services: No school profile found");
      throw new Error("No school profile found");
    }

    console.log("Services: School profile fetched successfully:", schoolResult[0]);
    return schoolResult[0];
  } catch (error) {
    console.error("Services: Error fetching school profile:", error.message);
    throw error;
  }
};

const getStaffCount = async () => {
  try {
    console.log("Services: GET /api/staffcount: Fetching staff count...");
    
    const store = asyncLocalStorage.getStore();
    if (!store) {
      console.error("Services: AsyncLocalStorage store is undefined");
      throw new Error("AsyncLocalStorage store is unavailable");
    }
    console.log("Services: Store contents:", Array.from(store.entries()));

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.error("Services: School database connection not established");
      throw new Error("School database connection not established");
    }


    const staffSql = `SELECT COUNT(*) AS TOTAL_STAFF FROM ACD_STAFF_PROFILE WHERE IS_ACTIVE = 1`;

    console.log("Services: Executing SQL query:", staffSql);

    const [staffResult] = await schoolDbConnection.query(staffSql);
    const totalStaff = staffResult[0].TOTAL_STAFF;

    console.log("Services: Staff count fetched successfully. Total staff:", totalStaff);
    return { totalStaff };
  } catch (error) {
    console.error("Services: Error fetching staff count:", error.message);
    throw error;
  }
};

const getWorkingStaff = async () => {
  try {
    console.log("Services: GET /api/workingStaff: Fetching working staff...");
    
    const store = asyncLocalStorage.getStore();
    if (!store) {
      console.error("Services: AsyncLocalStorage store is undefined");
      throw new Error("AsyncLocalStorage store is unavailable");
    }
    console.log("Services: Store contents:", Array.from(store.entries()));

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.error("Services: School database connection not established");
      throw new Error("School database connection not established");
    }

    const staffSql = `

    SELECT STAFF_ID, STAFF_NAME, STAFF_ROLE, CONTACT_NUMBER, EMAIL, DATE_OF_JOINING
      FROM SCHOOL_ERP_DATABASE.ACD_STAFF_PROFILE
      WHERE IS_ACTIVE =  1

      ORDER BY STAFF_NAME
    `;
    console.log("Services: Executing SQL query:", staffSql);

    const [staffResult] = await schoolDbConnection.query(staffSql);
    console.log("Services: Working staff fetched successfully:", staffResult);
    return staffResult;
  } catch (error) {
    console.error("Services: Error fetching working staff:", error.message);
    throw error;
  }
};

module.exports = {
  getStudentCount,
  getSchoolProfile,
  getStaffCount,
  getWorkingStaff
};