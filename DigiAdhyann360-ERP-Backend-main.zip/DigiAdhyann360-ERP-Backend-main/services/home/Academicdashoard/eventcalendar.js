const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getEvents = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context in eventcalendar service');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established in eventcalendar service');
    throw new Error('School database connection not established');
  }

  const query = `
    SELECT
      NAME,
      START_DATE,
      END_DATE,
      OCCUPANCYTYPE
    FROM ACD_EVENTS_HOLIDAYS
  `;

  try {
    logger.info('Executing query to fetch events data');
    const [results] = await schoolDbConnection.query(query);

    if (!results || results.length === 0) {
      logger.info('No events data found in the database');
      throw new Error('No events data found');
    }

    logger.info('Successfully fetched events data');
    return results;
  } catch (err) {
    logger.error('Error fetching events data', { error: err.message });
    throw new Error(`Error fetching events: ${err.message}`);
  }
};

module.exports = {
  getEvents,
};