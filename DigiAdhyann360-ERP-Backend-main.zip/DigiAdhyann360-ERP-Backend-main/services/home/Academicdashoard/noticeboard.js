const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getNoticeboard = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context in noticeboard service');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established in noticeboard service');
    throw new Error('School database connection not established');
  }

  const query = 'SELECT MESSAGE, START_DATE, FILE_URL FROM ACD_NOTICE_BOARD ORDER BY START_DATE DESC';

  try {
    logger.info('Executing query to fetch noticeboard data');
    const [results] = await schoolDbConnection.query(query);

    if (!results || results.length === 0) {
      logger.info('No noticeboard data found in the database');
      throw new Error('No noticeboard data found');
    }

    logger.info('Successfully fetched noticeboard data');
    return results;
  } catch (err) {
    logger.error('Error fetching noticeboard data', { error: err.message });
    throw new Error(`Error fetching noticeboard: ${err.message}`);
  }
};

module.exports = {
  getNoticeboard,
};