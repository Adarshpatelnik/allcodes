const { asyncLocalStorage } = require('../../../middleware/authmiddleware')
const logger = require('../../../logger/logger');

const getAttendanceSummary = async (filter, customStartDate, className, section) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Missing AsyncLocalStorage context');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  const validFilters = ["1 Week", "1 Month", "3 Months", "6 Months", "1 Year", "Custom"];
  if (!validFilters.includes(filter)) {
    logger.error('Invalid filter option', { filter });
    throw new Error(`Invalid filter option: ${filter}. Valid options are: ${validFilters.join(", ")}`);
  }

  let dateCondition = "";
  let values = [];

  switch (filter) {
    case "1 Week":
      dateCondition = "sa.ATTENDANCE_DATE BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 WEEK) AND CURDATE()";
      break;
    case "1 Month":
      dateCondition = "sa.ATTENDANCE_DATE BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND CURDATE()";
      break;
    case "3 Months":
      dateCondition = "sa.ATTENDANCE_DATE BETWEEN DATE_SUB(CURDATE(), INTERVAL 3 MONTH) AND CURDATE()";
      break;
    case "6 Months":
      dateCondition = "sa.ATTENDANCE_DATE BETWEEN DATE_SUB(CURDATE(), INTERVAL 6 MONTH) AND CURDATE()";
      break;
    case "1 Year":
      dateCondition = "sa.ATTENDANCE_DATE BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND CURDATE()";
      break;
    case "Custom":
      if (!customStartDate) {
        logger.error('Custom start date required for custom filter');
        throw new Error('Custom start date required');
      }
      dateCondition = "sa.ATTENDANCE_DATE BETWEEN ? AND CURDATE()";
      values.push(customStartDate);
      break;
  }

  let query = `
     SELECT
      cd.CLASS,
      cd.SECTION,
      SUM(CASE WHEN sa.STATUS = 'Present' THEN 1 ELSE 0 END) AS PresentCount,
      SUM(CASE WHEN sa.STATUS = 'Absent' THEN 1 ELSE 0 END) AS AbsentCount,
      COUNT(*) AS TotalCount,
      ROUND((SUM(CASE WHEN sa.STATUS = 'Present' THEN 1 ELSE 0 END) * 100.0) / COUNT(*), 2) AS PresentPercentage,
      ROUND((SUM(CASE WHEN sa.STATUS = 'Absent' THEN 1 ELSE 0 END) * 100.0) / COUNT(*), 2) AS AbsentPercentage
    FROM
      ACD_STUDENT_PROFILE sp
    INNER JOIN
      ACD_STUDENT_ATTENDANCE sa ON sp.STUDENT_ID = sa.STUDENT_ID
    INNER JOIN
      ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
    WHERE
      ${dateCondition}
  `;

  if (className && className !== 'All') {
    query += ' AND cd.CLASS = ?';
    values.push(className);
  }
  if (section && section !== 'All') {
    query += ' AND cd.SECTION = ?';
    values.push(section);
  }

  query += ' GROUP BY cd.CLASS, cd.SECTION';

  try {
    logger.info('Executing SQL query for attendance summary', { filter, className, section, customStartDate });
    const [rows] = await schoolDbConnection.query(query, values);
    logger.info('Attendance summary fetched successfully', { count: rows.length });
    return rows;
  } catch (err) {
    logger.error('Error fetching attendance summary', { error: err.message });
    throw new Error(`Error fetching attendance summary: ${err.message}`);
  }
};

module.exports = { getAttendanceSummary };


