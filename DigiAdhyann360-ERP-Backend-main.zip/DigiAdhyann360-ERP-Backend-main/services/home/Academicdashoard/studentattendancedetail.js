const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStudentAttendanceDetail = async (period) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context in studentattendancedetail service');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established in studentattendancedetail service');
    throw new Error('School database connection not established');
  }

  let dateInterval;
  switch (period) {
    case 'monthly':
      dateInterval = '1 MONTH';
      break;
    case 'quarterly':
      dateInterval = '3 MONTH';
      break;
    case 'half-yearly':
      dateInterval = '6 MONTH';
      break;
    case 'yearly':
      dateInterval = '1 YEAR';
      break;
    default:
      dateInterval = '100 YEAR';
  }

  const query = `
    SELECT
      sp.STUDENT_ID,
      sp.FIRST_NAME,
      cd.CLASS,
      cd.SECTION,
      DATE_FORMAT(sa.ATTENDANCE_DATE, '%m-%Y') AS MonthYear,
      COUNT(sa.ATTENDANCE_DATE) AS TotalDays,
      SUM(CASE WHEN sa.STATUS = 'Present' THEN 1 ELSE 0 END) AS PresentCount,
      ROUND((SUM(CASE WHEN sa.STATUS = 'Present' THEN 1 ELSE 0 END) * 100.0) / NULLIF(COUNT(sa.ATTENDANCE_DATE), 0), 2) AS PresentPercentage,
      ROUND((SUM(CASE WHEN sa.STATUS = 'Absent' THEN 1 ELSE 0 END) * 100.0) / NULLIF(COUNT(sa.ATTENDANCE_DATE), 0), 2) AS AbsentPercentage
    FROM
      ACD_STUDENT_PROFILE sp
    LEFT JOIN
      ACD_STUDENT_ATTENDANCE sa ON sp.STUDENT_ID = sa.STUDENT_ID
    LEFT JOIN
      ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
    WHERE sa.ATTENDANCE_DATE BETWEEN DATE_SUB(CURDATE(), INTERVAL ${dateInterval}) AND CURDATE()
    GROUP BY
      sp.STUDENT_ID, sp.FIRST_NAME, cd.CLASS, cd.SECTION, MonthYear
    ORDER BY
      sp.STUDENT_ID, STR_TO_DATE(MonthYear, '%m-%Y')
  `;

  try {
    logger.info('Executing query to fetch student attendance detail data', { period });
    const [results] = await schoolDbConnection.query(query);

    if (!results || results.length === 0) {
      logger.info('No student attendance detail data found in the database', { period });
      throw new Error('No student attendance detail data found');
    }

    logger.info('Successfully fetched student attendance detail data', { period });
    return results;
  } catch (err) {
    logger.error('Error fetching student attendance detail data', { error: err.message, period });
    throw new Error(`Error fetching student attendance detail: ${err.message}`);
  }
};

module.exports = {
  getStudentAttendanceDetail,
};