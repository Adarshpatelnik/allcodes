const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStudentGender = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context in studentgender service');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established in studentgender service');
    throw new Error('School database connection not established');
  }

  const query = `
    SELECT
      SP.GENDER,
      CD.CLASS,
      COUNT(*) AS STUDENT_COUNT
    FROM ACD_STUDENT_PROFILE SP
    JOIN ACD_STUDENT_CLASS_MAPPING CD ON SP.STUDENT_ID = CD.STUDENT_ID
    WHERE SP.GENDER IN ('MALE', 'FEMALE')
    GROUP BY SP.GENDER, CD.CLASS
  `;

  try {
    logger.info('Executing query to fetch student gender data');
    const [results] = await schoolDbConnection.query(query);

    if (!results || results.length === 0) {
      logger.info('No student gender data found in the database');
      throw new Error('No student gender data found');
    }

    logger.info('Successfully fetched student gender data');
    return results;
  } catch (err) {
    logger.error('Error fetching student gender data', { error: err.message });
    throw new Error(`Error fetching student gender: ${err.message}`);
  }
};

module.exports = {
  getStudentGender,
};