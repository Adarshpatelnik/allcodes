const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const studentGenderDetailService = {
  async getCasteDistribution() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('Unauthorized or missing context in getCasteDistribution');
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established in getCasteDistribution');
      throw new Error('School database connection not established');
    }

    const studentsSql = `
      SELECT
        sp.CASTE,
        CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
        sp.GENDER,
        CD.CLASS,
        CD.SECTION,
        COUNT(*) AS STUDENT_COUNT,
        (COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY sp.GENDER, CD.CLASS)) AS CASTE_PERCENTAGE
      FROM ACD_STUDENT_PROFILE sp
      JOIN ACD_STUDENT_CLASS_MAPPING CD ON sp.STUDENT_ID = CD.STUDENT_ID
      WHERE sp.GENDER IN ('MALE', 'FEMALE')
      GROUP BY sp.CASTE, sp.GENDER, CD.CLASS, CD.SECTION;
    `;

    logger.info('Executing SQL query for caste distribution:', studentsSql);
    const [studentsResult] = await schoolDbConnection.query(studentsSql);
    return studentsResult;
  },

  async getStudentDetailsByClass(selectedClass) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('Unauthorized or missing context in getStudentDetailsByClass');
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established in getStudentDetailsByClass');
      throw new Error('School database connection not established');
    }

    let studentsSql = `
      SELECT
        CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
        CD.CLASS,
        CD.SECTION,
        sp.CASTE,
        sp.GENDER
      FROM STUDENT_PROFILE sp
      JOIN CLASS_DETAIL CD ON sp.STUDENT_ID = CD.STUDENT_ID
      WHERE sp.GENDER IN ('MALE', 'FEMALE')
    `;

    if (selectedClass) {
      studentsSql += ` AND CD.CLASS = ?`;
    }

    logger.info('Executing SQL query for student details by class:', studentsSql);
    const [studentsResult] = selectedClass
      ? await schoolDbConnection.query(studentsSql, [selectedClass])
      : await schoolDbConnection.query(studentsSql);

    return studentsResult;
  },
};

module.exports = studentGenderDetailService;