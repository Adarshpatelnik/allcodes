const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getPerformanceSummary = async (queryParams) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context in performanceSummary service');
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established in performanceSummary service');
    throw new Error('School database connection not established');
  }

  const { CLASS, ACADEMIC_YEAR, TERM, PERFORMANCE } = queryParams;

  let query = `
WITH cte AS (
  SELECT
    student_id,
    CASE
      WHEN
        ROUND(
          SUM(CASE WHEN s.EXAM_TYPE = 'Annual' THEN s.MARKS ELSE 0 END) /
          (COUNT(CASE WHEN s.EXAM_TYPE = 'Annual' THEN s.SUBJECT_NAME ELSE NULL END) * 100) * 100,
          2
        ) < 33 THEN 'FAIL'
      ELSE 'PASS'
    END AS Annual_PERFORMANCE
  FROM ACD_MARKS_DETAIL s
  GROUP BY student_id
)
SELECT
  a.CLASS,count(*) AS TOTAL_STUDENT,a.ACADEMIC_YEAR,a.EXAM_TYPE,
SUM(case when cte.Annual_PERFORMANCE = 'PASS' THEN 1 ELSE 0 END) AS STUDENT_PASS,
SUM(case when cte.Annual_PERFORMANCE = 'FAIL' THEN 1 ELSE 0 END) AS STUDENT_FAIL
FROM ACD_MARKS_DETAIL a
INNER JOIN cte ON cte.student_id = a.student_id
group by a.CLASS,a.ACADEMIC_YEAR,a.EXAM_TYPE
  `;

  const conditions = [];
  const params = [];

  if (CLASS) {
    conditions.push('CLASS = ?');
    params.push(CLASS);
  }
  if (ACADEMIC_YEAR) {
    conditions.push('ACADEMIC_YEAR = ?');
    params.push(ACADEMIC_YEAR);
  }
  if (TERM) {
    conditions.push('TERM = ?');
    params.push(TERM);
  }
  if (PERFORMANCE) {
    conditions.push('PERFORMANCE = ?');
    params.push(PERFORMANCE);
  }

  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }

  try {
    logger.info('Executing query to fetch performance summary data');
    const [results] = await schoolDbConnection.query(query, params);

    if (!results || results.length === 0) {
      logger.info('No performance summary data found in the database');
      throw new Error('No performance summary data found');
    }

    logger.info('Successfully fetched performance summary data');
    return results;
  } catch (err) {
    logger.error('Error fetching performance summary data', { error: err.message });
    throw new Error(`Error fetching performance summary: ${err.message}`);
  }
};

module.exports = {
  getPerformanceSummary,
};