const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getTotalExpenseForDashboard = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  try {
    const query = `SELECT COALESCE(SUM(AMOUNT), 0) AS Amount FROM ACC_EXPENSES`;
    console.log('Executing getTotalExpenseForDashboard query:', query);
    const [results] = await schoolDbConnection.query(query);
    console.log('Total expense fetched:', results[0].Amount);
    return { Amount: Number(results[0].Amount) || 0 };
  } catch (error) {
    console.error('Error fetching total expense:', error.message);
    throw new Error('Database query error: ' + error.message);
  }
};

const getFeeCollectionRateForDashboard = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) throw new Error('Unauthorized or missing context');

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) throw new Error('School database connection not established');

  try {
    const query = `
      	  SELECT
  ROUND(
    (SUM(CASE WHEN STATUS = 'PAID' THEN TOTAL_FEES ELSE 0 END) /
     NULLIF(SUM(TOTAL_FEES), 0)) * 100, 2
  ) AS Fee_Collection_Rate
FROM
  ACC_FEE_COLLECTION_RECORD;
    `;
    console.log('Executing getFeeCollectionRateForDashboard query:', query);
    const [results] = await schoolDbConnection.query(query);
    console.log('Fee collection rate fetched:', results[0].Fee_Collection_Rate);
    return { Fee_Collection_Rate: Number(results[0].Fee_Collection_Rate) || 0 };
  } catch (error) {
    console.error('Error fetching fee collection rate:', error.message);
    throw new Error('Database query error: ' + error.message);
  }
};

module.exports = {
  getTotalExpenseForDashboard,
  getFeeCollectionRateForDashboard,
};