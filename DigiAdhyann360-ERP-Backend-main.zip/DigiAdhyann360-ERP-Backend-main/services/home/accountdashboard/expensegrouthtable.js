const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

class ExpenseGrouthService {
  async getExpenseGrouth() {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        throw new Error('Unauthorized or missing context');
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        throw new Error('School database connection not established');
      }

      const query = `
        SELECT CATEGORY_ID, CATEGORY_NAME, BUDGET, FINANCIAL_YEAR, CREATE_DATE, UPDATE_DATE 
        FROM ACC_EXPENSE_CATEGORIES
      `;

      logger.info('Executing expense grouth query');
      const [results] = await schoolDbConnection.query(query);
      logger.info('Expense grouth data fetched successfully', { count: results.length });

      return results;
    } catch (error) {
      logger.error('Error fetching expense grouth data', { error: error.message });
      throw new Error(`Failed to fetch expense grouth data: ${error.message}`);
    }
  }
}

module.exports = new ExpenseGrouthService();
