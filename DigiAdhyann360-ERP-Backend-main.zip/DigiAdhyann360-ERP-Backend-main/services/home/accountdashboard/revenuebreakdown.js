const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

class TotalRevenueService {
  async getTotalRevenue() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
    SELECT
        YEAR(DUE_END_DATE) AS YEAR,
        MONTHNAME(DUE_END_DATE) AS MONTH_NAME,
        SUM(NET_FEES) AS TOTAL_REVENUE
      FROM ACC_FEE_COLLECTION_STATUS
      WHERE FREQUENCY IN ('APRIL', 'MAY', 'JUNE', 'JULY', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC')
        AND STATUS = 'Paid'
      GROUP BY YEAR(DUE_END_DATE), MONTH(DUE_END_DATE)
      ORDER BY YEAR(DUE_END_DATE), MONTH(DUE_END_DATE)
	  `;

    logger.info('Executing total revenue query');
    const [results] = await schoolDbConnection.query(query);

    logger.info('Total revenue fetched successfully', { count: results.length });
    return results;
  }
}

module.exports = new TotalRevenueService();