const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

class TotalExpenseServices {
  async getTotalExpense() {
    try {
      const store = asyncLocalStorage.getStore();
      if (!store) {
        throw new Error('Unauthorized or missing context');
      }

      const schoolDbConnection = store.get('schoolDbConnection');
      if (!schoolDbConnection) {
        logger.error('School database connection not established');
        throw new Error('School database connection not established');
      }

      const query = `SELECT  
        EXPENSE_ID, CATEGORY_ID, AMOUNT, EXPENSE_DATE, PAID_BY, DEPARTMENT, STATUS, FINANCIAL_YEAR, CREATE_DATE, UPDATE_DATE 
        FROM ACC_EXPENSES`;

      logger.info('Executing total expense query');
      const [results] = await schoolDbConnection.query(query);

      logger.info('Total expense fetched successfully', { count: results.length });
      return results;

    } catch (error) {
      logger.error('Error fetching total expenses', { error: error.message });
     throw new Error(`Failed to fetch total expenses: ${error.message}`);
    }
  }
}

module.exports = new TotalExpenseServices();
