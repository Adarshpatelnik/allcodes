const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getDbConnection = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context');
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }
  return schoolDbConnection;
};

const fetchStaffAttendance = async () => {
  const schoolDbConnection = getDbConnection();
  try {
    logger.info('Fetching staff attendance data');
    const staffAttendanceSql = `
      SELECT 
        a.STAFF_ID, 
        a.STAFF_NAME, 
        a.STAFF_ROLE, 
        b.ACADEMIC_YEAR, 
        b.ATTENDANCE_DATE, 
        b.STATUS
      FROM ACD_STAFF_PROFILE a, ACD_STAFF_ATTENDANCE b
      WHERE a.STAFF_ID = b.STAFF_ID
    `;
    logger.debug('Executing SQL query:', { query: staffAttendanceSql });
    const [rows] = await schoolDbConnection.query(staffAttendanceSql);
    logger.info('Staff attendance fetched successfully', { count: rows.length });
    return rows;
  } catch (error) {
    logger.error('Error fetching staff attendance', { error: error.message });
    throw error;
  }
};

module.exports = {
  fetchStaffAttendance,
};