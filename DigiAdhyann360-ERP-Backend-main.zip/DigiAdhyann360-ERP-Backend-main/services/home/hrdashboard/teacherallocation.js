const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getDbConnection = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context');
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }
  return schoolDbConnection;
};

const fetchTeacherReassign = async () => {
  const schoolDbConnection = getDbConnection();
  try {
    logger.info('Fetching teacher reassignment data');
    const teacherReassignSql = `
      WITH LeaveTeacher AS (
    SELECT DISTINCT MAPPING.TEACHER_ID, MAPPING.TEACHER_NAME
    FROM ACD_CLASS_SUB_TEACHER_MAPPING MAPPING
    WHERE MAPPING.TEACHER_ID IN (
        SELECT STAFF_ID
        FROM ACD_STAFF_ATTENDANCE
        WHERE STATUS = 'LEAVE'
          AND STAFF_ID LIKE 'TID-%'
    )
),
AbsentTeacherSchedule AS (
    SELECT
        SCH.CLASS_ID,
        SCH.SECTION,
        SCH.PERIOD,
        SCH.SUBJECT,
        SCH.TIME_SLOT,
        SCH.DURATION,
        MAPPING.TEACHER_ID AS ABSENT_TEACHER_ID,
        MAPPING.TEACHER_NAME AS ABSENT_TEACHER_NAME
    FROM ACD_CLASS_SCHEDULE SCH
    INNER JOIN ACD_CLASS_SUB_TEACHER_MAPPING MAPPING
        ON SCH.CLASS_ID = MAPPING.CLASS_ID
        AND SCH.SUBJECT = MAPPING.SUBJECT
    WHERE MAPPING.TEACHER_ID IN (SELECT TEACHER_ID FROM LeaveTeacher)
),
PresentTeacher AS (
    SELECT DISTINCT MAPPING.TEACHER_ID, MAPPING.TEACHER_NAME
    FROM ACD_CLASS_SUB_TEACHER_MAPPING MAPPING
    WHERE MAPPING.TEACHER_ID IN (
        SELECT STAFF_ID
        FROM ACD_STAFF_ATTENDANCE
        WHERE STATUS = 'PRESENT'
          AND STAFF_ID LIKE 'TID-%'
    )
),
FreeTeachers AS (
    SELECT
        PT.TEACHER_ID,
        PT.TEACHER_NAME,
        ATS.PERIOD,
        ATS.TIME_SLOT,
        ROW_NUMBER() OVER (PARTITION BY ATS.PERIOD ORDER BY PT.TEACHER_ID) AS row_num
    FROM PresentTeacher PT
    CROSS JOIN AbsentTeacherSchedule ATS
    WHERE NOT EXISTS (
        SELECT 1
        FROM ACD_CLASS_SCHEDULE SCH
        INNER JOIN ACD_CLASS_SUB_TEACHER_MAPPING M
            ON SCH.CLASS_ID = M.CLASS_ID
           AND SCH.SUBJECT = M.SUBJECT
        WHERE M.TEACHER_ID = PT.TEACHER_ID
          AND SCH.TIME_SLOT = ATS.TIME_SLOT
    )
)
SELECT DISTINCT
    ATS.CLASS_ID,
    ATS.SECTION,
    ATS.PERIOD,
    ATS.SUBJECT,
    ATS.TIME_SLOT,
    ATS.DURATION,
    ATS.ABSENT_TEACHER_NAME AS ABSENT_TEACHER,
    FT.TEACHER_NAME AS SUBSTITUTE_TEACHER
FROM AbsentTeacherSchedule ATS
LEFT JOIN FreeTeachers FT
    ON ATS.PERIOD = FT.PERIOD
   AND ATS.TIME_SLOT = FT.TIME_SLOT
   AND FT.row_num = 1
ORDER BY ATS.PERIOD, ATS.SECTION
  `;
    logger.debug('Executing SQL query:', { query: teacherReassignSql });
    const [rows] = await schoolDbConnection.query(teacherReassignSql);
    logger.info('Teacher reassignment fetched successfully', { count: rows.length });
    return rows;
  } catch (error) {
    logger.error('Error fetching teacher reassignment', { error: error.message });
    throw error;
  }
};

module.exports = {
  fetchTeacherReassign,
};