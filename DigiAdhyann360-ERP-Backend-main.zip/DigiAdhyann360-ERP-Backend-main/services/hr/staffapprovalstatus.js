const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');
const bcrypt = require('bcrypt');
const { pool } = require('../../config/db');

const staffRolePrefix = {
  ADMIN: 'AID',
  TEACHER: 'TID',
  PRINCIPAL: 'PRID',
  VICE_PRINCIPAL: 'VPRID',
  ACCOUNTANT: 'ACID',
  'MANAGEMENT STAFF': 'MSID',
  'STORE MANAGER': 'SMID',
  OTHER: 'OID',
};

const normalizeStaffRole = (role) => role.trim().toUpperCase();

class StaffApprovalService {
  async getPendingRegistrations() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
      SELECT * 
      FROM ACD_STAFF_REGISTRATION 
      WHERE IS_ENROLLED = 'FALSE' 
      AND APPROVAL_STATUS = 'PENDING'
    `;
    logger.info('Fetching pending staff registrations');
    const [results] = await schoolDbConnection.query(query);
    return results;
  }

  async processApproval(applicationIds, approvalStatus) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    if (approvalStatus === 'PENDING') {
      return { success: true, message: 'No changes made. Status is PENDING.' };
    }

    if (approvalStatus === 'REJECTED') {
      const rejectQuery = `
        UPDATE ACD_STAFF_REGISTRATION
        SET APPROVAL_STATUS = 'REJECTED', IS_ENROLLED = 'FALSE'
        WHERE STAFF_ID IN (?)
      `;
      logger.info('Rejecting staff applications', { applicationIds });
      await schoolDbConnection.query(rejectQuery, [applicationIds]);
      return { success: true, message: 'Applications rejected successfully.' };
    }

    if (approvalStatus === 'APPROVED') {
      const fetchQuery = `
        SELECT * 
        FROM ACD_STAFF_REGISTRATION 
        WHERE STAFF_ID IN (?) 
        AND APPROVAL_STATUS = 'PENDING'
      `;
      const [results] = await schoolDbConnection.query(fetchQuery, [applicationIds]);

      if (results.length === 0) {
        throw new Error('No staff found or already processed.');
      }

      // Begin transaction
      await schoolDbConnection.query('START TRANSACTION');

      try {
        for (const staff of results) {
          const normalizedStaffRole = normalizeStaffRole(staff.STAFF_ROLE);
          const prefix = staffRolePrefix[normalizedStaffRole] || 'OID';
          const regexPattern = `^${prefix}-[0-9]{5}$`;

          // Fetch max sequence for STAFF_ID
          const fetchMaxSeqQuery = `
            SELECT MAX(CAST(SUBSTRING_INDEX(STAFF_ID, '-', -1) AS UNSIGNED)) AS MAX_SEQ
            FROM ACD_STAFF_PROFILE
            WHERE STAFF_ROLE = ? AND STAFF_ID REGEXP ?
          `;
          const [seqResults] = await schoolDbConnection.query(fetchMaxSeqQuery, [normalizedStaffRole, regexPattern]);
          const maxSeq = seqResults[0].MAX_SEQ || 0;
          const newSeq = maxSeq + 1;
          const newStaffId = `${prefix}-${String(newSeq).padStart(5, '0')}`;
          const firstName = staff.STAFF_NAME.trim().split(' ')[0].toUpperCase();
          const newStaffUserId = `${firstName}_${String(newSeq).padStart(5, '0')}`;

          // Insert into STAFF
          const insertQuery = `
            INSERT INTO ACD_STAFF_PROFILE (
              STAFF_ID, STAFF_USER_ID, STAFF_NAME, STAFF_INITIALS, MARITAL_STATUS, CONTACT_NUMBER,
              STAFF_ROLE, FATHER_HUSBAND_NAME, GENDER, EXPERIENCE, ADHAR_ID, RELIGION, EMAIL, EDUCATION,
              BLOOD_GROUP, DATE_OF_BIRTH, ADDRESS, CITY, STATE, POSTAL_CODE, SCHOOL_INFO
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `;
          const values = [
            newStaffId,
            newStaffUserId,
            staff.STAFF_NAME,
            staff.STAFF_INITIALS,
            staff.MARITAL_STATUS,
            staff.PHONE_NUMBER,
            staff.STAFF_ROLE,
            staff.FATHER_HUSBAND_NAME,
            staff.GENDER,
            staff.EXPERIENCE,
            staff.ADHAR_ID,
            staff.RELIGION,
            staff.EMAIL,
            staff.EDUCATION,
            staff.BLOOD_GROUP,
            staff.DATE_OF_BIRTH,
            staff.ADDRESS,
            staff.CITY,
            staff.STATE,
            staff.POSTAL_CODE,
            store.get('tenantId'), // Set SCHOOL_INFO to tenantId
          ];
          await schoolDbConnection.query(insertQuery, values);

          // Update ACD_STAFF_REGISTRATION
          const updateQuery = `
            UPDATE ACD_STAFF_REGISTRATION
            SET APPROVAL_STATUS = 'APPROVED', IS_ENROLLED = 'TRUE'
            WHERE STAFF_ID = ?
          `;
          await schoolDbConnection.query(updateQuery, [staff.STAFF_ID]);

          // Generate password and insert into USERS
          const generateRandomPassword = (length = 8) => {
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+[]{}|;:,.<>?';
            let password = '';
            for (let i = 0; i < length; i++) {
              const randomIndex = Math.floor(Math.random() * characters.length);
              password += characters[randomIndex];
            }
            return password;
          };
          const randomGeneratedPass = generateRandomPassword();
          const hashedPassword = await bcrypt.hash(randomGeneratedPass, 10);

          // Fetch ROLE_ID
          const roleQuery = `
            SELECT ROLE_ID 
            FROM ROLES 
            WHERE ROLE_NAME = ?
          `;
          const [roleResult] = await pool.query(roleQuery, [staff.STAFF_ROLE]);
          if (!roleResult.length) {
            throw new Error(`ROLE_ID not found for role: ${staff.STAFF_ROLE}`);
          }
          const roleId = roleResult[0].ROLE_ID;

          // Insert into USERS
          const userQuery = `
            INSERT INTO USERS (
              TENANT_ID, FULL_NAME, USER_ID, USERNAME, PASSWORD, ROLE_ID, CONTACT_NUMBER, EMAIL
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `;
          const userValues = [
            store.get('tenantId'),
            staff.STAFF_NAME,
            newStaffId,
            newStaffUserId,
            hashedPassword,
            roleId,
            staff.PHONE_NUMBER,
            staff.EMAIL,
          ];
          await pool.query(userQuery, userValues);
        }

        // Commit transaction
        await schoolDbConnection.query('COMMIT');
        logger.info('Approved staff applications', { applicationIds });
        return { success: true, message: 'Staff approved and added successfully.' };
      } catch (err) {
        // Rollback transaction
        await schoolDbConnection.query('ROLLBACK');
        throw err;
      }
    }
  }
}

module.exports = new StaffApprovalService();