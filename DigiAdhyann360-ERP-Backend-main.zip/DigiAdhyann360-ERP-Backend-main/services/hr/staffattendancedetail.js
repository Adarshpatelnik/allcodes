const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StaffAttendanceDetailService {
  async getAttendanceData(period) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    let dateInterval;
    switch (period) {
      case 'monthly':
        dateInterval = '1 MONTH';
        break;
      case 'quarterly':
        dateInterval = '3 MONTH';
        break;
      case 'half-yearly':
        dateInterval = '6 MONTH';
        break;
      case 'yearly':
        dateInterval = '1 YEAR';
        break;
      default:
        dateInterval = '100 YEAR'; // Default: Fetch all data
    }

    const query = `
      SELECT
        a.STAFF_ID,
        a.STAFF_NAME,
        a.STAFF_ROLE,
        MAX(b.STATUS) AS STATUS,
        DATE_FORMAT(b.ATTENDANCE_DATE, '%m-%Y') AS MonthYear,
        COUNT(b.ATTENDANCE_DATE) AS TotalDays,
        SUM(CASE WHEN b.STATUS = 'PRESENT' THEN 1 ELSE 0 END) AS PresentCount,
        ROUND((SUM(CASE WHEN b.STATUS = 'PRESENT' THEN 1 ELSE 0 END) * 100.0) / NULLIF(COUNT(b.ATTENDANCE_DATE), 0), 2) AS PresentPercentage,
        ROUND((SUM(CASE WHEN b.STATUS = 'LEAVE' THEN 1 ELSE 0 END) * 100.0) / NULLIF(COUNT(b.ATTENDANCE_DATE), 0), 2) AS AbsentPercentage
      FROM ACD_STAFF_PROFILE a
      LEFT JOIN ACD_STAFF_ATTENDANCE b ON a.STAFF_ID = b.STAFF_ID
      WHERE b.ATTENDANCE_DATE BETWEEN DATE_SUB(CURDATE(), INTERVAL ${dateInterval}) AND CURDATE()
        OR b.ATTENDANCE_DATE IS NULL
      GROUP BY a.STAFF_ID, a.STAFF_NAME, a.STAFF_ROLE, MonthYear
      ORDER BY a.STAFF_ID, STR_TO_DATE(MonthYear, '%m-%Y')
    `;

    logger.info('Fetching staff attendance data', { period });
    const [results] = await schoolDbConnection.query(query);
    return results;
  }
}

module.exports = new StaffAttendanceDetailService();