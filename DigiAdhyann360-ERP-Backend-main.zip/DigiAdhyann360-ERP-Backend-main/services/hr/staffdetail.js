const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StaffDetailService {
  async getStaffDetail(staffId) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
           SELECT
        a.STAFF_ID, a.STAFF_NAME, a.CONTACT_NUMBER, a.STAFF_ROLE, a.DATE_OF_JOINING,b.NET_SALARY AS MONTHLY_SALARY,
        a.FATHER_HUSBAND_NAME, a.GENDER, a.EXPERIENCE, a.ADHAR_ID, a.RELIGION, a.EMAIL, a.EDUCATION,
        a.BLOOD_GROUP, a.DATE_OF_BIRTH, a.ADDRESS, a.CITY, a.STATE, a.POSTAL_CODE, a.EXIT_DATE
      FROM ACD_STAFF_PROFILE a
      left join ACC_STAFF_SALARY b on a.STAFF_ID = b.STAFF_ID
      WHERE a.STAFF_ID = ?
    `;

    logger.info('Fetching staff details', { staffId });
    const [results] = await schoolDbConnection.query(query, [staffId]);

    if (results.length === 0) {
      throw new Error('Staff not found');
    }

    return results[0];
  }

  async updateStaffDetail(staffId, updatedData) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const allowedFields = [
      'STAFF_NAME', 'CONTACT_NUMBER', 'STAFF_ROLE', 'DATE_OF_JOINING', 'NET_SALARY',
      'FATHER_HUSBAND_NAME', 'GENDER', 'EXPERIENCE', 'ADHAR_ID', 'RELIGION', 'EMAIL', 
      'EDUCATION', 'BLOOD_GROUP', 'DATE_OF_BIRTH', 'ADDRESS', 'CITY', 'STATE', 
      'POSTAL_CODE', 'EXIT_DATE'
    ];

    const setClause = [];
    const values = [];

    allowedFields.forEach(field => {
      if (field in updatedData && updatedData[field] !== undefined) {
        setClause.push(`${field} = ?`);
        values.push(updatedData[field]);
      }
    });

    if (setClause.length === 0) {
      throw new Error('No valid fields provided for update');
    }

    const query = `
      UPDATE ACD_STAFF_PROFILE
      SET ${setClause.join(', ')}
      WHERE STAFF_ID = ?
    `;

    values.push(staffId);

    logger.info('Updating staff details', { staffId, fields: Object.keys(updatedData) });
    const [result] = await schoolDbConnection.query(query, values);

    if (result.affectedRows === 0) {
      throw new Error('Staff not found or no changes made');
    }

    return { message: 'Staff updated successfully' };
  }
}

module.exports = new StaffDetailService();