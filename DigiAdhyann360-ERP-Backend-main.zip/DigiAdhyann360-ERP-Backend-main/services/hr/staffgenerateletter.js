const logger = require('../../logger/logger');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

const getDbConnection = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('No asyncLocalStorage context found');
    throw new Error('Unauthorized access');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection failed');
  }
  return schoolDbConnection;
};

const getStaffGenerateLetterData = async () => {
  const schoolDbConnection = getDbConnection();
  try {
    const query = `
      SELECT
  s.STAFF_ID,
  s.CONTACT_NUMBER,
  s.EMAIL,
  (
    SELECT s2.STAFF_NAME
    FROM ACD_STAFF_PROFILE s2
    WHERE s2.STAFF_ROLE = 'PRINCIPAL'
    LIMIT 1
  ) AS PRINCIPAL_NAME,
  s.STAFF_ROLE,
  s.DATE_OF_JOINING,
  ass.NET_SALARY AS MONTHLY_SALARY,
  td.TEACHER_NAME,
  sd.SCHOOL_NAME,
  sd.CITY,
  sd.POSTAL_CODE,
  s.EXIT_DATE,
  s.STAFF_INITIALS
FROM ACD_STAFF_PROFILE s
LEFT JOIN ACD_CLASS_SUB_TEACHER_MAPPING td ON s.STAFF_ID = td.TEACHER_ID
LEFT JOIN ACC_STAFF_SALARY ass ON ass.STAFF_ID = s.STAFF_ID
JOIN ACD_SCHOOL_PROFILE sd ON 1 = 1
WHERE s.STAFF_ROLE = 'TEACHER'
GROUP BY
  s.STAFF_ID,
  s.CONTACT_NUMBER,
  s.EMAIL,
  s.STAFF_ROLE,
  s.DATE_OF_JOINING,
  ass.NET_SALARY,
  td.TEACHER_NAME,
  sd.SCHOOL_NAME,
  sd.CITY,
  sd.POSTAL_CODE,
  s.EXIT_DATE,
  s.STAFF_INITIALS
 `;
    logger.info('Executing getStaffGenerateLetterData query', { query });
    const [results] = await schoolDbConnection.query(query);
    logger.info('Staff data retrieved', { count: results.length });
    if (!results.length) {
      logger.warn('No staff data found');
      throw new Error('No data found for teachers');
    }
    return results;
  } catch (error) {
    logger.error('Error fetching staff data', { error: error.message });
    throw error;
  }
};

module.exports = { getStaffGenerateLetterData };