const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StaffLeaveBalanceService {
  async getLeaveBalances() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
      SELECT 
        la.STAFF_ID,
        s.STAFF_NAME,
        s.STAFF_ROLE,
        la.LEAVE_TYPE,
        lt.MAX_ALLOWED AS ALLOWED_LEAVE,
        COUNT(*) AS LEAVE_TAKEN,
        lt.MAX_ALLOWED - COUNT(*) AS LEAVE_BALANCE
      FROM ACD_STAFF_PROFILE s
      INNER JOIN ACD_LEAVE_APPLICATION la ON la.STAFF_ID = s.STAFF_ID 
      INNER JOIN ACD_LEAVE_TYPE lt 
        ON TRIM(LOWER(la.LEAVE_TYPE)) = TRIM(LOWER(lt.LEAVE_TYPE))
      GROUP BY la.STAFF_ID, la.LEAVE_TYPE, lt.MAX_ALLOWED
      ORDER BY la.STAFF_ID ASC
    `;

    logger.info('Fetching staff leave balances');
    const [results] = await schoolDbConnection.query(query);
    return results;
  }
}

module.exports = new StaffLeaveBalanceService();