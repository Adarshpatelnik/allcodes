const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StaffLeaveTypeService {
  async getStaffRoles() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = 'SELECT DISTINCT STAFF_ROLE AS name FROM ACD_STAFF_PROFILE WHERE STAFF_ROLE IS NOT NULL';
    logger.info('Fetching distinct staff roles');
    const [results] = await schoolDbConnection.query(query);

    return results;
  }

  async getLeaveData(role) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    let query = 'SELECT LEAVE_ID AS NUM, LEAVE_TYPE, MAX_ALLOWED, STAFF_ROLE FROM ACD_LEAVE_TYPE';
    const params = [];
    if (role) {
      query += ' WHERE STAFF_ROLE = ?';
      params.push(role);
    }

    logger.info('Fetching leave data', { role });
    const [results] = await schoolDbConnection.query(query, params);
    return results;
  }

  async addLeaveType({ num, leaveType, maxAllowed, staffRole }) {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }

  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  const query = 'INSERT INTO ACD_LEAVE_TYPE (LEAVE_ID, LEAVE_TYPE, MAX_ALLOWED, STAFF_ROLE) VALUES (?, ?, ?, ?)';
  logger.info('Adding new leave type', { num, leaveType, maxAllowed, staffRole });

  const [result] = await schoolDbConnection.query(query, [
    num,
    leaveType,
    maxAllowed,
    staffRole || null
  ]);

  return {
    message: 'Leave type added successfully',
    data: {
      LEAVE_ID: num,
      LEAVE_TYPE: leaveType,
      MAX_ALLOWED: maxAllowed,
      STAFF_ROLE: staffRole || null
    }
  };
}

  async updateLeaveType(num, { leaveType, maxAllowed, staffRole }) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = 'UPDATE ACD_LEAVE_TYPE SET LEAVE_TYPE = ?, MAX_ALLOWED = ?, STAFF_ROLE = ? WHERE LEAVE_ID = ?';
    logger.info('Updating leave type', { num, leaveType, maxAllowed, staffRole });
    const [result] = await schoolDbConnection.query(query, [leaveType, maxAllowed, staffRole || null, num]);

    if (result.affectedRows === 0) {
      throw new Error('Leave type not found');
    }

    return { message: 'Leave type updated successfully' };
  }

  async deleteLeaveType(num) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = 'DELETE FROM ACD_LEAVE_TYPE WHERE LEAVE_ID = ?';
    logger.info('Deleting leave type', { num });
    const [result] = await schoolDbConnection.query(query, [num]);

    if (result.affectedRows === 0) {
      throw new Error('Leave type not found');
    }

    return { message: 'Leave type deleted successfully' };
  }
}

module.exports = new StaffLeaveTypeService();