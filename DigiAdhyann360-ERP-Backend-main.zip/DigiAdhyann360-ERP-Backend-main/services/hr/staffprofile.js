const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');
const { generateToken } = require('../../config/auth');

class StaffProfileService {
  async getAllStaffProfiles() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
  SELECT 
        a.STAFF_ID, a.STAFF_USER_ID, a.STAFF_NAME, a.CONTACT_NUMBER, a.STAFF_ROLE, 
        a.DATE_OF_JOINING, b.NET_SALARY AS MONTHLY_SALARY, a.FATHER_HUSBAND_NAME, a.GENDER, 
        a.EXPERIENCE, a.ADHAR_ID, a.RELIGION, a.EMAIL, a.EDUCATION, a.BLOOD_GROUP, 
        a.DATE_OF_BIRTH, a.ADDRESS, a.CITY, a.STATE, a.POSTAL_CODE, a.EXIT_DATE, a.IS_ACTIVE
      FROM ACD_STAFF_PROFILE a
      left join ACC_STAFF_SALARY b on a.STAFF_ID = b.STAFF_ID
    `;

    logger.info('Fetching all staff profiles');
    const [results] = await schoolDbConnection.query(query);
    return results;
  }

  async setStaffId(staffId, user) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    // Validate staffId exists in STAFF table
    const [staffResult] = await schoolDbConnection.query(
      'SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?',
      [staffId]
    );

    if (staffResult.length === 0) {
      throw new Error('Staff ID not found');
    }

    // Create updated JWT payload
    const updatedPayload = {
      userName: user.userName,
      tenantId: user.tenantId,
      roleAllowed: user.roleAllowed,
      current_admin: user.current_admin,
      current_staff: staffId, // Update staff ID
      current_student: user.current_student,
      servicesAllowed: user.servicesAllowed,
      schoolDbNAME: user.schoolDbNAME,
    };

    logger.info('Generating new JWT with updated staff ID', { staffId });
    const newToken = generateToken(updatedPayload, '1h');

    return {
      token: newToken,
      staffId,
      message: 'Staff ID updated successfully',
    };
  }
}

module.exports = new StaffProfileService();