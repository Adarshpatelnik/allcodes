const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StaffRegistrationService {
  async addStaff(staffData) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const {
      STAFF_NAME,
      STAFF_INITIALS,
      PHONE_NUMBER,
      STAFF_ROLE,
      FATHER_HUSBAND_NAME,
      GENDER,
      EXPERIENCE,
      ADHAR_ID,
      RELIGION,
      EMAIL,
      EDUCATION,
      BLOOD_GROUP,
      DATE_OF_BIRTH,
      ADDRESS,
      CITY,
      STATE,
      POSTAL_CODE,
      MARITAL_STATUS,
    } = staffData;

    const values = [
      STAFF_NAME.toUpperCase(),
      STAFF_INITIALS.toUpperCase(),
      PHONE_NUMBER,
      STAFF_ROLE.toUpperCase(),
      FATHER_HUSBAND_NAME.toUpperCase(),
      GENDER.toUpperCase(),
      parseInt(EXPERIENCE, 10),
      ADHAR_ID,
      RELIGION ? RELIGION.toUpperCase() : 'UNKNOWN',
      EMAIL.toUpperCase(),
      EDUCATION.toUpperCase(),
      BLOOD_GROUP.toUpperCase(),
      DATE_OF_BIRTH,
      ADDRESS ? ADDRESS.toUpperCase() : null,
      CITY ? CITY.toUpperCase() : null,
      STATE ? STATE.toUpperCase() : null,
      POSTAL_CODE ? POSTAL_CODE : null,
      MARITAL_STATUS ? MARITAL_STATUS.toUpperCase() : null,
    ];

    const query = `
      INSERT INTO ACD_STAFF_REGISTRATION (
        STAFF_NAME, STAFF_INITIALS, PHONE_NUMBER, STAFF_ROLE,
        FATHER_HUSBAND_NAME, GENDER, EXPERIENCE, ADHAR_ID,
        RELIGION, EMAIL, EDUCATION, BLOOD_GROUP, DATE_OF_BIRTH,
        ADDRESS, CITY, STATE, POSTAL_CODE, MARITAL_STATUS
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    logger.info('Adding new staff', { STAFF_NAME, STAFF_ROLE, EMAIL });
    try {
      await schoolDbConnection.query(query, values);
      return { message: 'Staff added successfully' };
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        const errors = {};
        if (err.message.includes('UNQ_ADHAR_ID')) {
          errors.ADHAR_ID = 'Aadhaar ID already exists';
        }
        if (err.message.includes('UNQ_EMAIL')) {
          errors.EMAIL = 'Email already exists';
        }
        if (err.message.includes('UNQ_PHONE_NUMBER')) {
          errors.PHONE_NUMBER = 'Phone Number already exists';
        }
        throw { status: 400, message: 'Validation failed', details: errors };
      }
      throw err;
    }
  }
}

module.exports = new StaffRegistrationService();