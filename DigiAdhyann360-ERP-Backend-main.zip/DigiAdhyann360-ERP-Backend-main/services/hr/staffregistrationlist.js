const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StaffRegistrationService {
  async getAllStaffRegistrations() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
      
 SELECT *
      FROM ACD_STAFF_REGISTRATION
      where APPROVAL_STATUS in ('APPROVED','REJECTED')
      ORDER BY APPROVAL_STATUS
    `;

    logger.info('Fetching all staff registrations with all statuses');
    const [results] = await schoolDbConnection.query(query);
    return results;
  }
}

module.exports = new StaffRegistrationService();