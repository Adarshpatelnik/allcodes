const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

class StaffScheduleService {
  async deleteSchedule(period, className, section) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    logger.info('Deleting schedule', { period, className, section });
    const [result] = await schoolDbConnection.query(
      'DELETE FROM ACD_CLASS_SCHEDULE WHERE PERIOD = ? AND CLASS = ? AND SECTION = ?',
      [period, className, section]
    );

    if (result.affectedRows === 0) {
      throw new Error('No schedule found to delete');
    }

    return { message: 'Schedule deleted successfully' };
  }

  async upsertSchedule(data) {
    const { PERIOD, TIME_SLOT, CLASS, SECTION, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, DURATION } = data;
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const days = { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday };
    const queries = [];

    for (const [day, subject] of Object.entries(days)) {
      if (subject) {
        const upperDay = day.toUpperCase();
        const upperSubject = subject.toUpperCase();
        const dayId = { MONDAY: 1, TUESDAY: 2, WEDNESDAY: 3, THURSDAY: 4, FRIDAY: 5, SATURDAY: 6 }[upperDay];

        logger.info('Processing schedule for day', { day: upperDay, period: PERIOD, class: CLASS, section: SECTION });

        const [existingRecords] = await schoolDbConnection.query(
          'SELECT * FROM ACD_CLASS_SCHEDULE WHERE PERIOD = ? AND CLASS = ? AND SECTION = ? AND DAY = ?',
          [PERIOD, CLASS, SECTION, upperDay]
        );

        if (existingRecords.length > 0) {
          queries.push(
            schoolDbConnection.query(
              'UPDATE ACD_CLASS_SCHEDULE SET TIME_SLOT = ?, SUBJECT = ?, DURATION = ? WHERE PERIOD = ? AND CLASS = ? AND SECTION = ? AND DAY = ?',
              [TIME_SLOT, upperSubject, DURATION, PERIOD, CLASS, SECTION, upperDay]
            )
          );
        } else {
          queries.push(
            schoolDbConnection.query(
              'INSERT INTO ACD_CLASS_SCHEDULE (PERIOD, TIME_SLOT, DURATION, CLASS, SECTION, DAY, DAY_ID, SUBJECT) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
              [PERIOD, TIME_SLOT, DURATION, CLASS, SECTION, upperDay, dayId, upperSubject]
            )
          );
        }
      }
    }

    if (queries.length === 0) {
      throw new Error('No valid day subjects provided');
    }

    await Promise.all(queries);
    return { message: 'Schedule updated successfully' };
  }

  async getClassSections() {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    const query = `
      SELECT 
        CLASS, 
        GROUP_CONCAT(DISTINCT SECTION ORDER BY SECTION ASC) AS SECTION
      FROM ACD_CLASS_SCHEDULE
      GROUP BY CLASS
      ORDER BY 
        CASE 
          WHEN CLASS = 'LKG' THEN 0
          WHEN CLASS = 'UKG' THEN 1
          ELSE CAST(CLASS AS UNSIGNED) + 2
        END ASC
    `;

    logger.info('Fetching class and section data');
    const [results] = await schoolDbConnection.query(query);

    if (results.length === 0) {
      throw new Error('No class and section data found');
    }

    return results;
  }

  async getScheduleData(selectedClasses, selectedSections) {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established');
      throw new Error('School database connection not established');
    }

    let query = `
     SELECT
        PERIOD,
        TIME_SLOT,
        CLASS_ID,
        CLASS,
        SECTION,
        MAX(CASE WHEN DAY = 'MONDAY' THEN SUBJECT END) AS Monday,
        MAX(CASE WHEN DAY = 'TUESDAY' THEN SUBJECT END) AS Tuesday,
        MAX(CASE WHEN DAY = 'WEDNESDAY' THEN SUBJECT END) AS Wednesday,
        MAX(CASE WHEN DAY = 'THURSDAY' THEN SUBJECT END) AS Thursday,
        MAX(CASE WHEN DAY = 'FRIDAY' THEN SUBJECT END) AS Friday,
        MAX(CASE WHEN DAY = 'SATURDAY' THEN SUBJECT END) AS Saturday
      FROM ACD_CLASS_SCHEDULE sc
      WHERE 1=1
   `;

    const params = [];

    if (selectedClasses) {
      const classes = selectedClasses.split(',');
      query += ' AND sc.CLASS IN (?)';
      params.push(classes);
    }

    if (selectedSections) {
      const sections = selectedSections.split(',');
      query += ' AND sc.SECTION IN (?)';
      params.push(sections);
    }

    query += `
      GROUP BY sc.PERIOD, sc.TIME_SLOT, sc.CLASS, sc.SECTION
      ORDER BY sc.PERIOD
    `;

    logger.info('Fetching schedule data', { classes: selectedClasses, sections: selectedSections });
    const [results] = await schoolDbConnection.query(query, params);

    if (results.length === 0) {
      throw new Error('No schedule data found for the selected classes and sections');
    }

    return results;
  }
}

module.exports = new StaffScheduleService();