
const bcrypt = require('bcryptjs');
const { pool, connectToSchoolDatabase } = require('../../config/db');
const { generateToken } = require('../../config/auth');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const { setRoleContext } = require('../../config/rbac');
const logger = require('../../logger/logger');

// --------------------- Login for Users ---------------------
const loginUser = async ({ UserName, Password }) => {
  logger.info('Service: Login function called', { UserName, Password: '[HIDDEN]' });

  if (!UserName || !Password) {
    logger.warn('Missing UserName or Password', { UserName });
    throw new Error('Username and Password are required');
  }

  try {
    logger.info('Testing database connection');
    await pool.query('SELECT 1');

    logger.info('Executing query for user', { UserName });
    const loginQuery = `
      SELECT U.*, R.ROLE_NAME, S.SERVICE_NAME
      FROM USERS U
      JOIN ROLES R ON U.ROLE_ID = R.ROLE_ID
      JOIN ROLE_SERVICES RS ON R.ROLE_ID = RS.ROLE_ID
      JOIN SERVICES S ON RS.SERVICE_ID = S.SERVICE_ID
      JOIN TENANT_SERVICES TS ON S.SERVICE_ID = TS.SERVICE_ID
      WHERE (U.USERNAME = ? OR U.EMAIL = ?)
      AND TS.TENANT_ID = U.TENANT_ID
    `;
    const [result] = await pool.query(loginQuery, [UserName, UserName]);

    const sanitizedResult = result.map(row => ({
      ROW_ID: row.ROW_ID,
      TENANT_ID: row.TENANT_ID,
      FULL_NAME: row.FULL_NAME,
      USER_ID: row.USER_ID,
      USERNAME: row.USERNAME,
      ROLE_ID: row.ROLE_ID,
      CONTACT_NUMBER: row.CONTACT_NUMBER,
      EMAIL: row.EMAIL,
      CREATED_AT: row.CREATED_AT,
      ROLE_NAME: row.ROLE_NAME,
      SERVICE_NAME: row.SERVICE_NAME
    }));
    logger.info('Query result', { resultLength: result.length, result: sanitizedResult });

    if (result.length === 0) {
      logger.warn('Login failed: User not found', { UserName });
      throw new Error('Username or Email not registered');
    }

    const servicesArray = result.map(row => row.SERVICE_NAME);
    const user = result[0];
    logger.info('User found', { userId: user.USER_ID, role: user.ROLE_NAME });

    logger.info('Verifying password');
    const isPasswordValid = await bcrypt.compare(Password, user.PASSWORD);
    if (!isPasswordValid) {
      logger.warn('Login failed: Invalid Password', { UserName });
      throw new Error('Invalid Password');
    }

    logger.info('Fetching school database credentials', { tenantId: user.TENANT_ID });
    const [schoolResult] = await pool.query(
      'SELECT * FROM SCHOOL_DB_CREDENTIALS WHERE TENANT_ID = ?',
      [user.TENANT_ID]
    );
    logger.info('School query result', { schoolResultLength: schoolResult.length });

    if (schoolResult.length === 0) {
      logger.warn('School database not found for tenant', { tenantId: user.TENANT_ID });
      throw new Error('School database not found');
    }

    const schoolDbCredential = schoolResult[0];
    logger.info('School database credentials fetched', { dbName: schoolDbCredential.DATABASE_NAME });

    logger.info('Connecting to school database', { dbName: schoolDbCredential.DATABASE_NAME });
    const schoolDbConnection = await connectToSchoolDatabase(schoolDbCredential);
    logger.info('Connected to school database', { dbName: schoolDbCredential.DATABASE_NAME });

    const { current_admin, current_staff, current_student } = setRoleContext(asyncLocalStorage, user);

    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('AsyncLocalStorage store unavailable in login');
      throw new Error('Internal server error: AsyncLocalStorage unavailable');
    }
    store.set('schoolDbConnection', schoolDbConnection);

    // ✅ Fetch UDISE_CODE from school DB
    let UDISE_CODE = null;
    try {
      const [udiseResult] = await schoolDbConnection.query(
        'SELECT UDISE_CODE FROM ACD_SCHOOL_PROFILE LIMIT 1'
      );
      UDISE_CODE = udiseResult.length > 0 ? udiseResult[0].UDISE_CODE : null;
    } catch (udiseErr) {
      logger.error('Failed to fetch UDISE_CODE', { error: udiseErr.message });
    }

    const payload = {
      userId: user.USER_ID,
      userName: user.USERNAME,
      tenantId: user.TENANT_ID,
      role: user.ROLE_NAME,
      roleAllowed: user.ROLE_NAME,
      current_admin,
      current_staff,
      current_student,
      servicesAllowed: servicesArray,
      schoolDbName: schoolDbCredential.DATABASE_NAME,
    };

    logger.info('Generating token');
    const token = generateToken(payload, '1h');
    logger.info('User authenticated successfully', { userName: user.USERNAME, tenantId: user.TENANT_ID });

    return {
      token,
      role: user.ROLE_NAME,
      userId: user.USER_ID,
      UDISE_CODE,
      message: 'Login successful',
    };
  } catch (err) {
    logger.error('Error during login', { error: err.message, stack: err.stack, UserName });
    if (err.code === 'ER_BAD_FIELD_ERROR') {
      throw new Error('Database query error: Invalid column in query');
    }
    if (err.code === 'ENOTFOUND') {
      throw new Error('Database connection failed: Unable to reach the database server');
    }
    if (err.code === 'ER_ACCESS_DENIED_ERROR') {
      throw new Error('Database access denied: Invalid credentials');
    }
    throw err;
  }
};

// --------------------- Developer Login ---------------------
const developerLogin = async ({ school }) => {
  logger.info('Service: Developer login function called', { school });

  try {
    const sql = 'SELECT * FROM SCHOOL_DB_CREDENTIALS WHERE DATABASE_NAME = ?';
    const [schoolResults] = await pool.query(sql, [school]);

    if (schoolResults.length === 0) {
      logger.warn('School database credentials not found', { school });
      throw new Error('School database credentials not found');
    }

    const schoolDbCredential = schoolResults[0];
    const schoolDbConnection = await connectToSchoolDatabase(schoolDbCredential);
    logger.info('Connected to the school database successfully for developer', {
      dbName: schoolDbCredential.DATABASE_NAME,
    });

    return {
      message: 'Developer login successful',
    };
  } catch (err) {
    logger.error('Error during developer login process', { error: err.message, stack: err.stack });
    throw err;
  }
};

// --------------------- Exports ---------------------
module.exports = { loginUser, developerLogin };
