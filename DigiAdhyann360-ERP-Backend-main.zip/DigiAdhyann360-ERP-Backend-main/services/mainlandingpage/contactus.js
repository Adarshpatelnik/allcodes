const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const createContact = async ({ fullName, email, phoneNumber, schoolName, schoolAddress }) => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    // Basic validation
    if (![fullName, email, phoneNumber, schoolName, schoolAddress].every(Boolean)) {
      throw new Error("All fields are required");
    }

    const query = `
      INSERT INTO CONTACT_SUBMISSIONS (
        FULL_NAME, EMAIL, PHONE_NUMBER, SCHOOL_NAME, SCHOOL_ADDRESS
      ) VALUES (?, ?, ?, ?, ?)
    `;

    logger.info('Service: Executing query', { query, values: { fullName, email, phoneNumber, schoolName, schoolAddress } });

    const [result] = await schoolDbConnection.query(query, [
      fullName,
      email,
      phoneNumber,
      schoolName,
      schoolAddress,
    ]);

    logger.info("Service: Contact created successfully", { insertId: result.insertId });

    return {
      id: result.insertId,
      fullName,
      email,
      phoneNumber,
      schoolName,
      schoolAddress,
    };
  } catch (error) {
    logger.error("Service: Error creating contact", { error: error.message, stack: error.stack });
    throw new Error("Failed to create contact");
  }
};

module.exports = {
  createContact,
};