const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getStaffNotification = async () => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.error("Service: School Database connection not established!");
      throw new Error("School Database connection not established");
    }

    const query = `
      SELECT COUNT(STAFF_ID) AS STAFF_COUNT
      FROM ACD_STAFF_ATTENDANCE_NOTIFICATIONS
      WHERE STATUS = 'PENDING'
    `;
    const [results] = await schoolDbConnection.query(query);

    const count = results[0]?.STAFF_COUNT || 0;
    return { message: `Attendance marked for staff attendance: ${count}`, count };
  } catch (error) {
    console.error("Service: Error fetching notifications:", error);
    throw new Error("Failed to fetch notifications");
  }
};

const getLeaveRequests = async () => {
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.error("Service: School Database connection not established!");
      throw new Error("School Database connection not established");
    }

    const query = `
      SELECT COUNT(*) AS PENDING_COUNT
      FROM ACD_LEAVE_NOTIFICATION
      WHERE STATUS = 'PENDING'
    `;
    const [results] = await schoolDbConnection.query(query);
    const pendingCount = results[0]?.PENDING_COUNT || 0;

    return { message: `Pending leave requests: ${pendingCount}`, count: pendingCount };
  } catch (error) {
    console.error("Service: Error fetching leave requests:", error);
    throw new Error("Failed to fetch leave requests");
  }
};

const getParentRaiseIssueCount = async () => {
  console.log("Service: getParentRaiseIssueCount");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      SELECT COUNT(*) AS ISSUE_COUNT
      FROM ACD_STUDENT_ISSUE_TRACKING
      WHERE STATUS = 'PENDING'
    `;
    console.log("Service: Executing leave query:", query);

    const [results] = await schoolDbConnection.query(query);
    console.log(`Service: Data fetched successfully. Found ${results.length} records.`);
    return results;
  } catch (error) {
    console.error("Service: Error fetching leave data:", error);
    throw error;
  }
};

const getStudentEditRequestCount = async () => {
  console.error("Service: studenteditrequestcount call");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      SELECT COUNT(*) FROM ACD_PROFILE_CHANGE_REQUEST WHERE STATUS = 'Pending';
    `;

    console.log('Service: Query results:');
    const [results] = await schoolDbConnection.query(query);
    return results;
  } catch (error) {
    console.error('Service: Error fetching student edit request:', error);
    throw new Error('Server error');
  }
};

module.exports = {
  getStaffNotification,
  getLeaveRequests,
  getParentRaiseIssueCount,
  getStudentEditRequestCount,
};