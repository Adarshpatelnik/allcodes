const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getRaiseIssueList = async () => {
  console.log("Service: getRaiseIssueList");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      SELECT ri.STUDENT_ID, ri.STUDENT_NAME, cd.CLASS, ri.PARENT_ID, ri.CONTACT, ri.ISSUE_TYPE, ri.DESCRIPTION, ri.STATUS, ri.ISSUE_DATE 
      FROM CLASS_DETAIL cd
      INNER JOIN RAISE_ISSUE ri ON cd.STUDENT_ID = ri.STUDENT_ID 
      GROUP BY  
        ri.STUDENT_ID,
        ri.STUDENT_NAME,
        cd.CLASS,
        ri.PARENT_ID,
        ri.CONTACT,
        ri.ISSUE_TYPE,
        ri.DESCRIPTION,
        ri.STATUS,
        ri.ISSUE_DATE;
    `;

    console.log("Executing query:", query);
    const [results] = await schoolDbConnection.query(query);
    console.log(`Service: Data fetched successfully. Found ${results.length} records.`);
    return results;
  } catch (error) {
    console.error("Service: Error fetching raise issue data:", error);
    throw error;
  }
};

const updateRaiseIssueStatus = async (student_id, status) => {
  console.log("Service: updateRaiseIssueStatus");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      UPDATE RAISE_ISSUE SET STATUS = ? WHERE STUDENT_ID = ?
    `;

    const [result] = await schoolDbConnection.query(query, [status, student_id]);
    console.log(`Service: Updated student_id ${student_id} with status ${status}`);
    return result;
  } catch (error) {
    console.error("Service: Error updating issue status:", error);
    throw error;
  }
};

module.exports = {
  getRaiseIssueList,
  updateRaiseIssueStatus,
};