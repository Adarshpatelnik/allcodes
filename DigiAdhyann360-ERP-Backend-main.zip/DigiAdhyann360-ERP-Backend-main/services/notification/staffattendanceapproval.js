const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getStaffAttendanceApproval = async () => {
  console.log("Service: getStaffAttendanceApproval");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      SELECT STAFF_ID, STAFF_NAME, STATUS, ATTENDANCE_DATE  
      FROM ACD_STAFF_ATTENDANCE_NOTIFICATIONS
    `;

    console.log("Executing attendance query:", query);
    const [results] = await schoolDbConnection.query(query);
    console.log(`Service: Data fetched successfully. Found ${results.length} records.`);
    return results;
  } catch (error) {
    console.error("Service: Error fetching attendance data:", error);
    throw error;
  }
};

const getStaffLeaveApproval = async () => {
  console.log("Service: getStaffLeaveApproval");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error("Unauthorized or missing context");
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      SELECT 
        s.STAFF_NAME,
        s.STAFF_ROLE,
        s.STAFF_ID, 
        la.LEAVE_TYPE, 
        la.START_DATE, 
        la.END_DATE, 
        la.REASON, 
        la.CONTACT_NUMBER, 
        la.STATUS 
      FROM ACD_STAFF_PROFILE s  
      INNER JOIN ACD_LEAVE_APPLICATION la 
        ON la.STAFF_ID = s.STAFF_ID;
    `;

    console.log("Executing leave query...");
    const [results] = await schoolDbConnection.query(query);
    console.log(`Service: Leave data fetched successfully. Found ${results.length} records.`);
    return results;
  } catch (error) {
    console.error("Service: Error fetching leave data:", error);
    throw error;
  }
};

const updateStaffAttendanceApproval = async (staff_id, status) => {
  console.log("Service: updateStaffAttendanceApproval");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      UPDATE ACD_STAFF_ATTENDANCE_NOTIFICATIONS
      SET STATUS = ?
      WHERE STAFF_ID = ?
    `;

    const [result] = await schoolDbConnection.query(query, [status, staff_id]);
    console.log(`Service: Updated staff ID ${staff_id} with status ${status}`);
    return result;
  } catch (error) {
    console.error("Service: Error updating attendance status:", error);
    throw error;
  }
};

const updateStaffLeaveApproval = async (staff_id, status) => {
  console.log("Service: updateStaffLeaveApproval");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    if (!['APPROVED', 'REJECTED'].includes(status)) {
      console.log("Service: Invalid status provided.");
      throw new Error('Valid status (APPROVED or REJECTED) is required');
    }

    const query1 = `UPDATE ACD_LEAVE_NOTIFICATION SET STATUS = ? WHERE STAFF_ID = ?`;
    const query2 = `UPDATE ACD_LEAVE_APPLICATION SET STATUS = ? WHERE STAFF_ID = ?`;

    console.log('Executing queries:', query1, query2, [status, staff_id]);

    const [updateResult1] = await schoolDbConnection.query(query1, [status, staff_id]);
    const [updateResult2] = await schoolDbConnection.query(query2, [status, staff_id]);

    if (updateResult1.affectedRows === 0 && updateResult2.affectedRows === 0) {
      console.log("Service: No record found for given STAFF_ID.");
      throw new Error('No leave request found for the given staff ID');
    }

    console.log("Service: Leave status updated successfully in both tables.");
    return { success: true, message: `Leave status updated to ${status.toLowerCase()} successfully in both tables.` };
  } catch (error) {
    console.error("Service: Error updating leave status:", error);
    throw error;
  }
};

module.exports = {
  getStaffAttendanceApproval,
  getStaffLeaveApproval,
  updateStaffAttendanceApproval,
  updateStaffLeaveApproval,
};  