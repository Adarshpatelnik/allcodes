const asyncLocalStorage = require('../../middleware/authmiddleware').asyncLocalStorage;

const getStudentData = async () => {
  console.log("Service: getStudentData");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const current_student = store.get('current_student');
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    const query = `
      SELECT 
        REQUEST_ID,
        REQUESTER_ID,
        REQUESTER_TYPE,
        FIRST_NAME,
        TYPE,
        OLDDATA,
        NEWDATA,
        STATUS,
        ISSUE
      FROM ACD_PROFILE_CHANGE_REQUEST
      WHERE STATUS = 'Pending'
    `;

    const [rows] = await schoolDbConnection.query(query);
    return rows;
  } catch (error) {
    console.error('Service: Error fetching student data:', error);
    throw error;
  }
};

const updateStatus = async (REQUEST_ID, STATUS) => {
  console.log("Service: updateStatus");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const current_student = store.get('current_student');
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    if (STATUS !== 'Approved' && STATUS !== 'Rejected') {
      console.log('Service: Invalid status received:', STATUS);
      throw new Error('Invalid status');
    }

    const query = `
      UPDATE ACD_PROFILE_CHANGE_REQUEST 
      SET STATUS = ? 
      WHERE REQUEST_ID = ?;
    `;

    console.log('Service: Executing query:', query, 'with STATUS:', STATUS, 'and REQUEST_ID:', REQUEST_ID);
    const [result] = await schoolDbConnection.query(query, [STATUS, REQUEST_ID]);

    console.log('Service: Query result:', result);
    return result;
  } catch (error) {
    console.error('Service: Error updating status:', error);
    throw error;
  }
};

const updateStudentProfile = async (REQUESTER_ID) => {
  console.log("Service: updateStudentProfile");
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }
    const current_student = store.get('current_student');
    const schoolDbConnection = store.get('schoolDbConnection');

    if (!schoolDbConnection) {
      console.log("Service: School database connection not established.");
      throw new Error("School database connection not established");
    }

    if (!REQUESTER_ID) {
      throw new Error('REQUESTER_ID is required');
    }

    console.log('Service: Received REQUESTER_ID:', REQUESTER_ID);

    const query = `
      UPDATE ACD_STUDENT_PROFILE sp
      LEFT JOIN (
        SELECT 
          REQUESTER_ID, 
          MAX(CASE WHEN TYPE = 'CONTACT_NUMBER' THEN NEWDATA END) AS CONTACT_NUMBER,
          MAX(CASE WHEN TYPE = 'CITY' THEN NEWDATA END) AS CITY,
          MAX(CASE WHEN TYPE = 'EMAIL' THEN NEWDATA END) AS EMAIL,
          MAX(CASE WHEN TYPE = 'EMERGENCY_CONTACT_NUMBER' THEN NEWDATA END) AS EMERGENCY_CONTACT_NUMBER,
          MAX(CASE WHEN TYPE = 'POSTAL_CODE' THEN NEWDATA END) AS POSTAL_CODE
        FROM ACD_PROFILE_CHANGE_REQUEST 
        WHERE REQUESTER_ID = ?
        GROUP BY REQUESTER_ID
      ) AS req ON req.REQUESTER_ID = sp.STUDENT_ID
      SET 
        sp.CONTACT_NUMBER = req.CONTACT_NUMBER,
        sp.CITY = req.CITY,
        sp.EMAIL = req.EMAIL,
        sp.EMERGENCY_CONTACT_NUMBER = req.EMERGENCY_CONTACT_NUMBER,
        sp.POSTAL_CODE = req.POSTAL_CODE
      WHERE sp.STUDENT_ID = ?;
    `;

    const [result] = await schoolDbConnection.query(query, [REQUESTER_ID, REQUESTER_ID]);
    return result;
  } catch (error) {
    console.error('Service: Error updating student profile:', error);
    throw error;
  }
};

module.exports = {
  getStudentData,
  updateStatus,
  updateStudentProfile,
};