//--------------------- Payment gateway integrations  ------------------------------------ //

const Razorpay = require('razorpay');
const crypto = require('crypto');

const razorpayInstance = new Razorpay({CL
  key_id: process.env.RAZORPAY_KEY,
  key_secret: process.env.RAZORPAY_SECRET,
});

const verifyPayment = (orderId, paymentId, signature) => {
  const generatedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_SECRET)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
  return generatedSignature === signature;
};

module.exports = { razorpayInstance, verifyPayment };