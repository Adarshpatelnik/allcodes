const Razorpay = require('razorpay');
const crypto = require('crypto');
const { pool } = require('../../config/db');
require('dotenv').config();

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;
if (!ENCRYPTION_KEY) {
  throw new Error("Encryption key is missing in environment variables");
}

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_SECRET,
});

// Function to decrypt payload using AES-ECB
const decryptPayload = (encryptedText) => {
  try {
    const decipher = crypto.createDecipheriv('aes-256-ecb', ENCRYPTION_KEY, null);
    let decrypted = decipher.update(encryptedText, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
  } catch (error) {
    console.error('Backend: Error decrypting payload:', error.message);
    throw new Error('Failed to decrypt payload');
  }
};

// Validate coupon code
const validateCoupon = async (couponCode, serviceIds) => {
  try {
    console.log('Services: Validating coupon code:', couponCode);
    const query = `
      SELECT COUPON_ID, COUPON_CODE, DESCRIPTION, VALID_FROM, VALID_TILL, DISCOUNT_VALUE, DISCOUNT_TYPE, MAX_USAGE 
      FROM COUPONS 
      WHERE COUPON_CODE = ? 
      AND VALID_FROM <= CURRENT_DATE 
      AND VALID_TILL >= CURRENT_DATE
    `;
    const [results] = await pool.query(query, [couponCode]);

    if (!results || results.length === 0) {
      console.log('Services: Coupon code not found or expired');
      throw new Error(`Coupon code ${couponCode} is invalid or expired. Please try another code.`);
    }

    const coupon = results[0];
    const usageQuery = `
      SELECT COUNT(*) as usage_count 
      FROM COUPON_USAGE 
      WHERE COUPON_ID = ?
    `;
    const [usageResult] = await pool.query(usageQuery, [coupon.COUPON_ID]);
    const usageCount = usageResult[0].usage_count;

    if (usageCount >= coupon.MAX_USAGE) {
      console.log('Services: Coupon usage limit exceeded');
      throw new Error(`Coupon code ${couponCode} has reached its maximum usage limit.`);
    }

    console.log('Services: Coupon validated successfully:', coupon);
    return {
      couponId: coupon.COUPON_ID,
      couponCode: coupon.COUPON_CODE,
      description: coupon.DESCRIPTION,
      validFrom: coupon.VALID_FROM,
      validTill: coupon.VALID_TILL,
      discountValue: coupon.DISCOUNT_VALUE,
      discountType: coupon.DISCOUNT_TYPE,
      maxUsage: coupon.MAX_USAGE,
      remainingUsage: coupon.MAX_USAGE - usageCount,
    };
  } catch (error) {
    console.error('Services: Error validating coupon:', error.message);
    throw error;
  }
};

// Apply coupon and insert into COUPON_USAGE
const applyCoupon = async (couponCode, tenantId, serviceIds, udiseCode) => {
  try {
    console.log('Services: Applying coupon:', couponCode, 'for tenant:', tenantId, 'UDISE_CODE:', udiseCode);
    const coupon = await validateCoupon(couponCode, serviceIds);

    // Fetch email for the tenant
    const tenantQuery = `
      SELECT s.TENANT_ID, s.UDISE_CODE, u.EMAIL 
      FROM SCHOOLS_TENANT s
      JOIN USERS u ON s.TENANT_ID = u.TENANT_ID 
      WHERE s.UDISE_CODE = ?
      ORDER BY s.TENANT_ID DESC LIMIT 1
    `;
    const [tenantResult] = await pool.query(tenantQuery, [udiseCode]);
    if (!tenantResult || tenantResult.length === 0) {
      console.log('Services: No tenant found for UDISE_CODE:', udiseCode);
      throw new Error(`No tenant found for UDISE_CODE: ${udiseCode}`);
    }
    const email = tenantResult[0].EMAIL;

    const usageQuery = `
      INSERT INTO COUPON_USAGE (COUPON_ID, TENANT_ID, EMAIL, USED_ON)
      VALUES (?, ?, ?, NOW())
    `;
    await pool.query(usageQuery, [coupon.couponId, tenantId, email]);
    console.log('Services: Coupon usage recorded for TENANT_ID:', tenantId, 'EMAIL:', email);

    return coupon;
  } catch (error) {
    console.error('Services: Error applying coupon:', error.message);
    throw error;
  }
};

// Create Razorpay order
const createRazorpayOrder = async (Payload) => {
  try {
    // Decrypt the payload
    const payload = decryptPayload(Payload);
    const { amount, selectedServices, udiseCode, couponCode } = payload;
    console.log('Backend: Creating Razorpay order for UDISE_CODE:', udiseCode);

    // Fetch tenant details
    const tenantQuery = `
      SELECT s.TENANT_ID, s.UDISE_CODE, u.EMAIL 
      FROM SCHOOLS_TENANT s
      JOIN USERS u ON s.TENANT_ID = u.TENANT_ID 
      WHERE s.UDISE_CODE = ?
      ORDER BY s.TENANT_ID DESC LIMIT 1
    `;
    const [tenantResult] = await pool.query(tenantQuery, [udiseCode]);
    if (!tenantResult || tenantResult.length === 0) {
      throw new Error(`No tenant found for UDISE_CODE: ${udiseCode}`);
    }
    const tenantId = tenantResult[0].TENANT_ID;

    // Fetch service prices to verify amount
    const serviceQuery = `
      SELECT SERVICE_ID, Price 
      FROM SERVICES 
      WHERE SERVICE_ID IN (?)
    `;
    const [serviceResults] = await pool.query(serviceQuery, [selectedServices]);
    if (!serviceResults || serviceResults.length === 0) {
      throw new Error('No services found for the provided SERVICE_IDs');
    }

    const totalPrice = serviceResults.reduce((sum, service) => sum + Number(service.Price), 0);
    let finalAmount = totalPrice;

    let couponApplied = false;
    let discountValue = 0;
    let discountType = null;

    if (couponCode) {
      const coupon = await applyCoupon(couponCode, tenantId, selectedServices, udiseCode);
      discountValue = coupon.discountValue;
      discountType = coupon.discountType;
      finalAmount = discountType === 'PERCENT'
        ? totalPrice * (1 - discountValue / 100)
        : Math.max(0, totalPrice - discountValue);
      couponApplied = true;
    }

    // Verify the amount sent from frontend
    if (Math.round(finalAmount * 100) !== amount) {
      throw new Error('Amount mismatch between frontend and backend calculations');
    }

    const options = {
      amount: amount, // In paise
      currency: 'INR',
      receipt: `order_rcptid_${udiseCode}_${Date.now()}`,
      notes: {
        selectedServices: JSON.stringify(selectedServices),
        tenantId,
        couponCode: couponCode || null,
      },
    };

    const order = await razorpay.orders.create(options);
    console.log('Backend: Razorpay order created:', order);
    return {
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      receipt: order.receipt,
      couponApplied,
      discountValue,
      discountType,
    };
  } catch (error) {
    console.error('Backend: Error creating Razorpay order:', error);
    throw error;
  }
};

// Verify Razorpay payment signature
const verifyPaymentSignature = (Payload) => {
  try {
    // Decrypt the payload
    const payload = decryptPayload(Payload);
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = payload;

    const generatedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    const isValid = generatedSignature === razorpay_signature;
    console.log('Backend: Payment signature verification:', isValid);
    return { isValid, decryptedPayload: payload };
  } catch (error) {
    console.error('Backend: Error verifying Razorpay signature:', error);
    throw new Error('Signature verification failed');
  }
};

// Save payment details to PAYMENT_SERVICE_DETAILS
const savePaymentDetails = async (Payload) => {
  try {
    // Decrypt the payload
    const payload = decryptPayload(Payload);
    const { razorpay_payment_id, udiseCode, selectedServices, couponCode, discountValue, discountType } = payload;
    console.log('Backend: Saving payment details for paymentId:', razorpay_payment_id, 'UDISE_CODE:', udiseCode);

    const payment = await razorpay.payments.fetch(razorpay_payment_id);

    if (!payment || payment.status !== 'captured') {
      console.log('Backend: Payment not captured or invalid:', payment?.status);
      throw new Error('Payment not captured or invalid');
    }

    // Check for existing payment record
    const checkQuery = `
      SELECT PAYMENT_ID 
      FROM PAYMENT_SERVICE_DETAILS 
      WHERE PAYMENT_ID = ?
    `;
    const [existingPayment] = await pool.query(checkQuery, [razorpay_payment_id]);
    if (existingPayment.length > 0) {
      console.log('Backend: Payment already exists for PAYMENT_ID:', razorpay_payment_id);
      return { success: true, data: payment, tenantId: existingPayment[0].TENANT_ID, message: 'Payment already recorded' };
    }

    // Fetch TENANT_ID
    const tenantQuery = `
      SELECT s.TENANT_ID, s.UDISE_CODE, u.EMAIL 
      FROM SCHOOLS_TENANT s
      JOIN USERS u ON s.TENANT_ID = u.TENANT_ID 
      WHERE s.UDISE_CODE = ?
      ORDER BY s.TENANT_ID DESC LIMIT 1
    `;
    const [tenantResult] = await pool.query(tenantQuery, [udiseCode]);
    if (!tenantResult || tenantResult.length === 0) {
      throw new Error(`No tenant found for UDISE_CODE: ${udiseCode}`);
    }
    const tenantId = tenantResult[0].TENANT_ID;

    // Insert into PAYMENT_SERVICE_DETAILS
    const insertQuery = `
      INSERT INTO PAYMENT_SERVICE_DETAILS (
        PAYMENT_ID, ORDER_ID, INVOICE_ID, TENANT_ID, STATUS, AMOUNT, 
        ACCOUNT_ID, PAYMENT_METHOD, CUSTOMER_EMAIL, CUSTOMER_CONTACT, 
        RAZORPAY_FEE, GST, TOTAL_FEE, FEE_BEARER, NOTES, UDISE_CODE, 
        SELECTED_SERVICES, APP_NAME, APP_ID, DESCRIPTION, TRANSFER, 
        REFUND_STATUS, PAYMENT_STATUS, BANK_RRN, CREATED_ON, CREATED_AT
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [
      payment.id || null,
      payment.order_id || null,
      payment.invoice_id || null,
      tenantId,
      payment.status || 'unknown',
      payment.amount ? payment.amount / 100 : 0, // Convert paise to rupees
      payment.acquirer_data?.account_id || null,
      payment.method ? `${payment.method}${payment.bank ? ` (${payment.bank})` : ''}` : null,
      payment.email || null,
      payment.contact || null,
      (payment.fee || 0) / 100,
      payment.tax || 0,
      ((payment.fee || 0) + (payment.tax || 0)) / 100,
      payment.fee_bearer || 'platform',
      JSON.stringify(payment.notes || {}),
      udiseCode || null,
      JSON.stringify(selectedServices || []),
      payment.app_name || '--',
      payment.app_id || '--',
      payment.description || 'Payment for selected ERP services',
      JSON.stringify(payment.transfers || []),
      payment.refund_status || 'No refund issued',
      payment.status || 'unknown',
      payment.acquirer_data?.bank_transaction_id || null,
      new Date(payment.created_at * 1000).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
      new Date(payment.created_at * 1000),
    ];

    await pool.query(insertQuery, values);
    console.log('Backend: Payment details saved to PAYMENT_SERVICE_DETAILS');

    return { success: true, data: payment, tenantId };
  } catch (error) {
    console.error('Backend: Error saving payment details:', error.message);
    throw error;
  }
};

module.exports = {
  createRazorpayOrder,
  verifyPaymentSignature,
  savePaymentDetails,
  validateCoupon,
  applyCoupon,
};