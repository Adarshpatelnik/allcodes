const { pool, connectToSchoolDatabase } = require('../../config/db');
const crypto = require('crypto');

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;

if (!ENCRYPTION_KEY) {
  throw new Error("Encryption key is missing in environment variables");
}

// Function to decrypt payload using AES-ECB
const decryptPayload = (encryptedText) => {
  try {
    const decipher = crypto.createDecipheriv('aes-256-ecb', ENCRYPTION_KEY, null);
    let decrypted = decipher.update(encryptedText, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
  } catch (error) {
    console.error('Backend: Error decrypting payload:', error.message);
    throw new Error('Failed to decrypt payload');
  }
};

// Fetch services
const getServices = async () => {
  try {
    console.log('Services: Executing query to fetch services data');
    const query = `SELECT SERVICE_ID, SERVICE_NAME, Price FROM SERVICES`;
    const [results] = await pool.query(query);
    if (!results || results.length === 0) {
      console.log('Services: No services data found in the database');
      throw new Error('No services data found');
    }
    console.log('Services: Successfully fetched services data', results);
    return results;
  } catch (error) {
    console.error('Services: Error fetching services data:', error);
    throw new Error('Failed to fetch services data');
  }
};

// Add tenant service
const addTenantService = async (Payload) => {
  try {
    // Decrypt the payload
    const payload = decryptPayload(Payload);
    const {
      serviceId,
      udiseCode,
      schoolName,
      schoolBranch,
      city,
      state,
      postalCode,
      phoneNumber,
      email,
    } = payload;
    console.log('Services: Adding tenant service:', { serviceId, udiseCode });

    const tenantQuery = `
      SELECT st.TENANT_ID, st.SCHOOL_NAME, st.SCHOOL_BRANCH, st.UDISE_CODE, st.CITY, st.STATE, st.POSTAL_CODE, st.CONTACT_NUMBER, u.EMAIL 
      FROM SCHOOLS_TENANT st 
      JOIN USERS u ON st.TENANT_ID = u.TENANT_ID 
      WHERE UDISE_CODE = ?
      LIMIT 1
    `;
    const [tenantResult] = await pool.query(tenantQuery, [udiseCode]);
    if (!tenantResult || tenantResult.length === 0) {
      throw new Error(`No tenant found for UDISE_CODE: ${udiseCode}`);
    }

    const tenantData = tenantResult[0];
    const tenantId = tenantData.TENANT_ID;

    const tenantServiceQuery = `
      INSERT INTO TENANT_SERVICES (TENANT_ID, SERVICE_ID)
      VALUES (?, ?)
    `;
    await pool.query(tenantServiceQuery, [tenantId, serviceId]);
    console.log('Services: Tenant service inserted successfully for TENANT_ID:', tenantId);

    const dbQuery = `
      SELECT DATABASE_NAME, DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_HOST 
      FROM SCHOOL_DB_CREDENTIALS 
      WHERE TENANT_ID = ?
    `;
    const [dbResult] = await pool.query(dbQuery, [tenantId]);
    if (!dbResult || dbResult.length === 0) {
      throw new Error('Database credentials not found for this tenant');
    }

    const dbDetails = dbResult[0];
    const dbConnection = await connectToSchoolDatabase(dbDetails);
    if (!dbConnection) {
      throw new Error('Failed to establish school database connection');
    }

    const schoolProfileQuery = `
      INSERT INTO ACD_SCHOOL_PROFILE 
      ( SCHOOL_NAME, SCHOOL_BRANCH, UDISE_CODE, CITY, STATE, POSTAL_CODE, PHONE_NUMBER, EMAIL) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const emailToInsert = email || tenantData.EMAIL;
    if (!emailToInsert) {
      throw new Error(`Email not found for UDISE_CODE: ${udiseCode}`);
    }

    const schoolProfileValues = [
      (schoolName || tenantData.SCHOOL_NAME).toUpperCase(),
      (schoolBranch || tenantData.SCHOOL_BRANCH).toUpperCase(),
      udiseCode || tenantData.UDISE_CODE,
      (city || tenantData.CITY).toUpperCase(),
      (state || tenantData.STATE).toUpperCase(),
      postalCode || tenantData.POSTAL_CODE,
      phoneNumber || tenantData.CONTACT_NUMBER,
      emailToInsert,
    ];

    console.log('Services: Inserting into ACD_SCHOOL_PROFILE with values:', schoolProfileValues);
    const [insertResult] = await dbConnection.query(schoolProfileQuery, schoolProfileValues);
    if (insertResult.affectedRows === 0) {
      console.error('Services: No rows affected - ACD_SCHOOL_PROFILE insert failed silently!');
      throw new Error('Failed to insert school profile');
    }

    console.log('Services: School profile inserted successfully.');
    return {
      message: 'Tenant service and school profile added successfully',
      tenantId,
      serviceId,
    };
  } catch (error) {
    console.error('Services: Error adding tenant service:', error.message);
    throw error;
  }
};

module.exports = {
  getServices,
  addTenantService,
};