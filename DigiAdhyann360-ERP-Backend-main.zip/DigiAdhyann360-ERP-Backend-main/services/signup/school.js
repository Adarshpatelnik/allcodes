const { pool } = require('../../config/db');
const logger = require('../../logger/logger');

const getLatestSchool = async () => {
  logger.info('Service: getLatestSchool');
  try {
    const query = `
      SELECT UDISE_CODE, SCHOOL_NAME, TENANT_ID 
      FROM SCHOOLS_TENANT 
      ORDER BY TENANT_ID DESC 
      LIMIT 1
    `;
    const [rows] = await pool.query(query);

    if (rows.length === 0) {
      logger.info('Service: No school found');
      throw new Error('No school data found');
    }

    logger.info('Service: Fetched latest school:', { school: rows[0] });
    return rows[0];
  } catch (error) {
    logger.error('Service: Error fetching latest school:', { error: error.message });
    throw error;
  }
};

module.exports = { getLatestSchool };
