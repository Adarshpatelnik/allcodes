const bcrypt = require('bcryptjs');
const { pool, createNewDbPool, connectToSchoolDatabase } = require('../../config/db');
const { createS3FolderStructure } = require('../../config/aws');
const createtable = require('../../database/createtable');
const logger = require('../../logger/logger');

const usernameExists = async (username) => {
  const userCheckSql = "SELECT 1 FROM USERS WHERE USERNAME = ?";
  const [userCheckResult] = await pool.query(userCheckSql, [username]);
  return userCheckResult.length > 0;
};

const emailExists = async (email) => {
  const emailCheckSql = "SELECT 1 FROM USERS WHERE EMAIL = ?";
  const [emailCheckResult] = await pool.query(emailCheckSql, [email]);
  return emailCheckResult.length > 0;
};

const databaseExists = async (dbName) => {
  const checkDbSql = "SHOW DATABASES LIKE ?";
  const [dbResult] = await pool.query(checkDbSql, [dbName]);
  return dbResult.length > 0;
};

const signupUser = async ({
  FullName, SchoolName, SchoolBranch, UdiseCode, City, State, PostalCode, Email, MobileNumber, Password, Role
}) => {
  logger.info('Signup started', { Email, UdiseCode });

  if (!FullName || !SchoolName || !SchoolBranch || !UdiseCode || !City || !State || !PostalCode || !Email || !MobileNumber || !Password || !Role) {
    throw new Error('Some field is empty');
  }

  try {
    if (await emailExists(Email)) {
      throw new Error('This email is already registered');
    }

    const hashedPassword = await bcrypt.hash(Password, 10);
    logger.info('Password hashed', { Email });

    const sql = "INSERT INTO SCHOOLS_TENANT (SCHOOL_NAME, SCHOOL_BRANCH, UDISE_CODE, CITY, STATE, POSTAL_CODE, CONTACT_NUMBER) VALUES (?, ?, ?, ?, ?, ?, ?)";
    const values = [
      SchoolName.toUpperCase(),
      SchoolBranch.toUpperCase(),
      UdiseCode,
      City.toUpperCase(),
      State.toUpperCase(),
      PostalCode.toUpperCase(),
      MobileNumber
    ];
    await pool.query(sql, values);
    logger.info('School tenant created', { UdiseCode });

    const trimmedSchoolName = SchoolName.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    const trimmedCity = City.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    const DATABASE_NAME = `${trimmedSchoolName}_${trimmedCity}_${UdiseCode}`;

    if (await databaseExists(DATABASE_NAME)) {
      throw new Error(`Database ${DATABASE_NAME} already exists`);
    }

    const TenantQuery = `SELECT * FROM SCHOOLS_TENANT WHERE UDISE_CODE = ?`;
    const [TenantDetail] = await pool.query(TenantQuery, [UdiseCode]);

    if (!TenantDetail || TenantDetail.length === 0) {
      throw new Error('Tenant not found after insertion');
    }

    const baseUsername = FullName.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    let username = `${baseUsername}_${TenantDetail[0].TENANT_ID}`;
    let usernameSuffix = 1;

    while (await usernameExists(username)) {
      username = `${baseUsername}_${TenantDetail[0].TENANT_ID}_${usernameSuffix}`;
      usernameSuffix++;
    }

    const sqlCredentials = "INSERT INTO SCHOOL_DB_CREDENTIALS (TENANT_ID, DATABASE_NAME, DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_HOST) VALUES (?, ?, ?, ?, ?)";
    const valuesCredential = [TenantDetail[0].TENANT_ID, DATABASE_NAME, process.env.DB_USER, process.env.DB_PASSWORD, process.env.DB_HOST];
    await pool.query(sqlCredentials, valuesCredential);
    logger.info('Database credentials inserted', { DATABASE_NAME });

    const UserQuery = "INSERT INTO USERS (TENANT_ID, FULL_NAME, USERNAME, PASSWORD, ROLE_ID, CONTACT_NUMBER, EMAIL) VALUES (?, ?, ?, ?, ?, ?, ?)";
    const UserValues = [TenantDetail[0].TENANT_ID, FullName, username, hashedPassword, Role, MobileNumber, Email];
    await pool.query(UserQuery, UserValues);
    logger.info('User created', { username, Email });

    const createDbSql = `CREATE DATABASE IF NOT EXISTS \`${DATABASE_NAME}\``;
    await pool.query(createDbSql);
    logger.info(`Database ${DATABASE_NAME} created`);

    const fetchCredentialSql = "SELECT * FROM SCHOOL_DB_CREDENTIALS WHERE TENANT_ID = ?";
    const [credentialRows] = await pool.query(fetchCredentialSql, [TenantDetail[0].TENANT_ID]);

    if (!credentialRows || credentialRows.length === 0) {
      throw new Error('Database credentials not found after insertion');
    }

    const dbDetails = credentialRows[0];
    const SCHOOL_INFO = dbDetails.TENANT_ID;

    const newDbPool = createNewDbPool(dbDetails);
    const s3Success = await createS3FolderStructure(UdiseCode);
    if (!s3Success) {
      logger.warn('S3 folder not created, but signup continues', { UdiseCode });
    }

    return new Promise((resolve, reject) => {
      createtable(newDbPool, DATABASE_NAME, SCHOOL_INFO, (errors) => {
        if (errors) {
          logger.error('Error creating tables', { errors });
          reject(new Error('Failed to create tables in new database'));
        } else {
          logger.info('Tables created');
          resolve({ message: 'User registered and database/tables created!' });
        }
      });
    });
  } catch (err) {
    logger.error('Error in signup', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { signupUser, usernameExists, emailExists, databaseExists };