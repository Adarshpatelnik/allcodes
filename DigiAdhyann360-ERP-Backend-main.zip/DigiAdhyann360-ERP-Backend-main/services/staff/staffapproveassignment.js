const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getAssignmentData = async () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context in asyncLocalStorage');
    throw new Error('Unauthorized or missing context');
  }
  const current_staff = store.get('current_staff');
  const schoolDbConnection = store.get('schoolDbConnection');

  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }

  logger.info('School database connection established', { staff: current_staff });

  const query = `
    SELECT
      ut.ASSIGNMENT_ID,
      ut.STUDENT_ID,
      CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
      sa.CLASS_ID,
      sa.SUBJECT_NAME,
      td.TEACHER_NAME AS CLASS_TEACHER,
      sa.ASSIGNMENT_TYPE,
      sa.ASSIGNMENT_DESC,
      sa.SUBMISSION_START_DATE,
      sa.SUBMISSION_END_DATE,
      ut.STATUS AS TeacherApprovalStatus,
      ut.STUDENT_SUBMITTED_DATE,
      sa.SUBMISSION_DATE,
      sa.IS_SUBMITTED,
      sa.STUDENT_STATUS
    FROM ACD_STUDENT_ASSIGNMENT_STATUS ut
    JOIN ACD_STUDENT_ASSIGNMENT sa ON ut.STUDENT_ID = sa.STUDENT_ID AND sa.ASSIGNMENT_ID = ut.ASSIGNMENT_ID
    JOIN ACD_STUDENT_PROFILE sp ON sp.STUDENT_ID = ut.STUDENT_ID
    JOIN ACD_STUDENT_CLASS_MAPPING cd ON cd.STUDENT_ID = sp.STUDENT_ID
    JOIN ACD_CLASS_SUB_TEACHER_MAPPING td ON sa.SUBJECT_NAME = td.SUBJECT AND cd.CLASS_ID = td.CLASS_ID
    JOIN ACD_STAFF_PROFILE s ON td.TEACHER_ID = s.STAFF_ID
    WHERE ut.STATUS = 'PENDING'
      AND s.STAFF_ID = ?
  `;

  logger.info('Executing query to fetch assignment data', { staffId: current_staff });
  try {
    const [rows] = await schoolDbConnection.query(query, [current_staff]);
    logger.info('Query execution successful', { rowsFetched: rows.length });
    if (rows.length === 0) {
      logger.info('No assignment data found for staff', { staffId: current_staff });
    }
    return rows;
  } catch (error) {
    logger.error('Error executing query', { error: error.message, sqlMessage: error.sqlMessage });
    throw error;
  }
};

const updateAssignmentStatus = async ({ assignmentId, studentId, submittedDate, status }) => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context in asyncLocalStorage');
    throw new Error('Unauthorized or missing context');
  }
  const current_staff = store.get('current_staff');
  const schoolDbConnection = store.get('schoolDbConnection');

  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('Database connection not established');
  }

  logger.info('Updating assignment status', { assignmentId, status, staffId: current_staff });

  try {
    if (status === 'APPROVED') {
      await schoolDbConnection.query(
        `UPDATE ACD_STUDENT_ASSIGNMENT SET SUBMISSION_DATE = ?, IS_SUBMITTED = 1 WHERE ASSIGNMENT_ID = ? AND STAFF_ID = ?`,
        [submittedDate, assignmentId, current_staff]
      );
      logger.info('Updated ACD_STUDENT_ASSIGNMENT', { assignmentId, submittedDate });
      await schoolDbConnection.query(
        `UPDATE ACD_STUDENT_ASSIGNMENT_STATUS SET STATUS = 'APPROVED' WHERE ASSIGNMENT_ID = ?`,
        [assignmentId]
      );
      logger.info('Updated ACD_STUDENT_ASSIGNMENT_STATUS to APPROVED', { assignmentId });
    } else if (status === 'CANCEL') {
      await schoolDbConnection.query(
        `UPDATE ACD_STUDENT_ASSIGNMENT_STATUS SET STATUS = 'CANCEL' WHERE ASSIGNMENT_ID = ?`,
        [assignmentId]
      );
      logger.info('Updated ACD_STUDENT_ASSIGNMENT_STATUS to CANCEL', { assignmentId });
    }
  } catch (error) {
    logger.error('Error updating assignment status', { error: error.message, sqlMessage: error.sqlMessage });
    throw error;
  }
};

module.exports = {
  getAssignmentData,
  updateAssignmentStatus,
};