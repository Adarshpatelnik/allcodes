const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getStaffId = async (schoolDbConnection) => {
  if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
    logger.error('Service: AsyncLocalStorage is not properly initialized', { path: '/api/assignment or /api/assignmentdata' });
    throw new Error('AsyncLocalStorage is not properly initialized');
  }

  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.warn('Service: Unauthorized or missing context', { path: '/api/assignment or /api/assignmentdata' });
    throw new Error('Unauthorized or missing context');
  }

  const staffId = store.get('current_staff');
  if (!staffId) {
    logger.warn('Service: No current_staff found in AsyncLocalStorage', { path: '/api/assignment or /api/assignmentdata' });
    return null;
  }

  const [staffResult] = await schoolDbConnection.query(
    'SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?',
    [staffId]
  );
  if (staffResult.length === 0) {
    logger.warn('Service: No staff record found for staff ID', { staffId, path: '/api/assignment or /api/assignmentdata' });
    return null;
  }

  logger.info('Service: Staff ID validated', { staffId });
  return staffId;
};

exports.getAssignments = async () => {
  logger.info('Service: GET /api/assignment: Fetching assignment data');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/assignment' });
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/assignment' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      logger.info('Service: No valid staff ID found', { path: '/api/assignment' });
      throw new Error('No valid staff ID found');
    }

    const assignmentSql = `
      SELECT
        cd.CLASS_ID,
        s.SUBJECT_NAME
      FROM
        ACD_STUDENT_PROFILE sp
      JOIN
        ACD_STUDENT_CLASS_MAPPING   cd ON cd.STUDENT_ID = sp.STUDENT_ID
      JOIN
        ACD_SUBJECT s ON s.CLASS = cd.CLASS
      LEFT JOIN
        ACD_CLASS_SUB_TEACHER_MAPPING  td ON s.SUBJECT_NAME = td.SUBJECT AND cd.CLASS_ID = td.CLASS_ID
      LEFT JOIN
        ACD_STAFF_PROFILE   s2 ON td.TEACHER_ID = s2.STAFF_ID
          WHERE
        s2.STAFF_ID = ?
      GROUP BY
        cd.CLASS_ID, s.SUBJECT_NAME
    `;

    logger.info('Service: Executing assignment query', { query: assignmentSql, params: [staffId] });
    const [assignmentResult] = await schoolDbConnection.query(assignmentSql, [staffId]);

    logger.info('Service: Assignments fetched successfully', { staffId, count: assignmentResult.length });
    return assignmentResult;
  } catch (err) {
    logger.error('Service: Error fetching assignment data', { error: err.message, stack: err.stack, path: '/api/assignment' });
    throw err;
  }
};

exports.submitAssignmentData = async ({
  Class,
  AssignmentType,
  Subject,
  AssignmentDescription,
  SubmissionStartDate,
  SubmissionEndDate,
}) => {
  logger.info('Service: POST /api/assignmentdata: Submitting assignment data');
  let connection;
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/assignmentdata' });
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/assignmentdata' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      logger.info('Service: No valid staff ID found', { path: '/api/assignmentdata' });
      throw new Error('No valid staff ID found');
    }

    if (!Class || !AssignmentType || !Subject || !AssignmentDescription || !SubmissionStartDate || !SubmissionEndDate) {
      logger.warn('Service: Missing required fields', {
        Class,
        AssignmentType,
        Subject,
        AssignmentDescription,
        SubmissionStartDate,
        SubmissionEndDate,
        path: '/api/assignmentdata',
      });
      throw new Error('Missing required fields');
    }

    connection = await schoolDbConnection.getConnection();
    logger.info('Service: Database connection established', { path: '/api/assignmentdata' });

    const fetchStudentIdsQuery = `
      SELECT cd.STUDENT_ID, sp.FIRST_NAME
      FROM ACD_STUDENT_CLASS_MAPPING cd
      JOIN ACD_STUDENT_PROFILE sp ON cd.STUDENT_ID = sp.STUDENT_ID
      WHERE cd.CLASS_ID = ?
    `;
    const fetchMaxAssignmentIdQuery = `
      SELECT MAX(ASSIGNMENT_ID) AS MAX_ASSIGNMENT_ID
      FROM ACD_STUDENT_ASSIGNMENT
    `;
    const fetchStaffIdsQuery = `
      SELECT STAFF_ID, STAFF_NAME
      FROM ACD_STAFF_PROFILE
      WHERE STAFF_ID = ?
    `;

    logger.info('Service: Fetching staff details', { query: fetchStaffIdsQuery, params: [staffId] });
    const [staffResults] = await connection.query(fetchStaffIdsQuery, [staffId]);

    if (staffResults.length === 0) {
      logger.warn('Service: No staff found for the given staff ID', { staffId, path: '/api/assignmentdata' });
      throw new Error('Staff details not found');
    }

    const staffName = staffResults[0].STAFF_NAME;
    logger.info('Service: Fetched staff name', { staffName });

    logger.info('Service: Fetching students for Class', { query: fetchStudentIdsQuery, params: [Class] });
    const [studentResults] = await connection.query(fetchStudentIdsQuery, [Class]);

    if (studentResults.length === 0) {
      logger.warn('Service: No students found for the given class', { Class, path: '/api/assignmentdata' });
      throw new Error('No students found for the given class');
    }

    logger.info('Service: Fetching max assignment ID', { query: fetchMaxAssignmentIdQuery });
    const [assignmentIdResult] = await connection.query(fetchMaxAssignmentIdQuery);
    let newAssignmentId = assignmentIdResult[0]?.MAX_ASSIGNMENT_ID || 0;

    logger.info('Service: Starting transaction', { path: '/api/assignmentdata' });
    await connection.beginTransaction();

    const insertAssignmentQuery = `
      INSERT INTO ACD_STUDENT_ASSIGNMENT
      (ASSIGNMENT_ID, STUDENT_ID, STUDENT_NAME, CLASS_ID, ASSIGNMENT_TYPE, SUBJECT_NAME, ASSIGNMENT_DESC, SUBMISSION_START_DATE, SUBMISSION_END_DATE, STAFF_ID, STAFF_NAME)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    logger.info('Service: Preparing to insert assignments', { studentCount: studentResults.length });
    const insertPromises = studentResults.map((row, index) => {
      newAssignmentId++;
      logger.info(`Service: Preparing to insert record ${index + 1} for Student: ${row.FIRST_NAME}`, { newAssignmentId });
      return connection.query(insertAssignmentQuery, [
        newAssignmentId,
        row.STUDENT_ID,
        row.FIRST_NAME,
        Class,
        AssignmentType,
        Subject,
        AssignmentDescription,
        SubmissionStartDate,
        SubmissionEndDate,
        staffId,
        staffName,
      ]);
    });

    await Promise.all(insertPromises);
    logger.info('Service: Committing transaction', { path: '/api/assignmentdata' });
    await connection.commit();

    logger.info('Service: Assignment data inserted successfully', { insertedRecords: studentResults.length, assignmentIdRange: { start: assignmentIdResult[0]?.MAX_ASSIGNMENT_ID + 1, end: newAssignmentId } });
    return {
      message: 'Assignment Data inserted successfully.',
      insertedRecords: studentResults.length,
      assignmentIdRange: { start: assignmentIdResult[0]?.MAX_ASSIGNMENT_ID + 1 || 1, end: newAssignmentId },
    };
  } catch (err) {
    if (connection) {
      logger.info('Service: Rolling back transaction', { path: '/api/assignmentdata' });
      await connection.rollback();
    }
    logger.error('Service: Error inserting assignment data', { error: err.message, stack: err.stack, path: '/api/assignmentdata' });
    throw err;
  } finally {
    if (connection) {
      logger.info('Service: Releasing database connection', { path: '/api/assignmentdata' });
      connection.release();
    }
  }
};