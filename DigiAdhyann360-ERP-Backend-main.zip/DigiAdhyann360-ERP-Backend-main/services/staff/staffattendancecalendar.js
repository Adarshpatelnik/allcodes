
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getStaffId = async (schoolDbConnection) => {
  if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
    throw new Error('AsyncLocalStorage is not properly initialized');
  }

  const store = asyncLocalStorage.getStore();
  if (!store) {
    throw new Error('Unauthorized or missing context');
  }

  let staffId = store.get('current_staff');
  if (!staffId) {
    const current_admin = store.get('current_admin');
    if (current_admin) {
      const [staffResult] = await schoolDbConnection.query(
        'SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?',
        [current_admin]
      );
      if (staffResult.length > 0) {
        staffId = staffResult[0].STAFF_ID;
        logger.info('Administrator found as staff', { staffId: current_admin });
      } else {
        logger.warn('No staff ID found for current_admin', { current_admin, path: '/api/staffattendancecalendar' });
        return null;
      }
    } else {
      logger.warn('No current_staff or current_admin found in AsyncLocalStorage', { path: '/api/staffattendancecalendar' });
      return null;
    }
  }
  return staffId;
};

const getStaffGender = async () => {
  logger.info('getStaffGender: Fetching staff gender');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffattendancecalendar/get-staff-gender' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      return null;
    }

    const query = `
      SELECT GENDER
      FROM ACD_STAFF_PROFILE
      WHERE STAFF_ID = ?
    `;
    logger.info('Executing query', { query, params: [staffId] });
    const [results] = await schoolDbConnection.query(query, [staffId]);
    if (!results || results.length === 0) {
      logger.warn('No gender data found for staff ID', { staffId });
      return null;
    }
    logger.info('getStaffGender: Gender fetched successfully', { gender: results[0].GENDER });
    return { GENDER: results[0].GENDER };
  } catch (err) {
    logger.error('Error fetching staff gender', { error: err.message, stack: err.stack });
    throw err;
  }
};

const getAttendance = async () => {
  logger.info('getAttendance: Fetching attendance data');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffattendancecalendar/get-attendance' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      return [];
    }

    const query = `
      SELECT s.STAFF_ID, sa.ATTENDANCE_DATE, sa.STATUS, sa.ACADEMIC_YEAR
      FROM ACD_STAFF_PROFILE s
      JOIN ACD_STAFF_ATTENDANCE sa ON s.STAFF_ID = sa.STAFF_ID
      WHERE s.STAFF_ID = ?
    `;
    logger.info('Executing query', { query, params: [staffId] });
    const [results] = await schoolDbConnection.query(query, [staffId]);
    logger.info('getAttendance: Attendance data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching attendance', { error: err.message, stack: err.stack });
    throw err;
  }
};

const getLeave = async () => {
  logger.info('getLeave: Fetching leave data');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffattendancecalendar/get-leave' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      return [];
    }

    const query = `
      SELECT STAFF_ID, START_DATE, END_DATE, STATUS
      FROM ACD_LEAVE_APPLICATION
      WHERE STAFF_ID = ?
    `;
    logger.info('Executing query', { query, params: [staffId] });
    const [results] = await schoolDbConnection.query(query, [staffId]);
    logger.info('getLeave: Leave data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching leave', { error: err.message, stack: err.stack });
    throw err;
  }
};

const getLeaveType = async () => {
  logger.info('getLeaveType: Fetching leave type data');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffattendancecalendar/get-leave-type' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      return [];
    }

    // Fetch staff gender and role
    const profileQuery = `
      SELECT GENDER, STAFF_ROLE
      FROM ACD_STAFF_PROFILE
      WHERE STAFF_ID = ?
    `;
    const [profileResult] = await schoolDbConnection.query(profileQuery, [staffId]);
    if (!profileResult || profileResult.length === 0) {
      logger.warn('No profile data found for staff ID', { staffId });
      return [];
    }
    const gender = profileResult[0].GENDER.toUpperCase();
    const staffRole = profileResult[0].STAFF_ROLE;
    logger.info('Fetched staff profile', { gender, staffRole });

    // Fetch leave types based on staff role only (no role-less leaves)
    const baseQuery = `
      SELECT
        lt.STAFF_ROLE,
        s.STAFF_ID,
        lt.LEAVE_TYPE,
        lt.MAX_ALLOWED AS ALLOWED_LEAVE,
        COUNT(lat.LEAVE_TYPE) AS LEAVE_TAKEN,
        lt.MAX_ALLOWED - COUNT(lat.LEAVE_TYPE) AS LEAVE_BALANCE
      FROM ACD_STAFF_PROFILE s
      INNER JOIN ACD_LEAVE_TYPE lt ON lt.STAFF_ROLE = s.STAFF_ROLE
      LEFT JOIN ACD_LEAVE_APPLICATION lat
        ON lat.STAFF_ID = s.STAFF_ID
        AND lat.LEAVE_TYPE = lt.LEAVE_TYPE
      WHERE s.STAFF_ID = ?
      GROUP BY s.STAFF_ID, lt.LEAVE_TYPE, lt.MAX_ALLOWED, lt.STAFF_ROLE
      ORDER BY s.STAFF_ID ASC
    `;
    const [results] = await schoolDbConnection.query(baseQuery, [staffId]);
    logger.info('Raw leave types fetched', { rawCount: results.length, rawResults: results });

    // Filter leave types based on gender only for TEACHER role
    let filteredResults = results;
    if (staffRole === 'TEACHER') {
      if (gender === 'MALE' || gender === 'M') {
        filteredResults = results.filter(result => result.LEAVE_TYPE !== 'Maternity Leave');
      } else if (gender === 'FEMALE' || gender === 'F') {
        filteredResults = results.filter(result => result.LEAVE_TYPE !== 'Paternity Leave');
      }
    }

    logger.info('getLeaveType: Leave type data fetched and filtered by gender', { count: filteredResults.length, gender });
    return filteredResults.length > 0 ? filteredResults : [];
  } catch (err) {
    logger.error('Error fetching leave type', { error: err.message, stack: err.stack });
    throw err;
  }
};

const submitLeave = async (leaveData) => {
  logger.info('submitLeave: Submitting leave application');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffattendancecalendar/submit-leave' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      throw new Error('No valid staff ID found');
    }

    const { leaveType, startDate, endDate, reason, contactNumber } = leaveData;

    // Fetch STAFF_NAME
    const staffQuery = `SELECT STAFF_NAME FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?`;
    const [staffResult] = await schoolDbConnection.query(staffQuery, [staffId]);
    if (!staffResult || staffResult.length === 0) {
      throw new Error('Staff not found');
    }
    const staffName = staffResult[0].STAFF_NAME;

    // Generate ACADEMIC_YEAR
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1;
    const academicYear = month >= 4 ? `${year}-${year + 1}` : `${year - 1}-${year}`;

    // Insert into ACD_LEAVE_APPLICATION
    const leaveQuery = `
      INSERT INTO ACD_LEAVE_APPLICATION (STAFF_ID, LEAVE_TYPE, START_DATE, END_DATE, REASON, CONTACT_NUMBER, STATUS)
      VALUES (?, ?, ?, ?, ?, ?, 'PENDING')
    `;
    await schoolDbConnection.query(leaveQuery, [staffId, leaveType, startDate, endDate, reason, contactNumber]);

    // Insert into LEAVE_NOTIFICATION
    const notificationQuery = `
      INSERT INTO ACD_LEAVE_NOTIFICATION (STAFF_ID, STAFF_NAME, STATUS)
      VALUES (?, ?, 'PENDING')
    `;
    await schoolDbConnection.query(notificationQuery, [staffId, staffName]);

    // Insert or update ACD_STAFF_ATTENDANCE for each date
    let currentDate = new Date(startDate);
    const endDateObj = new Date(endDate);
    while (currentDate <= endDateObj) {
      const formattedDate = currentDate.toISOString().split('T')[0];
      const attendanceQuery = `
        INSERT INTO ACD_STAFF_ATTENDANCE (STAFF_ID, ATTENDANCE_DATE, STATUS, ACADEMIC_YEAR)
        VALUES (?, ?, 'LEAVE', ?)
        ON DUPLICATE KEY UPDATE STATUS = VALUES(STATUS)
      `;
      await schoolDbConnection.query(attendanceQuery, [staffId, formattedDate, academicYear]);
      currentDate.setDate(currentDate.getDate() + 1);
    }

    logger.info('submitLeave: Leave application submitted successfully');
    return { message: 'Leave application submitted successfully', leaveStatus: 'PENDING' };
  } catch (err) {
    logger.error('Error submitting leave', { error: err.message, stack: err.stack });
    throw err;
  }
};

const submitAttendance = async (attendanceData) => {
  logger.info('submitAttendance: Submitting attendance');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffattendancecalendar/submitattendance' });
      throw new Error('School database connection not established');
    }

    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      throw new Error('No valid staff ID found');
    }

    const { STATUS, ATTENDANCE_DATE } = attendanceData;
    if (!STATUS || !ATTENDANCE_DATE) {
      throw new Error('STATUS and ATTENDANCE_DATE are required fields');
    }

    // Fetch ACADEMIC_YEAR
    const academicYearQuery = `
      SELECT ACADEMIC_YEAR
      FROM ACD_STUDENT_CLASS_MAPPING
      LIMIT 1
    `;
    const [academicYearResult] = await schoolDbConnection.query(academicYearQuery);
    const ACADEMIC_YEAR = academicYearResult.length > 0 ? academicYearResult[0].ACADEMIC_YEAR : null;
    if (!ACADEMIC_YEAR) {
      throw new Error('ACADEMIC_YEAR not found in ACD_STUDENT_CLASS_MAPPING table');
    }

    const localDate = new Date();
    localDate.setMinutes(localDate.getMinutes() - localDate.getTimezoneOffset());
    const formattedDateString = localDate.toISOString().split('T')[0];

    const attendanceQuery = `
      INSERT INTO ACD_STAFF_ATTENDANCE (STAFF_ID, ATTENDANCE_DATE, STATUS, ACADEMIC_YEAR)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE STATUS = VALUES(STATUS)
    `;
    await schoolDbConnection.query(attendanceQuery, [staffId, formattedDateString, STATUS, ACADEMIC_YEAR]);

    const staffQuery = `SELECT STAFF_NAME FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?`;
    const [staffResult] = await schoolDbConnection.query(staffQuery, [staffId]);
    const staffName = staffResult.length > 0 ? staffResult[0].STAFF_NAME : null;
    if (!staffName) {
      throw new Error('Staff name not found for the given STAFF_ID');
    }

    const notificationQuery = `
      INSERT INTO ACD_STAFF_ATTENDANCE_NOTIFICATIONS (STAFF_ID, STAFF_NAME, ATTENDANCE_DATE, STATUS)
      VALUES (?, ?, ?, 'PENDING')
    `;
    const currentDate = new Date().toISOString().split('T')[0];
    await schoolDbConnection.query(notificationQuery, [staffId, staffName, currentDate]);

    logger.info('submitAttendance: Attendance submitted successfully');
    return { message: 'Attendance submitted successfully' };
  } catch (err) {
    logger.error('Error submitting attendance', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { getAttendance, getLeave, getLeaveType, submitLeave, submitAttendance, getStaffGender };