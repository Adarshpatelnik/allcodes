const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getMyAttendance = async (dateRange, fromDate, toDate) => {
  logger.info('getMyAttendance: Fetching attendance data', { dateRange, fromDate, toDate });
  try {
    if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
      throw new Error('AsyncLocalStorage is not properly initialized');
    }

    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    let staffId = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/myattendance' });
      throw new Error('School database connection not established');
    }

    // If current_staff is not set, check if current_admin is a staff member
    if (!staffId) {
      const current_admin = store.get('current_admin');
      if (current_admin) {
        const [staffResult] = await schoolDbConnection.query(
          'SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?',
          [current_admin]
        );
        if (staffResult.length > 0) {
          staffId = staffResult[0].STAFF_ID;
          logger.info('Administrator found as staff member', { staffId: current_admin });
        } else {
          logger.warn('No staff ID found for current_admin', { current_admin, path: '/api/myattendance' });
          return [];
        }
      } else {
        logger.warn('No current_staff or current_admin found in AsyncLocalStorage', { path: '/api/myattendance' });
        return [];
      }
    }

    let query = `
      SELECT
        sp.STAFF_ID,
        sp.STAFF_NAME,
        sa.ATTENDANCE_DATE,
        sa.STATUS
      FROM
        ACD_STAFF_PROFILE sp
      LEFT JOIN
        ACD_STAFF_ATTENDANCE sa ON sp.STAFF_ID = sa.STAFF_ID
      WHERE
        sp.STAFF_ID = ?
    `;
    const queryParams = [staffId];

 
    if (fromDate && toDate) {
      query += ` AND sa.ATTENDANCE_DATE BETWEEN ? AND ?`;
      queryParams.push(fromDate, toDate);
    } else if (dateRange && dateRange !== 'Custom') {
      let startDate;
      const endDate = new Date().toISOString().split('T')[0]; 
      switch (dateRange) {
        case 'Last 1 Month':
          startDate = new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString().split('T')[0];
          break;
        case 'Last 3 Months':
          startDate = new Date(new Date().setMonth(new Date().getMonth() - 3)).toISOString().split('T')[0];
          break;
        case 'Last 6 Months':
          startDate = new Date(new Date().setMonth(new Date().getMonth() - 6)).toISOString().split('T')[0];
          break;
        case 'Last 1 Year':
          startDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1)).toISOString().split('T')[0];
          break;
        default:
          startDate = null;
      }
      if (startDate) {
        query += ` AND sa.ATTENDANCE_DATE BETWEEN ? AND ?`;
        queryParams.push(startDate, endDate);
      }
    }

    query += ` ORDER BY sp.STAFF_ID, sa.ATTENDANCE_DATE ASC`;

    logger.info('Executing query', { query, params: queryParams });
    const [results] = await schoolDbConnection.query(query, queryParams);
    logger.info('getMyAttendance: Attendance data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching attendance', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { getMyAttendance };