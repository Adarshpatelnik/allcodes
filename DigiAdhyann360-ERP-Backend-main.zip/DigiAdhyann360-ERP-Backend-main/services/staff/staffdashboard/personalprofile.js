const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getDbConnection = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('No asyncLocalStorage context found');
    throw new Error('Unauthorized access: No context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
  return { schoolDbConnection, store };
};

const fetchStaffPersonalProfile = async () => {
  const { schoolDbConnection, store } = getDbConnection();
  const staffId = store.get('current_staff') || store.get('user')?.STAFF_ID;
  if (!staffId) {
    logger.error('Staff ID not found in session');
    throw new Error('Staff ID not found');
  }

  try {
    logger.info('Fetching staff personal profile', { staffId });
    const query = `
      SELECT
        s.STAFF_ID,
        s.STAFF_NAME,
        s.MARITAL_STATUS,
        s.STAFF_ROLE,
        s.DATE_OF_JOINING,
        b.NET_SALARY AS MONTHLY_SALARY,
        s.FATHER_HUSBAND_NAME,
        s.GENDER,
        s.EXPERIENCE,
        s.ADHAR_ID,
        s.ADDRESS
      FROM ACD_STAFF_PROFILE s
      left join ACC_STAFF_SALARY b on s.STAFF_ID = b.STAFF_ID
      WHERE STAFF_ID = ?
    `;
    logger.debug('Executing SQL query:', { query, params: [staffId] });
    const [results] = await schoolDbConnection.query(query, [staffId]);
    logger.info('Staff personal profile fetched', { data: results[0] });
    return results[0] || null;
  } catch (error) {
    logger.error('Error fetching staff personal profile', {
      error: error.message,
      stack: error.stack,
      staffId,
    });
    throw error;
  }
};

module.exports = {
  fetchStaffPersonalProfile,
};