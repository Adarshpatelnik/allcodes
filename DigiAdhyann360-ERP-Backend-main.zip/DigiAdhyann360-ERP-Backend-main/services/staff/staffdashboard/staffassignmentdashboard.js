const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getDbConnection = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('No asyncLocalStorage context found');
    throw new Error('Unauthorized access: No context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('Database connection not established');
    throw new Error('Database connection not established');
  }
  return { schoolDbConnection, store };
};

const fetchStaffAssignmentDashboard = async () => {
  const { schoolDbConnection, store } = getDbConnection();
  const staffId = store.get('current_staff') || store.get('user')?.STAFF_ID;
  if (!staffId) {
    logger.error('Staff ID not found in session');
    throw new Error('Staff ID not found');
  }

  try {
    logger.info('Fetching staff assignment dashboard', { staffId });
    const query = `
      SELECT
        COALESCE(SUM(CASE
            WHEN (IS_SUBMITTED = 'No' OR IS_SUBMITTED IS NULL) AND
                 DATE(SUBMISSION_END_DATE) = CURDATE() THEN 1
            ELSE 0
        END), 0) AS OnTimeAssignments,
        COALESCE(SUM(CASE
            WHEN (IS_SUBMITTED = 'No' OR IS_SUBMITTED IS NULL) AND
                 CURDATE() > SUBMISSION_END_DATE THEN 1
            ELSE 0
        END), 0) AS LateAssignments,
        COALESCE(SUM(CASE
            WHEN CURDATE() < SUBMISSION_END_DATE THEN 1
            ELSE 0
        END), 0) AS UpcomingAssignments
      FROM
        STUDENT_ASSIGNMENT
      WHERE STAFF_ID = ?;
    `;
    logger.debug('Executing SQL query:', { query, params: [staffId] });
    const [rows] = await schoolDbConnection.query(query, [staffId]);
    logger.info('Staff assignment dashboard fetched', { data: rows[0] });
    return rows[0] || { OnTimeAssignments: 0, LateAssignments: 0, UpcomingAssignments: 0 };
  } catch (error) {
    logger.error('Error fetching staff assignment dashboard', {
      error: error.message,
      stack: error.stack,
      staffId,
    });
    throw error;
  }
};

module.exports = {
  fetchStaffAssignmentDashboard,
};

