const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStaffAssignmentOverview = async () => {
  logger.info('getStaffAssignmentOverview: Fetching assignment data');
  try {
    if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
      throw new Error('AsyncLocalStorage is not properly initialized');
    }

    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    const current_staff = store.get('current_staff');
    if (!current_staff) {
      logger.warn('No current_staff found in AsyncLocalStorage', { path: '/api/staffassignmentoverview' });
      return [];
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffassignmentoverview' });
      throw new Error('School database connection not established');
    }

    const query = `
      SELECT
        SUM(CASE
          WHEN (IS_SUBMITTED = 'No' OR IS_SUBMITTED IS NULL) AND
            DATE(SUBMISSION_END_DATE) = CURRENT_DATE THEN 1
          ELSE 0
        END) AS OnTimeAssignments,
        SUM(CASE
          WHEN (IS_SUBMITTED = 'No' OR IS_SUBMITTED IS NULL) AND CURRENT_DATE > SUBMISSION_END_DATE THEN 1
          ELSE 0
        END) AS LateAssignments,
        SUM(CASE
          WHEN CURRENT_DATE < SUBMISSION_END_DATE THEN 1
          ELSE 0
        END) AS UpcomingAssignments
      FROM
        ACD_STUDENT_ASSIGNMENT
      WHERE
        STAFF_ID = ?
    `;
    logger.info('Executing query', { query, params: [current_staff] });
    const [results] = await schoolDbConnection.query(query, [current_staff]);
    logger.info('getStaffAssignmentOverview: Assignment data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching assignment overview', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { getStaffAssignmentOverview };