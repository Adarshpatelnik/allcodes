const logger = require('../../../logger/logger');
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');

const getDbConnection = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context');
    throw new Error('Unauthorized or missing context');
  }
  const schoolDbConnection = store.get('schoolDbConnection');
  if (!schoolDbConnection) {
    logger.error('School database connection not established');
    throw new Error('School database connection not established');
  }
  return schoolDbConnection;
};

const getCurrentStaff = () => {
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.error('Unauthorized or missing context');
    throw new Error('Unauthorized or missing context');
  }
  const current_staff = store.get('current_staff');
  if (!current_staff) {
    logger.error('Current staff not found in context');
    throw new Error('Current staff not found in context');
  }
  return current_staff;
};

const fetchClassSchedule = async () => {
  const schoolDbConnection = getDbConnection();
  const current_staff = getCurrentStaff();
  try {
    logger.info('Fetching class schedule', { teacher_id: current_staff });
    const query = `
      SELECT
        sc.SUBJECT,
        td.TEACHER_NAME,
        sc.PERIOD,
        sc.TIME_SLOT,
        sc.CLASS_ID,
        MAX(CASE WHEN sc.DAY = 'MONDAY' THEN sc.SUBJECT END) AS Monday,
        MAX(CASE WHEN sc.DAY = 'TUESDAY' THEN sc.SUBJECT END) AS Tuesday,
        MAX(CASE WHEN sc.DAY = 'WEDNESDAY' THEN sc.SUBJECT END) AS Wednesday,
        MAX(CASE WHEN sc.DAY = 'THURSDAY' THEN sc.SUBJECT END) AS Thursday,
        MAX(CASE WHEN sc.DAY = 'FRIDAY' THEN sc.SUBJECT END) AS Friday,
        MAX(CASE WHEN sc.DAY = 'SATURDAY' THEN sc.SUBJECT END) AS Saturday
      FROM
        ACD_CLASS_SCHEDULE sc
        JOIN ACD_CLASS_SUB_TEACHER_MAPPING td ON sc.CLASS_ID = td.CLASS_ID AND sc.SUBJECT = td.SUBJECT
      WHERE
        td.TEACHER_ID = ?
      GROUP BY
        sc.PERIOD, sc.TIME_SLOT, sc.CLASS_ID
    `;
    logger.debug('Executing SQL query:', { query, params: [current_staff] });
    const [rows] = await schoolDbConnection.query(query, [current_staff]);
    logger.info('Class schedule fetched successfully', { count: rows.length });
    return rows;
  } catch (error) {
    logger.error('Error fetching class schedule', { error: error.message, teacher_id: current_staff });
    throw error;
  }
};

module.exports = {
  fetchClassSchedule,
};