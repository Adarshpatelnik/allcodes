
const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStaffTimetable = async () => {
  logger.info('getStaffTimetable: Fetching timetable data');
  try {
    if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
      throw new Error('AsyncLocalStorage is not properly initialized');
    }

    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    let teacherId = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/stafftimetable' });
      throw new Error('School database connection not established');
    }

    // If current_staff is not set, check if current_admin is a teacher
    if (!teacherId) {
      const current_admin = store.get('current_admin');
      if (current_admin) {
        const [teacherResult] = await schoolDbConnection.query(
          'SELECT TEACHER_ID FROM ACD_CLASS_SUB_TEACHER_MAPPING WHERE TEACHER_ID = ?',
          [current_admin]
        );
        if (teacherResult.length > 0) {
          teacherId = teacherResult[0].TEACHER_ID;
          logger.info('Administrator found as teacher', { teacherId: current_admin });
        } else {
          logger.warn('No teacher ID found for current_admin', { current_admin, path: '/api/stafftimetable' });
          return [];
        }
      } else {
        logger.warn('No current_staff or current_admin found in AsyncLocalStorage', { path: '/api/stafftimetable' });
        return [];
      }
    }

 const query = `
      SELECT
        sc.SUBJECT,
        td.TEACHER_NAME,
        sc.PERIOD,
        sc.TIME_SLOT,
        sc.CLASS_ID,
        MAX(CASE WHEN sc.DAY = 'MONDAY' THEN sc.SUBJECT END) AS Monday,
        MAX(CASE WHEN sc.DAY = 'TUESDAY' THEN sc.SUBJECT END) AS Tuesday,
        MAX(CASE WHEN sc.DAY = 'WEDNESDAY' THEN sc.SUBJECT END) AS Wednesday,
        MAX(CASE WHEN sc.DAY = 'THURSDAY' THEN sc.SUBJECT END) AS Thursday,
        MAX(CASE WHEN sc.DAY = 'FRIDAY' THEN sc.SUBJECT END) AS Friday,
        MAX(CASE WHEN sc.DAY = 'SATURDAY' THEN sc.SUBJECT END) AS Saturday
      FROM
        ACD_CLASS_SCHEDULE sc
      JOIN
        ACD_CLASS_SUB_TEACHER_MAPPING td ON sc.CLASS_ID = td.CLASS_ID AND sc.SUBJECT = td.SUBJECT
      WHERE
        td.TEACHER_ID = ?
      GROUP BY
        sc.PERIOD,
        sc.TIME_SLOT,
        sc.CLASS_ID
    `;
    logger.info('Executing query', { query, params: [teacherId] });
    const [results] = await schoolDbConnection.query(query, [teacherId]);
    logger.info('getStaffTimetable: Timetable data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching timetable', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { getStaffTimetable };

