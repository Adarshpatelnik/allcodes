const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStudentList = async (classId, sectionId) => {
  logger.info('getStudentList: Fetching student list data', { classId, sectionId });
  try {
    if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
      throw new Error('AsyncLocalStorage is not properly initialized');
    }

    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    let teacherId = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/studentlist' });
      throw new Error('School database connection not established');
    }

   
    if (!teacherId) {
      const current_admin = store.get('current_admin');
      if (current_admin) {
        const [teacherResult] = await schoolDbConnection.query(
          'SELECT TEACHER_ID FROM ACD_CLASS_SUB_TEACHER_MAPPING WHERE TEACHER_ID = ?',
          [current_admin]
        );
        if (teacherResult.length > 0) {
          teacherId = teacherResult[0].TEACHER_ID;
          logger.info('Administrator found as teacher', { teacherId: current_admin });
        } else {
          logger.warn('No teacher ID found for current_admin', { current_admin, path: '/api/studentlist' });
          return [];
        }
      } else {
        logger.warn('No current_staff or current_admin found in AsyncLocalStorage', { path: '/api/studentlist' });
        return [];
      }
    }

    let query = `
  SELECT
  cd.CLASS_ID,
  sp.STUDENT_ID,
  pp.PARENT_ID,
  pp.FATHER_NAME,
  pp.MOTHER_NAME,
  CONCAT(sp.FIRST_NAME, ' ', sp.LAST_NAME) AS FULL_NAME,
  sp.GENDER,
  sp.CONTACT_NUMBER,
  sp.EMAIL,
  td.TEACHER_NAME,
  cd.CLASS,
  cd.SECTION
FROM
  ACD_STUDENT_PROFILE sp
JOIN
  ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
JOIN
  ACD_PARENT_PROFILE pp ON sp.STUDENT_ID = pp.STUDENT_ID
JOIN
  ACD_CLASS_SUB_TEACHER_MAPPING td ON cd.CLASS_ID = td.CLASS_ID
WHERE
  td.TEACHER_ID = ?
ORDER BY
  CASE 
    WHEN cd.CLASS = 'LKG' THEN 0
    WHEN cd.CLASS = 'UKG' THEN 1
    WHEN cd.CLASS = '1' THEN 2
    WHEN cd.CLASS = '2' THEN 3
    WHEN cd.CLASS = '3' THEN 4
    WHEN cd.CLASS = '4' THEN 5
    WHEN cd.CLASS = '5' THEN 6
    WHEN cd.CLASS = '6' THEN 7
    WHEN cd.CLASS = '7' THEN 8
    WHEN cd.CLASS = '8' THEN 9
    WHEN cd.CLASS = '9' THEN 10
    WHEN cd.CLASS = '10' THEN 11
    WHEN cd.CLASS = '11' THEN 12
    WHEN cd.CLASS = '12' THEN 13
    ELSE 14
  END,
  cd.SECTION;
    `;
    const queryParams = [teacherId];

    // 
    if (classId) {
      query += ` AND cd.CLASS = ?`;
      queryParams.push(classId);
    }
    if (sectionId) {
      query += ` AND cd.SECTION = ?`;
      queryParams.push(sectionId);
    }

    logger.info('Executing query', { query, params: queryParams });
    const [results] = await schoolDbConnection.query(query, queryParams);
    logger.info('getStudentList: Student list data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching student list', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { getStudentList };
