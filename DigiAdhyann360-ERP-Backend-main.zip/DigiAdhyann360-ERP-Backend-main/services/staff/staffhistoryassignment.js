const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');
 
const getStaffId = async (schoolDbConnection) => {
  if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
    logger.error('Service: AsyncLocalStorage is not properly initialized', { path: '/api/get-assignmentrecord' });
    throw new Error('AsyncLocalStorage is not properly initialized');
  }
 
  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.warn('Service: Unauthorized or missing context', { path: '/api/get-assignmentrecord' });
    throw new Error('Unauthorized or missing context');
  }
 
  const staffId = store.get('current_staff');
  if (!staffId) {
    logger.warn('Service: No current_staff found in AsyncLocalStorage', { path: '/api/get-assignmentrecord' });
    return null;
  }
 
  const [staffResult] = await schoolDbConnection.query(
    'SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?',
    [staffId]
  );
  if (staffResult.length === 0) {
    logger.warn('Service: No staff record found for staff ID', { staffId, path: '/api/get-assignmentrecord' });
    return null;
  }
 
  logger.info('Service: Staff ID validated', { staffId });
  return staffId;
};
 
exports.getAssignmentRecord = async () => {
  logger.info('Service: GET /api/get-assignmentrecord: Fetching assignment records');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/get-assignmentrecord' });
      throw new Error('Unauthorized or missing context');
    }
 
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/get-assignmentrecord' });
      throw new Error('School database connection not established');
    }
 
    const staffId = await getStaffId(schoolDbConnection);
    if (!staffId) {
      logger.info('Service: No valid staff ID found', { path: '/api/get-assignmentrecord' });
      throw new Error('No valid staff ID found');
    }
 
    const query = `
     SELECT
        ut.ASSIGNMENT_ID,
        ut.STUDENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
        sa.CLASS_ID,
        sa.SUBJECT_NAME,
        td.TEACHER_NAME AS CLASS_TEACHER,
        sa.ASSIGNMENT_TYPE,
        sa.ASSIGNMENT_DESC,
        sa.SUBMISSION_START_DATE,
        sa.SUBMISSION_END_DATE,
        ut.STATUS AS TeacherApprovalStatus,
        ut.STUDENT_SUBMITTED_DATE,
        sa.SUBMISSION_DATE,
        sa.IS_SUBMITTED,
        sa.STUDENT_STATUS
      FROM ACD_STUDENT_ASSIGNMENT_STATUS ut
      JOIN ACD_STUDENT_ASSIGNMENT sa ON ut.STUDENT_ID = sa.STUDENT_ID AND sa.ASSIGNMENT_ID = ut.ASSIGNMENT_ID
      JOIN ACD_STUDENT_PROFILE sp ON sp.STUDENT_ID = ut.STUDENT_ID
      JOIN ACD_STUDENT_CLASS_MAPPING cd ON cd.STUDENT_ID = sp.STUDENT_ID
      JOIN ACD_CLASS_SUB_TEACHER_MAPPING td ON sa.SUBJECT_NAME = td.SUBJECT AND cd.CLASS_ID = td.CLASS_ID
      JOIN ACD_STAFF_PROFILE s ON td.TEACHER_ID = s.STAFF_ID
        AND s.STAFF_ID = ?
    `;
 
    logger.info('Service: Executing assignment record query', { query, params: [staffId] });
    const [rows] = await schoolDbConnection.query(query, [staffId]);
 
    logger.info('Service: Assignment records fetched successfully', { staffId, count: rows.length });
    return rows;
  } catch (err) {
    logger.error('Service: Error fetching assignment records', { error: err.message, stack: err.stack, path: '/api/get-assignmentrecord' });
    throw err;
  }
};  
 