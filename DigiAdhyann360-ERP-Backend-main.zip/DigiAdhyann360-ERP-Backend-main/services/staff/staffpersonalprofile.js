const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getStaffPersonalProfile = async () => {
  logger.info('getStaffPersonalProfile: Fetching staff profile data');
  try {
    if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
      throw new Error('AsyncLocalStorage is not properly initialized');
    }

    const store = asyncLocalStorage.getStore();
    if (!store) {
      throw new Error('Unauthorized or missing context');
    }

    let staffId = store.get('current_staff');
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/staffpersonalprofile' });
      throw new Error('School database connection not established');
    }

    // If current_staff is not set, check if current_admin is a staff member
    if (!staffId) {
      const current_admin = store.get('current_admin');
      if (current_admin) {
        const [staffResult] = await schoolDbConnection.query(
          'SELECT STAFF_ID FROM ACD_STAFF_PROFILE WHERE STAFF_ID = ?',
          [current_admin]
        );
        if (staffResult.length > 0) {
          staffId = staffResult[0].STAFF_ID;
          logger.info('Administrator found as staff', { staffId: current_admin });
        } else {
          logger.warn('No staff ID found for current_admin', { current_admin, path: '/api/staffpersonalprofile' });
          return [];
        }
      } else {
        logger.warn('No current_staff or current_admin found in AsyncLocalStorage', { path: '/api/staffpersonalprofile' });
        return [];
      }
    }

    const query = `
      SELECT
        s.STAFF_ID,
        s.STAFF_NAME,
        s.MARITAL_STATUS,
        s.STAFF_ROLE,
        s.DATE_OF_JOINING,
        b.NET_SALARY AS MONTHLY_SALARY,
        s.FATHER_HUSBAND_NAME,
        s.GENDER,
        s.EXPERIENCE,
        s.ADHAR_ID,
        s.ADDRESS
      FROM
        ACD_STAFF_PROFILE   s
      left join ACC_STAFF_SALARY b on s.STAFF_ID = b.STAFF_ID
      WHERE
        s.STAFF_ID = ?
    `;
    logger.info('Executing query', { query, params: [staffId] });
    const [results] = await schoolDbConnection.query(query, [staffId]);
    logger.info('getStaffPersonalProfile: Staff profile data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching staff profile', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { getStaffPersonalProfile };