const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

//  Issue type mapping (hardcoded)
const issueTypeMap = {
  FEES: 101,
  TRANSPORT: 102,
  ACADEMICS: 103,
  BEHAVIOR: 104,
  OTHERS: 105,
};

const getCurrentStudentDetails = async (req) => {
  logger.info('Service: Fetching current student details', { path: '/api/getCurrentStudentDetails' });
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) throw new Error('Unauthorized or missing context');

    const schoolDbConnection = store.get('schoolDbConnection');
    const current_student = store.get('current_student');
    const current_admin = store.get('current_admin');
    let studentId = req.query.studentId || store.get('selected_student');

    if (!schoolDbConnection) throw new Error('School database connection not established');
    if (current_admin && !studentId) throw new Error('Admin must provide a student ID');
    if (!studentId && !current_student) throw new Error('User not authenticated');

    studentId = studentId || current_student;

    const query = `
      SELECT s.STUDENT_ID, p.PARENT_ID AS PARENT_ID,
             CONCAT(s.FIRST_NAME, ' ', IFNULL(s.MIDDLE_NAME, ''), ' ', s.LAST_NAME) AS STUDENT_NAME,
             s.CONTACT_NUMBER AS CONTACT, s.EMAIL
      FROM ACD_STUDENT_PROFILE s
      JOIN ACD_PARENT_PROFILE p ON s.STUDENT_ID = p.STUDENT_ID
      WHERE s.STUDENT_ID = ?
    `;

    logger.info('Service: Executing query', { query, params: [studentId] });
    const [students] = await schoolDbConnection.query(query, [studentId]);

    if (!students || students.length === 0) throw new Error('No student found');

    logger.info('Service: Student details fetched successfully', { studentId });
    return students[0];
  } catch (error) {
    logger.error('Service: Error fetching student details', {
      error: error.message,
      stack: error.stack,
      path: '/api/getCurrentStudentDetails',
    });
    throw error;
  }
};

const raiseIssue = async (req) => {
  logger.info('Service: Raising issue', { path: '/api/RaiseIssue' });
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) throw new Error('Unauthorized or missing context');

    const schoolDbConnection = store.get('schoolDbConnection');
    const current_student = store.get('current_student');
    const current_admin = store.get('current_admin');
    let studentId = req.query.studentId || store.get('selected_student');

    if (!schoolDbConnection) throw new Error('School database connection not established');
    if (current_admin && !studentId) throw new Error('Admin must provide a student ID');
    if (!studentId && !current_student) throw new Error('User not authenticated');

    studentId = studentId || current_student;

    const { issueType, description } = req.body;
    const attachment = req.file ? req.file.buffer : null;
    const issueDate = new Date();

    // ✅ Validate and map issue type
    const issueTypeUpperCase = issueType.toUpperCase();
    const issueTypeId = issueTypeMap[issueTypeUpperCase];

    logger.info("Mapped issueTypeId:", issueTypeId);
    logger.info("issueTypeUpperCase:", issueTypeUpperCase);

    if (!issueTypeId) {
      throw new Error('Invalid issue type selected');
    }

    // ✅ Insert into issue tracking table
    const query = `
      INSERT INTO ACD_STUDENT_ISSUE_TRACKING (
        STUDENT_ID,
        ISSUE_TYPE_ID,
        ISSUE_TYPE,
        DESCRIPTION,
        STATUS,
        ISSUE_DATE
      ) VALUES (?, ?, ?, ?, ?, ?)
    `;

    const values = [
      studentId,
      issueTypeId,
      issueTypeUpperCase,
      description.trim(),
      'PENDING',
      issueDate,
    ];

    logger.info('Service: Executing query', { query, params: values });
    const [result] = await schoolDbConnection.query(query, values);

    logger.info('Service: Issue raised successfully', { studentId, insertId: result.insertId });
    return result;
  } catch (error) {
    logger.error('Service: Error raising issue', {
      error: error.message,
      stack: error.stack,
      path: '/api/RaiseIssue',
    });
    throw error;
  }
};

module.exports = { getCurrentStudentDetails, raiseIssue };
