const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getSchoolDetails = async () => {
  logger.info('Service: Fetching school details', { path: '/api/getSchoolDetails' });
  console.log('Service: Entering getSchoolDetails');
  try {
    const store = asyncLocalStorage.getStore();
    console.log('Service: asyncLocalStorage store', { store });
    if (!store) {
      console.log('Service: Store is null');
      throw new Error('Unauthorized: Missing async context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      console.log('Service: No schoolDbConnection');
      throw new Error('Database error: School database connection not established');
    }

    const query = `
      SELECT SCHOOL_LOGO, SCHOOL_NAME, CITY, STATE 
      FROM ACD_SCHOOL_PROFILE
    `;
    console.log('Service: Running query', { query });
    const [results] = await schoolDbConnection.query(query);
    console.log('Service: Query results', { results });

    if (results.length === 0) {
      console.log('Service: No school details found');
      throw new Error('Not found: No school details available in database');
    }

    logger.info('Service: School details fetched successfully', { recordCount: results.length });
    console.log('Service: School details fetched', { result: results[0] });
    return results[0];
  } catch (error) {
    logger.error('Service: Error fetching school details', {
      error: error.message,
      stack: error.stack,
      path: '/api/getSchoolDetails',
    });
    console.log('Service: Error in getSchoolDetails', { error: error.message });
    throw error;
  }
};

const getStudentDetails = async (req) => {
  logger.info('Service: Fetching student details', { path: '/api/getStudentsstude' });
  console.log('Service: Entering getStudentDetails', { query: req.query });
  try {
    const store = asyncLocalStorage.getStore();
    console.log('Service: asyncLocalStorage store', { store });
    if (!store) {
      console.log('Service: Store is null');
      throw new Error('Unauthorized: Missing async context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    const current_student = store.get('current_student');
    const { studentId } = req.query;
    console.log('Service: studentId resolution', { studentId, current_student });

    if (!schoolDbConnection) {
      console.log('Service: No schoolDbConnection');
      throw new Error('Database error: School database connection not established');
    }

    if (!studentId && !current_student) {
      console.log('Service: No studentId or current_student');
      throw new Error('Unauthorized: Student not logged in or no studentId provided');
    }

    const query = `
      SELECT
        sp.STUDENT_ID,  
        CONCAT_WS(' ', sp.FIRST_NAME, sp.MIDDLE_NAME, sp.LAST_NAME) AS FULL_NAME,  
        sp.DATE_OF_BIRTH,  
        pp.FATHER_NAME,
        CASE
          WHEN CAST(fs.RECORD_CREATE_DT AS DATE) <= fs.DUE_END_DATE THEN 'ON-TIME'
          WHEN CAST(fs.RECORD_CREATE_DT AS DATE) > fs.DUE_END_DATE THEN 'LATE'
          ELSE 'OUTSTANDING'
        END AS STATUS,
        cd.CLASS
      FROM ACD_STUDENT_PROFILE sp  
      INNER JOIN ACD_PARENT_PROFILE pp ON pp.STUDENT_ID = sp.STUDENT_ID  
      INNER JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
      INNER JOIN ACC_FEE_COLLECTION_STATUS fs ON sp.STUDENT_ID = fs.STUDENT_ID AND fs.CLASS = cd.CLASS
      WHERE sp.STUDENT_ID = ?
    `;
    const finalStudentId = studentId || current_student;
    console.log('Service: Running query', { query, studentId: finalStudentId });
    const [results] = await schoolDbConnection.query(query, [finalStudentId]);
    console.log('Service: Query results', { results });

    if (results.length === 0) {
      console.log('Service: No student details found', { studentId: finalStudentId });
      throw new Error(`Not found: No student details found for ID ${finalStudentId}`);
    }

    logger.info('Service: Student details fetched successfully', { studentId: finalStudentId, recordCount: results.length });
    console.log('Service: Student details fetched', { results });
    return results;
  } catch (error) {
    logger.error('Service: Error fetching student details', {
      error: error.message,
      stack: error.stack,
      path: '/api/getStudentsstude',
    });
    console.log('Service: Error in getStudentDetails', { error: error.message });
    throw error;
  }
};

const getExamSchedule = async (req) => {
  logger.info('Service: Fetching exam schedule', { path: '/api/getExamSchedule' });
  console.log('Service: Entering getExamSchedule', { query: req.query });
  try {
    const store = asyncLocalStorage.getStore();
    console.log('Service: asyncLocalStorage store', { store });
    if (!store) {
      console.log('Service: Store is null');
      throw new Error('Unauthorized: Missing async context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    const { class: selectedClass } = req.query;
    console.log('Service: Class parameter', { selectedClass });

    if (!schoolDbConnection) {
      console.log('Service: No schoolDbConnection');
      throw new Error('Database error: School database connection not established');
    }

    if (!selectedClass) {
      console.log('Service: Missing class parameter');
      throw new Error('Bad request: Class parameter is required');
    }

    const query = `
      SELECT EXAM_DATE, EXAM_TYPE, SUBJECT_CODE, SUBJECT_NAME 
      FROM ACD_EXAM_SCHEDULE 
      WHERE CLASS = ? 
      AND EXAM_TYPE = (
        SELECT EXAM_TYPE 
        FROM ACD_EXAM_SCHEDULE 
        WHERE CLASS = ? 
        GROUP BY EXAM_TYPE 
        ORDER BY EXAM_DATE DESC 
        LIMIT 1
      )
    `;
    const queryParams = [selectedClass, selectedClass];
    console.log('Service: Running query', { query, queryParams });
    const [results] = await schoolDbConnection.query(query, queryParams);
    console.log('Service: Query results', { results });

    logger.info('Service: Exam schedule fetched successfully', { class: selectedClass, recordCount: results.length });
    console.log('Service: Exam schedule fetched', { results });
    return results;
  } catch (error) {
    logger.error('Service: Error fetching exam schedule', {
      error: error.message,
      stack: error.stack,
      path: '/api/getExamSchedule',
    });
    console.log('Service: Error in getExamSchedule', { error: error.message });
    throw error;
  }
};

const generateAdmitCard = async (req) => {
  logger.info('Service: Generating admit card', { path: '/api/generateAdmitCard' });
  console.log('Service: Entering generateAdmitCard', { body: req.body });
  try {
    const store = asyncLocalStorage.getStore();
    console.log('Service: asyncLocalStorage store', { store });
    if (!store) {
      console.log('Service: Store is null');
      throw new Error('Unauthorized: Missing async context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    const current_student = store.get('current_student');
    const { studentId, examType } = req.body;
    console.log('Service: Parameters', { studentId, examType, current_student });

    if (!schoolDbConnection) {
      console.log('Service: No schoolDbConnection');
      throw new Error('Database error: School database connection not established');
    }

    const finalStudentId = studentId || current_student;
    if (!finalStudentId) {
      console.log('Service: No studentId or current_student');
      throw new Error('Unauthorized: Student not logged in or no studentId provided');
    }

    if (!examType) {
      console.log('Service: Missing examType');
      throw new Error('Bad request: Exam type is required');
    }

    const statusQuery = `
      SELECT CASE
        WHEN CAST(fs.RECORD_CREATE_DT AS DATE) <= fs.DUE_END_DATE THEN 'ON-TIME'
        WHEN CAST(fs.RECORD_CREATE_DT AS DATE) > fs.DUE_END_DATE THEN 'LATE'
        ELSE 'OUTSTANDING'
      END AS STATUS
      FROM ACC_FEE_COLLECTION_STATUS fs
      WHERE STUDENT_ID = ?
      ORDER BY FREQUENCY DESC LIMIT 1
    `;
    console.log('Service: Running status query', { statusQuery, studentId: finalStudentId });
    const [statusResults] = await schoolDbConnection.query(statusQuery, [finalStudentId]);
    console.log('Service: Status query results', { statusResults });

 lanterns

    if (statusResults.length === 0 || !['ON-TIME', 'LATE'].includes(statusResults[0].STATUS)) {
      console.log('Service: Invalid fee status', { status: statusResults[0]?.STATUS });
      throw new Error('Forbidden: Cannot generate admit card due to unpaid fees');
    }

    logger.info('Service: Admit card generated successfully', { studentId: finalStudentId });
    console.log('Service: Admit card generated', { studentId: finalStudentId });
    return { success: true, message: 'Admit card generated successfully' };
  } catch (error) {
    logger.error('Service: Error generating admit card', {
      error: error.message,
      stack: error.stack,
      path: '/api/generateAdmitCard',
    });
    console.log('Service: Error in generateAdmitCard', { error: error.message });
    throw error;
  }
};

module.exports = { getSchoolDetails, getStudentDetails, getExamSchedule, generateAdmitCard };