const logger = require('../../logger/logger');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

const getAssignments = async () => {
  logger.info('getAssignments: Fetching assignments');
  try {
    const store = asyncLocalStorage.getStore();
    logger.debug('AsyncLocalStorage store contents in getAssignments', { store: store ? Object.fromEntries(store.entries()) : null });
    if (!store) {
      logger.error('No asyncLocalStorage context found');
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('GET /api/studenthistory/assignments: School database connection not established');
      throw new Error('School database connection not established');
    }
    const current_student = store.get('current_student');
    if (!current_student) {
      logger.warn('No current_student found in AsyncLocalStorage', { path: '/api/studenthistory/assignments' });
      throw new Error('Unauthorized: Student not logged in');
    }

    // Fetch class ID
    const classidSql = `SELECT CLASS_ID FROM SCHOOL_ERP_DATABASE.ACD_STUDENT_ASSIGNMENT WHERE STUDENT_ID = ?`;
    logger.info('Executing class ID query for student', { studentId: current_student });
    const [classidSqlResult] = await schoolDbConnection.query(classidSql, [current_student]);
    logger.info('Class ID query result', { result: classidSqlResult });

    if (classidSqlResult.length === 0) {
      logger.warn('No class found for the provided student', { studentId: current_student });
      throw new Error('No class found for the provided student');
    }

    const classId = classidSqlResult[0].CLASS_ID;
    logger.info('Class ID found', { classId });

    // Fetch assignment data
    const assignmentsSql = `
      SELECT
        sa.STUDENT_ID,
        sa.ASSIGNMENT_ID,
        sa.STUDENT_NAME,
        sa.CLASS_ID,
        sa.ASSIGNMENT_TYPE,
        sa.SUBJECT_NAME,
        sa.ASSIGNMENT_DESC,
        sa.SUBMISSION_START_DATE,
        sa.SUBMISSION_END_DATE,
        ut.STATUS
      FROM SCHOOL_ERP_DATABASE.ACD_STUDENT_ASSIGNMENT sa
      LEFT JOIN SCHOOL_ERP_DATABASE.ACD_STUDENT_ASSIGNMENT_SUBMISSION ut ON ut.STUDENT_ID = sa.STUDENT_ID AND sa.ASSIGNMENT_ID = ut.ASSIGNMENT_ID
      WHERE sa.STUDENT_ID = ?
        AND sa.CLASS_ID = ?
        AND sa.SUBMITTED = 0
    `;
    logger.info('Executing assignment query for student and class ID', { studentId: current_student, classId });
    const [assignmentsResult] = await schoolDbConnection.query(assignmentsSql, [current_student, classId]);
    logger.info('Assignments query result', { result: assignmentsResult });

    if (assignmentsResult.length === 0) {
      logger.warn('No assignments found for student and class ID', { studentId: current_student, classId });
      throw new Error('No assignments found for the provided student and class');
    }

    logger.info('Returning assignments data', { count: assignmentsResult.length });
    return assignmentsResult;
  } catch (err) {
    logger.error('Error fetching assignment table', { error: err.message, stack: err.stack });
    throw err;
  }
};

const submitAssignments = async (assignments) => {
  logger.info('submitAssignments: Processing assignment submissions', { assignments });
  try {
    const store = asyncLocalStorage.getStore();
    logger.debug('AsyncLocalStorage store contents in submitAssignments', { store: store ? Object.fromEntries(store.entries()) : null });
    if (!store) {
      logger.error('No asyncLocalStorage context found');
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('POST /api/studenthistory/submit-assignment: School database connection not established');
      throw new Error('School database connection not established');
    }

    if (!Array.isArray(assignments) || assignments.length === 0) {
      logger.warn('No assignments provided or not an array');
      throw new Error('No assignments provided');
    }

    const insertPromises = assignments.map(({ assignmentId, studentId }) => {
      if (!assignmentId || !studentId) {
        logger.warn('Missing assignmentId or studentId', { assignmentId, studentId });
        return Promise.reject('Missing assignmentId or studentId');
      }

      const query = 'INSERT INTO SCHOOL_ERP_DATABASE.ACD_STUDENT_ASSIGNMENT_SUBMISSION (ASSIGNMENT_ID, STUDENT_ID) VALUES (?, ?)';
      const values = [assignmentId, studentId];

      return new Promise((resolve, reject) => {
        schoolDbConnection.execute(query, values, (err, results) => {
          if (err) {
            logger.error('Database query error', { error: err.message });
            reject('Internal server error');
          } else {
            logger.info('Assignment submitted successfully', { results });
            resolve();
          }
        });
      });
    });

    await Promise.all(insertPromises);
    logger.info('Assignments submitted successfully', { count: assignments.length });
    return { message: 'Assignments submitted successfully' };
  } catch (err) {
    logger.error('Error during submission', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = {
  getAssignments,
  submitAssignments,
};