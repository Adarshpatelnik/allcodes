const logger = require('../../logger/logger');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

const getAssignmentHistory = async () => {
  logger.info('getAssignmentHistory: Fetching assignment history');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('No asyncLocalStorage context found');
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Database connection not established');
      throw new Error('Database connection error');
    }
    const current_student = store.get('current_student');
    if (!current_student) {
      logger.warn('No current_student found in AsyncLocalStorage', { path: '/api/studentassignmenthistory/assignmenthistory' });
      throw new Error('Unauthorized: Student not logged in');
    }

    const query = `
      SELECT sa.STUDENT_ID, sa.ASSIGNMENT_ID, sa.SUBJECT_NAME, sa.ASSIGNMENT_DESC,
             sa.SUBMISSION_START_DATE, sa.SUBMISSION_END_DATE, sa.STUDENT_STATUS, ut.STATUS
      FROM SCHOOL_ERP_DATABASE.ACD_STUDENT_ASSIGNMENT sa
      LEFT JOIN SCHOOL_ERP_DATABASE.ACD_STUDENT_ASSIGNMENT_SUBMISSION ut ON ut.STUDENT_ID = sa.STUDENT_ID
          AND sa.ASSIGNMENT_ID = ut.ASSIGNMENT_ID
      WHERE sa.STUDENT_STATUS != 'NOT SUBMITTED'
      AND sa.STUDENT_ID = ?
    `;

    logger.info('Executing SQL query', { query, params: [current_student] });
    const [results] = await schoolDbConnection.query(query, [current_student]);
    logger.info('getAssignmentHistory: Assignment history fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching assignment history', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = {
  getAssignmentHistory,
};