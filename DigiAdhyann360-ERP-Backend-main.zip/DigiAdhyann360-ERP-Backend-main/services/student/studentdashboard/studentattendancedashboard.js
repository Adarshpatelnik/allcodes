const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStudentId = async (schoolDbConnection) => {
  if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
    logger.error('Service: AsyncLocalStorage is not properly initialized', { path: '/api/dashbordstudentattendance' });
    throw new Error('AsyncLocalStorage is not properly initialized');
  }

  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.warn('Service: Unauthorized or missing context', { path: '/api/dashbordstudentattendance' });
    throw new Error('Unauthorized or missing context');
  }

  let studentId = store.get('current_student');
  if (!studentId) {
    const current_admin = store.get('current_admin');
    if (current_admin) {
      const [studentResult] = await schoolDbConnection.query(
        'SELECT STUDENT_ID FROM SCHOOL_ERP_DATABASE.ACD_STUDENT_PROFILE WHERE STUDENT_ID = ?',
        [current_admin]
      );
      if (studentResult.length > 0) {
        studentId = studentResult[0].STUDENT_ID;
        logger.info('Service: Administrator found as student', { studentId: current_admin });
      } else {
        logger.warn('Service: No student ID found for current_admin', { current_admin, path: '/api/dashbordstudentattendance' });
        return null;
      }
    } else {
      logger.warn('Service: No current_student or current_admin found in AsyncLocalStorage', { path: '/api/dashbordstudentattendance' });
      return null;
    }
  }
  return studentId;
};

exports.getDashboardStudentAttendance = async () => {
  logger.info('Service: GET /api/dashbordstudentattendance: Fetching student attendance data');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/dashbordstudentattendance' });
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/dashbordstudentattendance' });
      throw new Error('School database connection not established');
    }

    const studentId = await getStudentId(schoolDbConnection);
    if (!studentId) {
      logger.info('Service: No valid student ID found', { path: '/api/dashbordstudentattendance' });
      return [];
    }

    const query = `
      SELECT
        sp.STUDENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', COALESCE(sp.MIDDLE_NAME, ''), ' ', sp.LAST_NAME) AS STUDENT_NAME,
        cd.CLASS_ID AS CLASS,
        sa.ATTENDANCE_DATE,
        sa.STATUS
      FROM
        SCHOOL_ERP_DATABASE.ACD_STUDENT_PROFILE sp
      LEFT JOIN
        SCHOOL_ERP_DATABASE.ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
      LEFT JOIN
        SCHOOL_ERP_DATABASE.ACD_STUDENT_ATTENDANCE sa ON sp.STUDENT_ID = sa.STUDENT_ID
      WHERE
        sp.STUDENT_ID = ?
      ORDER BY
        sp.STUDENT_ID, sa.ATTENDANCE_DATE ASC
    `;

    logger.info('Service: Executing student attendance query', { query, params: [studentId] });
    const [attendanceResult] = await schoolDbConnection.query(query, [studentId]);

    if (!attendanceResult || attendanceResult.length === 0) {
      logger.info('Service: No attendance data found', { studentId, path: '/api/dashbordstudentattendance' });
      throw new Error('No attendance data found for the provided student ID.');
    }

    logger.info('Service: Student attendance data fetched successfully', { studentId, count: attendanceResult.length });
    return attendanceResult;
  } catch (err) {
    logger.error('Service: Error fetching student attendance', { error: err.message, stack: err.stack, path: '/api/dashbordstudentattendance' });
    throw err;
  }
};