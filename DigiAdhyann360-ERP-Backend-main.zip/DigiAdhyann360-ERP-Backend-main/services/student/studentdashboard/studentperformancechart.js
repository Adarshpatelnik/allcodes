const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStudentPerformanceChart = async () => {
  logger.info('getStudentPerformanceChart: Fetching student performance data');

  try {
    // Validate AsyncLocalStorage
    if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
      logger.error('AsyncLocalStorage is not properly initialized');
      throw new Error('AsyncLocalStorage is not properly initialized');
    }

    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.error('No AsyncLocalStorage store found');
      throw new Error('Unauthorized or missing context');
    }

    // Get studentId from store
    const studentId = store.get('current_student');
    const schoolDbConnection = store.get('schoolDbConnection');

    // Validate database connection
    if (!schoolDbConnection) {
      logger.error('School database connection not established', { path: '/api/studentperformancechart' });
      throw new Error('School database connection not established');
    }

    // Validate studentId
    if (!studentId) {
      logger.warn('No current_student found in AsyncLocalStorage', { path: '/api/studentperformancechart' });
      throw new Error('No student context found');
    }

    // Log the studentId for debugging
    logger.info('Fetching performance data for student', { studentId });

    // Query to fetch student performance data
    const query = `      
SELECT
  s.STUDENT_ID,
  s.CLASS,
  s.ACADEMIC_YEAR,
  s.SUBJECT_NAME,
 ROUND(
    SUM(CASE WHEN s.EXAM_TYPE = 'Annual' THEN s.MARKS ELSE 0 END) /
    NULLIF(SUM(CASE WHEN s.EXAM_TYPE = 'Annual' THEN e.TOTAL_MARKS ELSE 0 END), 0) * 100,
    2
  ) AS ANNUAL_PERCENTAGE,

  ROUND(
    SUM(CASE WHEN s.EXAM_TYPE = 'Half Yearly' THEN s.MARKS ELSE 0 END) /
    NULLIF(SUM(CASE WHEN s.EXAM_TYPE = 'Half Yearly' THEN e.TOTAL_MARKS ELSE 0 END), 0) * 100,
    2
  ) AS HALF_YEARLY_PERCENTAGE,

  ROUND(
    SUM(CASE WHEN s.EXAM_TYPE = 'QUARTERLY' THEN s.MARKS ELSE 0 END) /
    NULLIF(SUM(CASE WHEN s.EXAM_TYPE = 'QUARTERLY' THEN e.TOTAL_MARKS ELSE 0 END), 0) * 100,
    2
  ) AS QUARTERLY_PERCENTAGE

FROM ACD_MARKS_DETAIL s
JOIN ACD_EXAM_SCHEDULE e
  ON s.CLASS         = e.CLASS
 AND s.EXAM_NAME     = e.EXAM_NAME
 AND s.EXAM_TYPE     = e.EXAM_TYPE
 AND s.SUBJECT_NAME  = e.SUBJECT_NAME
WHERE s.STUDENT_ID = ?
GROUP BY
  s.STUDENT_ID,
  s.CLASS,
  s.ACADEMIC_YEAR,
  s.SUBJECT_NAME
ORDER BY
  s.STUDENT_ID,
  s.SUBJECT_NAME
`;

    logger.info('Executing query', { query, params: [studentId] });
    const [results] = await schoolDbConnection.query(query, [studentId]);

    if (results.length === 0) {
      logger.warn('No performance data found for student', { studentId });
      throw new Error('No student performance data found');
    }

    logger.info('getStudentPerformanceChart: Student performance data fetched successfully', { count: results.length });
    return results;
  } catch (err) {
    logger.error('Error fetching student performance data', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = { getStudentPerformanceChart };