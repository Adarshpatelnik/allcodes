const { asyncLocalStorage } = require('../../../middleware/authmiddleware');
const logger = require('../../../logger/logger');

const getStudentId = async (schoolDbConnection) => {
  if (!asyncLocalStorage || typeof asyncLocalStorage.getStore !== 'function') {
    logger.error('Service: AsyncLocalStorage is not properly initialized', { path: '/api/timetable' });
    throw new Error('AsyncLocalStorage is not properly initialized');
  }

  const store = asyncLocalStorage.getStore();
  if (!store) {
    logger.warn('Service: Unauthorized or missing context', { path: '/api/timetable' });
    throw new Error('Unauthorized or missing context');
  }

  const studentId = store.get('current_student');
  const currentAdmin = store.get('current_admin');
  const tenantId = store.get('tenantId');
  logger.info('Service: Checking AsyncLocalStorage for student ID', {
    current_student: studentId,
    current_admin: currentAdmin,
    tenantId,
    path: '/api/timetable',
  });

  if (studentId) {
    return studentId;
  }

  if (currentAdmin) {
    // Check if admin has a linked student profile
    const [studentResult] = await schoolDbConnection.query(
      'SELECT STUDENT_ID FROM SCHOOL_ERP_DATABASE.ACD_STUDENT_PROFILE WHERE STUDENT_ID = ?',
      [currentAdmin]
    );
    if (studentResult.length > 0) {
      logger.info('Service: Administrator found as student', { studentId: currentAdmin });
      return studentResult[0].STUDENT_ID;
    }
    // If admin is not a student, they may need to view all timetables or a specific student's timetable
    logger.warn('Service: Admin has no student profile, checking role permissions', {
      current_admin: currentAdmin,
      path: '/api/timetable',
    });
    throw new Error('Admins cannot fetch their own timetable. Please specify a student ID.');
  }

  logger.warn('Service: No current_student or current_admin found in AsyncLocalStorage', { path: '/api/timetable' });
  throw new Error('No valid user context found');
};

exports.getTimetable = async (req) => {
  logger.info('Service: GET /api/timetable: Fetching timetable data');
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/timetable' });
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/timetable' });
      throw new Error('School database connection not established');
    }

    const studentId = await getStudentId(schoolDbConnection);
    if (!studentId) {
      logger.info('Service: No valid student ID found', { path: '/api/timetable' });
      return [];
    }

    const timetableSql = `
      SELECT
        sp.STUDENT_ID,
        sc.PERIOD,
        sc.TIME_SLOT,
        sc.CLASS_ID,
        MAX(CASE WHEN DAY = 'MONDAY' THEN SUBJECT END) AS Monday,
        MAX(CASE WHEN DAY = 'TUESDAY' THEN SUBJECT END) AS Tuesday,
        MAX(CASE WHEN DAY = 'WEDNESDAY' THEN SUBJECT END) AS Wednesday,
        MAX(CASE WHEN DAY = 'THURSDAY' THEN SUBJECT END) AS Thursday,
        MAX(CASE WHEN DAY = 'FRIDAY' THEN SUBJECT END) AS Friday,
        MAX(CASE WHEN DAY = 'SATURDAY' THEN SUBJECT END) AS Saturday
      FROM
        SCHOOL_ERP_DATABASE.ACD_CLASS_SCHEDULE sc
      JOIN SCHOOL_ERP_DATABASE.ACD_STUDENT_CLASS_MAPPING cd ON sc.CLASS_ID = cd.CLASS_ID
      JOIN SCHOOL_ERP_DATABASE.ACD_STUDENT_PROFILE sp ON cd.STUDENT_ID = sp.STUDENT_ID
      WHERE sp.STUDENT_ID = ?
      GROUP BY sc.PERIOD, sc.TIME_SLOT, sc.CLASS_ID
      ORDER BY sc.PERIOD`;

    logger.info('Service: Executing timetable query', { query: timetableSql, params: [studentId] });
    const [timetableResult] = await schoolDbConnection.query(timetableSql, [studentId]);

    if (!timetableResult || timetableResult.length === 0) {
      logger.info('Service: No timetable found', { studentId, path: '/api/timetable' });
      throw new Error(`No timetable found for student ID: ${studentId}`);
    }

    logger.info('Service: Timetable data fetched successfully', { studentId, count: timetableResult.length });
    return timetableResult;
  } catch (err) {
    logger.error('Service: Error fetching timetable', { error: err.message, stack: err.stack, path: '/api/timetable' });
    throw err;
  }
};