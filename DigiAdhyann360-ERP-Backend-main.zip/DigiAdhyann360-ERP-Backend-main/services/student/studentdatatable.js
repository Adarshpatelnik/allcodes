const logger = require('../../logger/logger');
const { asyncLocalStorage } = require('../../middleware/authmiddleware');

const getStudentData = async () => {
  logger.info('getStudentData: Fetching student data');
  try {
    const store = asyncLocalStorage.getStore();
    logger.debug('AsyncLocalStorage store contents in getStudentData', { store: store ? Object.fromEntries(store.entries()) : null });
    if (!store) {
      logger.error('No asyncLocalStorage context found');
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('GET /api/studentdatatable/student-data: School database connection not established');
      throw new Error('School database connection not established');
    }
    const current_student = store.get('current_student');
    if (!current_student) {
      logger.warn('No current_student found in AsyncLocalStorage', { path: '/api/studentdatatable/student-data' });
      throw new Error('Unauthorized: Student not logged in');
    }

    const query = `
      SELECT 
        REQUEST_ID,
        REQUESTER_ID,
        REQUESTER_TYPE,
        FIRST_NAME,
        TYPE,
        OLDDATA,
        NEWDATA,
        STATUS,
        ISSUE
      FROM ACD_PROFILE_CHANGE_REQUEST
      WHERE STATUS = 'Pending'
    `;
    logger.info('Executing student data query');
    const [rows] = await schoolDbConnection.query(query);
    logger.info('Student data fetched successfully', { count: rows.length });
    return rows;
  } catch (err) {
    logger.error('Error fetching student data', { error: err.message, stack: err.stack });
    throw err;
  }
};

const updateStatus = async (REQUEST_ID, STATUS) => {
  logger.info('updateStatus: Updating status', { REQUEST_ID, STATUS });
  try {
    const store = asyncLocalStorage.getStore();
    logger.debug('AsyncLocalStorage store contents in updateStatus', { store: store ? Object.fromEntries(store.entries()) : null });
    if (!store) {
      logger.error('No asyncLocalStorage context found');
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('POST /api/studentdatatable/update-status: School database connection not established');
      throw new Error('School database connection not established');
    }

    if (STATUS !== 'Approved' && STATUS !== 'Rejected') {
      logger.warn('Invalid status received', { STATUS });
      throw new Error('Invalid status');
    }

    const query = `
      UPDATE ACD_PROFILE_CHANGE_REQUEST 
      SET STATUS = ? 
      WHERE REQUEST_ID = ?;
    `;
    logger.info('Executing update status query', { query, STATUS, REQUEST_ID });
    const [result] = await schoolDbConnection.query(query, [STATUS, REQUEST_ID]);
    logger.info('Update status query result', { result });

    if (result.affectedRows > 0) {
      return 'Status updated successfully';
    } else {
      logger.warn('Request not found for REQUEST_ID', { REQUEST_ID });
      throw new Error('Request not found');
    }
  } catch (err) {
    logger.error('Error updating status', { error: err.message, stack: err.stack });
    throw err;
  }
};

const updateStudentProfile = async (REQUESTER_ID) => {
  logger.info('updateStudentProfile: Updating student profile', { REQUESTER_ID });
  try {
    const store = asyncLocalStorage.getStore();
    logger.debug('AsyncLocalStorage store contents in updateStudentProfile', { store: store ? Object.fromEntries(store.entries()) : null });
    if (!store) {
      logger.error('No asyncLocalStorage context found');
      throw new Error('Unauthorized or missing context');
    }
    const schoolDbConnection = store.get('schoolDbConnection');
    if (!schoolDbConnection) {
      logger.error('POST /api/studentdatatable/update-student-profile: School database connection not established');
      throw new Error('School database connection not established');
    }

    if (!REQUESTER_ID) {
      logger.warn('REQUESTER_ID is required', { REQUESTER_ID });
      throw new Error('REQUESTER_ID is required');
    }

    const query = `
      UPDATE ACD_STUDENT_PROFILE sp
      LEFT JOIN (
        SELECT 
          REQUESTER_ID, 
          MAX(CASE WHEN TYPE = 'CONTACT_NUMBER' THEN NEWDATA END) AS CONTACT_NUMBER,
          MAX(CASE WHEN TYPE = 'CITY' THEN NEWDATA END) AS CITY,
          MAX(CASE WHEN TYPE = 'EMAIL' THEN NEWDATA END) AS EMAIL,
          MAX(CASE WHEN TYPE = 'EMERGENCY_CONTACT_NUMBER' THEN NEWDATA END) AS EMERGENCY_CONTACT_NUMBER,
          MAX(CASE WHEN TYPE = 'POSTAL_CODE' THEN NEWDATA END) AS POSTAL_CODE
        FROM ACD_PROFILE_CHANGE_REQUEST 
        WHERE REQUESTER_ID = ?
        GROUP BY REQUESTER_ID
      ) AS req ON req.REQUESTER_ID = sp.STUDENT_ID
      SET 
        sp.CONTACT_NUMBER = req.CONTACT_NUMBER,
        sp.CITY = req.CITY,
        sp.EMAIL = req.EMAIL,
        sp.EMERGENCY_CONTACT_NUMBER = req.EMERGENCY_CONTACT_NUMBER,
        sp.POSTAL_CODE = req.POSTAL_CODE
      WHERE sp.STUDENT_ID = ?;
    `;
    logger.info('Executing update student profile query', { REQUESTER_ID });
    const [result] = await schoolDbConnection.query(query, [REQUESTER_ID, REQUESTER_ID]);
    logger.info('Update student profile query result', { result });

    if (result.affectedRows > 0) {
      return 'Student profile updated successfully';
    } else {
      logger.warn('No profile found for the provided REQUESTER_ID', { REQUESTER_ID });
      throw new Error('No profile found for the provided REQUESTER_ID');
    }
  } catch (err) {
    logger.error('Error updating student profile', { error: err.message, stack: err.stack });
    throw err;
  }
};

module.exports = {
  getStudentData,
  updateStatus,
  updateStudentProfile,
};