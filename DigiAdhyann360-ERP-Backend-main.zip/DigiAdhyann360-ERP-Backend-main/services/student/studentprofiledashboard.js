
const { asyncLocalStorage } = require('../../middleware/authmiddleware');
const logger = require('../../logger/logger');

const getStudentProfile = async (req) => {
  logger.info('Service: Fetching student profile', { path: '/api/student-profile' });
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/student-profile' });
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    const current_student = store.get('current_student');
    const current_admin = store.get('current_admin');
    let studentId = req.query.studentId || store.get('selected_student');

    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/student-profile' });
      throw new Error('School database connection not established');
    }

    if (current_admin && !studentId) {
      logger.warn('Service: Admin must provide a student ID', { current_admin, path: '/api/student-profile' });
      throw new Error('Admin must provide a student ID');
    }

    if (!studentId && !current_student) {
      logger.warn('Service: Missing current student context and no studentId provided', { path: '/api/student-profile' });
      throw new Error('Missing current student context');
    }

    studentId = studentId || current_student;

    const query = `
      SELECT
        sp.STUDENT_ID,
        CONCAT(sp.FIRST_NAME, ' ', sp.MIDDLE_NAME, ' ', sp.LAST_NAME) AS STUDENT_NAME,
        cd.CLASS_ID AS CLASS,
        sp.GENDER,
        sp.CONTACT_NUMBER,
        sp.POSTAL_CODE,
        sp.DATE_OF_BIRTH,
        sp.EMAIL,
        sp.BLOOD_GROUP
      FROM ACD_STUDENT_PROFILE sp
      JOIN ACD_STUDENT_CLASS_MAPPING cd ON sp.STUDENT_ID = cd.STUDENT_ID
      WHERE sp.STUDENT_ID = ?
    `;

    logger.info('Service: Executing query', { query, params: [studentId] });
    const [results] = await schoolDbConnection.query(query, [studentId]);

    logger.info('Service: Student profile fetched successfully', { studentId, recordCount: results.length });
    return results;
  } catch (error) {
    logger.error('Service: Error fetching student profile', {
      error: error.message,
      stack: error.stack,
      path: '/api/student-profile',
    });
    throw error;
  }
};

const updateStudentProfile = async (req) => {
  logger.info('Service: Updating student profile', { path: '/api/student-profile' });
  try {
    const store = asyncLocalStorage.getStore();
    if (!store) {
      logger.warn('Service: Unauthorized or missing context', { path: '/api/student-profile' });
      throw new Error('Unauthorized or missing context');
    }

    const schoolDbConnection = store.get('schoolDbConnection');
    const current_student = store.get('current_student');
    let studentId = req.body.studentId || current_student;

    if (!schoolDbConnection) {
      logger.error('Service: School database connection not established', { path: '/api/student-profile' });
      throw new Error('School database connection not established');
    }

    if (!studentId) {
      logger.warn('Service: Missing student ID for update', { path: '/api/student-profile' });
      throw new Error('Missing student ID');
    }

    const {
      StudentName,
      Class,
      Gender,
      ContactNumber,
      PostalCode,
      DateOfBirth,
      Email,
      BloodGroup,
    } = req.body;

    // Split StudentName into FirstName, MiddleName, LastName
    const nameParts = StudentName.split(' ');
    const FIRST_NAME = nameParts[0] || '';
    const MIDDLE_NAME = nameParts[1] || '';
    const LAST_NAME = nameParts[2] || '';

    const query = `
      UPDATE ACD_STUDENT_PROFILE
      SET 
        FIRST_NAME = ?,
        MIDDLE_NAME = ?,
        LAST_NAME = ?,
        GENDER = ?,
        CONTACT_NUMBER = ?,
        POSTAL_CODE = ?,
        DATE_OF_BIRTH = ?,
        EMAIL = ?,
        BLOOD_GROUP = ?,
        UPDATE_DATE = CURRENT_TIMESTAMP,
        UPDATED_BY = ?
      WHERE STUDENT_ID = ?
    `;

    const updatedBy = store.get('current_user') || 'SYSTEM';
    const params = [
      FIRST_NAME,
      MIDDLE_NAME,
      LAST_NAME,
      Gender,
      ContactNumber,
      PostalCode,
      DateOfBirth,
      Email,
      BloodGroup,
      updatedBy,
      studentId,
    ];

    logger.info('Service: Executing update query', { query, params });
    const [result] = await schoolDbConnection.query(query, params);

    if (result.affectedRows === 0) {
      logger.warn('Service: No rows updated', { studentId, path: '/api/student-profile' });
      throw new Error('No student profile updated');
    }

    logger.info('Service: Student profile updated successfully', { studentId, affectedRows: result.affectedRows });
    return { message: 'Student profile updated successfully', studentId };
  } catch (error) {
    logger.error('Service: Error updating student profile', {
      error: error.message,
      stack: error.stack,
      path: '/api/student-profile',
    });
    throw error;
  }
};

module.exports = { getStudentProfile, updateStudentProfile };