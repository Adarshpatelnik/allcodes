
const { GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { S3Client } = require('@aws-sdk/client-s3');
const { AWS_CONFIG } = require('./constants');

// Initialize S3 client
const s3Client = new S3Client({
  region: AWS_CONFIG.region,
  credentials: {
    accessKeyId: AWS_CONFIG.accessKeyId,
    secretAccessKey: AWS_CONFIG.secretAccessKey
  }
});

// Generate pre-signed URL for S3 object
const generateSignedUrl = async (bucket, key, expiresIn = 3600) => {
  try {
    const command = new GetObjectCommand({
      Bucket: bucket,
      Key: key
    });
    const url = await getSignedUrl(s3Client, command, { expiresIn });
    return url;
  } catch (error) {
    console.error('Error generating signed URL:', error);
    throw new Error('Failed to generate signed URL');
  }
};

// Placeholder for caching logic (e.g., Redis or in-memory cache)
const cache = {
  set: async (key, value, ttl) => {
    // Implement caching logic (e.g., using Redis or in-memory store)
    console.log(`Caching ${key} with TTL ${ttl}`);
    // Example: redis.set(key, value, 'EX', ttl);
  },
  get: async (key) => {
    // Implement cache retrieval logic
    console.log(`Retrieving cache for ${key}`);
    // Example: return redis.get(key);
    return null;
  },
  del: async (key) => {
    // Implement cache deletion logic
    console.log(`Deleting cache for ${key}`);
    // Example: redis.del(key);
  }
};

module.exports = {
  generateSignedUrl,
  cache
};