
require('dotenv').config({ path: './.env' });

const PORT = process.env.PORT || 2081;

const RAZORPAY_CONFIG = {
  key_id: 'rzp_test_Dv9OW9PBamHoTf',
  key_secret: 'CR7M2LF9pv9TELppscGQ47N5'
};

const SENDGRID_CONFIG = {
  apiKey: process.env.SENDGRID_API_KEY,
  fromEmail: process.env.FROM_EMAIL
};

const TWILIO_CONFIG = {
  accountSid: process.env.REACT_APP_TWILIO_ACCOUNT_SID,
  authToken: process.env.REACT_APP_TWILIO_AUTH_TOKEN,
  phoneNumber: process.env.REACT_APP_TWILIO_PHONE_NUMBER
};

const AWS_CONFIG = {
  region: process.env.AWS_REGION,
  bucketName: process.env.AWS_BUCKET_NAME,
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_KEY_ID
};

const MULTER_CONFIG = {
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB limit
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype === 'text/csv' ||
      file.mimetype === 'application/vnd.ms-excel' ||
      file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ) {
      cb(null, true);
    } else {
      cb(new Error('Only .csv, .xls, and .xlsx files are allowed!'), false);
    }
  }
};

module.exports = {
  PORT,
  RAZORPAY_CONFIG,
  SENDGRID_CONFIG,
  TWILIO_CONFIG,
  AWS_CONFIG,
  MULTER_CONFIG
};