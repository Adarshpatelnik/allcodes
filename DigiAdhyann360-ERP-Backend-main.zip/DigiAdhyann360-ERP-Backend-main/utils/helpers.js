
const { parsePhoneNumberFromString } = require('libphonenumber-js');
const { pool } = require('../db'); // Assuming db.js is in the root directory

// Helper function to check if username exists
const usernameExists = async (username) => {
  const userCheckSql = "SELECT 1 FROM USERS WHERE USERNAME = ?";
  const [userCheckResult] = await pool.query(userCheckSql, [username]);
  return userCheckResult.length > 0;
};

// Helper function to check if email exists
const emailExists = async (email) => {
  const emailCheckSql = "SELECT 1 FROM USERS WHERE EMAIL = ?";
  const [emailCheckResult] = await pool.query(emailCheckSql, [email]);
  return emailCheckResult.length > 0;
};

// Helper function to check if database exists
const databaseExists = async (dbName) => {
  const checkDbSql = "SHOW DATABASES LIKE ?";
  const [dbResult] = await pool.query(checkDbSql, [dbName]);
  return dbResult.length > 0;
};

// Function to send messages via Twilio
const sendMessage = (to, body, isWhatsApp, mediaUrl) => {
  const twilio = require('twilio');
  const accountSid = process.env.REACT_APP_TWILIO_ACCOUNT_SID;
  const authToken = process.env.REACT_APP_TWILIO_AUTH_TOKEN;
  const twilioPhoneNumber = process.env.REACT_APP_TWILIO_PHONE_NUMBER;
  const client = new twilio(accountSid, authToken);

  const toStr = String(to).trim();
  console.log(`Original phone number: ${toStr}`);
  
  const phoneNumberStr = toStr.startsWith('+') ? toStr : `+91${toStr}`;
  console.log(`Processed phone number: ${phoneNumberStr}`);

  try {
    const phoneNumber = parsePhoneNumberFromString(phoneNumberStr, 'IN');
    if (!phoneNumber) {
      throw new Error('Phone number parsing failed.');
    }

    if (phoneNumber.isValid()) {
      const formattedNumber = phoneNumber.format('E.164');
      console.log(`Formatted phone number: ${formattedNumber}`);
      
      const messageType = isWhatsApp ? 'whatsapp' : 'sms';
      const fromNumber = isWhatsApp ? `whatsapp:${twilioPhoneNumber}` : twilioPhoneNumber;

      const messageData = {
        body: body,
        to: `${messageType}:${formattedNumber}`,
        from: fromNumber
      };

      if (mediaUrl) {
        messageData.mediaUrl = mediaUrl;
      }

      client.messages.create(messageData)
        .then((message) => console.log(`Message sent successfully to ${formattedNumber} with SID: ${message.sid}`))
        .catch((error) => console.error(`Failed to send message to ${formattedNumber}:`, error));
    } else {
      console.error(`Invalid phone number format: ${phoneNumberStr}`);
    }
  } catch (error) {
    console.error(`Error processing phone number: ${error.message}`);
  }
};

// Function to create folder structure in S3
const createS3FolderStructure = async (schoolCode) => {
  const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
  const s3Client = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_KEY_ID,
    }
  });

  const folderStructure = [
    `${schoolCode}/Students/Applicants/`,
    `${schoolCode}/Students/Enrolled/`,
    `${schoolCode}/Staff/Applicants/`,
    `${schoolCode}/Staff/Enrolled/`,
    `${schoolCode}/School-details/`
  ];

  try {
    const createFolderPromises = folderStructure.map((folder) =>
      s3Client.send(
        new PutObjectCommand({
          Bucket: process.env.AWS_BUCKET_NAME,
          Key: folder,
          Body: '',
        })
      )
    );

    await Promise.all(createFolderPromises);
    console.log(`Folder structure for ${schoolCode} created successfully in S3.`);
  } catch (error) {
    console.error('Error creating folder structure in S3:', error);
    throw new Error('Failed to create folder structure in S3');
  }
};

module.exports = {
  usernameExists,
  emailExists,
  databaseExists,
  sendMessage,
  createS3FolderStructure
};