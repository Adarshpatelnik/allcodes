import React from 'react'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from './components/Login'
import { ToastContainer } from 'react-toastify';
import LandingPage from './LandingPage'
import SignUp from './components/SignUp';
import  Contact from './components/ContactUs';

function App() {
 

  return (
    <>

<Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path='/login' element={<Login/>}/>
        <Route path='/signup' element={<SignUp/>}/>
        <Route path='/contact' element={<Contact/>}/>
      </Routes>
    </Router>
      <ToastContainer />
    </>
  )
}

export default App
