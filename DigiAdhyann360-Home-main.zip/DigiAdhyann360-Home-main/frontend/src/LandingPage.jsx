import React, { useState } from 'react';
import {
  School, Users, GraduationCap, ArrowRight, BarChart,
  Shield, Clock, Globe, CheckCircle, Menu, X, LogIn,
  Facebook, Twitter, Github, Trophy, Video, LucideBookOpenCheck,
  Sun, Moon
} from 'lucide-react';
import PricingSection from './components/Pricing';
import LogoLight from '../src/assets/B2B Logo.png'
import LogoDark from '../src/assets/BITTWOBYTE Final Logo-2.png'

// Navigation Link Component
const NavLink = ({ children, href, darkMode }) => (
  <a
    href={href}
    className={`relative text-base md:text-lg font-semibold transition-all duration-300 hover:scale-110 group ${darkMode ? 'text-gray-300 hover:text-green-700' : 'text-gray-800 hover:text-green-800'}`}
  >
    {children}
    <span className={`absolute -bottom-1 left-0 h-0.5 w-full transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ${darkMode ? 'bg-green-700' : 'bg-green-800'}`}></span>
  </a>
);

// Card Component with Enhanced Effects
const Card = ({ icon, title, description, features, color, darkMode }) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleAccessClick = (e) => {
    e.stopPropagation(); // Prevent event bubbling to parent elements
    console.log(`Button clicked for ${title} at ${new Date().toISOString()}`);
     if (title === "Adhyayan ERP") {
      window.location.href = 'https://erp.adhyayan360.com/';
    } else {
      console.log(`Accessing ${title}`);
    }
  };

  return (
    <div
      className={`relative rounded-2xl p-4 sm:p-6 shadow-lg transition-all duration-500 transform  ${darkMode ? `bg-gradient-to-br from-${color}-900/30 to-gray-800 border-${color}-900/40` : `bg-gradient-to-br from-${color}-50 to-white border-${color}-100`}`}
    >
      <div className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${darkMode ? `from-${color}-700/20 to-transparent` : `from-${color}-200/20 to-transparent`} opacity-0 hover:opacity-100 transition-opacity duration-300 z-0`}></div>
      <div className={`relative flex items-center gap-3 mb-4 sm:mb-6 transition-all duration-500 ${isHovered ? 'scale-110 rotate-6' : ''}`}>
        <div className={`h-12 w-12 sm:h-16 sm:w-16 rounded-xl flex items-center justify-center shadow-md ${darkMode ? `bg-${color}-900/60` : `bg-${color}-100`}`}>
          {icon}
        </div>
        <h3 className={`relative text-xl sm:text-2xl font-extrabold tracking-tight whitespace-nowrap ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>
  {title}
  <span className={`absolute -bottom-1 left-0 h-0.5 w-full transform ${isHovered ? 'scale-x-100' : 'scale-x-0'} transition-transform duration-300 ${darkMode ? `bg-${color}-400` : `bg-${color}-600`}`}></span>
</h3>
      </div>
     
      <p className={`text-sm sm:text-base mb-4 sm:mb-6 leading-relaxed ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{description}</p>
      <ul className="space-y-3 sm:space-y-4 mb-4 sm:mb-6">
        {features.map((feature, index) => (
          <li key={index} className={`flex items-center text-xs sm:text-sm transition-all duration-300 ${isHovered ? 'translate-x-2' : ''} ${darkMode ? 'text-gray-300' : 'text-gray-800'}`}>
            <CheckCircle className={`h-4 w-4 sm:h-5 sm:w-5 mr-2 sm:mr-3 transition-transform duration-300 ${isHovered ? 'scale-125 rotate-12' : ''} ${
              color === 'blue' ? (darkMode ? 'text-blue-400' : 'text-blue-600') :
              color === 'green' ? (darkMode ? 'text-green-400' : 'text-green-600') :
              color === 'amber' ? (darkMode ? 'text-amber-400' : 'text-amber-600') :
              color === 'rose' ? (darkMode ? 'text-rose-400' : 'text-rose-600') :
              color === 'lime' ? (darkMode ? 'text-lime-400' : 'text-lime-600') :
              (darkMode ? 'text-violet-400' : 'text-violet-600')
            }`} />
            {feature}
          </li>
        ))}
      </ul>
      <div className="space-y-3 sm:space-y-4">
        {title === "Adhyayan Tutor" || (title !== "Adhyayan ERP") ? (
          <button
            className={`w-full text-white py-2 sm:py-3 px-4 sm:px-6 rounded-xl font-semibold transition-all duration-300 cursor-not-allowed opacity-75 text-sm sm:text-base
              ${title === "Adhyayan SmartExam" ? "bg-amber-600 hover:bg-amber-700" :
                title === "Adhyayan T-Connect" ? "bg-green-600 hover:bg-green-700"  :
                title === "Adhyayan M-Connect" ? "bg-rose-600 hover:bg-rose-700" :
                title === "Adhyayan Events" ? "bg-lime-700 hover:bg-lime-800" :
                title === "Adhyayan Tutor" ? "bg-violet-600 hover:bg-violet-700" :
                "bg-gray-600 hover:bg-gray-700"}`}
          >
            Coming Soon...
          </button>
        ) : (
          <button
            onClick={handleAccessClick}
            className={`relative w-full bg-gradient-to-r text-white py-2 sm:py-3 px-4 sm:px-6 rounded-xl font-semibold text-sm sm:text-base cursor-pointer z-10
              ${color === 'blue' ? 'from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800' :
                'from-green-600 to-green-700 hover:from-green-700 hover:to-green-800'}`}
          >
            <span className="flex items-center justify-center gap-2 sm:gap-3">
              <LogIn className="w-4 h-4 sm:w-5 sm:h-5 pointer-events-none" />
              {title === "Adhyayan T-Connect" ? "Access Adhyayan T-Connect" : `Access ${title}`}
            </span>
          </button>
        )}
      </div>
    </div>
  );
};

// Main Landing Page Component
function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(true);

  const handleAccessClick = () => {
    window.location.href = '/contact';
  };

  return (
    
    <div className={`min-h-screen transition-colors duration-500 ${darkMode ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-green-50'}`}>
      {/* Navigation */}
      <nav className={`fixed w-full z-50 shadow-lg ${darkMode ? 'bg-gradient-to-b from-gray-900/95 to-gray-800/90 backdrop-blur-lg' : 'bg-gradient-to-b from-white/95 to-gray-50/90 backdrop-blur-lg'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            <div className="flex items-center gap-2 sm:gap-3">
              <img 
  src={darkMode ? LogoDark : LogoLight} 
  alt="Logo" 
  className='w-10 h-10'
/>
              <span className={`text-2xl sm:text-3xl font-extrabold tracking-tight transition-all duration-300 hover:text-opacity-80 ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>Adhyayan360</span>
            </div>
            <div className="hidden md:flex items-center gap-6 lg:gap-10">
              <NavLink href="#solutions" darkMode={darkMode}>Solutions</NavLink>
              <NavLink href="#features" darkMode={darkMode}>Features</NavLink>
              <NavLink href="#pricing" darkMode={darkMode}>Pricing</NavLink>
              <NavLink href="/Contact" darkMode={darkMode}>Contact</NavLink>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`p-2 rounded-full transition-all duration-500 transform hover:rotate-180 ${darkMode ? 'bg-gray-700/50 hover:bg-gray-600' : 'bg-gray-200/50 hover:bg-gray-300'}`}
              >
                {darkMode ? <Sun className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-400" /> : <Moon className="h-5 w-5 sm:h-6 sm:w-6 text-gray-700" />}
              </button>
            </div>
            <button
              className={`md:hidden p-2 rounded-full transition-all duration-300 transform hover:scale-110 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-200'}`}
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6 sm:h-7 sm:w-7" /> : <Menu className="h-6 w-6 sm:h-7 sm:w-7" />}
            </button>
          </div>
        </div>
        {isMenuOpen && (
          <div className={`md:hidden shadow-lg transition-all duration-300 transform ${isMenuOpen ? 'scale-y-100 opacity-100' : 'scale-y-0 opacity-0'} origin-top ${darkMode ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-white to-gray-50'}`}>
            <div className="px-4 pt-4 pb-6 space-y-2 sm:space-y-3">
              {["Solutions", "Features", "Pricing", "Contact"].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className={`block px-4 py-2 sm:py-3 rounded-lg transition-all duration-300 hover:scale-105 text-sm sm:text-base transform hover:translate-x-2 ${darkMode ? 'text-gray-300 hover:bg-gray-700 hover:text-green-700' : 'text-gray-700 hover:bg-blue-50 hover:text-green-800'}`}
                >
                  {item}
                </a>
              ))}
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`w-full text-left px-4 py-2 sm:py-3 rounded-lg transition-all duration-500 hover:scale-105 flex items-center gap-2 sm:gap-3 text-sm sm:text-base transform hover:translate-x-2 ${darkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-blue-50'}`}
              >
                {darkMode ? <Sun className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-400 transition-transform duration-500 hover:rotate-180" /> : <Moon className="h-5 w-5 sm:h-6 sm:w-6 text-gray-700 transition-transform duration-500 hover:rotate-180" />}
                {darkMode ? 'Light Mode' : 'Dark Mode'}
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <header className="relative overflow-hidden pt-16 sm:pt-24">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-green-500/10 to-transparent transition-opacity duration-1000 opacity-50 hover:opacity-75"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 sm:pt-20 pb-12 sm:pb-16 text-center relative z-10">
          <h1 className={`text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold mb-4 sm:mb-6 leading-tight transition-all duration-500 ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>
            Transform Education with
            <span className={`block mt-1 sm:mt-2 relative ${darkMode ? 'text-green-600' : 'text-green-800'}`}>
              Adhyayan360 Unified
            </span>
          </h1>
          <p className={`text-base sm:text-xl md:text-2xl max-w-3xl mx-auto mb-6 sm:mb-10 leading-relaxed transition-all duration-300 transform ${darkMode ? 'text-white' : 'text-black'}`}>
            A revolutionary edutech ecosystem uniting school management, recruitment, and tutoring in one seamless platform.
          </p>
          <button
            onClick={() => document.getElementById('solutions').scrollIntoView({ behavior: 'smooth' })}
            className={`relative bg-gradient-to-r text-white px-6 sm:px-10 py-3 sm:py-4 rounded-full text-sm sm:text-lg font-semibold transition-all duration-500 transform hover:scale-105 hover:shadow-xl inline-flex items-center gap-2 sm:gap-3 overflow-hidden ${darkMode ? 'from-green-700 to-green-800 hover:from-green-800 hover:to-green-900' : 'from-green-700 to-green-800 hover:from-green-800 hover:to-green-900'}`}
          >
            <span className="absolute inset-0 bg-white/20 opacity-0 hover:opacity-100 transition-opacity duration-300 transform -skew-x-12 cursor-pointer"></span>
            Get Started <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 transition-transform duration-500 hover:translate-x-2 hover:rotate-12" />
          </button>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-8 py-8 sm:py-12">
            {[
              { number: "500+", label: "Schools" },
              { number: "10k+", label: "Teachers" },
              { number: "50k+", label: "Students" },
              { number: "95%", label: "Satisfaction" },
            ].map((stat, index) => (
              <div key={index} className="text-center transform transition-all duration-500 hover:-translate-y-2 hover:scale-105">
                <div className={`text-2xl sm:text-4xl font-extrabold transition-colors duration-300 ${darkMode ? 'text-green-700 hover:text-green-600' : 'text-green-900 hover:text-green-800'}`}>{stat.number}</div>
                <div className={`mt-1 sm:mt-2 text-sm sm:text-base ${darkMode ? 'text-white' : 'text-black'}`}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section id="solutions" className={`py-16 sm:py-24 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-center mb-10 sm:mb-16 tracking-tight relative ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>
            Our Integrated Solutions
            <span className={`absolute -bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-24 rounded-full bg-gradient-to-r ${darkMode ? 'from-green-500 to-blue-500' : 'from-green-600 to-blue-600'} transition-all duration-500 hover:w-32`}></span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-10">
            <Card
              icon={<School className={`h-6 w-6 sm:h-8 sm:w-8 ${darkMode ? 'text-blue-400' : 'text-blue-700'}`} />}
              title="Adhyayan ERP"
              description="Streamline school operations with a robust management system for admissions, attendance, grades, and more."
              color="blue"
              features={['Student Management', 'Fee Management', 'Attendance Tracking', 'Report Generation']}
              darkMode={darkMode}
            />
            <Card
              icon={<LucideBookOpenCheck className={`h-6 w-6 sm:h-8 sm:w-8 ${darkMode ? 'text-amber-400' : 'text-amber-700'}`} />}
              title="Adhyayan SmartExam"
              description="Boost preparation with tailored mock tests for various subjects and skill levels, ensuring targeted improvement and confidence."
              color="amber"
              features={['Timed Practice Tests', 'Subject-Specific Questions', 'Instant Feedback', 'Progress Tracking']}
              darkMode={darkMode}
            />
            <Card
              icon={<Users className={`h-6 w-6 sm:h-8 sm:w-8 ${darkMode ? 'text-green-400' : 'text-green-700'}`} />}
              title="Adhyayan T-Connect"
              description="Connect schools with top educators through a specialized job portal designed for recruitment."
              color="green"
              features={['Job Postings', 'Candidate Screening', 'Interview Scheduling', 'Profile Management']}
              darkMode={darkMode}
            />
            <Card
              icon={<Video className={`h-6 w-6 sm:h-8 sm:w-8 ${darkMode ? 'text-rose-400' : 'text-rose-700'}`} />}
              title="Adhyayan M-Connect"
              description="Personalized one-on-one mentorship to accelerate learning and career growth."
              color="rose"
              features={['Expert Guidance', 'One-on-One Sessions', 'Career Advice', 'Flexible Scheduling']}
              darkMode={darkMode}
            />
            <Card
              icon={<Trophy className={`h-6 w-6 sm:h-8 sm:w-8 ${darkMode ? 'text-lime-400' : 'text-lime-700'}`} />}
              title="Adhyayan Events"
              description="Engage in inter-school sports, tournaments, and training sessions."
              color="lime"
              features={['Competitions', 'Sports Events', 'Coaching', 'Live Updates']}
              darkMode={darkMode}
            />
            <Card
              icon={<GraduationCap className={`h-6 w-6 sm:h-8 sm:w-8 ${darkMode ? 'text-violet-400' : 'text-violet-700'}`} />}
              title="Adhyayan Tutor"
              description="Access qualified tutors for personalized learning across subjects and grades."
              color="violet"
              features={['Tutor Search', 'Booking System', 'Reviews & Ratings', 'Online Sessions']}
              darkMode={darkMode}
            />
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="features" className={`py-16 sm:py-24 ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-center mb-10 sm:mb-16 tracking-tight relative ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>
            Why Choose Adhyayan360?
            <span className={`absolute -bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-24 rounded-full bg-gradient-to-r ${darkMode ? 'from-green-500 to-blue-500' : 'from-green-600 to-blue-600'} transition-all duration-500 hover:w-32`}></span>
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 sm:gap-10">
            {[
              {
                icon: <BarChart className={`h-8 w-8 sm:h-10 sm:w-10 ${darkMode ? 'text-green-500' : 'text-green-700'}`} />,
                title: "Data-Driven",
                description: "Leverage analytics for informed decision-making."
              },
              {
                icon: <Shield className={`h-8 w-8 sm:h-10 sm:w-10 ${darkMode ? 'text-green-500' : 'text-green-700'}`} />,
                title: "Secure",
                description: "Top-tier security for your institutional data."
              },
              {
                icon: <Clock className={`h-8 w-8 sm:h-10 sm:w-10 ${darkMode ? 'text-green-500' : 'text-green-700'}`} />,
                title: "Time-Saving",
                description: "Automate tasks to boost productivity."
              },
              {
                icon: <Globe className={`h-8 w-8 sm:h-10 sm:w-10 ${darkMode ? 'text-green-500' : 'text-green-700'}`} />,
                title: "Scalable",
                description: "Adapts to your institution's growth."
              }
            ].map((feature, index) => (
              <div key={index} className="text-center group">
                <div className={`relative h-12 w-12 sm:h-16 sm:w-16 rounded-2xl shadow-md flex items-center justify-center mx-auto mb-4 sm:mb-6 transition-all duration-500 group-hover:rotate-12 group-hover:scale-110 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                  {feature.icon}
                  <div className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${darkMode ? 'from-green-500/20 to-transparent' : 'from-green-600/20 to-transparent'} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
                </div>
                <h3 className={`text-base sm:text-xl font-semibold mb-2 sm:mb-3 transition-all duration-300 group-hover:translate-y-1 ${darkMode ? 'text-gray-100 group-hover:text-green-500' : 'text-gray-900 group-hover:text-green-700'}`}>
                  {feature.title}
                </h3>
                <p className={`text-sm sm:text-base transition-all duration-300 group-hover:text-opacity-80 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>


{/* Pricing Section */}
<PricingSection darkMode={darkMode} />


      {/* CTA Section */}
      <section className={`py-16 sm:py-24 relative overflow-hidden ${darkMode ? 'bg-gradient-to-r from-green-900 to-blue-900' : 'bg-gradient-to-r from-green-700 to-blue-700'}`}>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent transition-opacity duration-1000 opacity-50 hover:opacity-75"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className={`text-3xl sm:text-5xl font-extrabold text-white mb-4 sm:mb-6 tracking-tight transition-all duration-500 transform hover:scale-105 ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>
            Ready to Transform Education?
          </h2>
          <p className="text-base sm:text-xl text-white mb-6 sm:mb-10 max-w-3xl mx-auto leading-relaxed transition-all duration-300 hover:text-opacity-80">
            Join hundreds of institutions thriving with Adhyayan360's unified solutions.
          </p>
          <button
            onClick={handleAccessClick}
            className={`relative bg-white px-6 sm:px-10 py-3 sm:py-4 rounded-full text-sm sm:text-lg font-semibold transition-all duration-500 transform hover:scale-105 hover:shadow-xl inline-flex items-center gap-2 sm:gap-3 overflow-hidden ${darkMode ? 'text-green-600 hover:bg-gray-200' : 'text-green-700 hover:bg-gray-100'}`}
          >
            <span className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-blue-500/20 opacity-0 hover:opacity-100 transition-opacity duration-300 transform -skew-x-12 cursor-pointer"></span>
            Schedule a Demo <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 transition-transform duration-500 hover:translate-x-2 hover:rotate-12" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className={`py-10 sm:py-12 ${darkMode ? 'bg-gradient-to-t from-gray-900 to-gray-800' : 'bg-gradient-to-t from-gray-100 to-gray-200'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-10">
            <div>
              <h4 className={`text-xl sm:text-2xl font-bold mb-3 sm:mb-4 transition-all duration-300 transform hover:translate-x-1 ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>Let's Keep in Touch!</h4>
              <p className={`text-sm sm:text-base mb-4 sm:mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Find us on these platforms; we respond within 1-2 business days.</p>
              <div className="flex gap-3 sm:gap-4">
                {[Twitter, Facebook, Github].map((Icon, idx) => (
                  <a key={idx} href="#" className={`h-8 w-8 sm:h-10 sm:w-10 flex items-center justify-center rounded-full shadow-md transition-all duration-500 hover:scale-125 hover:rotate-12 ${darkMode ? 'bg-gray-800 text-gray-400 hover:text-green-500' : 'bg-white text-gray-600 hover:text-green-700'}`}>
                    <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
                  </a>
                ))}
              </div>
            </div>
            <div>
              <span className={`block uppercase font-bold text-xs sm:text-sm mb-3 sm:mb-4 ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>Useful Links</span>
              <ul className="space-y-2 sm:space-y-3">
                {["About Us", "Blog", "Github"].map((item) => (
                  <li key={item}>
                    <a href="#" className={`text-sm sm:text-base transition-all duration-300 transform hover:translate-x-2 ${darkMode ? 'text-gray-400 hover:text-green-500' : 'text-gray-600 hover:text-green-700'}`}>{item}</a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <span className={`block uppercase font-bold text-xs sm:text-sm mb-3 sm:mb-4 ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>Other Resources</span>
              <ul className="space-y-2 sm:space-y-3">
                {["Terms & Conditions", "Privacy Policy", "Contact Us"].map((item) => (
                  <li key={item}>
                    <a href="#" className={`text-sm sm:text-base transition-all duration-300 transform hover:translate-x-2 ${darkMode ? 'text-gray-400 hover:text-green-500' : 'text-gray-600 hover:text-green-700'}`}>{item}</a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <hr className={`my-6 sm:my-8 ${darkMode ? 'border-gray-700' : 'border-gray-300'}`} />
          <div className={`text-center text-sm sm:text-base ${darkMode ? 'text-gray-500' : 'text-gray-500'}`}>
            <p>All rights reserved © 2025 <a href="https://www.bittwobyte.com/" className={`transition-all duration-300 transform hover:scale-110 ${darkMode ? 'text-green-500 hover:text-green-400' : 'text-green-700 hover:text-green-800'}`}>BitTwoByte Technology</a></p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default LandingPage;