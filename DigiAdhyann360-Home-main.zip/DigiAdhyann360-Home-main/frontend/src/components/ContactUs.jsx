import React, { useState } from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { motion } from "framer-motion";
import {
  FaEnvelope,
  FaPhone,
  FaUser,
  FaBuilding,
  FaPaperPlane,
  FaSpinner,
  FaBriefcase,
  FaRocket,
  FaLaptop,
  FaUsers,
} from "react-icons/fa";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    lastName: "",
    email: "",
    phone: "",
    school: "",
    inquiry: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setFormData({
        name: "",
        lastName: "",
        email: "",
        phone: "",
        school: "",
        inquiry: "",
      });
      alert("Your message has been sent successfully!");
    }, 2000);
  };

  const scrollingIcons = [
    <FaBriefcase />,
    <FaRocket />,
    <FaLaptop />,
    <FaUsers />,
    <FaBriefcase />,
    <FaRocket />,
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#012353]/10 via-[#27ae60]/10 to-[#012353]/10 flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Elements */}
      <motion.div
        className="absolute top-20 left-20 text-[#27ae60] text-7xl opacity-10"
        animate={{ y: [0, -15, 0], rotate: [0, 10, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
      >
        <FaBriefcase />
      </motion.div>
      <motion.div
        className="absolute bottom-24 right-24 text-[#012353] text-6xl opacity-10"
        animate={{ y: [0, 15, 0], rotate: [0, -10, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      >
        <FaRocket />
      </motion.div>

      {/* Main Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative flex flex-col lg:flex-row max-w-4xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden z-10"
      >
        {/* Left Panel - Unique Side Info with Scrolling Icons */}
        <div className="lg:w-1/3 bg-gradient-to-b from-[#012353] to-[#27ae60] p-8 text-white flex flex-col justify-between relative overflow-hidden">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-2xl font-bold mb-2 relative z-10">Launch Your Career</h3>
            <p className="text-sm opacity-80 relative z-10">
              Connect with us to explore job opportunities or hire top talent!
            </p>
          </motion.div>

          {/* Scrolling Icons Container */}
          <div className="absolute inset-0 pointer-events-none">
            <motion.div
              className="flex flex-col items-center gap-8 text-white text-2xl opacity-30"
              animate={{
                y: [-100, 100],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "linear",
                repeatType: "loop",
              }}
            >
              {scrollingIcons.map((icon, index) => (
                <div key={index}>{icon}</div>
              ))}
            </motion.div>
          </div>

          <motion.div
            className="mt-6 relative z-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <p className="text-xs opacity-70">Email: support@jobportal.com</p>
            <p className="text-xs opacity-70">Phone: +1 800 123 4567</p>
          </motion.div>
        </div>

        {/* Right Panel - Form */}
        <div className="lg:w-2/3 p-8 relative">
          <motion.div
            className="absolute -top-12 right-6 bg-[#27ae60] p-4 rounded-full shadow-lg"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.6, ease: "backOut", delay: 0.2 }}
          >
            <FaPaperPlane className="text-white text-2xl" />
          </motion.div>

          <h2 className="text-3xl font-extrabold text-[#012353] text-center mb-6">
            Contact Us
          </h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="relative">
                <FaUser className="absolute top-1/2 -translate-y-1/2 left-4 text-[#27ae60]" />
                <motion.input
                  whileFocus={{ scale: 1.02, borderColor: "#27ae60" }}
                  type="text"
                  name="name"
                  placeholder="First Name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full pl-12 p-3 border border-[#27ae60]/30 rounded-lg focus:ring-2 focus:ring-[#27ae60] focus:border-transparent outline-none transition-all"
                  required
                />
              </div>
              <div className="relative">
                <FaUser className="absolute top-1/2 -translate-y-1/2 left-4 text-[#27ae60]" />
                <motion.input
                  whileFocus={{ scale: 1.02, borderColor: "#27ae60" }}
                  type="text"
                  name="lastName"
                  placeholder="Last Name"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="w-full pl-12 p-3 border border-[#27ae60]/30 rounded-lg focus:ring-2 focus:ring-[#27ae60] focus:border-transparent outline-none transition-all"
                  required
                />
              </div>
            </div>

            <div className="relative">
              <FaEnvelope className="absolute top-1/2 -translate-y-1/2 left-4 text-[#27ae60]" />
              <motion.input
                whileFocus={{ scale: 1.02, borderColor: "#27ae60" }}
                type="email"
                name="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleChange}
                className="w-full pl-12 p-3 border border-[#27ae60]/30 rounded-lg focus:ring-2 focus:ring-[#27ae60] focus:border-transparent outline-none transition-all"
                required
              />
            </div>

            <div className="relative">
              <FaPhone className="absolute top-1/2 -translate-y-1/2 left-4 text-[#27ae60]" />
              <PhoneInput
                country={"in"} // Changed from "us" to "in" for India
                value={formData.phone}
                onChange={(phone) => setFormData({ ...formData, phone })}
                containerClass="w-full"
                inputClass="w-full pl-12 p-3 border border-[#27ae60]/30 rounded-lg focus:ring-2 focus:ring-[#27ae60] focus:border-transparent outline-none transition-all"
              />
            </div>

            <div className="relative">
              <FaBuilding className="absolute top-1/2 -translate-y-1/2 left-4 text-[#27ae60]" />
              <motion.input
                whileFocus={{ scale: 1.02, borderColor: "#27ae60" }}
                type="text"
                name="school"
                placeholder="School (Optional)"
                value={formData.school}
                onChange={handleChange}
                className="w-full pl-12 p-3 border border-[#27ae60]/30 rounded-lg focus:ring-2 focus:ring-[#27ae60] focus:border-transparent outline-none transition-all"
              />
            </div>

            <motion.textarea
              whileFocus={{ scale: 1.02, borderColor: "#27ae60" }}
              name="inquiry"
              placeholder="Tell us about your job needs..."
              value={formData.inquiry}
              onChange={handleChange}
              className="w-full p-3 border border-[#27ae60]/30 rounded-lg focus:ring-2 focus:ring-[#27ae60] focus:border-transparent outline-none h-28 resize-none transition-all"
              required
            />

            <motion.button
              whileHover={{ scale: 1.05, boxShadow: "0 8px 20px rgba(39, 174, 96, 0.4)" }}
              whileTap={{ scale: 0.95 }}
              type="submit"
              disabled={isSubmitting}
              className="w-3/4 mx-auto bg-gradient-to-r from-[#012353] to-[#27ae60] text-white font-semibold py-2 rounded-lg flex items-center justify-center gap-2 disabled:opacity-50 transition-all cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <FaSpinner className="animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <FaPaperPlane />
                  Send Message
                </>
              )}
            </motion.button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default Contact;