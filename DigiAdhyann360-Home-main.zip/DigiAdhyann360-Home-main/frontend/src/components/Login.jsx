import React, { useState, useEffect } from 'react';
import { signInWithGoogle } from './auth'; 
import GoogleIcon from '../assets/Google Icon.png.png';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Axios from 'axios';

// / Mentorship Showcase Component
const MentorshipShowcase = () => {
  const [activeSlide, setActiveSlide] = useState(0);
 
  const slides = [
    {
      image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80",
      title: "Adhyayan360 Job Portal",
      subtitle: "Connecting Talent with Opportunity..."
    },
    {
      image: "https://plus.unsplash.com/premium_vector-1682310651540-1b314bb8e965?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8am9iJTIwcG9ydGFsfGVufDB8fDB8fHww",
      title: "Find Your Dream Job",
      subtitle: "Connecting Employers with Talent"
    },
    {
      image: "https://plus.unsplash.com/premium_photo-1677093906033-dc2beb53ace3?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8am9iJTIwcG9ydGFsfGVufDB8fDB8fHww",
      title: "Innovative Solutions",
      subtitle: "Opportunities for the Right Candidates"
    }
  ];

 
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

 
  return (
    <div className="relative h-full w-full bg-[#fbf7fc] p-8 flex flex-col items-center">
      <div className="relative h-99 w-full overflow-hidden rounded-xl">
        <div className="flex transition-transform duration-500 h-full" style={{ transform: `translateX(-${activeSlide * 100}%)` }}>
          {slides.map((slide, index) => (
            <div key={index} className="min-w-full h-full relative">
              <img src={slide.image} alt={slide.title} className="w-full h-full object-cover rounded-xl" />
              <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent text-white rounded-b-xl">
                <h2 className="text-xl font-bold mb-0.5">{slide.title}</h2>
                <p className="text-sm">{slide.subtitle}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="flex justify-center mt-3 gap-2 ">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-all ${activeSlide === index ? 'bg-black scale-110' : 'bg-black/50'}`}
            onClick={() => setActiveSlide(index)}
          />
        ))}
      </div>
    </div>
  );
};

// Login Form Component
const LoginForm = () => {
  const [isCandidate, setIsCandidate] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false); // Loader state

  const handleGoogleLogin = async () => {
    try {
        setLoading(true);  // Show loader
        const userData = await signInWithGoogle();  // Assume this returns the Google token
        console.log("User logged in: ", userData);

        const response = await Axios.post("http://localhost:5000/auth/google-login", { tokenId: userData.tokenId });
        if (response.status === 200) {
            toast.success("Logged in with Google!");
            localStorage.setItem("token", response.data.token); // Store token
        } else {
            toast.error("Google login failed");
        }
    } catch (error) {
        toast.error("Google login failed");
    } finally {
        setLoading(false); // Hide loader after request
    }
};

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Please provide valid credentials");
      return;
    }

    setLoading(true); // Show loader
    try {
      const response = await Axios.post("http://localhost:5000/auth/login", { email, password });
      const data = response.data;

      if (response.status === 200) {
        toast.success("Login successful!");
        localStorage.setItem("token", data.token); // Store token
      } else {
        toast.error(data.error);
      }
    } catch (error) {
      toast.error("Login failed! Please try again.");
    } finally {
      setLoading(false);
    }
};


  return (
    <div className="w-full max-w-md space-y-6 p-6">
      <h1 className="text-3xl font-bold text-gray-900 text-center">Log in</h1>
      <div className="flex rounded-lg bg-blue-50 p-1 w-full max-w-xs mx-auto">
        <button
          className={`flex-1 rounded-xl px-4 py-2 text-sm font-medium transition-colors
            ${isCandidate ? 'bg-[#0F2B48] text-white' : 'text-gray-600 cursor-pointer'}`}
          onClick={() => setIsCandidate(true)}
        >
          As Candidate
        </button>
        <button
          className={`flex-1 rounded-xl px-4 py-2 text-sm font-medium transition-colors
            ${!isCandidate ? 'bg-[#0F2B48] text-white' : 'text-gray-600 cursor-pointer'}`}
          onClick={() => setIsCandidate(false)}
        >
          As Recruiter
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <button 
          onClick={handleGoogleLogin}
          className="h-12 w-full flex items-center justify-center gap-3 px-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition"
          disabled={loading} // Disable when loading
        >
          <img src={GoogleIcon} alt="Google" className="h-6 w-6" />
          Continue with Google
        </button>

        <div className="relative flex items-center justify-center">
          <span className="w-full border-t" />
          <span className="absolute bg-white px-2 text-xs text-gray-500">Or Login with Email</span>
        </div>

        <input
          type="email"
          placeholder="Email Id"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="h-12 w-full px-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        
        <div className="relative">
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Enter Your Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="h-12 w-full px-4 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="button"
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-500 hover:text-gray-700"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? "👁️" : "👁️‍🗨️"}
          </button>
        </div>

        <div className="flex justify-between text-sm">
          <a href="#" className="text-blue-600 hover:underline">Login via OTP</a>
          <a href="#" className="text-blue-600 hover:underline">Forgot Password?</a>
        </div>

        <button 
          type="submit"
          disabled={loading} // Disable button when loading
          className={`h-12 w-full flex items-center justify-center bg-[#0F2B48] text-white rounded-lg 
            hover:bg-[#1A4A6B] transition ${loading ? "opacity-50 cursor-not-allowed" : ""}`}
        >
          {loading ? (
            <svg
              className="w-5 h-5 mr-2 animate-spin text-white"
              fill="none"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              ></circle>
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 0116 0h-4a4 4 0 00-8 0H4z"
              ></path>
            </svg>
          ) : (
            "Login"
          )}
        </button>
      </form>
    </div>
  );
};

const LoginPage = () => {
  return (
    <div className="flex min-h-screen bg-gray-100 justify-center items-center">
      <div className="w-full max-w-4xl bg-white p-6 rounded-lg shadow-lg flex flex-col lg:flex-row">
        <div className="w-full lg:w-1/2 bg-[#fdf7f7] rounded-lg shadow-md p-4 flex flex-col">
          <MentorshipShowcase />
        </div>
        <div className="w-full lg:w-1/2 bg-[#fdf7f7] rounded-lg shadow-md p-4 flex flex-col">
          <LoginForm />
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
