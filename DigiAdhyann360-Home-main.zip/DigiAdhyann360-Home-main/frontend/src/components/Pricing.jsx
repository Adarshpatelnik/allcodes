import React from 'react';
import { motion } from 'framer-motion';
import { Check, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const pricingPlans = [
  {
    name: 'Basic Plan',
    features: [
      'Essential school management tools',
      'Student information system',
      'Basic attendance tracking',
      'Email support during business hours'
    ],
    color: 'blue'
  },
  {
    name: 'Standard Plan',
    features: [
      'All Basic features plus',
      'Advanced reporting dashboard',
      'Exam management system',
      'Priority email support',
      'Teacher performance analytics'
    ],
    color: 'green'
  },
  {
    name: 'Premium Plan',
    features: [
      'All Standard features plus',
      'Customizable modules',
      '24/7 dedicated support',
      'Advanced analytics suite',
      'API integrations',
      'Personalized onboarding'
    ],
    color: 'violet'
  },
];

const PricingSection = ({ darkMode }) => {
  const navigate = useNavigate();

  const handleContactClick = () => {
    navigate('/contact');
  };

  return (
    <section id="pricing" className={`py-16 sm:py-24 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-10 sm:mb-16"
        >
          <h2 className={`text-3xl sm:text-5xl font-extrabold tracking-tight relative ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>
            Our Flexible Plans
            <span className={`absolute -bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-24 rounded-full bg-gradient-to-r ${darkMode ? 'from-green-500 to-blue-500' : 'from-green-600 to-blue-600'} transition-all duration-500 hover:w-32`}></span>
          </h2>
          <p className={`mt-4 text-base sm:text-xl ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Custom solutions tailored to your institution's needs
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-10">
          {pricingPlans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className={`relative rounded-2xl p-6 sm:p-8 shadow-lg transition-all duration-500 transform ${
                darkMode 
                  ? `bg-gradient-to-br from-${plan.color}-900/30 to-gray-800 border-${plan.color}-900/40` 
                  : `bg-gradient-to-br from-${plan.color}-50 to-white border-${plan.color}-100`
              } border`}
            >
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${
                darkMode 
                  ? `from-${plan.color}-700/20 to-transparent` 
                  : `from-${plan.color}-200/20 to-transparent`
              } opacity-0 hover:opacity-100 transition-opacity duration-300 z-0`}></div>
              
              <div className="relative z-10">
                <h3 className={`text-2xl font-extrabold tracking-tight ${darkMode ? 'text-gray-100' : 'text-gray-900'}`}>
                  {plan.name}
                </h3>
                
                <ul className="space-y-3 sm:space-y-4 my-6">
                  {plan.features.map((feature) => (
                    <li key={feature} className={`flex items-start text-sm sm:text-base ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      <Check className={`flex-shrink-0 h-4 w-4 sm:h-5 sm:w-5 mr-2 sm:mr-3 mt-1 ${
                        plan.color === 'blue' ? (darkMode ? 'text-blue-400' : 'text-blue-600') :
                        plan.color === 'green' ? (darkMode ? 'text-green-400' : 'text-green-600') :
                        (darkMode ? 'text-violet-400' : 'text-violet-600')
                      }`} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button
                  onClick={handleContactClick}
                  className={`relative w-full bg-gradient-to-r text-white py-2 sm:py-3 px-4 sm:px-6 rounded-xl font-semibold text-sm sm:text-base cursor-pointer z-10 ${
                    plan.color === 'blue' ? 'from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800' :
                    plan.color === 'green' ? 'from-green-600 to-green-700 hover:from-green-700 hover:to-green-800' :
                    'from-violet-600 to-violet-700 hover:from-violet-700 hover:to-violet-800'
                  }`}
                >
                  <span className="flex items-center justify-center gap-2 sm:gap-3">
                    Contact Us <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
                  </span>
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <div className={`mt-16 text-center ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
          <p className="text-lg">Need a custom solution? We'll create a plan specifically for your institution.</p>
          <button onClick={handleContactClick} className={`mt-6 px-8 py-3 rounded-xl font-semibold cursor-pointer ${
            darkMode ? 'bg-green-700 hover:bg-green-600' : 'bg-green-600 hover:bg-green-700'
          } text-white transition-colors duration-300`}>
            Request Custom Quote
          </button>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;